/**
 * NextDayFlyers Price Parser
 * 
 * Takes Claude-extracted pricing and outputs Excel
 * 
 * Usage: node parse-prices.js
 * Then paste Claude's output when prompted
 */

const XLSX = require('xlsx');
const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function parseClaudeOutput(text) {
  // Look for structured data patterns
  const products = [];
  
  // Try to find JSON first
  try {
    const jsonMatch = text.match(/\{[\s\S]*?\}/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }
  } catch (e) {}
  
  // Parse tabular format
  const lines = text.split('\n');
  let currentProduct = null;
  let currentData = [];
  
  for (const line of lines) {
    // Detect product name
    const productMatch = line.match(/^\*\*([^*]+)\*\*/) || line.match(/^([A-Za-z]+):/);
    if (productMatch && !line.includes('|')) {
      if (currentProduct && currentData.length) {
        products.push({ name: currentProduct, data: currentData });
      }
      currentProduct = productMatch[1].trim();
      currentData = [];
      continue;
    }
    
    // Parse price lines like: 4x6 | 100 | $45.99 | $62.99 | $89.99
    const priceMatch = line.match(/([\d.]+x[\d.]+)\s*\|\s*(\d+)\s*\|\s*\$?([\d.]+)\s*\|\s*\$?([\d.]+)\s*\|\s*\$?([\d.]+)/);
    if (priceMatch) {
      currentData.push({
        size: priceMatch[1],
        quantity: parseInt(priceMatch[2]),
        price3bd: parseFloat(priceMatch[3]),
        priceNext: parseFloat(priceMatch[4]),
        priceSame: parseFloat(priceMatch[5])
      });
    }
    
    // Parse simpler format: 4x6, 100, 45.99, 62.99, 89.99
    const simpleMatch = line.match(/([\d.]+x[\d.]+)\s*,\s*(\d+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)/);
    if (simpleMatch) {
      currentData.push({
        size: simpleMatch[1],
        quantity: parseInt(simpleMatch[2]),
        price3bd: parseFloat(simpleMatch[3]),
        priceNext: parseFloat(simpleMatch[4]),
        priceSame: parseFloat(simpleMatch[5])
      });
    }
  }
  
  if (currentProduct && currentData.length) {
    products.push({ name: currentProduct, data: currentData });
  }
  
  return products;
}

function saveToExcel(products) {
  const workbook = XLSX.utils.book_new();
  
  for (const product of products) {
    const sheetName = product.name.substring(0, 31).replace(/[\/\\?*\[\]]/g, '_');
    const ws = XLSX.utils.aoa_to_sheet([
      ['Size', 'Quantity', '3 Business Days', 'Next Day', 'Same Day']
    ]);
    
    for (const item of product.data || []) {
      const row = [
        item.size,
        item.quantity,
        item.price3bd || 0,
        item.priceNext || 0,
        item.priceSame || 0
      ];
      XLSX.utils.sheet_add_row(ws, row);
    }
    
    XLSX.utils.book_append_sheet(workbook, ws, sheetName);
  }
  
  const filename = 'nextdayflyers-pricing.xlsx';
  XLSX.writeFile(workbook, filename);
  console.log(`\n💾 Saved to ${filename}`);
  console.log('✅ Done!');
}

async function main() {
  console.log('📊 NextDayFlyers Price Parser');
  console.log('============================\n');
  console.log('Paste Claude\'s extracted pricing data below,');
  console.log('then press Ctrl+D (or Enter twice on Windows) to finish:\n');
  
  let input = '';
  
  rl.input.on('keypress', (ch, key) => {
    if (key && key.ctrl && key.name === 'd') {
      rl.close();
    }
  });
  
  rl.on('close', () => {
    const products = parseClaudeOutput(input);
    
    if (products.length === 0) {
      console.log('\n⚠️  No pricing data found. Make sure to paste Claude\'s output.');
      console.log('\nExample format:');
      console.log('Postcards');
      console.log('4x6 | 100 | $45.99 | $62.99 | $89.99');
      console.log('4x6 | 250 | $62.99 | $85.99 | $125.99');
      process.exit(1);
    }
    
    console.log(`\n📦 Found ${products.length} product(s): ${products.map(p => p.name).join(', ')}`);
    saveToExcel(products);
  });
  
  // Collect input
  rl.setPrompt('');
  rl.prompt();
  
  for await (const line of rl) {
    input += line + '\n';
    rl.setPrompt('');
    rl.prompt();
  }
}

main().catch(console.error);
