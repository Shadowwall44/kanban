#!/usr/bin/env node
/**
 * NDF Comprehensive Price Scraper
 * Scrapes ALL product pricing from NextDayFlyers.com via their calculator API
 * Outputs clean Excel (.xlsx) and CSV files
 */

import https from 'https';
import fs from 'fs';
import XLSX from 'xlsx';

const API_URL = 'https://calculator.digitalroom.com/v1/computePrice';
const API_AUTH = Buffer.from('calculator.site:KEfm75#XjwSMux92zUWD9T8AafG!vwV6').toString('base64');

// ==================== PRODUCT DEFINITIONS ====================

const PRODUCTS = {
  business_cards: {
    name: 'Standard Business Cards',
    category: 'Business Cards',
    product_id: '461',
    defaults: {
      attr3: '22652', attr5: '22665', attr332: '32377', attr333: '22770',
      attr336: '22655', attr337: '22656', attr338: '22659', attr339: '22660',
      attr340: '22664', attr341: '32376', attr356: '27446'
    },
    sizes: [
      {id: '36770', name: '1.75 x 3.5 Slim'}, {id: '22652', name: '2 x 3.5 Standard'},
      {id: '86212', name: '2.5 x 2.5'}, {id: '86213', name: '3 x 3'},
    ],
    papers: [
      {id: '22659', name: '14 pt. Cardstock'}, {id: '69261', name: '16 pt. Cardstock'},
      {id: '86214', name: '17 pt. Cardstock'},
    ],
    quantities: [
      {id: '22665', name: '100'}, {id: '22666', name: '250'},
      {id: '22667', name: '500'}, {id: '22668', name: '1,000'},
      {id: '22809', name: '2,500'}, {id: '22672', name: '5,000'},
      {id: '22677', name: '10,000'},
    ],
    turnarounds: [
      {id: '22769', name: '3 Business Days'}, {id: '22770', name: 'Next Business Day'},
      {id: '22771', name: 'Ready Today'},
    ],
  },
  postcards: {
    name: 'Standard Postcards',
    category: 'Postcards',
    product_id: '459',
    defaults: {
      attr3: '22396', attr5: '22413', attr333: '22519',
      attr336: '22402', attr337: '22403', attr338: '22406',
      attr339: '22408', attr340: '22412', attr356: '27443'
    },
    sizes: [
      {id: '22396', name: '4 x 6'}, {id: '108285', name: '4 x 9'},
      {id: '108283', name: '4.25 x 6'}, {id: '22397', name: '5 x 7'},
      {id: '22398', name: '5.5 x 8.5'}, {id: '22399', name: '6 x 9'},
      {id: '22400', name: '6 x 11'}, {id: '22401', name: '8.5 x 11'},
    ],
    papers: [
      {id: '22406', name: '14 pt. Cardstock'}, {id: '69259', name: '16 pt. Cardstock'},
      {id: '108287', name: '17 pt. Cardstock'},
    ],
    quantities: [
      {id: '22413', name: '100'}, {id: '22414', name: '250'},
      {id: '22415', name: '500'}, {id: '22416', name: '1,000'},
      {id: '22418', name: '2,500'}, {id: '22421', name: '5,000'},
      {id: '22426', name: '10,000'},
    ],
    turnarounds: [
      {id: '22518', name: '3 Business Days'}, {id: '22519', name: 'Next Business Day'},
      {id: '22520', name: 'Ready Today'},
    ],
  },
  flyers: {
    name: 'Custom Flyers',
    category: 'Flyers',
    product_id: '475',
    defaults: {
      attr3: '24079', attr5: '116338', attr331: '24103', attr333: '24217',
      attr336: '24094', attr337: '24095', attr338: '24102', attr339: '24106',
      attr340: '24110', attr356: '27234'
    },
    sizes: [
      {id: '116333', name: '4 x 6 Flat'}, {id: '24086', name: '4.25 x 5.5'},
      {id: '24090', name: '5.5 x 8.5'}, {id: '24092', name: '8.5 x 11'},
      {id: '116337', name: '8.5 x 14'}, {id: '86531', name: '11 x 17'},
    ],
    papers: [
      {id: '24100', name: '70 lb. Paper'}, {id: '24101', name: '80 lb. Paper'},
      {id: '24099', name: '100 lb. Paper'}, {id: '24098', name: '14 pt. Cardstock'},
    ],
    quantities: [
      {id: '24111', name: '100'}, {id: '24112', name: '250'},
      {id: '24113', name: '500'}, {id: '24114', name: '1,000'},
      {id: '24116', name: '2,500'}, {id: '24119', name: '5,000'},
      {id: '24124', name: '10,000'},
    ],
    turnarounds: [
      {id: '24216', name: '3 Business Days'}, {id: '24217', name: 'Next Business Day'},
      {id: '24218', name: 'Ready Today'},
    ],
  },
  trifold: {
    name: 'Tri-Fold Brochure',
    category: 'Brochures',
    product_id: '460',
    defaults: {
      attr3: '22522', attr5: '22536', attr331: '22532', attr333: '22642',
      attr336: '22526', attr337: '22527', attr338: '22528', attr339: '80614',
      attr340: '22535', attr341: '22646', attr364: '27835'
    },
    sizes: [
      {id: '22522', name: '8.5 x 11'}, {id: '22523', name: '8.5 x 14'},
      {id: '22524', name: '11 x 17'}, {id: '22525', name: '11 x 25.5'},
    ],
    papers: [
      {id: '22529', name: '70 lb. Paper'}, {id: '22530', name: '80 lb. Paper'},
      {id: '22528', name: '100 lb. Paper'},
    ],
    quantities: [
      {id: '22536', name: '100'}, {id: '22537', name: '250'},
      {id: '22538', name: '500'}, {id: '22539', name: '1,000'},
      {id: '22541', name: '2,500'}, {id: '22544', name: '5,000'},
    ],
    turnarounds: [
      {id: '22641', name: '3 Business Days'}, {id: '22642', name: 'Next Business Day'},
      {id: '22643', name: 'Ready Today'},
    ],
  },
  bifold: {
    name: 'Bi-Fold Brochure',
    category: 'Brochures',
    product_id: '460',
    defaults: {
      attr3: '22522', attr5: '22536', attr331: '22532', attr333: '22642',
      attr336: '22526', attr337: '22527', attr338: '22528', attr339: '80614',
      attr340: '22535', attr341: '22644', attr364: '27835'
    },
    sizes: [
      {id: '22522', name: '8.5 x 11'}, {id: '22523', name: '8.5 x 14'},
      {id: '22524', name: '11 x 17'}, {id: '22525', name: '11 x 25.5'},
    ],
    papers: [
      {id: '22529', name: '70 lb. Paper'}, {id: '22530', name: '80 lb. Paper'},
      {id: '22528', name: '100 lb. Paper'},
    ],
    quantities: [
      {id: '22536', name: '100'}, {id: '22537', name: '250'},
      {id: '22538', name: '500'}, {id: '22539', name: '1,000'},
      {id: '22541', name: '2,500'}, {id: '22544', name: '5,000'},
    ],
    turnarounds: [
      {id: '22641', name: '3 Business Days'}, {id: '22642', name: 'Next Business Day'},
      {id: '22643', name: 'Ready Today'},
    ],
  },
  banners: {
    name: 'Vinyl Banners',
    category: 'Large Format',
    product_id: '484',
    defaults: {
      attr3: '25166', attr5: '25175', attr310: '0', attr333: '25196',
      attr336: '25172', attr337: '25173', attr338: '25174',
      attr347: '25199', attr348: '35581'
    },
    sizes: [
      {id: '100659', name: '24 x 36'}, {id: '25166', name: '48 x 24'},
      {id: '25167', name: '72 x 36'}, {id: '25168', name: '96 x 36'},
      {id: '25169', name: '96 x 48'}, {id: '25170', name: '120 x 36'},
      {id: '25171', name: '120 x 60'},
    ],
    papers: [
      {id: '100660', name: 'Mesh 9 oz. Vinyl'}, {id: '25174', name: '13 oz. Standard Vinyl'},
      {id: '100661', name: '18 oz. Heavy Duty Vinyl'},
    ],
    quantities: [
      {id: '25175', name: '1'}, {id: '25176', name: '2'},
      {id: '25178', name: '4'}, {id: '25179', name: '5'}, {id: '25184', name: '10'},
    ],
    turnarounds: [
      {id: '25195', name: '3 Business Days'}, {id: '25196', name: 'Next Business Day'},
      {id: '67445', name: 'Ready Today'},
    ],
  },
  posters: {
    name: 'Bulk Posters',
    category: 'Large Format',
    product_id: '478',
    defaults: {
      attr3: '24469', attr5: '24522', attr331: '24499', attr333: '24628',
      attr336: '24486', attr337: '24488', attr338: '24491', attr339: '24495',
      attr340: '24501', attr356: '27527'
    },
    sizes: [
      {id: '91350', name: '8.5 x 11'}, {id: '24468', name: '11 x 17'},
      {id: '24469', name: '12 x 18'}, {id: '24470', name: '13 x 19'},
      {id: '24471', name: '18 x 24'}, {id: '24473', name: '24 x 36'},
    ],
    papers: [
      {id: '24492', name: '80 lb. Paper'}, {id: '24491', name: '100 lb. Paper'},
      {id: '24490', name: '14 pt. Cardstock'},
    ],
    quantities: [
      {id: '24522', name: '100'}, {id: '24523', name: '250'},
      {id: '24524', name: '500'}, {id: '24525', name: '1,000'},
      {id: '24527', name: '2,500'}, {id: '24530', name: '5,000'},
    ],
    turnarounds: [
      {id: '24627', name: '3 Business Days'}, {id: '24628', name: 'Next Business Day'},
      {id: '24629', name: 'Ready Today'},
    ],
  },
  stickers: {
    name: 'Bulk Stickers',
    category: 'Specialty',
    product_id: '486',
    defaults: {
      attr3: '34297', attr5: '25056', attr333: '25159',
      attr336: '25046', attr337: '25047', attr338: '25048',
      attr339: '25049', attr340: '25052', attr384: '32133',
      attr636: '59670', attr4: '34792', attr10: '34668',
      attr17: '34780', attr25: '34772', attr27: '34787',
      attr315: '34785', attr859: '159772'
    },
    sizes: [
      {id: '34297', name: '2 x 2'}, {id: '34298', name: '2 x 3'},
      {id: '25026', name: '2 x 3.5'}, {id: '25027', name: '2 x 4'},
      {id: '25029', name: '2.75 x 4.25'}, {id: '25033', name: '3 x 5'},
    ],
    papers: [
      {id: '1777189', name: 'Gloss White Paper'}, {id: '1777191', name: 'Matte White Paper'},
      {id: '1777194', name: 'Gloss White Outdoor BOPP'},
    ],
    quantities: [
      {id: '25056', name: '1,000'}, {id: '25058', name: '2,500'},
      {id: '25061', name: '5,000'}, {id: '25066', name: '10,000'},
    ],
    turnarounds: [
      {id: '25158', name: '3 Business Days'}, {id: '25159', name: 'Next Business Day'},
    ],
  },
  doorhangers: {
    name: 'Door Hangers',
    category: 'Specialty',
    product_id: '481',
    defaults: {
      attr3: '24345', attr5: '24357', attr333: '24462',
      attr336: '24346', attr337: '24347', attr338: '24350',
      attr339: '24352', attr340: '24356', attr356: '27452'
    },
    sizes: [
      {id: '68039', name: '3.5 x 8.5'}, {id: '24345', name: '4.25 x 11'},
      {id: '100667', name: '4 x 11'}, {id: '68041', name: '5.25 x 8.5'},
    ],
    papers: [
      {id: '24351', name: '10 pt. Cardstock'}, {id: '24350', name: '14 pt. Cardstock'},
      {id: '69275', name: '16 pt. Cardstock'},
    ],
    quantities: [
      {id: '24357', name: '100'}, {id: '24358', name: '250'},
      {id: '24359', name: '500'}, {id: '24360', name: '1,000'},
      {id: '24362', name: '2,500'}, {id: '24365', name: '5,000'},
    ],
    turnarounds: [
      {id: '24462', name: '3 Business Days'}, {id: '24463', name: 'Next Business Day'},
      {id: '24464', name: 'Ready Today'},
    ],
  },
  rackcards: {
    name: 'Custom Rack Cards',
    category: 'Specialty',
    product_id: '467',
    defaults: {
      attr3: '22933', attr5: '22945', attr333: '23051', attr334: '158401',
      attr336: '22934', attr337: '22935', attr338: '22938',
      attr339: '69266', attr340: '22944', attr341: '86760', attr356: '27533'
    },
    sizes: [
      {id: '86756', name: '3.5 x 8.5'}, {id: '22933', name: '4 x 9'},
    ],
    papers: [
      {id: '22938', name: '14 pt. Cardstock'}, {id: '69265', name: '16 pt. Cardstock'},
      {id: '86759', name: '17 pt. Cardstock'},
    ],
    quantities: [
      {id: '22945', name: '100'}, {id: '22946', name: '250'},
      {id: '22947', name: '500'}, {id: '22948', name: '1,000'},
      {id: '22950', name: '2,500'}, {id: '22952', name: '4,000'},
    ],
    turnarounds: [
      {id: '23050', name: '3 Business Days'}, {id: '23051', name: 'Next Business Day'},
      {id: '23052', name: 'Ready Today'},
    ],
  },
  greetingcards: {
    name: 'Custom Greeting Cards',
    category: 'Specialty',
    product_id: '485',
    defaults: {
      attr3: '26166', attr5: '24918', attr333: '25024',
      attr336: '24904', attr337: '24905', attr338: '24908',
      attr339: '66445', attr340: '24914', attr341: '32127',
      attr345: '29996', attr356: '27458', attr359: '136191', attr364: '136193'
    },
    sizes: [
      {id: '82671', name: '4 x 6 Flat'}, {id: '82672', name: '5 x 7 Flat'},
      {id: '26166', name: '8 x 6 (Folds to 4 x 6)'}, {id: '26167', name: '10 x 7 (Folds to 5 x 7)'},
    ],
    papers: [
      {id: '24908', name: '14 pt. Cardstock'}, {id: '69279', name: '16 pt. Cardstock'},
    ],
    quantities: [
      {id: '24918', name: '100'}, {id: '24919', name: '250'},
      {id: '24920', name: '500'}, {id: '24921', name: '1,000'},
      {id: '24923', name: '2,500'}, {id: '24926', name: '5,000'},
    ],
    turnarounds: [
      {id: '25023', name: '3 Business Days'}, {id: '25024', name: 'Next Business Day'},
      {id: '25025', name: 'Ready Today'},
    ],
  },
  booklets: {
    name: 'Booklets',
    category: 'Specialty',
    product_id: '464',
    defaults: {
      attr3: '23805', attr5: '23842', attr8: '23819', attr331: '23815',
      attr333: '23817', attr336: '23808', attr337: '23809',
      attr338: '23813', attr339: '80616', attr345: '0',
      attr354: '67714', attr357: '28890', attr358: '28891',
      attr359: '136741', attr364: '0'
    },
    sizes: [
      {id: '23805', name: '5.5 x 8.5'}, {id: '23807', name: '8.5 x 11'},
    ],
    papers: [
      {id: '23811', name: '70 lb. Paper'}, {id: '23813', name: '80 lb. Paper'},
      {id: '23810', name: '100 lb. Paper'},
    ],
    quantities: [
      {id: '23842', name: '100'}, {id: '23843', name: '250'},
      {id: '23844', name: '500'}, {id: '23845', name: '1,000'},
      {id: '23847', name: '2,500'}, {id: '23849', name: '4,000'},
    ],
    turnarounds: [
      {id: '23817', name: '3 Business Days'}, {id: '23818', name: 'Next Business Day'},
    ],
  },
  letterhead: {
    name: 'Letterhead',
    category: 'Specialty',
    product_id: '465',
    defaults: {
      attr3: '23174', attr5: '23182', attr333: '23290',
      attr336: '23175', attr337: '23177', attr338: '23178',
      attr339: '80613', attr340: '23181', attr344: '23288'
    },
    sizes: [
      {id: '23174', name: '8.5 x 11'}, {id: '83206', name: '8.5 x 14'},
    ],
    papers: [
      {id: '23178', name: '70 lb. Paper'},
    ],
    quantities: [
      {id: '23182', name: '100'}, {id: '23183', name: '250'},
      {id: '23184', name: '500'}, {id: '23185', name: '1,000'},
      {id: '23187', name: '2,500'}, {id: '23190', name: '5,000'},
      {id: '23195', name: '10,000'},
    ],
    turnarounds: [
      {id: '23289', name: '3 Business Days'}, {id: '23290', name: 'Next Business Day'},
      {id: '65792', name: 'Ready Today'},
    ],
  },
  envelopes_10: {
    name: '#10 Envelopes',
    category: 'Specialty',
    product_id: '490',
    defaults: {
      attr1: '34363', attr4: '34370', attr5: '34371', attr11: '34367',
      attr333: '34403', attr3: '27118', attr336: '27124',
      attr337: '27125', attr338: '27126', attr339: '80617',
      attr392: '35050', attr394: '35052'
    },
    sizes: [
      {id: '27118', name: '#10 (4.125 x 9.5)'},
    ],
    papers: [
      {id: '27126', name: 'Default'},
    ],
    quantities: [
      {id: '34371', name: '250'}, {id: '34372', name: '500'},
      {id: '34373', name: '1,000'}, {id: '34375', name: '3,000'},
      {id: '34377', name: '5,000'}, {id: '34382', name: '10,000'},
    ],
    turnarounds: [
      {id: '34403', name: '3 Business Days'},
    ],
  },
  envelopes_9: {
    name: '#9 Envelopes',
    category: 'Specialty',
    product_id: '490',
    defaults: {
      attr3: '27117', attr5: '27128', attr333: '27233',
      attr336: '27124', attr337: '27125', attr338: '27126',
      attr339: '80617', attr392: '35050', attr394: '35052'
    },
    sizes: [
      {id: '27117', name: '#9 (3.875 x 8.875)'},
    ],
    papers: [
      {id: '27126', name: 'Default'},
    ],
    quantities: [
      {id: '27128', name: '250'}, {id: '27129', name: '500'},
      {id: '27130', name: '1,000'}, {id: '27132', name: '3,000'},
      {id: '27134', name: '5,000'}, {id: '27139', name: '10,000'},
    ],
    turnarounds: [
      {id: '27233', name: '3 Business Days'},
    ],
  },
};

// ==================== API FUNCTIONS ====================

let _callNum = 0;
function computePrice(productId, attrs) {
  const callId = ++_callNum;
  return new Promise((resolve, reject) => {
    const payload = {
      productType: 'offset',
      publishedVersion: true,
      product_id: productId,
      addon_attributes: ['333'],
      mailing_service: 'on',
    };
    // Spread attrs individually to avoid nested objects
    for (const [k, v] of Object.entries(attrs)) {
      payload[k] = v;
    }
    const body = JSON.stringify(payload);

    const url = new URL(API_URL);
    const options = {
      hostname: url.hostname,
      path: url.pathname,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Basic ${API_AUTH}`,
        'Origin': 'https://www.nextdayflyers.com',
        'Referer': 'https://www.nextdayflyers.com/',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Content-Length': Buffer.byteLength(body)
      }
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          reject(new Error(`Parse error: ${data.substring(0, 200)}`));
        }
      });
    });
    req.on('error', reject);
    req.setTimeout(15000, () => { req.destroy(); reject(new Error('Timeout')); });
    req.write(body);
    req.end();
  });
}

function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

// ==================== PRICE SCRAPING ====================

async function scrapeProduct(key, product) {
  console.log(`\n--- ${product.name} (pid=${product.product_id}) ---`);
  console.log(`  Combos: ${product.sizes.length} sizes × ${product.papers.length} papers × ${product.quantities.length} qtys × ${product.turnarounds.length} turnarounds`);
  
  const rows = [];
  let callCount = 0;
  let errorCount = 0;
  let skipCount = 0;

  for (const size of product.sizes) {
    for (const paper of product.papers) {
      for (const qty of product.quantities) {
        // Group turnaround prices for same size/paper/qty
        let standardPrice = null, standardUnit = null;
        let nextDayPrice = null, nextDayUnit = null;
        let sameDayPrice = null, sameDayUnit = null;
        let actualSize = size.name, actualPaper = paper.name, actualQty = qty.name;
        let coating = 'Default';
        let gotAnyPrice = false;

        for (const turnaround of product.turnarounds) {
          const attrs = { ...product.defaults };
          attrs.attr3 = size.id;
          attrs.attr338 = paper.id;
          attrs.attr5 = qty.id;
          attrs.attr333 = turnaround.id;

          try {
            if (callCount === 0) console.log(`  First call: pid=${product.product_id}, attr3=${attrs.attr3}, attr5=${attrs.attr5}`);
            const result = await computePrice(product.product_id, attrs);
            callCount++;
            if (callCount <= 3) console.log(`  Call ${callCount}: $${result.total_price}, qty=${result.qty}, ta=${result.turnaround}`);

            const price = parseFloat(result.total_price);
            const unitPrice = parseFloat(result.unit_price);
            const ta = result.turnaround;

            if (price > 1 && (result.qty > 0 || result.sheet_qty > 0)) {
              gotAnyPrice = true;
              
              if (result.display_specs) {
                for (const spec of result.display_specs) {
                  if (spec.attribute_name?.includes('Size') || spec.attribute_name === 'Page Size') actualSize = spec.attr_value;
                  if (['Paper Stock', 'Paper', 'Material', 'Inside Pages'].includes(spec.attribute_name)) actualPaper = spec.attr_value;
                  if (spec.attribute_name === 'Quantity') actualQty = spec.attr_value;
                  if (spec.attribute_name === 'Coating') coating = spec.attr_value;
                }
              }

              if (ta >= 3) {
                standardPrice = price; standardUnit = unitPrice;
              } else if (ta >= 1) {
                nextDayPrice = price; nextDayUnit = unitPrice;
              } else {
                sameDayPrice = price; sameDayUnit = unitPrice;
              }
            } else {
              skipCount++;
            }

            await sleep(350);
          } catch (e) {
            errorCount++;
            await sleep(500);
          }
        }

        if (gotAnyPrice) {
          rows.push({
            category: product.category,
            productType: product.name,
            size: actualSize,
            paper: actualPaper,
            coating,
            quantity: parseInt(String(actualQty).replace(/,/g, '')) || actualQty,
            standardPrice, standardUnit,
            nextDayPrice, nextDayUnit,
            sameDayPrice, sameDayUnit,
          });
        }
      }
    }
    console.log(`  Size "${size.name}" done`);
  }

  console.log(`\n  ✓ ${callCount} calls, ${rows.length} rows, ${errorCount} errors, ${skipCount} skipped`);
  return rows;
}

// ==================== EXCEL GENERATION ====================

function generateExcel(allPricing) {
  console.log('\n=== Generating Excel ===');
  
  const enrichedData = allPricing.map(row => {
    const floor = row.standardPrice || row.nextDayPrice || 0;
    return {
      'Product Category': row.category,
      'Product Type': row.productType,
      'Size': row.size,
      'Paper Stock': row.paper,
      'Coating': row.coating,
      'Quantity': row.quantity,
      'Standard Price': row.standardPrice,
      'Standard Per Unit': row.standardUnit,
      'Next Day Price': row.nextDayPrice,
      'Next Day Per Unit': row.nextDayUnit,
      'Same Day Price': row.sameDayPrice,
      'Same Day Per Unit': row.sameDayUnit,
      'NDF Floor': floor || null,
      'Target (+10%)': floor ? Math.round(floor * 1.10 * 100) / 100 : null,
      'Opening (+25%)': floor ? Math.round(floor * 1.25 * 100) / 100 : null,
    };
  });

  const wb = XLSX.utils.book_new();

  // Sheet 1: All Pricing
  const ws1 = XLSX.utils.json_to_sheet(enrichedData);
  ws1['!cols'] = [
    {wch: 18}, {wch: 24}, {wch: 22}, {wch: 24}, {wch: 20},
    {wch: 10}, {wch: 14}, {wch: 16}, {wch: 14}, {wch: 16},
    {wch: 14}, {wch: 16}, {wch: 12}, {wch: 14}, {wch: 14}
  ];
  XLSX.utils.book_append_sheet(wb, ws1, 'All Pricing');

  // Filtered sheets
  const filters = [
    ['Business Cards', r => r['Product Category'] === 'Business Cards'],
    ['Postcards', r => r['Product Category'] === 'Postcards'],
    ['Flyers', r => r['Product Category'] === 'Flyers'],
    ['Large Format', r => r['Product Category'] === 'Large Format'],
    ['Specialty', r => ['Specialty', 'Brochures'].includes(r['Product Category'])],
  ];

  for (const [sheetName, filterFn] of filters) {
    const filtered = enrichedData.filter(filterFn);
    if (filtered.length > 0) {
      const ws = XLSX.utils.json_to_sheet(filtered);
      ws['!cols'] = ws1['!cols'];
      XLSX.utils.book_append_sheet(wb, ws, sheetName);
    }
  }

  const xlsxPath = '/home/inkredible/.openclaw/workspace/ndf-pricing-complete.xlsx';
  XLSX.writeFile(wb, xlsxPath);
  console.log(`Excel: ${xlsxPath}`);

  const csvPath = '/home/inkredible/.openclaw/workspace/ndf-pricing-complete.csv';
  fs.writeFileSync(csvPath, XLSX.utils.sheet_to_csv(ws1));
  console.log(`CSV: ${csvPath}`);

  return enrichedData;
}

// ==================== MAIN ====================

async function main() {
  console.log('╔══════════════════════════════════════════════════╗');
  console.log('║  NDF Comprehensive Price Scraper                 ║');
  console.log('╚══════════════════════════════════════════════════╝');
  const startTime = Date.now();
  console.log(`Started: ${new Date().toISOString()}`);
  
  const totalCombos = Object.values(PRODUCTS).reduce((sum, p) => 
    sum + p.sizes.length * p.papers.length * p.quantities.length * p.turnarounds.length, 0);
  console.log(`Products: ${Object.keys(PRODUCTS).length}, Total API calls planned: ~${totalCombos}`);

  const allPricing = [];
  const stats = {};

  for (const [key, product] of Object.entries(PRODUCTS)) {
    const rows = await scrapeProduct(key, product);
    allPricing.push(...rows);
    stats[product.name] = rows.length;
  }

  const enrichedData = generateExcel(allPricing);

  const elapsed = Math.round((Date.now() - startTime) / 1000);
  console.log('\n╔══════════════════════════════════════════════════╗');
  console.log('║  COMPLETE                                        ║');
  console.log('╚══════════════════════════════════════════════════╝');
  console.log(`Time: ${Math.floor(elapsed/60)}m ${elapsed%60}s`);
  console.log(`Products: ${Object.keys(PRODUCTS).length}`);
  console.log(`Total price rows: ${allPricing.length}`);
  console.log('\nBreakdown:');
  for (const [name, count] of Object.entries(stats)) {
    console.log(`  ${name}: ${count}`);
  }

  console.log('\nSample (first 8 rows):');
  enrichedData.slice(0, 8).forEach((r, i) => {
    console.log(`  ${i+1}. ${r['Product Type']} | ${r['Size']} | ${r['Paper Stock']} | Qty ${r['Quantity']} | Std $${r['Standard Price']||'-'} | Next $${r['Next Day Price']||'-'} | Same $${r['Same Day Price']||'-'}`);
  });
}

main().catch(e => { console.error('FATAL:', e); process.exit(1); });
