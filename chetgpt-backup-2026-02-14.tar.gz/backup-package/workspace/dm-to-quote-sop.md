# DM-to-Quote Conversion SOP (Q6)
**Business:** INKredible Printing (Brooklyn)  
**Owner:** Aviel (pricing/quoting)  
**Frontline:** Brandon (inbound + qualification)  
**Goal:** Turn inbound DMs into paid jobs fast, without missing details.

---

## How this works (simple flow)
1. **Reply fast** (speed wins in Brooklyn).
2. **Qualify the lead** (get the right info before quoting).
3. **Log the lead** in CRM-lite sheet immediately.
4. **Handoff to Aviel** with complete info.
5. **Send quote fast** and track status.
6. **Follow up on Day 1, 3, 7, 14** until won/lost.
7. **Recover lost deals** with smart re-open scripts.

---

## 1) DM Response Scripts (Copy/Paste)

> Use these exactly, then fill in brackets.  
> Optional Russian line for relevant customers: **"Если удобно, можем продолжить на русском."**

### A) Price inquiry script — “How much for [X]?”

**Reply 1 (fast):**
> Great question — pricing depends mostly on size, quantity, and deadline.  
> Most jobs like this usually fall in a range, and I can get you an exact quote today.  
> Send me these 4 things and I’ll price it fast:  
> 1) Exact size  
> 2) Quantity  
> 3) Needed date/time  
> 4) Delivery or pickup

**Reply 2 (after they send details):**
> Perfect, thank you. I’m sending this to our pricing manager now and we’ll get you the best option quickly.  
> If you have a target budget, share it so we can match the right material/finish.

**If they ask for “just a number”:**
> Totally understand. I don’t want to give you a fake number and waste your time.  
> Even rough size + date lets me give a real range in minutes.

---

### B) Capability inquiry script — “Do you do [X]?”

**Reply 1:**
> Yes — we do that ✅  
> We handle [floor graphics / banners / backdrops / large-format installs] with fast turnaround in Brooklyn/NYC.  
> Want me to give you a quick price + timing? Send size, quantity, and due date.

**Reply 2 (if they’re unsure):**
> If you send a photo/example, I’ll confirm the best material and exact next steps.

**If good fit for upsell:**
> Also, if this is for an event, we can bundle floor graphics + matching signage so everything looks consistent.

---

### C) Rush job script — “I need something for [date]”

**Reply 1 (urgent triage):**
> Got it — we can move fast. I need to check production capacity right now.  
> Send ASAP:  
> • exact size/qty  
> • final due date + time  
> • print-ready file (if ready)  
> • pickup or install address

**Reply 2 (after details):**
> Thanks — marked as **RUSH** and sending to pricing now.  
> I’ll update you by [time] with options.

**If same-day is unrealistic:**
> I want to be straight with you: same-day is tight for this spec.  
> I can offer two options right now:  
> 1) simplified version today  
> 2) full version by [time/date]

---

### D) Referral/recommendation inquiry script

**Reply 1:**
> Amazing — thank you for reaching out, and shoutout to [referrer name] 🙌  
> Happy to help. I can get you pricing quickly — send me: event date, size, quantity, and what you need printed.

**Reply 2 (relationship-forward):**
> Since you came through [referrer], we’ll prioritize this and keep it smooth.  
> If you have inspiration photos, send them and we’ll match the look.

**Optional referral-close line:**
> Once this is done, I’d love to send [referrer] a thank-you for the intro.

---

### E) Competitor comparison script — “Are you cheaper than [X]?”

**Reply 1 (don’t race to bottom):**
> Fair question. We’re not always the cheapest line item, but we’re strong on speed, quality, and clean installs — especially for event deadlines.  
> If you share their quote/spec, I’ll see the best option we can do for you.

**Reply 2 (reframe to value + options):**
> We can usually give 2 paths:  
> • **Best value option** (budget-friendly)  
> • **Best finish option** (premium look/durability)  
> Send size + due date and I’ll price both.

**If they hard-anchor to low price:**
> Understood. If budget is the main driver, tell me your target number and I’ll see what spec gets closest without risking quality.

---

## 2) Lead Qualification Checklist (Before any quote handoff)

> Brandon should collect this before handing to Aviel.  
> If missing key info, quote quality drops and close rate drops.

### Required info (must-have)
- [ ] Customer name + best phone
- [ ] Company (if any)
- [ ] Lead source (IG/DM/referral/phone/email)
- [ ] Product needed (floor graphic/banner/etc.)
- [ ] Event type (wedding, mitzvah, corporate, birthday, retail, etc.)
- [ ] Event/job date + install/delivery time window
- [ ] Exact size(s) + quantity
- [ ] Venue/address + on-site constraints (stairs, loading dock, install hours)
- [ ] Artwork status (ready/not ready/needs design help)
- [ ] Budget range (or target spend)
- [ ] Competitor quote mentioned? (yes/no + amount)
- [ ] Decision maker + approval deadline
- [ ] Repeat potential (one-time / monthly / seasonal)

### Nice-to-have (helps close faster)
- [ ] Venue photos
- [ ] Material preference (matte/gloss/non-slip/etc.)
- [ ] Payment preference (card/Zelle/check)
- [ ] Language preference (English/Russian)

### Quick lead priority score (simple)
- **A (High priority):** Event date soon + clear details + repeat potential + realistic budget
- **B (Normal):** Good fit but missing some details or slower timeline
- **C (Low):** Price shopping only, vague details, no urgency, no repeat value

---

## 3) Quote Handoff SOP (Brandon → Aviel)

## Timing standards
- **Standard leads:** handoff within **15 minutes** after qualification
- **Rush/same-day leads:** handoff within **5 minutes** and mark **URGENT**

## Handoff steps
1. Brandon qualifies lead using checklist above.
2. Brandon logs lead in CRM-lite sheet (new row).
3. Brandon sends handoff message to Aviel using template below.
4. Aviel returns quote options (internal pricing strategy).
5. Brandon sends customer-facing quote and logs sent time.
6. Brandon starts follow-up sequence (Day 1/3/7/14).

## Internal handoff template (copy/paste)
> **LEAD HANDOFF — [URGENT/STANDARD]**  
> **Client:** [Name]  
> **Phone:** [Number]  
> **Source:** [IG DM / referral / phone / email]  
> **Product:** [What they need]  
> **Event Type:** [Wedding / Mitzvah / Corporate / etc.]  
> **Event Date/Time:** [Date + exact due/install window]  
> **Venue:** [Address + access notes]  
> **Specs:** [Size, qty, material if known]  
> **Artwork:** [Ready / needs help]  
> **Budget Signal:** [Range or comment]  
> **Competitor Mentioned:** [No / Yes: $___ from ___]  
> **Repeat Potential:** [One-time / likely repeat / monthly]  
> **Files/Photos:** [Drive link or attachments]  
> **Customer Promise Time:** [“I told them we’ll reply by __”]  
> **Notes:** [Anything important]

## Pricing control rule (internal)
- Brandon **does not** negotiate final numbers.
- Aviel controls pricing using 3-tier logic:  
  - Opening: **NDF + 25%**  
  - Target: **NDF + 10%**  
  - Floor: **NDF base**
- Brandon can discuss value, speed, and options — not final floor concessions.

---

## 4) Follow-Up Sequence for Open Quotes

> Trigger this after quote is sent and not closed yet.

### Day 1 follow-up
> Hey [Name], just checking you got the quote for [project].  
> If you want, I can also send a lower-cost option and a premium option so you can choose what fits best.

### Day 3 follow-up
> Quick follow-up on [project date].  
> Do you want me to lock production space for you?  
> If yes, I can hold your slot once approved.

### Day 7 follow-up
> Hey [Name], wanted to make sure this doesn’t get delayed.  
> If budget or timing changed, tell me and I’ll adjust the quote so we keep this moving.

### Day 14 follow-up (soft close)
> Last check-in from my side on this quote.  
> Should I close this file for now, or do you want me to keep it open and update pricing/specs?

## If event date is close (under 7 days)
Don’t wait full cadence. Follow up daily until confirmed yes/no.

---

## 5) Lost Deal Recovery Scripts (When quote doesn’t close)

### Scenario A: Lost on price
> Thanks for the honesty — appreciate it.  
> If you’re open, I can rebuild this to hit a lower budget by adjusting material/finish/installation scope.  
> Want me to send a revised option?

### Scenario B: No response / went cold
> Hey [Name], totally understand things get busy.  
> Want me to keep this open, pause it, or close it out for now?

### Scenario C: Chose another vendor
> Thanks for the update and wishing you a smooth event.  
> If anything changes last minute, message me — we handle fast turnarounds and rescue jobs.

### Scenario D: Event postponed/cancelled
> Sorry to hear that — no problem.  
> I can keep your specs on file and reactivate quickly when the new date is set.

### Recovery re-open (30-day touch)
> Hey [Name], checking in — do you have any upcoming events where you need floor graphics or large-format print help?

---

## 6) Response Time Standards (non-negotiable)

| Channel | First Response Target (Business Hours) | Max Allowed | Quote/Next-Step Commitment |
|---|---:|---:|---|
| Instagram DM / WhatsApp | 5–10 min | 30 min | Initial range/questions same touch; handoff immediately |
| Email | 30–60 min | 2 hours | Confirm receipt + needed details + ETA |
| Phone call | Answer live if possible | Callback in 10 min if missed | Confirm details on call + send written recap |

### Business hours baseline
- Mon–Thu: 10:00 AM–6:00 PM
- Fri: 10:00 AM–2:30 PM

### After-hours auto-reply
> Thanks for reaching out to INKredible — we got your message.  
> We’ll reply by [time next business window]. If this is urgent and same-day, write **URGENT** in your message.

---

## 7) CRM-lite Tracking (Spreadsheet template)

Create a Google Sheet named: **INKredible Lead Pipeline (DM-to-Quote)**

## Sheet 1: `Leads`
Use these columns exactly:

1. Lead ID
2. Date/Time Inbound
3. Channel (DM/Email/Phone/Referral)
4. Lead Source Detail (IG account, referrer name, etc.)
5. Client Name
6. Phone
7. Company
8. Event Type
9. Product Type
10. Event Date
11. Due/Install Window
12. Venue/Address
13. Specs (size/qty/material)
14. Artwork Status
15. Budget Range
16. Competitor Price Mentioned
17. Repeat Potential (One-time/Seasonal/Monthly)
18. Lead Tier (A/B/C)
19. First Response Time
20. Qualified? (Y/N)
21. Handoff Sent to Aviel (timestamp)
22. Quote Sent (timestamp)
23. Quote Amount (Customer-facing)
24. Stage
25. Last Follow-Up Date
26. Next Follow-Up Date
27. Outcome (Won/Lost/Open)
28. Lost Reason (Price/Timing/No Response/Other)
29. Revenue Closed
30. Notes

### Stage options (use dropdown)
- New Inbound
- Qualifying
- Qualified
- Handoff Sent
- Quote Sent
- Follow-Up Day 1
- Follow-Up Day 3
- Follow-Up Day 7
- Follow-Up Day 14
- Won
- Lost
- Nurture

## Sheet 2: `Weekly Dashboard`
Track weekly:
- Total inbound leads
- % qualified
- % quoted
- Quote-to-win rate
- Average response time
- Revenue won
- Lost deals by reason
- Leads with repeat potential

### 3 quick formulas (Google Sheets)
- **Response minutes:** `=(First Response Time - Date/Time Inbound)*1440`
- **Quote turnaround hours:** `=(Quote Sent - Handoff Sent to Aviel)*24`
- **Close rate:** `=Won Deals / Total Quotes Sent`

---

## Daily operating checklist for Brandon (print this)
- [ ] Check DMs first thing at opening
- [ ] Reply to all fresh inbound before scrolling
- [ ] Qualify every serious lead with checklist
- [ ] Log every lead in sheet (no exceptions)
- [ ] Send complete handoff to Aviel
- [ ] Confirm quote sent to customer
- [ ] Run follow-ups due today
- [ ] Update stage/outcome before leaving

---

## Simple quality rules
- Fast beats perfect on first response.
- Never send blind pricing without basic specs/date.
- Don’t negotiate against yourself.
- Compete on speed + reliability + event quality, not just lowest price.
- Every lead is either **open, won, lost, or nurture** — never “forgotten.”

---

## What changed / why it matters / next trigger
### What changed
- Built full DM-to-Quote workflow with scripts, qualification, handoff, follow-ups, loss recovery, response SLAs, and CRM-lite template.

### Why it matters
- Converts inbound faster, reduces missed leads, protects pricing discipline, and improves close rate in a negotiation-heavy market.

### Next trigger
- Implement this in daily ops immediately and run for 2 weeks.
- After 2 weeks, review: response time, quote speed, close rate, and top lost reasons.
- Feed results into Q7 (MIS v1 scope lock) so this becomes productized in MIS.
