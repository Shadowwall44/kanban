/**
 * NextDayFlyers Pricing Extractor - Manual Method
 * 
 * Run this in Antigravity. Copy prices directly from NextDayFlyers into the prompt.
 * 
 * Usage:
 * 1. Run: node scrape-manual.js
 * 2. Copy prices from NextDayFlyers pages (format shown below)
 * 3. Paste into terminal when prompted
 * 4. Outputs Excel file with all pricing
 */

const XLSX = require('xlsx');
const readline = require('readline');
const fs = require('fs');

// Products to scrape
const PRODUCTS = [
  { name: 'Postcards', sizes: ['4x6', '5x7', '6x9', '6x11'] },
  { name: 'Flyers', sizes: ['8.5x11', '8.5x14', '11x17'] },
  { name: 'Booklets', sizes: ['8.5x11', '8.5x5.5'] },
  { name: 'Hang Tags', sizes: ['2x3', '3x4', '4x6'] },
];

// Standard quantities to capture
const QUANTITIES = [100, 250, 500, 1000, 2500, 5000];

function createPrompt(product) {
  return `
========================================
NEXTDAYFLYERS PRICING: ${product.name.toUpperCase()}
========================================

Go to: https://www.nextdayflyers.com/${product.name.toLowerCase().replace(' ', '-')}

For EACH size (${product.sizes.join(', ')}):
1. Set quantity to 100
2. Set Front Side: Full color
3. Set Back Side: Full color  
4. Set Paper Stock: 14 pt. Cardstock
5. Set Coating: High Gloss UV

Copy the 3 prices shown:
- 3 Business Days: $____.__
- Next Business Day: $____.__
- Same Day (by 10am): $____.__

FORMAT YOUR RESPONSE LIKE THIS:
4x6, 3bd: 45.99, next: 62.99, same: 89.99
5x7, 3bd: 52.99, next: 71.99, same: 99.99
6x9, 3bd: 65.99, next: 89.99, same: 129.99
6x11, 3bd: 78.99, next: 105.99, same: 149.99

Then repeat for quantity = 250, 500, 1000, 2500, 5000
`;
}

async function parseResponse(response, product) {
  const lines = response.trim().split('\n');
  const data = [];
  
  for (const line of lines) {
    const match = line.match(/([\d.]+x[\d.]+)\s*,\s*3bd:\s*\$?([\d.]+)\s*,\s*next:\s*\$?([\d.]+)\s*,\s*same:\s*\$?([\d.]+)/);
    if (match) {
      data.push({
        size: match[1],
        price3bd: parseFloat(match[2]),
        priceNext: parseFloat(match[3]),
        priceSame: parseFloat(match[4])
      });
    }
  }
  
  return data;
}

function saveToExcel(results) {
  const workbook = XLSX.utils.book_new();
  
  for (const product of results) {
    const sheetName = product.name.substring(0, 31).replace(/[\/\\?*\[\]]/g, '_');
    const ws = XLSX.utils.aoa_to_sheet([
      ['Size', 'Quantity', '3 Business Days', 'Next Day', 'Same Day']
    ]);
    
    let row = 1;
    for (const item of product.data || []) {
      for (const qty of QUANTITIES) {
        XLSX.utils.sheet_add_cell(ws, { ref: `A${row}`, t: 's', v: item.size });
        XLSX.utils.sheet_add_cell(ws, { ref: `B${row}`, t: 'n', v: qty });
        XLSX.utils.sheet_add_cell(ws, { ref: `C${row}`, t: 'n', v: item[`price${qty}`] || 0 });
        XLSX.utils.sheet_add_cell(ws, { ref: `D${row}`, t: 'n', v: item[`priceNext${qty}`] || 0 });
        XLSX.utils.sheet_add_cell(ws, { ref: `E${row}`, t: 'n', v: item[`priceSame${qty}`] || 0 });
        row++;
      }
    }
    
    XLSX.utils.book_append_sheet(workbook, ws, sheetName);
  }
  
  XLSX.writeFile(workbook, 'nextdayflyers-pricing.xlsx');
  console.log('💾 Saved to nextdayflyers-pricing.xlsx');
}

async function main() {
  console.log('📊 NextDayFlyers Pricing Extractor');
  console.log('================================\n');
  console.log('This tool helps you extract pricing from NextDayFlyers.\n');
  console.log('STEPS:');
  console.log('1. Run this script: node scrape-manual.js');
  console.log('2. For each product, copy prices from NextDayFlyers');
  console.log('3. Paste into this terminal');
  console.log('4. Generates Excel with all pricing\n');
  
  // Generate prompts for each product
  for (const product of PRODUCTS) {
    console.log(createPrompt(product));
  }
  
  console.log('\n📝 COPY/PASTE FORMAT:');
  console.log('After gathering data, format like:');
  console.log('4x6, 3bd: 45.99, next: 62.99, same: 89.99');
  console.log('5x7, 3bd: 52.99, next: 71.99, same: 99.99\n');
  
  console.log('Then paste into Claude Desktop with this prompt:');
  console.log('---');
  console.log('Parse these NextDayFlyers prices into JSON format:');
  console.log('[paste your prices here]');
  console.log('Output JSON:');
  console.log('{product: "Postcards", data: [{size: "4x6", prices: {100: {3bd: 45.99, next: 62.99, same: 89.99}, 250: {...}}}]}');
  console.log('---\n');
  
  console.log('✅ Ready! Copy this script to Antigravity and run it for guidance.');
}

main();
