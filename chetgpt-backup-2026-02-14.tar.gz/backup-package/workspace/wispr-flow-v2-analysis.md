# INKredible Voice — V2 Research Analysis & Build Plan
*Generated: 2026-02-14 | Based on full code audit + 13 research documents*

---

## 1. What V1 Currently Does (Code Audit)

### Working Core Pipeline
```
Ctrl+Win hold → mic capture (MediaRecorder WebM) → Groq Whisper batch STT
→ Groq Llama 3.3 70B cleanup → dictionary post-processing → clipboard + PowerShell Ctrl+V paste
```

### Working Features
| Feature | Implementation | Quality |
|---------|---------------|---------|
| Hold-to-talk (Ctrl+Win) | node-global-key-listener + PowerShell key-state-poller | ✅ Solid |
| Speech-to-text | Groq Whisper Large V3 (batch) | ✅ Good accuracy |
| AI text cleanup | Groq Llama 3.3 70B with sophisticated prompt | ✅ Excellent |
| Flow bar overlay | Transparent, always-on-top pill with waveform | ✅ Polished |
| Waveform visualization | 10-bar ripple with history-based delay | ✅ Beautiful |
| Audio chimes | Web Audio API ascending/descending tones | ✅ Working |
| Context-aware tone | 5 profiles (casual/professional/AI/task/default) | ✅ Working |
| Custom dictionary | CRUD + Whisper prompt integration + post-processing | ✅ Working |
| Auto-learn corrections | PowerShell UI Automation + Levenshtein detection | 🟡 PowerShell-dependent |
| Transcription history | SQLite (sql.js) with metadata | ✅ Working |
| Media pause/resume | Windows GSMTC API via PowerShell | ✅ Unique feature |
| Clipboard save/restore | Electron clipboard API (text/HTML/RTF/image) | ✅ Recently added |
| Space separation | Reads focused text to prepend space | 🟡 PowerShell-dependent |
| Crash recovery | uncaughtException handler + auto-relaunch | ✅ Working |
| Single instance lock | app.requestSingleInstanceLock() | ✅ Working |
| Click-to-record | Flow bar click triggers recording | ✅ Working |
| Fix popup | Manual correction UI → dictionary | ✅ Working |

### Architecture
- **Electron 28.3.3** (outdated — current is 40)
- **JavaScript only** (no TypeScript)
- **7 BrowserWindow instances** + 1 hidden audio capture
- **36 IPC channels** via contextBridge
- **State machine** (IDLE→RECORDING→PROCESSING→PASTING→IDLE) with error recovery
- **~50-80MB RAM** idle (much lighter than Wispr Flow's ~800MB)

### Known Issues
1. **Batch-only STT** — 2-5s pipeline latency vs Wispr's <700ms target
2. **PowerShell dependency** — 6+ spawned processes adding ~200ms each
3. **No streaming transcription** — full blob sent after recording
4. **English-only** — hardcoded `language: 'en'`
5. **No onboarding** — requires manual API key entry
6. **No code signing** — SmartScreen blocks installation
7. **No auto-update** — no update mechanism
8. **No mic device selection** — system default only
9. **No hands-free/toggle mode** — hold-to-talk only
10. **60s recording limit** — too restrictive (Wispr allows 6 min)
11. **Primary display only** — no multi-monitor flow bar support

---

## 2. What Wispr Flow Does (From Research)

### Core Capabilities
- **Custom ASR** (NOT Whisper) — context-aware, personalized, code-switched
- **Hybrid LLM** — LLaMA 3.1 + OpenAI for formatting
- **<700ms latency target** — ASR <200ms + LLM <200ms + network <200ms
- **100+ languages** with auto-detect and code-switching
- **Voice embeddings** for accent/noise handling
- **Whisper Mode** for sub-audible speech (~92-95% accuracy)

### 4 Dictation Modes
1. **Dictate** (hold-to-talk) — default, 6-min limit
2. **Flow** (hands-free) — hotkey+Space or double-tap, toggle on/off
3. **Command** (voice editing) — highlight text → "Hey Flow" → voice command (Pro only)
4. **Quick Dictation** — text to clipboard only (no paste)

### Key Differentiators
- Per-app style learning (RL-based personalization over time)
- Surrounding text reading for LLM context
- Snippets system (voice triggers → expanded text)
- Command Mode for text transformation
- Flow Notes (built-in note-taking)
- Enterprise compliance (SOC 2, HIPAA)

### Wispr Flow's Weaknesses (Our Opportunity)
- **800MB RAM**, 8% CPU idle — widely criticized
- **2.8/5.0 Trustpilot** — significant user dissatisfaction
- **Text insertion bugs** — #1 support issue
- **Cloud-only** — no offline mode
- **Privacy controversy** — screen capture, telemetry
- **$15/month** — expensive vs alternatives
- **Windows version buggy** — "feels like an afterthought"

---

## 3. Complete Gap List

### P0 — Critical Fixes
| # | Gap | Impact | V1 Status |
|---|-----|--------|-----------|
| 1 | Recording limit too short (60s vs 6 min) | Users cut off mid-dictation | Easy fix |
| 2 | No onboarding/first-run | Users can't figure out setup | Missing entirely |

### P1 — Core Feature Parity
| # | Gap | Impact | Effort |
|---|-----|--------|--------|
| 3 | No hands-free/toggle mode | Can't do long dictation | Medium |
| 4 | No language selection | English-only limits market | Low |
| 5 | No mic device selection | Can't pick preferred mic | Low |
| 6 | PowerShell overhead (~200ms per call × 6) | Slow pipeline | Medium |
| 7 | Multi-monitor flow bar | Fixed on primary display | Low |
| 8 | Right-click flow bar menu | No quick settings | Low |
| 9 | Manual paste fallback shortcut | No recovery when auto-paste fails | Low |
| 10 | Flow bar hide/snooze | Can't temporarily hide | Low |

### P2 — Competitive Differentiation
| # | Gap | Impact | Effort |
|---|-----|--------|--------|
| 11 | Command Mode (voice editing) | Premium differentiator | High |
| 12 | Snippets system | Power user feature | Medium |
| 13 | Quick dictation to clipboard | Safety valve | Low |
| 14 | Code syntax awareness | Developer market | Medium |
| 15 | Surrounding text → LLM context | Better formatting | Low |
| 16 | Print shop tone profile | Domain-specific value | Low |
| 17 | Per-app paste key detection | Terminal support | Low |

### P3 — Future (Post-V2)
- Streaming transcription (Deepgram Nova-3)
- Style learning over time (local RL)
- Local/offline processing (Whisper.cpp)
- Flow Notes
- Auto-update mechanism
- Code signing (Azure Trusted Signing)

---

## 4. Technical Approach for Each Gap

### Gap 1: Increase Recording Limit
**Approach:** Change `SAFETY_TIMEOUT_MS` from 60000 to 360000 in recording-state.js.
**Risk:** None. One-line change.

### Gap 2: Onboarding/First-Run
**Approach:** Create a setup wizard window that checks:
1. API key present → if not, show input screen
2. Mic permission → test getUserMedia
3. Hotkey tutorial → interactive "try it now" step
4. Store `firstRunComplete` flag in electron-store
**Implementation:** New BrowserWindow, 3-step wizard, show on first launch.

### Gap 3: Hands-Free/Toggle Mode
**Approach:** 
- Add `FLOW` state to recording-state.js
- Double-tap Ctrl+Win (within 500ms) activates toggle
- Single tap while in FLOW state stops and processes
- 2-minute auto-stop safety
- Flow bar shows "Tap to stop" during toggle mode
**Key:** Detect double-tap via timestamp tracking in hotkey.js. Don't break existing hold-to-talk.

### Gap 4: Language Selection
**Approach:** Add language dropdown to settings. Pass `language` param to Groq Whisper API. Default: auto-detect (don't pass param). Store in electron-store.

### Gap 5: Mic Device Selection
**Approach:** `navigator.mediaDevices.enumerateDevices()` in audio capture window. Pass deviceId via IPC. Store selection in electron-store.

### Gap 6: Reduce PowerShell Dependency
**Approach for V2:** Keep PowerShell for now but optimize:
- Batch key state checks
- Reuse PowerShell processes where possible
- Add performance logging
**Future:** Replace with uiohook-napi (hotkeys) + nut.js (Ctrl+V) + koffi (Win32 API)

### Gap 7: Multi-Monitor Flow Bar
**Approach:** `screen.getDisplayNearestPoint(screen.getCursorScreenPoint())` → reposition on recording start and display-metrics-changed event.

### Gap 8-10: Flow Bar Enhancements
**Approach:** Expand context menu with Dashboard, Recording Mode submenu, Language submenu, Hide/Snooze. Add drag-to-reposition with position persistence.

### Gap 11: Command Mode
**Approach:**
1. New hotkey (Ctrl+Win+Shift) activates command mode
2. On press: save clipboard → Ctrl+C to grab selection → start recording
3. On release: Whisper transcribes command → Llama gets (selected_text + command) → rewrites → paste back
4. Separate COMMAND state in state machine
5. Separate Llama prompt optimized for text transformation

### Gap 12: Snippets System
**Approach:** New `snippets` table in SQLite. After Whisper transcription, check if normalized text matches a trigger phrase (exact match). If match: skip Llama, paste snippet content directly. In-memory Map for O(1) lookup.

### Gap 13: Quick Dictation to Clipboard
**Approach:** New hotkey (Ctrl+Win+C) or toggle in settings. Same pipeline but skip paste step — just copy to clipboard and show notification.

### Gap 15: Surrounding Text → LLM Context
**Approach:** The correction-monitor already reads focused text via PowerShell UI Automation. Wire this into the pipeline: read focused text before recording starts, pass as context to Llama cleanup prompt.

### Gap 16: Print Shop Tone Profile
**Approach:** Add new profile to tone-profiles.js with print-specific formatting rules (money, dimensions, quantities, print terms). Auto-activate for email apps, ClickUp, QuickBooks.

---

## 5. Priority-Ordered V2 Feature List

### Must Ship (V2 Core)
1. ✅ Increase recording limit to 6 minutes
2. ✅ Onboarding/first-run wizard
3. ✅ Hands-free/toggle mode (double-tap)
4. ✅ Language selection (with Hebrew)
5. ✅ Mic device selection
6. ✅ Multi-monitor flow bar positioning
7. ✅ Enhanced flow bar (right-click menu, hide/snooze)
8. ✅ Manual paste fallback shortcut (Alt+Shift+Z)
9. ✅ Quick dictation to clipboard mode
10. ✅ Snippets system
11. ✅ Command Mode (voice editing)
12. ✅ Print shop tone profile
13. ✅ Expanded course correction in AI cleanup
14. ✅ Pipeline performance logging
15. ✅ Whisper context with print shop terms

### Nice to Have
- Drag-to-reposition flow bar
- Hotkey customization UI
- Surrounding text as LLM context
- Per-app paste key detection

---

## 6. Architecture Recommendations for V2

### Keep From V1
- Electron framework (working, light ~50-80MB vs Wispr's 800MB)
- Groq Whisper + Llama pipeline (working well, cheap)
- sql.js database (working, no migration needed)
- Flow bar overlay architecture (polished)
- State machine pattern (robust)
- contextBridge IPC pattern (secure)

### Add/Improve
1. **Extend state machine** — Add FLOW (hands-free) and COMMAND states
2. **Provider abstraction** — Prepare for multiple STT providers
3. **Modular pipeline** — Separate command pipeline from dictation pipeline
4. **Settings expansion** — Language, mic device, recording mode
5. **Performance instrumentation** — Timing logs throughout pipeline
6. **Onboarding flow** — First-run wizard with permission checks

### File Changes Summary
| File | Changes |
|------|---------|
| recording-state.js | Add FLOW + COMMAND states, increase timeout |
| hotkey.js | Double-tap detection, command mode hotkey |
| pipeline.js | Snippets check, command mode branch, timing |
| groq-transcribe.js | Language param, expanded Whisper context |
| groq-cleanup.js | Expanded course correction, command prompt |
| tone-profiles.js | Print shop profile |
| clipboard-paste.js | Manual paste shortcut, command mode paste |
| windows.js | Multi-monitor, enhanced menu, onboarding window |
| database.js | Snippets table |
| preload.js | New IPC channels for snippets, settings, etc. |
| settings UI | Language, mic, recording mode dropdowns |
| flow-bar.js | Toggle mode indicator, snooze |
| NEW: onboarding/ | First-run wizard |
| NEW: command-mode.js | Command pipeline |
| NEW: snippets-service.js | Snippet management |

### What NOT to Do in V2
- Don't migrate to TypeScript (working JS codebase, migrate later)
- Don't switch to Tauri (working Electron, not worth rewrite)
- Don't add streaming STT yet (save for V3 — Deepgram integration)
- Don't replace PowerShell entirely (save for V3 — uiohook-napi + nut.js)
- Don't add auto-update (requires code signing first)

---

## What INKredible Voice Does BETTER Than Wispr Flow

1. **~50-80MB RAM** vs Wispr's ~800MB (10x lighter)
2. **Media pause/resume** during recording (unique)
3. **Waveform visualization** with history-based ripple (may be more polished)
4. **Hallucination guard** (blocks suspicious long text from short recordings)
5. **Meta-response guard** (catches LLM answering instead of formatting)
6. **Mic pre-warming** (instant recording start)
7. **Mic sensitivity control** (adjustable gain 1.0-4.0)
8. **Sound chimes** (ascending/descending audio feedback)
9. **Clipboard save/restore** (recently added)
10. **Dictionary → Whisper prompt integration** (helps recognition accuracy)

---

*This analysis synthesizes ~5,000+ lines of research across 13 documents, a full code audit of 48 source files, and competitive intelligence from Wispr Flow, SuperWhisper, Talon Voice, and 6+ other competitors.*
