# MIS v1 Scope Lock + Build Plan (Q7)

**Business:** INKredible Printing  
**Date:** 2026-02-14  
**Owner:** Aviel  
**Positioning:** Internal operating system first, external product second

---

## Scope Lock Decision (Non-negotiable)

1. **Build custom MIS (already decided)** using existing Next.js + TypeScript stack.  
2. **v1 must be used daily at INKredible before any commercialization.**  
3. **v1 is workflow-first, not feature-maximal.** If a feature does not improve daily quote/job/cash control, it is out.  
4. **Zoho is blueprint only** (reference architecture), not a subscription path.  

---

## 1) Non-Negotiable v1 Modules (Daily-Use Minimum)

These are the required modules for MIS v1 launch:

| Module | v1 Outcome | Must-Have v1 Capabilities |
|---|---|---|
| **1. Job Tracker** | Every job visible from lead to payment | Stage pipeline: **Lead → Quote → Booked → Production → Delivered → Paid**, owner assignment, due dates, rush flags, stage history, lost-reason tracking |
| **2. Quote Calculator** | Fast, consistent pricing | 3-tier pricing: **Opening (NDF+25%) / Target (NDF+10%) / Floor (NDF base)**, line items, margin preview, quote versioning, quote-to-job conversion |
| **3. Customer CRM** | No lost context | Contact records, communication log, job history, quote history, lifetime value (LTV), repeat-customer flags, referral source |
| **4. Floor Graphics Calendar** | Capacity clarity | Calendar for floor jobs, install windows, production load by day, machine/resource allocation, collision warnings |
| **5. Financial Dashboard** | Weekly financial control | Cash position, reserve coverage, gross margin, debt exposure, floor graphics revenue share (Q1 schema aligned) |
| **6. Weekly KPI Report** | Decision-ready weekly summary | Auto-generated Monday report (Q2 rules): status colors, KPI deltas, 3 actions, risk alerts, mobile Telegram format |

### v1 success principle
If these 6 modules work reliably on mobile + desktop and are used every day, v1 is successful.

---

## 2) What’s OUT of v1 (Deferred to v2+)

To prevent scope creep, these are explicitly excluded from v1:

1. **Inventory system** (full FIFO lot tracking, barcode, reorder automation)  
2. **Vendor management** (supplier scorecards, automated PO optimization)  
3. **Multi-shop / multi-location architecture** (multi-tenant operations)  
4. **Native mobile app** (iOS/Android binaries) — v1 is responsive web app/PWA only

### Also deferred unless needed for v1 stability
- Advanced automations (complex workflows beyond alerts/reminders)
- Customer portal + online payments
- AI anomaly detection and forecasting
- Marketing/social scheduling modules

---

## 3) v1 Data Model (Tables, Relationships, Key Fields)

## 3.1 Core relational model

```text
customers 1---* contacts
customers 1---* jobs
jobs 1---* job_stage_events
jobs 1---* quotes
quotes 1---* quote_line_items
jobs 1---* calendar_events
jobs 1---* invoices
invoices 1---* payments
customers 1---* communications

financial side:
cash_accounts_daily
offbooks_cash_log
debt_accounts
margin_weekly
finance_scoreboard_weekly

pipeline/KPI side:
pipeline_weekly_metrics
kpi_weekly_snapshots
```

## 3.2 Table definitions by module

### A) Job Tracker

**`jobs`**
- `id` (PK)
- `job_number` (human-readable)
- `customer_id` (FK → customers)
- `primary_contact_id` (FK → contacts)
- `title`
- `job_type` (floor_graphics, banner, signage, etc.)
- `stage` (lead, quote, booked, production, delivered, paid, lost)
- `priority` (rush, normal)
- `event_date`
- `due_at`
- `owner_user`
- `estimated_value`
- `actual_revenue`
- `lost_reason`
- `created_at`, `updated_at`

**`job_stage_events`**
- `id` (PK)
- `job_id` (FK)
- `from_stage`, `to_stage`
- `changed_by`
- `changed_at`
- `note`

### B) Quote Calculator

**`quotes`**
- `id` (PK)
- `job_id` (FK)
- `quote_number`
- `version`
- `status` (draft, sent, approved, rejected, expired)
- `ndf_anchor_total`
- `opening_total` (NDF+25%)
- `target_total` (NDF+10%)
- `floor_total` (NDF base)
- `selected_tier` (opening, target, floor)
- `gross_margin_pct_estimate`
- `sent_at`, `approved_at`

**`quote_line_items`**
- `id` (PK)
- `quote_id` (FK)
- `item_type` (print, install, design, rush, delivery)
- `description`
- `qty`
- `unit_cost`
- `unit_price`
- `line_total`

### C) Customer CRM

**`customers`**
- `id` (PK)
- `name`
- `company_name`
- `source_channel` (IG, referral, walk-in, etc.)
- `segment` (event_planner, rental_company, corporate, retail)
- `language_pref`
- `first_job_date`
- `last_job_date`
- `lifetime_value`
- `repeat_score`

**`contacts`**
- `id` (PK)
- `customer_id` (FK)
- `full_name`
- `phone`
- `email`
- `role`
- `preferred_contact_method`

**`communications`**
- `id` (PK)
- `customer_id` (FK)
- `job_id` (nullable FK)
- `channel` (dm, phone, email)
- `summary`
- `next_follow_up_at`
- `owner_user`

### D) Floor Graphics Calendar

**`calendar_events`**
- `id` (PK)
- `job_id` (FK)
- `event_type` (print_slot, install_slot, delivery_slot)
- `start_at`, `end_at`
- `resource` (HP700W, Roland, install_team)
- `location`
- `capacity_units`
- `status` (planned, confirmed, completed)

**`capacity_rules`**
- `id` (PK)
- `resource`
- `daily_capacity_units`
- `blackout_dates`

### E) Financial Dashboard (aligned to Q1)

**`cash_accounts_daily`**
- `snapshot_date`, `account_id`, `account_name`, `account_type`, `ending_balance`, `source_system`

**`offbooks_cash_log`**
- `cash_txn_id`, `txn_date`, `customer_name`, `job_type`, `amount_received`, `invoice_id`, `deposited_flag`, `deposit_batch_id`, `notes`

**`debt_accounts`**
- `debt_id`, `lender`, `debt_type`, `current_balance`, `apr_percent`, `min_payment`, `due_day`, `status`, `refinance_candidate_flag`

**`margin_weekly`**
- `week_start`, `revenue_total`, `cogs_total`, `gross_profit`, `gross_margin_pct`, `floor_graphics_revenue`, `floor_graphics_share_pct`

### F) Weekly KPI Report (aligned to Q2)

**`finance_scoreboard_weekly`**
- `week_start`
- `real_cash_position`
- `reserve_floor`, `reserve_target`, `reserve_coverage_pct`
- `total_debt`, `debt_change_wow`, `monthly_interest_estimate`
- `gross_margin_pct`, `floor_graphics_share_pct`
- `status_color`
- `top_3_actions` (json/text)
- `risk_alerts` (json/text)
- `win_note`

**`pipeline_weekly_metrics`**
- `week_start`
- `leads_in`, `quotes_sent`, `booked_jobs`, `produced_jobs`, `delivered_jobs`, `paid_jobs`
- `lead_to_quote_pct`, `quote_to_booked_pct`, `booked_to_paid_pct`

**`kpi_weekly_snapshots`**
- `week_start`
- `response_time_minutes_avg`
- `quote_turnaround_hours_avg`
- `close_rate_pct`
- `avg_ticket`
- `repeat_customer_pct`

---

## 4) Tech Stack Recommendation (Maintainable + Mobile + QuickBooks-ready)

## 4.1 Recommended architecture

### Frontend/UI
- **Next.js 16 + TypeScript** (existing repo advantage)
- **App Router + Server Actions** for simpler backend wiring
- **Tailwind + shadcn/ui** for fast, clean, responsive UI
- **Recharts** for KPI and finance charts
- **PWA installability** for Samsung Z Fold 7 home-screen use

### Backend/Data
- **PostgreSQL (Supabase or Neon)**
- **Prisma ORM** for typed schema + easy migrations
- **Zod** for input validation at API boundaries

### Auth & Access
- Simple team auth (magic link or password)
- Role tiers: `owner`, `sales`, `ops`, `admin`

### Integrations
- **QuickBooks API sync service** (existing OAuth server path can be reused)
- Initial mode: sandbox/manual import
- Production mode: switch source tags without changing schema

### Automation
- **Vercel Cron / scheduled jobs**
  - Monday 8:00 AM ET weekly KPI report
  - Daily cash reconciliation prompt
  - Overdue quote follow-up reminders

### Why this stack fits Aviel
- Uses existing codebase and skills (lower cognitive overhead)
- Strong TypeScript guardrails reduce breakage
- Postgres + Prisma are maintainable with predictable migrations
- Web-first design avoids app-store complexity while still mobile-usable

---

## 5) Phased Build Plan (Locked Timeline)

## Phase 1 (2–3 weeks): Job Tracker + Quote Calculator
**Goal:** stop quote/job chaos first

**Deliverables**
- Job pipeline board with required stages
- Quote builder with 3-tier NDF pricing
- Quote-to-job conversion and stage audit trail
- Basic lead source + lost reason capture

**Exit criteria**
- 100% of new jobs tracked in system
- Quotes generated from MIS for daily operations
- No quoting outside system except emergency fallback

---

## Phase 2 (2 weeks): CRM + Floor Graphics Calendar
**Goal:** customer memory + scheduling control

**Deliverables**
- Customer/contact records with full history
- LTV + repeat customer tracking
- Floor graphics calendar with resource capacity and conflict flags
- Mobile-friendly daily schedule view

**Exit criteria**
- Team can view today/this week schedule from phone
- No double-booked install slots
- Repeat clients identifiable in <10 seconds

---

## Phase 3 (1–2 weeks): Financial Dashboard + Weekly KPI Reports
**Goal:** one-screen financial and operational truth

**Deliverables**
- Q1 schema-backed dashboard cards (cash, margin, debt, floor share)
- Q2 Monday auto-scoreboard generation (full + Telegram compact)
- KPI status logic (red/yellow/green)
- 3 action recommendations each week

**Exit criteria**
- Weekly report auto-generated on schedule
- Manual finance check reduced to review/decision, not data assembly
- Aviel can answer “where are we this week?” from one screen

---

## Phase 4 (Credential-dependent): QuickBooks Live Integration
**Goal:** replace manual pulls with trusted sync

**Trigger:** Production QuickBooks credentials/compliance approval cleared

**Deliverables**
- OAuth production connection
- Idempotent sync jobs (weekly + daily)
- Error retries + data quality flags
- Source-system tagging (`quickbooks_prod`)

**Exit criteria**
- 95%+ sync reliability over 4 weeks
- No KPI report skipped due to API failure (graceful degraded mode)
- Week-over-week metrics stable and audit-traceable

---

## 6) Pilot Criteria

## A) “Ready for daily use at INKredible”
System is daily-use ready when all are true for 30 consecutive days:

1. **Adoption:** >90% of leads/quotes/jobs entered in MIS
2. **Pipeline control:** Every active job has owner + stage + due date
3. **Quote speed:** median quote turnaround meets internal target
4. **Calendar reliability:** zero unplanned floor-graphics collisions
5. **Finance cadence:** weekly KPI report delivered every Monday
6. **Mobile usability:** Aviel and Brandon can run core tasks from phone

## B) “Ready for 3 pilot shops”
System is external-pilot ready when all are true:

1. **Internal stability:** 90 days continuous internal use
2. **Documentation:** onboarding guide + SOP + troubleshooting playbook complete
3. **Config layer:** shop-specific settings (branding, pricing defaults, stages)
4. **Security baseline:** role-based access + basic audit logs
5. **Support model:** response SLA and bug triage process defined
6. **Pilot proof:** at least 2 internal case studies (before/after KPIs)

---

## 7) Go-to-Market Hypothesis (Phase 2 of the dream)

## Positioning
**“The operating system for small print shops that do event and large-format work.”**

This is not generic CRM/accounting software; it is print workflow + pricing + production + finance in one system.

## ICP (initial customer profile)
- Independent print/sign/event shops
- 2–15 person teams
- Revenue roughly $300K–$3M
- Pain: slow quoting, production chaos, weak cash visibility

## Pricing hypothesis (post-pilot)

### Pilot offer (first 3 shops)
- **$0 setup for first 30 days** (feedback + testimonial exchange)
- Then **$149–$249/mo founder plan** during pilot window

### Early commercial pricing (after pilot validation)
- **Core Plan: $299/mo** (job tracker, quotes, CRM, calendar, weekly KPI)
- **Pro Plan: $499/mo** (advanced automation, deeper integrations)
- **Onboarding fee:** $750–$1,500 one-time (data import + workflow setup)

## Why this can win
- Cost advantage vs legacy/stacked tools
- Built from real print-shop workflow (INKredible proof)
- Fast ROI from quote speed + fewer missed jobs + weekly control

## Key GTM proof metrics to track
- Time-to-first-quote reduction
- Quote-to-booked uplift
- On-time delivery uplift
- Gross margin improvement
- Owner weekly visibility score (subjective but important)

---

## Risks & Dependencies (Scope-Protecting)

1. **QuickBooks production access delay** → keep phase 4 decoupled; continue with sandbox/manual pipeline
2. **Scope creep into inventory/vendor modules** → blocked until v1 success criteria met
3. **Data discipline risk** → enforce mandatory fields in lead/quote/job forms
4. **Mobile friction** → test every module in Z Fold narrow/folded mode before release

---

## Prioritized Build Backlog (P0 first)

### P0 (must ship in v1)
- Job pipeline board + stage audit log
- 3-tier quote calculator + quote conversion
- Customer record + LTV + history
- Floor graphics calendar + capacity checks
- Financial dashboard cards (Q1)
- Monday weekly KPI generator (Q2)

### P1 (after v1 stable)
- Invoice/payment portal UX improvements
- Deeper automations and alerts
- Enhanced reporting exports

### P2 (v2+)
- Inventory + vendor + multi-shop + native mobile app

---

## What changed / why it matters / next trigger

### What changed
- Locked MIS v1 scope into 6 daily-use modules
- Defined explicit out-of-scope list to prevent drift
- Mapped concrete v1 data model and implementation architecture
- Set 4-phase delivery plan and pilot readiness criteria
- Added monetization hypothesis for post-INKredible rollout

### Why it matters
- Prevents building a bloated system that never becomes daily habit
- Aligns product work to Aviel’s core outcome: control, confidence, and growth
- Creates a direct path from internal tool to external SaaS opportunity

### Next trigger
- Start **Phase 1 build tickets** (Job Tracker + Quote Calculator)
- Confirm UI wireframes and required form fields
- Keep inventory/vendor/multi-shop explicitly blocked until v1 daily-use criteria are met

---

### Source note
This scope lock uses: roadmap (Q7 context), Q1 financial schema, Q2 weekly KPI template, DM-to-Quote SOP, brain dump, and Zoho blueprint. The Q3 floor-pipeline markdown file path was not present at drafting time, so pipeline stages/metrics were derived from roadmap + memory definitions (`Lead → Quote → Booked → Production → Delivered → Paid`).
