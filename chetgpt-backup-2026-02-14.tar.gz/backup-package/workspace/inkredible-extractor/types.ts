export interface InvoiceItem {
  invoice_date: string;
  vendor: string;
  invoice_number: string;
  item_description: string;
  category: string;
  sheet_size: string;
  sku: string;
  quantity_ordered: number | string;
  unit_of_measure: string;
  sheets_per_unit: number | string;
  total_sheets_explicit?: number | null;
  total_sheets_manual?: number | null;
  unit_price: number | string;
  total_line_price: number | string;
  cost_per_sheet: number | string;
  notes: string;
  // New fields for advanced features
  paper_weight?: string;
  paper_type?: string;
  paper_finish?: string;
  // Large Format specific fields
  material_thickness?: string;
  roll_width?: string;
  roll_length?: string;

  confidence_score?: 'high' | 'medium' | 'low';
  confidence_reason?: string;
  source_file?: string; // Filename reference for split-screen
}

export interface Lot {
  id?: number;
  invoiceNumber: string;
  invoiceDate: string;
  vendor: string;
  materialKey: string;
  paperWeight: string;
  paperType: string;
  paperFinish: string;
  size: string;
  originalQty: number;
  currentQty: number;
  costPerSheet: number;
  totalCost: number;
  createdAt: number;
}

export interface InventoryItem {
  materialKey: string;
  paperWeight: string;
  paperType: string;
  paperFinish: string;
  size: string;
  totalQtyAvailable: number;
  lots: Lot[];
  avgCostPerSheet: number;
  oldestLotCost: number;
  lastUpdated: number;
}

export interface VendorRule {
  id?: number;
  vendorName: string;
  rule: string;
  isActive: boolean;
}

export const CSV_HEADERS = [
  'invoice_date',
  'vendor',
  'invoice_number',
  'item_description',
  'category',
  'sheet_size',
  'paper_weight',
  'paper_type',
  'paper_finish',
  'material_thickness',
  'roll_width',
  'roll_length',
  'sku',
  'quantity_ordered',
  'unit_of_measure',
  'sheets_per_unit',
  'total_sheets_explicit',
  'total_sheets_manual',
  'unit_price',
  'total_line_price',
  'cost_per_sheet',
  'notes',
  'confidence_score',
  'confidence_reason',
  'source_file'
] as const;
