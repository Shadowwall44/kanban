
import Dexie, { Table } from 'dexie';
import { InvoiceItem, VendorRule, Lot, InventoryItem } from '../types';

// Extend InvoiceItem with an optional ID for database storage
export interface SavedInvoiceItem extends InvoiceItem {
  id?: number;
  batchId: string; // To group items imported together
  createdAt: number;
}

// Define the database type
type InkredibleDatabase = Dexie & {
  invoiceItems: Table<SavedInvoiceItem>;
  vendorRules: Table<VendorRule>;
  lots: Table<Lot>;
};

// Initialize the database instance
export const db = new Dexie('InkredibleDB') as InkredibleDatabase;

// Define schema - each version must define ALL tables that exist at that version
db.version(2).stores({
  invoiceItems: '++id, batchId, invoice_number, vendor, invoice_date, category, createdAt',
  vendorRules: '++id, vendorName'
});

// Version 3 adds 'lots' table - must repeat existing tables
db.version(3).stores({
  invoiceItems: '++id, batchId, invoice_number, vendor, invoice_date, category, createdAt',
  vendorRules: '++id, vendorName',
  lots: '++id, materialKey, invoiceDate, createdAt'
});

export const saveItemsToDb = async (items: InvoiceItem[]) => {
  const batchId = crypto.randomUUID();
  const timestamp = Date.now();

  const itemsToSave: SavedInvoiceItem[] = items.map(item => ({
    ...item,
    batchId,
    createdAt: timestamp
  }));

  await db.invoiceItems.bulkAdd(itemsToSave);
  return batchId;
};

export const getAllItems = async (): Promise<SavedInvoiceItem[]> => {
  return await db.invoiceItems.orderBy('invoice_date').reverse().toArray();
};

export const deleteItem = async (id: number) => {
  await db.invoiceItems.delete(id);
};

export const clearDatabase = async () => {
  await db.invoiceItems.clear();
};

// Vendor Rules Methods
export const getVendorRules = async (): Promise<VendorRule[]> => {
  return await db.vendorRules.toArray();
};

export const saveVendorRule = async (rule: VendorRule) => {
  if (rule.id) {
    return await db.vendorRules.put(rule);
  }
  return await db.vendorRules.add(rule);
};

export const deleteVendorRule = async (id: number) => {
  await db.vendorRules.delete(id);
};

/**
 * Checks if any of the provided items belong to invoices that already exist in the database.
 * Returns a list of strings formatted as "Vendor #InvoiceNumber" for any duplicates found.
 */
export const getDuplicateInvoices = async (items: InvoiceItem[]): Promise<string[]> => {
  // Extract unique invoice numbers from the input items
  const uniqueInvoiceNumbers = Array.from(new Set(items.map(item => item.invoice_number)));

  if (uniqueInvoiceNumbers.length === 0) return [];

  // Fetch all items from DB that match these invoice numbers
  const existingRecords = await db.invoiceItems
    .where('invoice_number')
    .anyOf(uniqueInvoiceNumbers)
    .toArray();

  const duplicates = new Set<string>();

  // Compare vendor + invoice_number to ensure strict uniqueness
  // (e.g., Vendor A #100 and Vendor B #100 are different)
  items.forEach(newItem => {
    const isDuplicate = existingRecords.some(existing =>
      existing.invoice_number === newItem.invoice_number &&
      existing.vendor === newItem.vendor
    );

    if (isDuplicate) {
      duplicates.add(`${newItem.vendor} #${newItem.invoice_number}`);
    }
  });

  return Array.from(duplicates);
};

// --- Inventory Module ---

export const saveLotsFromInvoice = async (items: InvoiceItem[]) => {
  console.log('[Inventory] saveLotsFromInvoice called with', items.length, 'items');
  const timestamp = Date.now();
  const newLots: Lot[] = [];

  for (const item of items) {
    // Only track "Paper" categories or similar for inventory
    const catLower = item.category?.toLowerCase() || '';
    if (!catLower.includes('paper') && !catLower.includes('vinyl')) {
      console.log('[Inventory] Skipping non-paper/vinyl:', item.category);
      continue;
    }

    const manualTotal = Number(item.total_sheets_manual);
    const explicitTotal = Number(item.total_sheets_explicit);
    const calcTotal = (Number(item.quantity_ordered) || 0) * (Number(item.sheets_per_unit) || 1);

    const finalTotalSheets = !isNaN(manualTotal) && manualTotal > 0 ? manualTotal
      : (!isNaN(explicitTotal) && explicitTotal > 0 ? explicitTotal : calcTotal);

    console.log('[Inventory] Item sheets:', { manual: manualTotal, explicit: explicitTotal, calc: calcTotal, final: finalTotalSheets });

    if (finalTotalSheets <= 0) {
      console.log('[Inventory] Skipping - no sheets');
      continue;
    }

    const totalPrice = Number(item.total_line_price) || 0;
    const costPerSheet = totalPrice > 0 && finalTotalSheets > 0 ? totalPrice / finalTotalSheets : 0;

    const materialKey = `${item.paper_weight || 'Unknown'}-${item.paper_type || 'Generic'}-${item.paper_finish || ''}-${item.sheet_size}`.toUpperCase();

    newLots.push({
      invoiceNumber: item.invoice_number,
      invoiceDate: item.invoice_date,
      vendor: item.vendor,
      materialKey: materialKey.replace(/-+/g, '-').replace(/-$/, ''), // clean key
      paperWeight: item.paper_weight || '',
      paperType: item.paper_type || '',
      paperFinish: item.paper_finish || '',
      size: item.sheet_size,
      originalQty: finalTotalSheets,
      currentQty: finalTotalSheets,
      costPerSheet: costPerSheet,
      totalCost: totalPrice,
      createdAt: timestamp
    });
  }

  console.log('[Inventory] Lots to save:', newLots.length);

  if (newLots.length > 0) {
    try {
      await db.lots.bulkAdd(newLots);
      console.log('[Inventory] Successfully saved', newLots.length, 'lots');
    } catch (e) {
      console.error('[Inventory] Error saving lots:', e);
      throw e;
    }
  }
};

export const getInventory = async (): Promise<InventoryItem[]> => {
  const allLots = await db.table('lots').toArray() as Lot[];
  const grouped: Record<string, Lot[]> = {};

  // Group by materialKey
  allLots.forEach(lot => {
    // Exclude exhausted lots from the main list? Or keep them for history?
    // For "Current Inventory", we might only care about currentQty > 0
    // But for FIFO cost calc, we need the oldest available.
    if (lot.currentQty > 0) {
      if (!grouped[lot.materialKey]) grouped[lot.materialKey] = [];
      grouped[lot.materialKey].push(lot);
    }
  });

  const inventory: InventoryItem[] = Object.keys(grouped).map(key => {
    const lots = grouped[key].sort((a, b) => a.invoiceDate.localeCompare(b.invoiceDate) || a.createdAt - b.createdAt);

    const totalQty = lots.reduce((sum, lot) => sum + lot.currentQty, 0);
    // Weighted Average Cost (optional, user asked for Oldest Lot Cost)
    const totalVal = lots.reduce((sum, lot) => sum + (lot.currentQty * lot.costPerSheet), 0);
    const avgCost = totalQty > 0 ? totalVal / totalQty : 0;

    // Oldest available lot cost (FIFO basis)
    const oldestCost = lots.length > 0 ? lots[0].costPerSheet : 0;

    const firstLot = lots[0];

    return {
      materialKey: key,
      paperWeight: firstLot.paperWeight,
      paperType: firstLot.paperType,
      paperFinish: firstLot.paperFinish,
      size: firstLot.size,
      totalQtyAvailable: totalQty,
      lots: lots,
      avgCostPerSheet: avgCost,
      oldestLotCost: oldestCost,
      lastUpdated: Math.max(...lots.map(l => l.createdAt))
    };
  });

  return inventory;
};

export const clearInventory = async () => {
  await db.table('lots').clear();
};