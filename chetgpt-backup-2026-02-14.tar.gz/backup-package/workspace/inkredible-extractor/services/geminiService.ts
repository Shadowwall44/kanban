import { GoogleGenAI, Type } from "@google/genai";
import { InvoiceItem, VendorRule } from '../types';
import { SYSTEM_PROMPT } from '../constants';

const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY || '';
const GEMINI_MODEL = 'gemini-2.0-flash';

// Retry Configuration
const BACKOFF_SCHEDULE_MS = [2000, 5000, 10000]; // 2s, 5s, 10s - faster retries
const MIN_REQUEST_SPACING_MS = 1000; // Force 1s between requests from this client

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Track last request time to enforce spacing
let lastRequestTime = 0;

/**
 * Helper to handle API retries with exponential backoff.
 * Retries on 429 (rate limit) and 503 (service unavailable) errors.
 */
const callGeminiWithRetry = async <T>(fn: () => Promise<T>): Promise<T> => {
  let lastError: any;

  for (let attempt = 0; attempt < BACKOFF_SCHEDULE_MS.length + 1; attempt++) {
    try {
      // Enforce minimum request spacing
      const now = Date.now();
      const timeSinceLastRequest = now - lastRequestTime;
      if (timeSinceLastRequest < MIN_REQUEST_SPACING_MS) {
        await delay(MIN_REQUEST_SPACING_MS - timeSinceLastRequest);
      }

      // Add exponential backoff for retries
      if (attempt > 0) {
        const backoffMs = BACKOFF_SCHEDULE_MS[attempt - 1];
        console.warn(`Retry attempt ${attempt} after ${backoffMs}ms backoff...`);
        await delay(backoffMs);
      }

      lastRequestTime = Date.now();
      return await fn();
    } catch (error: any) {
      lastError = error;
      const isRateLimitError = error?.status === 429 || error?.message?.includes('RESOURCE_EXHAUSTED') || error?.message?.includes('429');
      const isServerError = error?.status === 503 || error?.status === 500 || error?.message?.includes('503') || error?.message?.includes('500');

      if ((isRateLimitError || isServerError) && attempt < BACKOFF_SCHEDULE_MS.length) {
        console.warn(`Gemini API Error (${isRateLimitError ? 'Rate Limit' : 'Server Error'}), retrying...`, error.message);
        continue; // Next iteration (retry)
      }

      // For other errors or final attempt, throw
      throw error;
    }
  }

  throw lastError;
};

const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = error => reject(error);
    reader.readAsDataURL(file);
  });
};

export const validateApiKey = async (): Promise<boolean> => {
  const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY });
  try {
    // Request a single token to test authentication
    await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: { parts: [{ text: "ping" }] },
      config: { maxOutputTokens: 1 }
    });
    return true;
  } catch (error) {
    console.error("Key validation failed:", error);
    return false;
  }
};

const tryParseJSON = (text: string): InvoiceItem[] => {
  if (!text || text.trim() === '') return [];

  // Strategy 1: Direct parse
  try {
    return JSON.parse(text) as InvoiceItem[];
  } catch (e) {
    // Continue
  }

  // Strategy 2: Clean Markdown blocks and trim
  let clean = text.replace(/```json/g, '').replace(/```/g, '').trim();
  try {
    return JSON.parse(clean) as InvoiceItem[];
  } catch (e) {
    // Continue
  }

  // Strategy 3: Find the first '[' and last ']'
  const start = clean.indexOf('[');
  const end = clean.lastIndexOf(']');
  if (start !== -1 && end !== -1) {
    try {
      const substring = clean.substring(start, end + 1);
      return JSON.parse(substring) as InvoiceItem[];
    } catch (e) {
      // Continue
    }
  }

  // Strategy 4: Aggressive Cleanup (Fix trailing commas and control characters)
  try {
    let fixed = clean
      .replace(/,\s*([\]}])/g, '$1') // Remove trailing commas
      .replace(/[\n\r\t]/g, ' ')     // Remove control characters
      .trim();

    const s = fixed.indexOf('[');
    const e = fixed.lastIndexOf(']');
    if (s !== -1 && e !== -1) {
      return JSON.parse(fixed.substring(s, e + 1)) as InvoiceItem[];
    }
  } catch (e) {
    // Fail
  }

  console.error("FAILED TO PARSE JSON. RAW TEXT FOLLOWS:");
  console.error(text);
  throw new Error("Failed to parse JSON after multiple recovery attempts.");
};

export const extractInvoiceData = async (file: File, vendorRules: VendorRule[] = []): Promise<InvoiceItem[]> => {
  const base64Data = await fileToBase64(file);

  const responseSchema = {
    type: Type.ARRAY,
    items: {
      type: Type.OBJECT,
      properties: {
        invoice_date: { type: Type.STRING, description: "YYYY-MM-DD" },
        vendor: { type: Type.STRING },
        invoice_number: { type: Type.STRING },
        item_description: { type: Type.STRING },
        category: {
          type: Type.STRING,
          description: "Select one: Paper-Copy (Copy/Bond/Uncoated), Paper-Cover (Cardstock), Paper-Gloss (Gloss Text/Flyer), Paper-NCR (Carbonless), Paper-Adhesive, Vinyl-Floor, Vinyl-Banner, Vinyl-Adhesive, Ink-HP, Ink-Roland, Substrate-Foam, Substrate-Rigid, Shipping-Fees, Other"
        },
        sheet_size: { type: Type.STRING },
        paper_weight: { type: Type.STRING, description: "Paper weight. For COPY paper use 'lb' format (e.g., '20lb'). For cardstock use 'pt' (e.g., '14pt') or '#' (e.g., '100#'). In pattern 'SIZE-WEIGHT-CODE' like '8.5X11-20-10M-COPY', the '20' = '20lb'" },
        paper_type: { type: Type.STRING, description: "REQUIRED for paper items. Stock type: GLOSS, MATTE, UNCOATED, COPY, BRIGHT, SATIN. Default 'COPY' for Paper-Copy category, 'UNCOATED' if unknown. NEVER leave blank for paper items." },
        paper_finish: { type: Type.STRING, description: "Coating side if specified: C1S, C2S, UV, AQUEOUS. Leave empty if not specified" },
        // Large Format specific fields
        roll_width: { type: Type.STRING, nullable: true, description: "LF ONLY: Roll width in INCHES (e.g., '54' from '54x98'). Extract from size string." },
        roll_length: { type: Type.STRING, nullable: true, description: "LF ONLY: Roll length in FEET (e.g., '98' from '54x98'). Extract from size string." },
        material_thickness: { type: Type.STRING, nullable: true, description: "LF ONLY: Material thickness (e.g., '7MIL', '3.2MIL', '13oz'). Do NOT put in paper_weight." },
        sku: { type: Type.STRING },
        quantity_ordered: { type: Type.NUMBER },
        unit_of_measure: { type: Type.STRING },
        sheets_per_unit: { type: Type.NUMBER, description: "Sheets per unit. If description says '5000/CASE', this = 5000. For industry codes: C=100, M=1000" },
        total_sheets_explicit: { type: Type.NUMBER, nullable: true, description: "Total sheets explicitly stated. If Qty=18 and desc says '5000/CASE', this = 90000" },
        unit_price: { type: Type.NUMBER },
        total_line_price: { type: Type.NUMBER },
        cost_per_sheet: { type: Type.NUMBER },
        notes: { type: Type.STRING },
        confidence_score: { type: Type.STRING, enum: ["high", "medium", "low"] },
        confidence_reason: { type: Type.STRING }
      },
      required: [
        "invoice_date", "vendor", "invoice_number", "item_description",
        "category", "quantity_ordered", "unit_price", "total_line_price",
        "paper_weight", "paper_type", "sheets_per_unit"
      ]
    }
  };

  // Build the system prompt with dynamic vendor rules
  let finalSystemPrompt = SYSTEM_PROMPT;

  if (vendorRules.length > 0) {
    const activeRules = vendorRules.filter(r => r.isActive);
    if (activeRules.length > 0) {
      const rulesText = activeRules.map(r => `- Vendor: "${r.vendorName}" -> Rule: ${r.rule}`).join('\n');
      finalSystemPrompt += `\n\n## USER-DEFINED VENDOR RULES\nAlways apply these rules if the invoice matches the vendor name:\n${rulesText}`;
    }
  }

  try {
    const response = await callGeminiWithRetry(async () => {
      const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          contents: [{
            parts: [
              {
                inline_data: {
                  mime_type: file.type,
                  data: base64Data
                }
              },
              {
                text: "Analyze this invoice and extract all line items according to the system instructions."
              }
            ]
          }],
          system_instruction: {
            parts: [{ text: finalSystemPrompt }]
          },
          generationConfig: {
            response_mime_type: "application/json",
            response_schema: responseSchema,
            temperature: 0.1,
            maxOutputTokens: 8192
          }
        })
      });

      if (!res.ok) {
        const errorText = await res.text();
        const error: any = new Error(`Gemini API Error: ${res.status} ${res.statusText} - ${errorText}`);
        error.status = res.status;
        throw error;
      }

      return await res.json();
    });

    const text = response.candidates?.[0]?.content?.parts?.[0]?.text;
    const finishReason = response.candidates?.[0]?.finishReason;

    if (finishReason === 'MAX_TOKENS') {
      throw new Error("This invoice is extremely large and exceeded the AI's output limit (8,192 tokens). Please try splitting the PDF into smaller parts (e.g., 5 pages each) or upload pages separately.");
    }

    if (!text) {
      if (finishReason === 'SAFETY') {
        throw new Error("Gemini blocked this file due to safety filters (likely PII detection).");
      }
      throw new Error(`Gemini returned empty text. Finish Reason: ${finishReason}`);
    }

    try {
      // Use robust parsing strategy
      const items = tryParseJSON(text);

      // Diagnostic logging for paper fields
      console.log('[Gemini] Parsed items count:', items.length);
      items.forEach((item: any, idx: number) => {
        console.log(`[Gemini] Item ${idx}:`, {
          description: item.item_description?.substring(0, 50),
          paper_weight: item.paper_weight,
          paper_type: item.paper_type,
          paper_finish: item.paper_finish,
          sheets_per_unit: item.sheets_per_unit,
          total_sheets_explicit: item.total_sheets_explicit
        });
      });

      // Attach the filename as source_file to each item for tracking
      return items.map(item => ({ ...item, source_file: file.name }));
    } catch (parseError: any) {
      console.error('JSON Parsing Failed for', file.name);
      console.error('Parse error:', parseError.message);
      throw new Error("Gemini response was not valid JSON format.");
    }
  } catch (error: any) {
    console.error(`Error in extractInvoiceData for ${file.name}:`, error);
    if (error?.message?.includes('RESOURCE_EXHAUSTED') || error?.status === 429) {
      throw new Error("API Limit Exceeded: You've reached your Gemini quota. Please wait a minute or ensure you have a paid tier configured in your Google Cloud Project.");
    }
    throw error;
  }
};