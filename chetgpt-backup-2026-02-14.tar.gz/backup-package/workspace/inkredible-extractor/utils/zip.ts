import JSZip from 'jszip';

export async function extractFilesFromZip(zipFile: File): Promise<File[]> {
  const zip = new JSZip();
  // JSZip.loadAsync can take a File/Blob directly
  const loadedZip = await zip.loadAsync(zipFile);
  const files: File[] = [];
  const promises: Promise<void>[] = [];

  loadedZip.forEach((relativePath, zipEntry) => {
    // Skip directories and hidden files (like __MACOSX)
    if (zipEntry.dir || zipEntry.name.startsWith('__MACOSX') || zipEntry.name.includes('/.')) {
        return;
    }

    const lowerName = zipEntry.name.toLowerCase();
    const isPdf = lowerName.endsWith('.pdf');
    const isImage = lowerName.endsWith('.png') || lowerName.endsWith('.jpg') || lowerName.endsWith('.jpeg');

    if (isPdf || isImage) {
      const promise = zipEntry.async('blob').then((blob) => {
        // Determine mime type
        const type = isPdf ? 'application/pdf' : 
                     lowerName.endsWith('.png') ? 'image/png' : 
                     'image/jpeg';
        
        // Use only the filename, not the full path, to avoid UI clutter
        const fileName = zipEntry.name.split('/').pop() || zipEntry.name;
        
        const file = new File([blob], fileName, { type });
        files.push(file);
      });
      promises.push(promise);
    }
  });

  await Promise.all(promises);
  return files;
}