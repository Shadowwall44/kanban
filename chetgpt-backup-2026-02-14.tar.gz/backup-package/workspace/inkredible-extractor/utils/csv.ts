import { InvoiceItem, CSV_HEADERS } from '../types';

/**
 * Cleans strings for CSV compatibility, specifically fixing encoding issues
 * with the multiplication sign (×) and quotes.
 */
const cleanForCSV = (val: any): string => {
  if (val === null || val === undefined) return '';
  let str = String(val);
  
  // Replace the multiplication sign (×) with standard 'x'
  str = str.replace(/×/g, 'x');
  
  // Fix common corrupted character artifacts
  str = str.replace(/Ã—/g, 'x');
  str = str.replace(/Â/g, '');
  
  // Standardize quotes
  str = str.replace(/[''']/g, "'");
  str = str.replace(/["""]/g, '"');
  
  return str;
};

export const downloadCSV = (items: InvoiceItem[]) => {
  // Sort items: vendor -> invoice_date -> item_description
  const sortedItems = [...items].sort((a, b) => {
    if (a.vendor !== b.vendor) return a.vendor.localeCompare(b.vendor);
    if (a.invoice_date !== b.invoice_date) return a.invoice_date.localeCompare(b.invoice_date);
    return a.item_description.localeCompare(b.item_description);
  });

  const headerRow = CSV_HEADERS.join(',');
  
  const rows = sortedItems.map(item => {
    return CSV_HEADERS.map(header => {
      const value = item[header as keyof InvoiceItem];
      const cleanedValue = cleanForCSV(value);
      
      // Escape quotes and wrap in quotes if contains comma
      if (cleanedValue.includes(',') || cleanedValue.includes('"') || cleanedValue.includes('\n')) {
        return `"${cleanedValue.replace(/"/g, '""')}"`;
      }
      return cleanedValue;
    }).join(',');
  });

  const csvContent = [headerRow, ...rows].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `invoice_extract_${new Date().toISOString().split('T')[0]}.csv`);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};