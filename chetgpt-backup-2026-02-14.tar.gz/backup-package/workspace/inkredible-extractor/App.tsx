import React, { useState, useCallback, useEffect, useRef, useMemo } from 'react';
import {
  FileText, Download, Trash2, AlertCircle, Loader2, Save, Database,
  Plus, CheckCircle, XCircle, Clock, StopCircle, FileIcon, BookOpen, BarChart3, Eye, Zap, Shield,
  Search, Filter, Package
} from 'lucide-react';
import { InvoiceItem, VendorRule } from './types';
import { extractInvoiceData } from './services/geminiService';
import { saveItemsToDb, getDuplicateInvoices, getVendorRules, SavedInvoiceItem, saveLotsFromInvoice } from './services/db';
import { Dropzone } from './components/Dropzone';
import { ResultsTable } from './components/ResultsTable';
import { DatabaseView } from './components/DatabaseView';
import { InventoryView } from './components/InventoryView';
import { RulesManager } from './components/RulesManager';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { PdfPreview } from './components/PdfPreview';
import { downloadCSV } from './utils/csv';
import { extractFilesFromZip } from './utils/zip';
import { Play, Pause, FastForward, RotateCcw, SaveAll } from 'lucide-react';

// Batch Processing Configuration for Free Tier
// Batch Processing Configuration
const FREE_TIER_DELAY = 12000; // 12 seconds
const TURBO_DELAY = 100; // 100ms
const FREE_TIER_CONCURRENCY = 1;
const TURBO_CONCURRENCY = 3; // Reduced from 5 to prevent API overload

type Tab = 'extract' | 'database' | 'rules' | 'analytics' | 'inventory';

interface FileStatus {
  name: string;
  status: 'pending' | 'processing' | 'completed' | 'error' | 'skipped';
  errorMessage?: string;
  startTime?: number;
  endTime?: number;
  duration?: number; // in seconds
}

const CircularProgress = ({ percentage, size = 60, strokeWidth = 5 }: { percentage: number; size?: number; strokeWidth?: number }) => {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (percentage / 100) * circumference;

  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      <svg className="transform -rotate-90 w-full h-full">
        <circle
          className="text-gray-200"
          strokeWidth={strokeWidth}
          stroke="currentColor"
          fill="transparent"
          r={radius}
          cx={size / 2}
          cy={size / 2}
        />
        <circle
          className="text-[#017494] transition-all duration-500 ease-out"
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          stroke="currentColor"
          fill="transparent"
          r={radius}
          cx={size / 2}
          cy={size / 2}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center text-xs font-bold text-[#0F1011]">
        {Math.round(percentage || 0)}%
      </div>
    </div>
  );
};

const ProcessingSpinner = () => (
  <div className="relative flex items-center justify-center">
    <Loader2 className="w-5 h-5 text-[#017494] animate-spin" />
  </div>
);

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('extract');
  const [extractedItems, setExtractedItems] = useState<InvoiceItem[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isTurboMode, setIsTurboMode] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
  const [processingQueue, setProcessingQueue] = useState<FileStatus[]>([]);

  const [isPaused, setIsPaused] = useState(false);
  const [completedInLastMinute, setCompletedInLastMinute] = useState<number[]>([]); // timestamps
  const [sessionRestored, setSessionRestored] = useState(false);

  const [filesMap, setFilesMap] = useState<Record<string, File>>({});
  const [previewFile, setPreviewFile] = useState<File | null>(null);

  const abortRef = useRef<boolean>(false);
  const isPausedRef = useRef<boolean>(false); // ref for sync access in loop
  const skippedFilesRef = useRef<Set<string>>(new Set());
  const listRef = useRef<HTMLDivElement>(null);
  const startTimeRef = useRef<number>(0);
  // No longer using currentDuration as it's localized in ProcessTimer

  // Filter State
  const [filterSearch, setFilterSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState('All');
  const [filterNeedsReview, setFilterNeedsReview] = useState(false);

  // Derive unique categories from current batch
  const uniqueCategories = useMemo(() => {
    const categories = new Set(extractedItems.map(i => i.category).filter(Boolean));
    return ['All', ...Array.from(categories).sort()];
  }, [extractedItems]);

  // Filtering Logic
  const filteredItems = useMemo(() => {
    return extractedItems.filter(item => {
      // 1. Search Text (Smart)
      const searchLower = filterSearch.toLowerCase();
      const matchesSearch = !filterSearch ||
        (item.vendor || '').toLowerCase().includes(searchLower) ||
        (item.item_description || '').toLowerCase().includes(searchLower) ||
        (item.invoice_number || '').toLowerCase().includes(searchLower) ||
        (item.sku || '').toLowerCase().includes(searchLower);

      // 2. Category Filter
      const matchesCategory = filterCategory === 'All' || item.category === filterCategory;

      // 3. Needs Review Toggle
      let matchesReview = true;
      if (filterNeedsReview) {
        const price = Number(item.unit_price);
        const qty = Number(item.quantity_ordered);
        const isInvalidPrice = isNaN(price) || price === 0 || !item.unit_price;
        const isInvalidQty = isNaN(qty) || qty === 0 || !item.quantity_ordered;
        const isLowConfidence = item.confidence_score === 'low';

        matchesReview = isInvalidPrice || isInvalidQty || isLowConfidence;
      }

      return matchesSearch && matchesCategory && matchesReview;
    });
  }, [extractedItems, filterSearch, filterCategory, filterNeedsReview]);

  // Stats Calculation (Moved up to fix lint error)
  const completedCount = processingQueue.filter(i => i.status === 'completed').length;
  const errorCount = processingQueue.filter(i => i.status === 'error').length;
  const skippedCount = processingQueue.filter(i => i.status === 'skipped').length;
  const totalCount = processingQueue.length;
  const processedCount = completedCount + errorCount + skippedCount;
  const progressPercentage = totalCount > 0 ? (processedCount / totalCount) * 100 : 0;
  const currentProcessingItem = processingQueue.find(i => i.status === 'processing');

  // Sync ref with state
  useEffect(() => {
    isPausedRef.current = isPaused;
  }, [isPaused]);

  // Persistence: Load on Mount
  useEffect(() => {
    const savedQueue = localStorage.getItem('processingQueue');
    const savedItems = localStorage.getItem('extractedItems');
    if (savedQueue && savedItems) {
      try {
        const queue = JSON.parse(savedQueue);
        const items = JSON.parse(savedItems);
        if (queue.length > 0) {
          if (window.confirm("Found an active batch session. Resume where you left off?")) {
            setProcessingQueue(queue);
            setExtractedItems(items);
            setIsProcessing(true); // Attempt to auto-resume visual state
            setSessionRestored(true);
          } else {
            localStorage.removeItem('processingQueue');
            localStorage.removeItem('extractedItems');
          }
        }
      } catch (e) {
        console.error("Failed to restore session", e);
      }
    }
  }, []);

  // Persistence: Save on Change
  useEffect(() => {
    if (processingQueue.length > 0) {
      try {
        localStorage.setItem('processingQueue', JSON.stringify(processingQueue));
        localStorage.setItem('extractedItems', JSON.stringify(extractedItems));
      } catch (e) {
        console.warn("Failed to save session to localStorage (quota likely exceeded)", e);
      }
    } else if (sessionRestored && processingQueue.length === 0) {
      // Clear when done
      localStorage.removeItem('processingQueue');
      localStorage.removeItem('extractedItems');
    }
  }, [processingQueue, extractedItems, sessionRestored]);

  // Speed Logic
  useEffect(() => {
    if (completedCount > 0) {
      setCompletedInLastMinute(prev => [...prev, Date.now()]);
    }
  }, [completedCount]);

  // Cleanup old timestamps
  const filesPerMinute = completedInLastMinute.filter(t => Date.now() - t < 60000).length;

  // Timer component to prevent whole-app re-renders
  const ProcessTimer = ({ isProcessing }: { isProcessing: boolean }) => {
    const [elapsed, setElapsed] = useState(0);

    useEffect(() => {
      let interval: number;
      if (isProcessing) {
        const start = Date.now();
        interval = window.setInterval(() => {
          setElapsed((Date.now() - start) / 1000);
        }, 100);
      } else {
        setElapsed(0);
      }
      return () => clearInterval(interval);
    }, [isProcessing]);

    return (
      <span className="text-[10px] font-bold bg-white text-[#017494] px-1.5 py-0.5 rounded border border-[#017494]/20 animate-pulse">
        {elapsed.toFixed(1)}s
      </span>
    );
  };

  // Auto-scroll to keep processing file centered in view
  useEffect(() => {
    if (isProcessing && listRef.current) {
      const processingIdx = processingQueue.findIndex(p => p.status === 'processing');
      if (processingIdx !== -1) {
        const listNode = listRef.current;
        const itemHeight = 72; // Height of each list item
        const containerHeight = listNode.clientHeight;

        // Center the processing item in the visible area
        const targetScroll = (processingIdx * itemHeight) - (containerHeight / 2) + (itemHeight / 2);
        const clampedScroll = Math.max(0, targetScroll);

        listNode.scrollTo({ top: clampedScroll, behavior: 'smooth' });
      }
    }
  }, [processingQueue, isProcessing]);

  const handleStopProcessing = () => {
    abortRef.current = true;
    setIsProcessing(false);
  };

  const handleSkip = (fileName: string) => {
    skippedFilesRef.current.add(fileName);
    setProcessingQueue(prev => prev.map(item =>
      item.name === fileName ? { ...item, status: 'skipped' } : item
    ));
  };

  const handleRetryFailed = () => {
    const failedFiles = processingQueue
      .filter(item => item.status === 'error')
      .map(item => filesMap[item.name])
      .filter(Boolean);

    if (failedFiles.length === 0) return;

    if (window.confirm(`Retry ${failedFiles.length} failed files?`)) {
      handleFilesSelected(failedFiles);
    }
  };

  const handleFilesSelected = useCallback(async (files: File[]) => {
    setIsProcessing(true);
    setError(null);
    setSaveStatus('idle');
    setProcessingQueue([]);
    skippedFilesRef.current = new Set();
    abortRef.current = false;

    // Determine delay based on mode at start of process
    const processDelay = isTurboMode ? 1000 : 12000;

    let vendorRules: VendorRule[] = [];
    try {
      vendorRules = await getVendorRules();
    } catch (e) {
      console.error("Failed to load rules", e);
    }

    const errors: string[] = [];
    const filesToProcess: File[] = [];
    const newFilesMap: Record<string, File> = {};

    try {
      for (const file of files) {
        const lowerName = file.name.toLowerCase();
        if (lowerName.endsWith('.zip') || file.type.includes('zip')) {
          try {
            const extractedFiles = await extractFilesFromZip(file);
            if (extractedFiles.length === 0) {
              errors.push(`No valid PDF or Image files found in ${file.name}`);
            }
            filesToProcess.push(...extractedFiles);
          } catch (e: any) {
            console.error(`Error unzipping ${file.name}:`, e);
            errors.push(`Failed to unzip ${file.name}: ${e.message || 'Unknown error'}`);
          }
        } else {
          filesToProcess.push(file);
        }
      }

      filesToProcess.forEach(f => {
        newFilesMap[f.name] = f;
      });
      setFilesMap(prev => ({ ...prev, ...newFilesMap }));

      if (filesToProcess.length === 0 && errors.length > 0) {
        setError(errors.join('\n'));
        return;
      }

      setProcessingQueue(filesToProcess.map(f => ({ name: f.name, status: 'pending' })));

      // Small delay to ensure UI renders before heavy processing starts
      await new Promise(resolve => setTimeout(resolve, 50));

      // Main Processing Loop - Concurrency control
      const concurrency = isTurboMode ? 2 : 1; // 2 for turbo, 1 for safe
      let currentIndex = 0;
      const activePromises: Promise<void>[] = [];

      const processNext = async () => {
        if (abortRef.current || currentIndex >= filesToProcess.length) return;

        // PAUSE LOGIC: Spin wait if paused
        while (isPausedRef.current && !abortRef.current) {
          await new Promise(resolve => setTimeout(resolve, 500));
        }
        if (abortRef.current) return;

        const i = currentIndex++;
        const file = filesToProcess[i];

        // Check if file was skipped via UI
        if (skippedFilesRef.current.has(file.name)) {
          // Already marked as skipped, continue to next
          if (!abortRef.current && currentIndex < filesToProcess.length) {
            await processNext();
          }
          return;
        }

        // Update UI to Processing
        const startTime = Date.now();
        setProcessingQueue(prev => prev.map((item, idx) =>
          idx === i ? { ...item, status: 'processing', startTime } : item
        ));

        try {
          const extractedItems = await extractInvoiceData(file, vendorRules);

          if (abortRef.current) {
            setProcessingQueue(prev => prev.map((item, idx) =>
              idx === i ? { ...item, status: 'skipped' } : item
            ));
            return;
          }

          const endTime = Date.now();
          const duration = (endTime - startTime) / 1000;

          setExtractedItems(prev => abortRef.current ? [] : [...prev, ...extractedItems]);
          setProcessingQueue(prev => prev.map((item, idx) =>
            idx === i ? { ...item, status: 'completed', endTime, duration } : item
          ));
        } catch (err: any) {
          if (abortRef.current) {
            setProcessingQueue(prev => prev.map((item, idx) =>
              idx === i ? { ...item, status: 'skipped' } : item
            ));
            return;
          }

          console.error(`Error processing ${file.name}:`, err);
          const endTime = Date.now();
          const duration = (endTime - startTime) / 1000;

          errors.push(`Failed to process ${file.name}: ${err.message || 'Unknown error'}`);
          setProcessingQueue(prev => prev.map((item, idx) =>
            idx === i ? { ...item, status: 'error', errorMessage: err.message, endTime, duration } : item
          ));
        }

        // Apply enforced delay for free tier if not the last item and not aborted
        if (i < filesToProcess.length - 1 && !abortRef.current && !isTurboMode) {
          console.log(`Waiting ${processDelay}ms before next file to respect API limits...`);
          await new Promise(resolve => setTimeout(resolve, processDelay));
        }
        // Keep chain alive (check pause again before recursing)
        if (!abortRef.current && currentIndex < filesToProcess.length) {
          await processNext();
        }
      };

      // Start initial batch with staggered timing to prevent API overload
      for (let k = 0; k < concurrency; k++) {
        // Stagger starts by 200ms to avoid simultaneous API hits
        if (k > 0) await new Promise(resolve => setTimeout(resolve, 200));
        activePromises.push(processNext());
      }

      await Promise.all(activePromises);

      // Final check for errors
      const finalErrors = processingQueue.filter(p => p.status === 'error').length;
      if (finalErrors > 0 && !abortRef.current) {
        // Notification logic handled by stats card now
      }
    } finally {
      setIsProcessing(false);
      startTimeRef.current = 0;
      // Clear persistence if done (success or full clear handled explicitly)
    }
  }, [isTurboMode, isPausedRef]);

  const handleClearBatch = () => {
    console.log('CLEAR CLICKED - items before:', extractedItems.length);

    // Stop any ongoing processing
    abortRef.current = true;
    setIsProcessing(false);

    // Clear the main data state
    setExtractedItems([]);

    // Reset all other related states
    setProcessingQueue([]);
    setFilesMap({});
    setPreviewFile(null);
    setError(null);
    setSaveStatus('idle');
    skippedFilesRef.current = new Set();
    startTimeRef.current = 0;

    console.log('CLEAR COMPLETE');
    alert('Batch cleared!');
  };

  const handleUpdateItem = (index: number, updatedItem: InvoiceItem) => {
    const newItems = [...extractedItems];
    newItems[index] = updatedItem;
    setExtractedItems(newItems);
  };

  const handlePreviewFile = (filename: string) => {
    const file = filesMap[filename];
    if (file) {
      setPreviewFile(file);
    } else {
      alert("File not available for preview.");
    }
  };

  const handleSaveToDatabase = async () => {
    setSaveStatus('saving');
    try {
      const duplicates = await getDuplicateInvoices(extractedItems);
      let itemsToSave = extractedItems;

      if (duplicates.length > 0) {
        const message = `Duplicate Invoices Detected:\n\nThe following invoices are already in the database:\n${duplicates.map(d => `• ${d}`).join('\n')}\n\nClick OK to SKIP these duplicates and save only new invoices.`;
        const shouldSkip = window.confirm(message);
        if (!shouldSkip) {
          setSaveStatus('idle');
          return;
        }
        const duplicateSet = new Set(duplicates);
        itemsToSave = extractedItems.filter(item => !duplicateSet.has(`${item.vendor} #${item.invoice_number}`));
        if (itemsToSave.length === 0) {
          alert("All items were skipped because they are already in the database.");
          setSaveStatus('idle');
          return;
        }
      }

      await saveItemsToDb(itemsToSave);
      await saveLotsFromInvoice(itemsToSave);
      setSaveStatus('saved');

      setTimeout(() => {
        setActiveTab('database');
        setExtractedItems([]);
        setSaveStatus('idle');
        setProcessingQueue([]);
      }, 1000);

    } catch (e) {
      console.error(e);
      alert('Failed to save to database');
      setSaveStatus('idle');
    }
  };

  const handleExport = () => {
    if (extractedItems.length === 0) return;
    downloadCSV(extractedItems);
  };

  // Stats calculation moved to top

  const navButtonClass = (tab: Tab) =>
    `px-4 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-2 
    ${activeTab === tab
      ? 'bg-[#0F1011] text-white shadow-md transform scale-105'
      : 'text-gray-600 hover:bg-gray-200 hover:text-[#0F1011]'}`;

  return (
    <div className="min-h-screen bg-[#F5F7FA] flex flex-col font-sans">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10 shadow-sm">
        <div className="w-full px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 flex-shrink-0">
            <div className="bg-[#0F1011] p-2 rounded-xl shadow-lg">
              <FileText className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold text-[#0F1011] tracking-tight hidden sm:block">
              INKredible <span className="text-[#017494]">Extractor</span>
            </h1>
          </div>

          <div className="flex items-center gap-3 sm:gap-4 flex-1 justify-end">
            <div className="hidden md:flex bg-gray-100 p-1.5 rounded-xl border border-gray-200 flex-shrink-0">
              <button onClick={() => setActiveTab('extract')} className={navButtonClass('extract')}>
                <Plus className="w-4 h-4" /> New
              </button>
              <button onClick={() => setActiveTab('database')} className={navButtonClass('database')}>
                <Database className="w-4 h-4" /> History
              </button>
              <button onClick={() => setActiveTab('analytics')} className={navButtonClass('analytics')}>
                <BarChart3 className="w-4 h-4" /> Analytics
              </button>
              <button onClick={() => setActiveTab('rules')} className={navButtonClass('rules')}>
                <BookOpen className="w-4 h-4" /> Rules
              </button>
              <button onClick={() => setActiveTab('inventory')} className={navButtonClass('inventory')}>
                <Package className="w-4 h-4" /> Inventory
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className={`flex-1 w-full px-4 sm:px-6 lg:px-8 py-8 space-y-8 transition-all duration-300 ${previewFile ? 'pr-[43%]' : ''}`}>
        <div className="md:hidden flex bg-gray-100 p-1 rounded-lg mb-6 overflow-x-auto border border-gray-200">
          {['extract', 'database', 'inventory', 'analytics', 'rules'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as Tab)}
              className={`flex-1 whitespace-nowrap px-4 py-2 rounded-md text-sm font-medium capitalize ${activeTab === tab ? 'bg-[#0F1011] text-white shadow-sm' : 'text-gray-500'}`}
            >
              {tab === 'extract' ? 'New' : tab}
            </button>
          ))}
        </div>

        {activeTab === 'database' ? (
          <DatabaseView />
        ) : activeTab === 'inventory' ? (
          <InventoryView />
        ) : activeTab === 'rules' ? (
          <RulesManager />
        ) : activeTab === 'analytics' ? (
          <DbAnalyticsWrapper />
        ) : (
          <>
            <div className="mb-8">
              <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden mb-6">
                <div className="px-6 py-4 border-b border-gray-100 bg-gray-50 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${isTurboMode ? 'bg-amber-100 text-amber-600' : 'bg-green-100 text-green-600'}`}>
                      {isTurboMode ? <Zap className="w-5 h-5" /> : <Shield className="w-5 h-5" />}
                    </div>
                    <div>
                      <h3 className="font-bold text-[#0F1011]">Processing Speed</h3>
                      <p className="text-xs text-gray-500">
                        {isTurboMode ? 'Turbo Mode: Maximum speed (Requires Paid API)' : 'Safe Mode: optimized for Free Tier'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 bg-gray-200 p-1 rounded-xl">
                    <button
                      onClick={() => setIsTurboMode(false)}
                      className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-all duration-200
                                    ${!isTurboMode
                          ? 'bg-white text-green-700 shadow-md transform scale-105'
                          : 'text-gray-500 hover:text-gray-700 hover:bg-gray-300/50'}`}
                    >
                      <Shield className="w-4 h-4" /> Safe
                    </button>
                    <button
                      onClick={() => setIsTurboMode(true)}
                      className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-all duration-200
                                    ${isTurboMode
                          ? 'bg-[#0F1011] text-white shadow-md transform scale-105'
                          : 'text-gray-500 hover:text-gray-700 hover:bg-gray-300/50'}`}
                    >
                      <Zap className="w-4 h-4" /> Turbo
                    </button>
                  </div>
                </div>
                {isTurboMode && (
                  <div className="px-6 py-3 bg-amber-50 text-amber-800 text-xs border-t border-amber-100 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <strong>Warning:</strong> Only use Turbo Mode if you have confirmed your Google Cloud project is on "Pay-as-you-go". Free accounts will fail.
                  </div>
                )}
              </div>

              <Dropzone onFilesSelected={handleFilesSelected} disabled={isProcessing} />
            </div>

            <div className="border-b border-gray-200 pb-8 mb-4">
              <div className="flex items-center justify-between px-1 mb-4">
                <h2 className="text-xl font-bold text-[#0F1011]">Current Batch Insights</h2>
                {filteredItems.length !== extractedItems.length && (
                  <span className="text-xs font-bold text-[#017494] bg-[#017494]/10 px-2 py-1 rounded-lg border border-[#017494]/20">
                    Showing filtered data ({filteredItems.length} of {extractedItems.length})
                  </span>
                )}
              </div>
              <AnalyticsDashboard items={filteredItems} mode="batch" />
            </div>

            {processingQueue.length > 0 && (
              <div className="max-w-3xl mx-auto mb-6 bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-lg shadow-gray-200/50">
                <div className="p-5 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                  <div className="flex items-center gap-5">
                    <CircularProgress percentage={progressPercentage} size={54} strokeWidth={5} />
                    <div>
                      <div className="flex items-center gap-3 mb-1">
                        <h3 className="font-bold text-[#0F1011] text-lg">Batch Progress</h3>
                        {/* Control Center */}
                        {isProcessing ? (
                          <button onClick={() => setIsPaused(p => !p)} className="p-1 hover:bg-gray-100 rounded-full transition-colors" title={isPaused ? "Resume" : "Pause"}>
                            {isPaused ? <Play className="w-5 h-5 text-green-600 fill-current" /> : <Pause className="w-5 h-5 text-gray-600 fill-current" />}
                          </button>
                        ) : errorCount > 0 ? (
                          <button onClick={handleRetryFailed} className="flex items-center gap-1 text-xs font-bold text-white bg-red-500 hover:bg-red-600 px-2 py-1 rounded-lg transition-colors">
                            <RotateCcw className="w-3 h-3" /> Retry Failed
                          </button>
                        ) : null}

                        {isProcessing && isPaused && (
                          <span className="text-xs font-bold text-amber-500 bg-amber-50 px-2 py-0.5 rounded border border-amber-100">PAUSED</span>
                        )}
                      </div>
                      <div className="text-sm text-gray-500 flex items-center gap-3">
                        <span>Done: <strong className="text-green-600">{completedCount}/{totalCount}</strong></span>
                        {errorCount > 0 && <span>Errors: <strong className="text-red-600">{errorCount}</strong></span>}
                        {filesPerMinute > 0 && <span className="text-xs bg-gray-100 px-1.5 py-0.5 rounded text-gray-600 hidden sm:inline-block">{filesPerMinute} items/min</span>}
                      </div>
                    </div>
                  </div>

                  {isProcessing && (
                    <button
                      onClick={handleStopProcessing}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-red-50 text-red-700 rounded-lg text-xs font-bold hover:bg-red-100 transition-colors border border-red-200"
                    >
                      <StopCircle className="w-3.5 h-3.5" /> Cancel
                    </button>
                  )}
                </div>



                <div ref={listRef} className="divide-y divide-gray-100 max-h-64 overflow-y-auto bg-white border-t border-gray-100">
                  {processingQueue.map((item, idx) => {
                    const isProcessingItem = item.status === 'processing';
                    return (
                      <div
                        key={idx}
                        data-status={item.status}
                        className={`px-5 py-4 flex items-center justify-between transition-all duration-200 min-h-[72px] ${isProcessingItem ? 'bg-[#F0F9FF] border-l-4 border-l-[#017494]' : 'bg-white'
                          }`}
                      >
                        <div className="flex items-center gap-4 overflow-hidden w-full">
                          <div className="flex-shrink-0 w-5 flex justify-center">
                            {item.status === 'pending' && <Clock className="w-4 h-4 text-gray-300" />}
                            {item.status === 'skipped' && <StopCircle className="w-4 h-4 text-gray-400" />}
                            {isProcessingItem && <Loader2 className="w-4 h-4 text-[#017494] animate-spin" />}
                            {item.status === 'completed' && <CheckCircle className="w-5 h-5 text-green-500" />}
                            {item.status === 'error' && <XCircle className="w-5 h-5 text-red-500" />}
                          </div>

                          <div className="flex flex-col min-w-0 flex-1">
                            <div className="flex items-center gap-2">
                              <span className={`text-sm truncate ${isProcessingItem ? 'font-bold text-[#017494]' : 'text-gray-700'}`}>
                                {item.name}
                              </span>
                              {isProcessingItem && (
                                <ProcessTimer isProcessing={isProcessingItem} />
                              )}
                            </div>
                            {item.errorMessage && (
                              <span className="text-[11px] text-red-500 font-medium truncate mt-0.5">
                                {item.errorMessage}
                              </span>
                            )}
                          </div>

                          <div className="flex-shrink-0">
                            {item.duration && !isProcessingItem && (
                              <span className="text-xs text-gray-400 font-mono bg-gray-50 px-2 py-1 rounded border border-gray-100">
                                {item.duration.toFixed(1)}s
                              </span>
                            )}

                            {item.status === 'pending' && (
                              <button
                                onClick={() => handleSkip(item.name)}
                                className="p-1.5 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                                title="Skip this file"
                              >
                                <FastForward className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {error && (
              <div className="max-w-3xl mx-auto mb-6 bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3 text-red-700 text-sm shadow-sm">
                <AlertCircle className="w-5 h-5 shrink-0" />
                <div className="whitespace-pre-line font-medium">{error}</div>
              </div>
            )}

            <section className="space-y-6 pt-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
                <h2 className="text-xl font-bold text-[#0F1011] flex items-center gap-3">
                  Extracted Items
                  {extractedItems.length > 0 && (
                    <span className="bg-gray-100 text-gray-600 text-xs font-bold px-2.5 py-1 rounded-full border border-gray-200">
                      {extractedItems.length} items
                    </span>
                  )}
                </h2>
                <div className="flex items-center gap-3 w-full sm:w-auto">
                  <button
                    onClick={handleClearBatch}
                    disabled={extractedItems.length === 0 && processingQueue.length === 0}
                    className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 bg-white border border-red-200 rounded-xl text-red-600 hover:bg-red-50 transition-all text-sm font-semibold disabled:opacity-50 disabled:cursor-not-allowed shadow-sm active:scale-95"
                  >
                    <Trash2 className="w-4 h-4" /> Clear Batch
                  </button>
                  <button
                    onClick={handleExport}
                    disabled={extractedItems.length === 0}
                    className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 bg-[#017494] rounded-xl text-white hover:bg-[#015e7a] transition-all text-sm font-semibold disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl active:scale-95"
                  >
                    <Download className="w-4 h-4" /> Export CSV
                  </button>
                  <button
                    onClick={handleSaveToDatabase}
                    disabled={saveStatus !== 'idle' || extractedItems.length === 0}
                    className={`
                        flex-1 sm:flex-none flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl shadow-lg hover:shadow-xl transition-all transform active:scale-95 text-sm font-bold disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none disabled:shadow-none
                        ${saveStatus === 'saved' ? 'bg-green-600 text-white' : 'bg-[#0F1011] text-white hover:bg-[#2A2B2C] border border-transparent'}
                      `}
                  >
                    {saveStatus === 'saving' ? <Loader2 className="w-4 h-4 animate-spin" /> : saveStatus === 'saved' ? <Save className="w-4 h-4" /> : <Database className="w-4 h-4" />}
                    {saveStatus === 'saved' ? 'Saved!' : 'Save to Database'}
                  </button>
                </div>
              </div>

              {extractedItems.length > 0 && (
                <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm space-y-4">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    {/* Smart Search */}
                    <div className="relative flex-1 max-w-md">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input
                        type="text"
                        placeholder="Search Vendor, Invoice #, Description, or SKU..."
                        value={filterSearch}
                        onChange={(e) => setFilterSearch(e.target.value)}
                        className="w-full pl-9 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#017494] focus:border-transparent transition-all"
                      />
                    </div>

                    {/* Review Mode Toggle */}
                    <div className="flex items-center gap-3 px-4 py-2 bg-amber-50 rounded-xl border border-amber-100">
                      <label className="flex items-center cursor-pointer gap-2 select-none">
                        <input
                          type="checkbox"
                          className="hidden"
                          checked={filterNeedsReview}
                          onChange={() => setFilterNeedsReview(!filterNeedsReview)}
                        />
                        <div className={`w-10 h-5 flex items-center rounded-full p-1 transition-colors ${filterNeedsReview ? 'bg-amber-500' : 'bg-gray-300'}`}>
                          <div className={`bg-white w-3 h-3 rounded-full shadow-md transform transition-transform ${filterNeedsReview ? 'translate-x-5' : ''}`} />
                        </div>
                        <span className="text-xs font-bold text-amber-700 flex items-center gap-1">
                          <AlertCircle className="w-3.5 h-3.5" /> Needs Review
                        </span>
                      </label>
                    </div>
                  </div>

                  {/* Category Chips */}
                  <div className="flex flex-wrap items-center gap-2 pt-2">
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mr-2">Quick Filter:</span>
                    {uniqueCategories.map(cat => (
                      <button
                        key={cat}
                        onClick={() => setFilterCategory(cat)}
                        className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all border ${filterCategory === cat
                          ? 'bg-[#017494] text-white border-[#017494] shadow-md scale-105'
                          : 'bg-white text-gray-600 border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                          }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {extractedItems.length > 0 ? (
                <div className="space-y-4">
                  {filteredItems.length > 0 ? (
                    <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
                      <ResultsTable
                        items={filteredItems}
                        onUpdateItem={handleUpdateItem}
                        onPreview={handlePreviewFile}
                      />
                    </div>
                  ) : (
                    <div className="bg-white p-16 rounded-2xl border border-gray-200 shadow-sm text-center">
                      <div className="bg-gray-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Search className="w-8 h-8 text-gray-400" />
                      </div>
                      <h3 className="text-lg font-bold text-[#0F1011]">No matching items found</h3>
                      <p className="text-xs text-gray-500 mt-1">Try adjusting your filters or search query.</p>
                      <button
                        onClick={() => { setFilterSearch(''); setFilterCategory('All'); setFilterNeedsReview(false); }}
                        className="mt-4 text-[#017494] text-xs font-bold hover:underline"
                      >
                        Reset all filters
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden opacity-70">
                  <div className="px-6 py-4 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <FileIcon className="w-4 h-4 text-gray-400" />
                      <h3 className="font-semibold text-gray-500 text-sm">Extracted Items</h3>
                    </div>
                  </div>
                  <ResultsTable items={[]} readonly={true} />
                  <div className="p-12 text-center text-gray-400 bg-white">
                    No data. Upload invoices to begin.
                  </div>
                </div>
              )}
            </section>
          </>
        )}
      </main>

      {previewFile && <PdfPreview file={previewFile} onClose={() => setPreviewFile(null)} />}
    </div>
  );
}

const DbAnalyticsWrapper = () => {
  const [dbItems, setDbItems] = useState<SavedInvoiceItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const { getAllItems } = await import('./services/db');
      const data = await getAllItems();
      setDbItems(data);
      setLoading(false);
    };
    load();
  }, []);

  if (loading) return <div className="p-8 text-center text-gray-500">Loading Analytics Data...</div>;

  return <AnalyticsDashboard items={dbItems} />;
};