import React, { useState, useMemo, useCallback, useRef, useEffect } from 'react';
import { InvoiceItem } from '../types';
import { Eye, ArrowUp, ArrowDown, AlertCircle, Info, RotateCcw } from 'lucide-react';

interface ResultsTableProps {
    items: InvoiceItem[];
    onUpdateItem?: (index: number, updatedItem: InvoiceItem) => void;
    onPreview?: (filename: string) => void;
    readonly?: boolean;
}

type SortDirection = 'asc' | 'desc';

interface SortConfig {
    key: keyof InvoiceItem;
    direction: SortDirection;
}

// Default widths for columns
const DEFAULT_WIDTHS: Record<string, number> = {
    row_index: 40,
    invoice_date: 95,
    vendor: 140,
    invoice_number: 100,
    item_description: 240,
    category: 130,
    sheet_size: 90,
    paper_weight: 70,
    paper_type: 80,
    material_thickness: 70, // LF
    roll_width: 60,         // LF
    roll_length: 60,        // LF
    quantity_ordered: 70,
    unit_price: 90,
    total_line_price: 90,
    sheets_per_unit: 90,
    total_sheets_explicit: 100,
    cost_per_sheet: 100,
    notes: 150
};

export const ResultsTable: React.FC<ResultsTableProps> = ({ items, onUpdateItem, onPreview, readonly = false }) => {
    const [editingCell, setEditingCell] = useState<{ idx: number, field: keyof InvoiceItem } | null>(null);
    const [sortConfig, setSortConfig] = useState<SortConfig>({ key: 'invoice_date', direction: 'desc' });

    // Sanitize numeric inputs (strip $ , characters)
    const parseNumber = (val: any) => {
        if (typeof val === 'number') return val;
        if (!val) return 0;
        const str = String(val).replace(/[^0-9.-]/g, '');
        return parseFloat(str) || 0;
    };

    // Resizing State
    const [columnWidths, setColumnWidths] = useState<Record<string, number>>(DEFAULT_WIDTHS);
    const resizingRef = useRef<{ field: string, startX: number, startWidth: number } | null>(null);

    const handleMouseDown = useCallback((e: React.MouseEvent, field: string) => {
        e.preventDefault();
        e.stopPropagation();
        resizingRef.current = {
            field,
            startX: e.pageX,
            startWidth: columnWidths[field] || 100
        };
        document.addEventListener('mousemove', handleMouseMove);
        document.addEventListener('mouseup', handleMouseUp);
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';
    }, [columnWidths]);

    const handleMouseMove = useCallback((e: MouseEvent) => {
        if (!resizingRef.current) return;
        const { field, startX, startWidth } = resizingRef.current;
        const delta = e.pageX - startX;
        const newWidth = Math.max(50, startWidth + delta); // Minimum 50px

        setColumnWidths(prev => ({
            ...prev,
            [field]: newWidth
        }));
    }, []);

    const handleMouseUp = useCallback(() => {
        resizingRef.current = null;
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
    }, [handleMouseMove]);

    // Cleanup on unmount
    useEffect(() => {
        return () => {
            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
        };
    }, [handleMouseMove, handleMouseUp]);

    const dataWithIndex = useMemo(() => {
        return items.map((item, idx) => ({ ...item, _originalIndex: idx }));
    }, [items]);

    // Smart column visibility: determine if we have LF or SF items
    const { hasLFItems, hasSFItems } = useMemo(() => {
        let lf = false;
        let sf = false;
        for (const item of items) {
            const fmt = getFormat(item.category, item.sheet_size);
            if (fmt === 'LF') lf = true;
            if (fmt === 'SF') sf = true;
            if (lf && sf) break; // No need to continue
        }
        return { hasLFItems: lf, hasSFItems: sf };
    }, [items]);

    const sortedData = useMemo(() => {
        if (!sortConfig) return dataWithIndex;

        return [...dataWithIndex].sort((a, b) => {
            const valA = a[sortConfig.key];
            const valB = b[sortConfig.key];

            if (valA === valB) return 0;
            if (valA === null || valA === undefined) return 1;
            if (valB === null || valB === undefined) return -1;

            if (typeof valA === 'number' && typeof valB === 'number') {
                return sortConfig.direction === 'asc' ? valA - valB : valB - valA;
            }

            const strA = String(valA).toLowerCase();
            const strB = String(valB).toLowerCase();
            const compare = strA.localeCompare(strB, undefined, { numeric: true, sensitivity: 'base' });

            return sortConfig.direction === 'asc' ? compare : -compare;
        });
    }, [dataWithIndex, sortConfig]);

    const handleSort = (key: keyof InvoiceItem) => {
        setSortConfig(current => {
            if (current.key === key) {
                return { key, direction: current.direction === 'asc' ? 'desc' : 'asc' };
            }
            return { key, direction: 'asc' };
        });
    };

    const getCategoryStyle = (category: any = '') => {
        const cat = String(category || '').toLowerCase();
        if (cat.includes('foam')) return 'bg-[#F59E0B]/10 text-[#F59E0B] border-[#F59E0B]/20';
        if (cat.includes('floor') || cat.includes('vinyl')) return 'bg-[#017494]/10 text-[#017494] border-[#017494]/20';
        if (cat.includes('adhesive')) return 'bg-amber-100 text-amber-700 border-amber-200';
        if (cat.includes('ncr') || cat.includes('carbonless')) return 'bg-indigo-100 text-indigo-700 border-indigo-200';
        if (cat.includes('gloss') || cat.includes('satin')) return 'bg-cyan-100 text-cyan-700 border-cyan-200';
        if (cat.includes('copy') || cat.includes('cover') || cat.includes('paper')) return 'bg-emerald-100 text-emerald-700 border-emerald-200';
        if (cat.includes('roland') || cat.includes('latex') || cat.includes('solvent') || cat.includes('ink')) return 'bg-[#3B82F6]/10 text-[#3B82F6] border-[#3B82F6]/20';
        if (cat.includes('laminate')) return 'bg-[#8B5CF6]/10 text-[#8B5CF6] border-[#8B5CF6]/20';
        if (cat.includes('shipping') || cat.includes('fees') || cat.includes('freight')) return 'bg-gray-100 text-gray-500 border-gray-300';
        return 'bg-[#6B7280]/10 text-[#6B7280] border-[#6B7280]/20';
    };

    // Format Logic
    const getFormat = (cat: string, size: string): 'LF' | 'SF' => {
        const c = cat.toLowerCase();
        // Vinyl and Substrate are always Large Format
        if (c.includes('vinyl') || c.includes('substrate') || c.includes('floor') || c.includes('banner')) return 'LF';
        // Ink is neither, but treat as SF for unit cost usually. 
        if (c.includes('ink')) return 'SF';

        // For Paper, check size if possible (default SF)
        // If size implies Roll (contains ') or large dimensions, could be LF.
        if (size && (size.includes("'") || size.toLowerCase().includes("roll"))) return 'LF';

        return 'SF';
    };

    const isRigidCategory = (cat: string = '') => {
        const c = cat.toLowerCase();
        return c.includes('substrate') || c.includes('foam') || c.includes('rigid');
    };

    const calculateRollSqFt = (item: InvoiceItem): number | null => {
        if (isRigidCategory(item.category)) return null;
        // Preferred: Explicit fields
        if (item.roll_width && item.roll_length) {
            const w = parseNumber(item.roll_width);
            const l = parseNumber(item.roll_length);
            if (w > 0 && l > 0) {
                return (w / 12) * l;
            }
        }
        // Fallback: Parse from size string
        return parseSizeString(item.sheet_size);
    };

    const parseSizeString = (sizeStr: string): number | null => {
        if (!sizeStr) return null;
        // Normalize: lowercase, remove spaces, convert × to x, normalize quotes
        const clean = sizeStr
            .toLowerCase()
            .replace(/\s/g, '')
            .replace(/×/g, 'x')           // Handle multiplication sign (U+00D7)
            .replace(/[''′`]/g, "'")      // Normalize foot marks (curly quotes, prime)
            .replace(/[""″]/g, '"');      // Normalize inch marks (curly quotes, double prime)
        // Match: 54"x150' or 54"x100ft or 54"x98'
        const rollMatch = clean.match(/(\d+(?:\.\d+)?)"x(\d+(?:\.\d+)?)(?:['f]|ft)/);
        if (rollMatch) {
            const widthInches = parseFloat(rollMatch[1]);
            const lengthFeet = parseFloat(rollMatch[2]);
            return (widthInches / 12) * lengthFeet;
        }

        // Match: 4'x8' (both dimensions in feet)
        const feetMatch = clean.match(/(\d+(?:\.\d+)?)'x(\d+(?:\.\d+)?)'/);
        if (feetMatch) {
            return parseFloat(feetMatch[1]) * parseFloat(feetMatch[2]);
        }

        // Match: 24"x36" (Sheets in inches - convert to sqft)
        const sheetMatch = clean.match(/(\d+(?:\.\d+)?)"x(\d+(?:\.\d+)?)"/);
        if (sheetMatch) {
            const w = parseFloat(sheetMatch[1]);
            const h = parseFloat(sheetMatch[2]);
            return (w * h) / 144;
        }

        return null;
    };

    const handleCellClick = (originalIdx: number, field: keyof InvoiceItem) => {
        if (readonly) return;
        setEditingCell({ idx: originalIdx, field });
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>, originalIdx: number, field: keyof InvoiceItem) => {
        if (!onUpdateItem) return;
        const newVal = e.target.value;
        const item = items[originalIdx];
        const updated = { ...item, [field]: newVal };

        // Handle specific recalculations
        if (field === 'unit_price' || field === 'sheets_per_unit' || field === 'quantity_ordered' || field === 'total_sheets_manual') {
            const price = parseNumber(field === 'unit_price' ? newVal : item.unit_price);
            const qty = parseNumber(field === 'quantity_ordered' ? newVal : item.quantity_ordered);
            const unitSize = parseNumber(field === 'sheets_per_unit' ? newVal : item.sheets_per_unit) || 1;

            // Determine the "True" Total Sheets
            let finalTotalSheets = (qty * unitSize);
            if (field === 'total_sheets_manual') {
                finalTotalSheets = parseNumber(newVal) || finalTotalSheets;
            } else if (item.total_sheets_manual) {
                finalTotalSheets = parseNumber(item.total_sheets_manual);
            } else if (item.total_sheets_explicit) {
                finalTotalSheets = parseNumber(item.total_sheets_explicit);
            }

            if (finalTotalSheets > 0) {
                // Use total_line_price if available, otherwise fallback to unit_price * qty
                const totalPrice = parseNumber(item.total_line_price) || (price * qty);
                updated.cost_per_sheet = (totalPrice / finalTotalSheets).toFixed(4);
            }
        }

        onUpdateItem(originalIdx, updated);
    };

    const handleRevertTotal = (originalIdx: number) => {
        if (!onUpdateItem) return;
        const item = items[originalIdx];
        const { total_sheets_manual, ...rest } = item;

        // Recalculate cost based on original source
        const finalTotalSheets = parseNumber(item.total_sheets_explicit) || (parseNumber(item.quantity_ordered) * parseNumber(item.sheets_per_unit)) || 1;
        const totalPrice = parseNumber(item.total_line_price);
        const costPerSheet = finalTotalSheets > 0 && totalPrice > 0 ? (totalPrice / finalTotalSheets).toFixed(4) : null;
        const updated = { ...rest, total_sheets_manual: null, cost_per_sheet: costPerSheet };
        onUpdateItem(originalIdx, updated);
    };

    const renderCell = (item: any, originalIdx: number, field: keyof InvoiceItem, align: 'left' | 'right' = 'left') => {
        const isEditing = editingCell?.idx === originalIdx && editingCell?.field === field;
        const value = item[field];

        if (isEditing) {
            return (
                <input
                    autoFocus
                    type={field.includes('price') || field.includes('quantity') || field.includes('cost') || field.includes('sheets') ? 'number' : 'text'}
                    value={value ?? ''}
                    onChange={(e) => handleChange(e, originalIdx, field)}
                    onBlur={() => setEditingCell(null)}
                    className="w-full bg-white border border-[#017494] rounded px-1 py-0.5 text-xs focus:outline-none shadow-sm text-gray-900"
                />
            );
        }

        let displayValue = value;
        let textStyle = "text-gray-900";

        if (field === 'cost_per_sheet') {
            // If cost_per_sheet is not provided, calculate it on the fly
            let costValue = value;
            if (!costValue || costValue === '' || costValue === '-') {
                // Calculate: total_line_price / effectiveTotal
                const totalPrice = parseNumber(item.total_line_price);
                const manualTotal = parseNumber(item.total_sheets_manual);
                const explicitTotal = parseNumber(item.total_sheets_explicit);
                const qty = parseNumber(item.quantity_ordered);
                const unitSize = parseNumber(item.sheets_per_unit) || 1;
                const calculatedTotal = qty * unitSize;
                const effectiveTotal = !isNaN(manualTotal) && manualTotal > 0 ? manualTotal
                    : (!isNaN(explicitTotal) && explicitTotal > 0 ? explicitTotal : calculatedTotal);

                if (effectiveTotal > 0 && totalPrice > 0) {
                    costValue = totalPrice / effectiveTotal;
                }
            }
            displayValue = (costValue !== null && costValue !== undefined && costValue !== '' && !isNaN(Number(costValue)))
                ? `$${Number(costValue).toFixed(4)}`
                : '-';
        } else if (field === 'unit_price' || field === 'total_line_price') {
            displayValue = value ? `$${Number(value).toFixed(2)}` : '-';
        } else if (field === 'total_sheets_manual') {
            displayValue = value ? Number(value).toLocaleString() : '-';
            textStyle = "font-bold text-emerald-600";
        } else if (typeof value === 'number') {
            displayValue = !isNaN(value) ? value.toLocaleString() : '-';
        } else if (!value && value !== 0) {
            displayValue = '-';
        }

        return (
            <div
                onClick={() => handleCellClick(originalIdx, field)}
                className={`w-full h-full cursor-text ${align === 'right' ? 'text-right' : 'text-left'} ${textStyle}`}
            >
                {displayValue}
            </div>
        );
    };

    const totalTableWidth = useMemo(() => {
        return Object.values(columnWidths).reduce((a, b) => (a as number) + (b as number), 0) as number;
    }, [columnWidths]);

    const Header = ({ label, field, align = 'left' }: { label: string, field: keyof InvoiceItem, align?: 'left' | 'right' | 'center' }) => {
        const isSorted = sortConfig.key === field;
        const width = columnWidths[field] || 100;

        return (
            <th
                style={{ width: `${width}px`, minWidth: `${width}px`, maxWidth: `${width}px` }}
                className={`px-4 py-3 text-xs font-bold text-gray-500 uppercase tracking-wider select-none hover:text-[#017494] transition-colors group bg-white border-b border-gray-200 sticky top-0 z-20 shadow-sm ${align === 'right' ? 'text-right' : align === 'center' ? 'text-center' : 'text-left'}`}
            >
                <div
                    className={`flex items-center gap-1 cursor-pointer h-full ${align === 'right' ? 'justify-end' : align === 'center' ? 'justify-center' : 'justify-start'}`}
                    onClick={() => handleSort(field)}
                >
                    <span className="whitespace-nowrap">{label}</span>
                    <span className={`transition-opacity flex-shrink-0 ${isSorted ? 'opacity-100 text-[#017494]' : 'opacity-0 group-hover:opacity-50'}`}>
                        {isSorted && sortConfig.direction === 'desc' ? <ArrowDown className="w-3 h-3" /> : <ArrowUp className="w-3 h-3" />}
                    </span>
                </div>

                {/* Resize Handle - wider for easier grabbing */}
                <div
                    onMouseDown={(e) => handleMouseDown(e, field)}
                    className="absolute right-0 top-0 bottom-0 w-2 cursor-col-resize bg-transparent hover:bg-[#017494] group-hover:bg-gray-300/50 transition-colors z-30"
                    style={{ transform: 'translateX(50%)' }}
                    title="Drag to resize"
                />
            </th>
        );
    };


    return (
        <div className="overflow-auto max-h-[calc(100vh-250px)] bg-white border border-gray-200 rounded-lg shadow-inner custom-scrollbar relative">
            <table className="border-separate border-spacing-0" style={{ minWidth: `${totalTableWidth}px`, width: '100%' }}>
                <thead className="sticky top-0 z-20">
                    <tr>
                        <th className="w-10 px-2 py-3 bg-white border-b border-gray-200 sticky top-0 left-0 z-30 text-[10px] font-bold text-gray-400 text-center shadow-sm">#</th>
                        <th className="w-10 px-1 py-3 bg-white border-b border-gray-200 sticky top-0 z-20 text-[10px] font-bold text-gray-500 text-center shadow-sm select-none">Fmt</th>
                        <Header label="Date" field="invoice_date" />
                        <Header label="Vendor" field="vendor" />
                        <Header label="Invoice #" field="invoice_number" />
                        <Header label="Item Description" field="item_description" />
                        <Header label="Category" field="category" />
                        {hasSFItems && <Header label="Size" field="sheet_size" />}

                        {/* SF Columns - only show if there are SF items */}
                        {hasSFItems && <Header label="Weight" field="paper_weight" />}
                        {hasSFItems && <Header label="Type" field="paper_type" />}

                        {/* LF Columns - only show if there are LF items */}
                        {hasLFItems && <Header label="Thick" field="material_thickness" />}
                        {hasLFItems && <Header label="Width" field="roll_width" align="right" />}
                        {hasLFItems && <Header label="Len" field="roll_length" align="right" />}

                        <Header label="Qty" field="quantity_ordered" align="right" />
                        <Header label="Unit Price" field="unit_price" align="right" />
                        <Header label="Total" field="total_line_price" align="right" />
                        <Header label="SqFt/Roll" field="sheets_per_unit" align="right" />
                        <Header label="Total SqFt" field="total_sheets_explicit" align="right" />
                        <Header label="Cost/SqFt" field="cost_per_sheet" align="right" />
                        <Header label="Notes" field="notes" />

                        {onPreview && (
                            <th className="w-12 bg-white border-b border-gray-200 sticky top-0 right-0 z-30 shadow-sm"></th>
                        )}
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 bg-white">
                    {sortedData.map((row, sIdx) => {
                        const item = row as InvoiceItem;
                        const originalIndex = row._originalIndex;
                        const isLowConfidence = item.confidence_score === 'low';
                        const manualTotal = parseNumber(item.total_sheets_manual);
                        const isVerified = !isNaN(manualTotal) && manualTotal > 0;

                        // Calculate quantities first (needed for validation)
                        const qty = parseNumber(item.quantity_ordered);
                        const unitSize = parseNumber(item.sheets_per_unit) || 1;
                        const calculatedTotal = qty * unitSize;
                        const explicitTotal = parseNumber(item.total_sheets_explicit);

                        // Validation checks
                        const unitPrice = parseNumber(item.unit_price);
                        const totalPrice = parseNumber(item.total_line_price);
                        const expectedTotal = qty * unitPrice;
                        const hasMathError = unitPrice > 0 && totalPrice > 0 && Math.abs(expectedTotal - totalPrice) > 0.02;

                        const fmt = getFormat(item.category, item.sheet_size);
                        const isPaperCategory = item.category?.toLowerCase().includes('paper');
                        const hasMissingWeight = isPaperCategory && (!item.paper_weight || item.paper_weight === '' || item.paper_weight === '-');
                        const isLFRoll = fmt === 'LF' && !isRigidCategory(item.category);
                        const hasMissingDimensions = isLFRoll && (!item.roll_width || !item.roll_length);

                        const hasValidationWarning = hasMathError || hasMissingWeight || hasMissingDimensions;

                        const rowClass = isLowConfidence
                            ? 'bg-red-50'
                            : hasValidationWarning
                                ? 'bg-amber-50'
                                : 'hover:bg-gray-50';

                        const effectiveTotal = !isNaN(manualTotal) && manualTotal > 0 ? manualTotal : (!isNaN(explicitTotal) && explicitTotal > 0 ? explicitTotal : calculatedTotal);
                        const hasDiscrepancy = !isNaN(explicitTotal) && explicitTotal > 0 && explicitTotal !== calculatedTotal && (isNaN(manualTotal) || manualTotal === 0);

                        let totalSheetsStyle = "text-gray-400";
                        if (!isNaN(manualTotal)) totalSheetsStyle = "text-emerald-600 font-bold";
                        else if (!isNaN(explicitTotal)) totalSheetsStyle = "text-gray-900 font-bold";

                        return (
                            <tr key={`${item.invoice_number}-${originalIndex}-${sIdx}`} className={`transition-colors border-b border-gray-100 ${rowClass}`}>
                                <td className="px-2 py-3 text-[10px] font-bold text-gray-300 text-center select-none sticky left-0 bg-white z-10 border-r border-gray-50">
                                    {sIdx + 1}
                                </td>
                                <td className="px-2 py-3 text-center">
                                    {getFormat(item.category, item.sheet_size) === 'LF' ? (
                                        <span className="text-[9px] font-black text-white bg-purple-600 px-1 py-0.5 rounded">LF</span>
                                    ) : (
                                        <span className="text-[9px] font-bold text-gray-400 bg-gray-100 px-1 py-0.5 rounded">SF</span>
                                    )}
                                </td>
                                <td className="px-4 py-3 text-sm text-gray-900 break-words overflow-hidden">
                                    {renderCell(item, originalIndex, 'invoice_date')}
                                </td>
                                <td className="px-4 py-3 text-sm font-medium text-gray-900 break-words overflow-hidden">
                                    {renderCell(item, originalIndex, 'vendor')}
                                </td>
                                <td className="px-4 py-3 text-sm text-gray-500 break-words overflow-hidden">
                                    <div className="flex items-center gap-2">
                                        {renderCell(item, originalIndex, 'invoice_number')}
                                    </div>
                                </td>
                                <td className="px-4 py-3 text-sm text-gray-900 break-words overflow-hidden">
                                    {renderCell(item, originalIndex, 'item_description')}
                                </td>
                                <td className="px-4 py-3">
                                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide whitespace-nowrap border ${getCategoryStyle(item.category)}`}>
                                        {item.category || 'Uncategorized'}
                                    </span>
                                </td>
                                {/* Size column - only show if SF items exist */}
                                {hasSFItems && (
                                    <td className="px-4 py-3 text-sm text-gray-600 font-mono break-words overflow-hidden">
                                        {getFormat(item.category, item.sheet_size) === 'LF' ? '-' : renderCell(item, originalIndex, 'sheet_size')}
                                    </td>
                                )}

                                {/* SF Columns: Weight & Type - only show if SF items exist */}
                                {hasSFItems && (
                                    <td className="px-4 py-3 text-sm text-gray-600 break-words overflow-hidden">
                                        {getFormat(item.category, item.sheet_size) === 'SF' ? renderCell(item, originalIndex, 'paper_weight') : '-'}
                                    </td>
                                )}
                                {hasSFItems && (
                                    <td className="px-4 py-3 text-sm text-gray-600 break-words overflow-hidden">
                                        {getFormat(item.category, item.sheet_size) === 'SF' ? renderCell(item, originalIndex, 'paper_type') : '-'}
                                    </td>
                                )}

                                {/* LF Columns: Thickness, Width, Length - only show if LF items exist */}
                                {hasLFItems && (
                                    <td className="px-4 py-3 text-sm text-gray-600 break-words overflow-hidden">
                                        {getFormat(item.category, item.sheet_size) === 'LF' && !isRigidCategory(item.category) ? renderCell(item, originalIndex, 'material_thickness') : '-'}
                                    </td>
                                )}
                                {hasLFItems && (
                                    <td className="px-4 py-3 text-sm text-gray-600 text-right break-words overflow-hidden">
                                        {getFormat(item.category, item.sheet_size) === 'LF' && !isRigidCategory(item.category)
                                            ? (item.roll_width ? `${item.roll_width}"` : '-')
                                            : '-'}
                                    </td>
                                )}
                                {hasLFItems && (
                                    <td className="px-4 py-3 text-sm text-gray-600 text-right break-words overflow-hidden">
                                        {getFormat(item.category, item.sheet_size) === 'LF' && !isRigidCategory(item.category)
                                            ? (item.roll_length ? `${item.roll_length}'` : '-')
                                            : '-'}
                                    </td>
                                )}
                                <td className="px-4 py-3 text-sm text-gray-900 font-medium text-right break-words overflow-hidden">
                                    {renderCell(item, originalIndex, 'quantity_ordered', 'right')}
                                </td>
                                <td className="px-4 py-3 text-sm text-gray-600 text-right break-words overflow-hidden">
                                    {renderCell(item, originalIndex, 'unit_price', 'right')}
                                </td>
                                <td className="px-4 py-3 text-sm font-bold text-gray-900 text-right break-words overflow-hidden">
                                    {renderCell(item, originalIndex, 'total_line_price', 'right')}
                                </td>
                                {/* SqFt/Roll or Sheets/Unit column */}
                                <td className="px-4 py-3 text-sm text-gray-900 text-right break-words overflow-hidden relative group">
                                    {(() => {
                                        const fmt = getFormat(item.category, item.sheet_size);
                                        if (fmt === 'LF' && !isRigidCategory(item.category)) {
                                            const sqFtPerUnit = calculateRollSqFt(item);
                                            if (sqFtPerUnit) {
                                                return (
                                                    <div className="flex flex-col items-end leading-tight">
                                                        <span className="font-medium text-gray-700">{sqFtPerUnit.toFixed(0)}</span>
                                                        <span className="text-[9px] text-purple-500 font-medium">1 roll</span>
                                                    </div>
                                                );
                                            }
                                            return '-';
                                        }
                                        // SF: Show sheets per unit
                                        return (
                                            <div className="flex items-center justify-end gap-2">
                                                {renderCell(item, originalIndex, 'sheets_per_unit', 'right')}
                                            </div>
                                        );
                                    })()}
                                </td>
                                {/* Total SqFt or Total Sheets column */}
                                <td className="px-4 py-3 text-sm text-gray-900 text-right break-words overflow-hidden">
                                    {(() => {
                                        const fmt = getFormat(item.category, item.sheet_size);
                                        const qty = parseNumber(item.quantity_ordered);

                                        // LF Roll Logic
                                        if (fmt === 'LF') {
                                            const isRigid = isRigidCategory(item.category);
                                            if (!isRigid) {
                                                const sqFtPerUnit = calculateRollSqFt(item);
                                                if (sqFtPerUnit) {
                                                    const totalSqFt = sqFtPerUnit * qty;
                                                    return (
                                                        <div className="flex flex-col items-end leading-tight">
                                                            <span className="font-bold text-purple-700">{totalSqFt.toLocaleString()}</span>
                                                            <span className="text-[9px] text-gray-400">sqft</span>
                                                        </div>
                                                    );
                                                }
                                            }
                                            // Rigid (or no sqft) shows explicit Total Qty or just Qty
                                            const explicit = parseNumber(item.total_sheets_explicit);
                                            const displayQty = explicit > 0 ? explicit : qty;
                                            return (
                                                <div className="flex flex-col items-end leading-tight">
                                                    <span className="font-bold text-gray-900">{displayQty.toLocaleString()}</span>
                                                    <span className="text-[9px] text-gray-400">units</span>
                                                </div>
                                            );
                                        }

                                        // SF Logic validation
                                        if (hasDiscrepancy) {
                                            return (
                                                <div className="flex items-center justify-end gap-1">
                                                    <span className="text-gray-900 font-bold">{explicitTotal.toLocaleString()}</span>
                                                    <AlertCircle className="w-3.5 h-3.5 text-amber-500" title="Discrepancy Check" />
                                                </div>
                                            );
                                        }

                                        // Default SF Display
                                        return (
                                            <span className={totalSheetsStyle}>
                                                {effectiveTotal > 0 ? effectiveTotal.toLocaleString() : '-'}
                                            </span>
                                        );
                                    })()}
                                </td>
                                <td className="px-4 py-3 text-sm text-gray-500 text-right break-words overflow-hidden bg-gray-50/10">
                                    {(() => {
                                        const fmt = getFormat(item.category, item.sheet_size);
                                        const totalLinePrice = parseNumber(item.total_line_price);
                                        const effectiveQty = effectiveTotal;

                                        if (fmt === 'LF') {
                                            const isRigid = isRigidCategory(item.category);
                                            if (!isRigid) {
                                                // Calculate SqFt Total
                                                const sqFtPerUnit = calculateRollSqFt(item);
                                                if (sqFtPerUnit && totalLinePrice > 0) {
                                                    const totalSqFt = sqFtPerUnit * effectiveQty;
                                                    if (totalSqFt > 0) {
                                                        return (
                                                            <div className="flex flex-col items-end leading-tight">
                                                                <span className="font-bold text-purple-700">${(totalLinePrice / totalSqFt).toFixed(2)}</span>
                                                                <span className="text-[9px] text-gray-400">/sqft</span>
                                                            </div>
                                                        );
                                                    }
                                                }
                                            } else {
                                                const qty = parseNumber(item.quantity_ordered);
                                                const unitPrice = parseNumber(item.unit_price);
                                                const effectiveUnit = unitPrice > 0 ? unitPrice : (qty > 0 ? totalLinePrice / qty : 0);
                                                return (
                                                    <div className="flex flex-col items-end leading-tight">
                                                        <span className="font-bold text-gray-700">{effectiveUnit > 0 ? `$${effectiveUnit.toFixed(2)}` : '-'}</span>
                                                        <span className="text-[9px] text-gray-400">/ea</span>
                                                    </div>
                                                );
                                            }
                                        }

                                        // Fallback to SF (Cost/Sheet) or default
                                        const val = item.cost_per_sheet;
                                        return (
                                            <div className="flex flex-col items-end leading-tight">
                                                <span className={fmt === 'LF' ? "text-gray-400" : "text-gray-700"}>
                                                    {val ? `$${Number(val).toFixed(4)}` : '-'}
                                                </span>
                                                <span className="text-[9px] text-gray-400">/unit</span>
                                            </div>
                                        );
                                    })()}
                                </td>
                                <td className="px-4 py-3 text-sm text-gray-500 italic relative group break-words overflow-hidden">
                                    <div className="flex items-center gap-2">
                                        <span className="flex-1">{renderCell(item, originalIndex, 'notes')}</span>
                                        {isLowConfidence && (
                                            <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0" title="Low confidence extraction" />
                                        )}
                                        {hasValidationWarning && !isLowConfidence && (
                                            <AlertCircle
                                                className="w-4 h-4 text-amber-500 flex-shrink-0"
                                                title={[
                                                    hasMathError && `Math error: ${qty} × $${unitPrice.toFixed(2)} = $${expectedTotal.toFixed(2)}, but total is $${totalPrice.toFixed(2)}`,
                                                    hasMissingWeight && 'Missing paper weight',
                                                    hasMissingDimensions && 'Missing roll dimensions (width/length)'
                                                ].filter(Boolean).join('\n')}
                                            />
                                        )}
                                    </div>
                                </td>
                                {onPreview && (
                                    <td className="px-3 py-3 text-center sticky right-0 bg-white z-10 border-l border-gray-50">
                                        {item.source_file && (
                                            <button
                                                onClick={(e) => { e.stopPropagation(); onPreview(item.source_file!); }}
                                                className="text-[#017494] hover:bg-[#017494]/10 p-1.5 rounded transition-colors"
                                                title="View Source File"
                                            >
                                                <Eye className="w-4 h-4" />
                                            </button>
                                        )}
                                    </td>
                                )}
                            </tr>
                        );
                    })}
                </tbody>
            </table>
        </div>
    );
};
