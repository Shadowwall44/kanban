import React, { useEffect, useState, useMemo } from 'react';
import { Download, Trash2, Search, Database, X, Filter } from 'lucide-react';
import { SavedInvoiceItem, getAllItems, clearDatabase } from '../services/db';
import { downloadCSV } from '../utils/csv';
import { ResultsTable } from './ResultsTable';

export const DatabaseView: React.FC = () => {
  const [items, setItems] = useState<SavedInvoiceItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Filters State
  const [searchText, setSearchText] = useState('');
  const [vendorFilter, setVendorFilter] = useState('All Vendors');
  const [categoryFilter, setCategoryFilter] = useState('All Categories');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const loadData = async () => {
    setIsLoading(true);
    const data = await getAllItems();
    setItems(data);
    setIsLoading(false);
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleDeleteAll = async () => {
    if (window.confirm('Are you sure you want to PERMANENTLY delete the entire database history? This cannot be undone.')) {
      await clearDatabase();
      loadData();
    }
  };

  const clearFilters = () => {
      setSearchText('');
      setVendorFilter('All Vendors');
      setCategoryFilter('All Categories');
      setStartDate('');
      setEndDate('');
  };

  // Extract Unique Lists for Dropdowns
  const uniqueVendors = useMemo(() => {
      const vendors = new Set(items.map(i => i.vendor).filter(Boolean));
      return Array.from(vendors).sort();
  }, [items]);

  const uniqueCategories = useMemo(() => {
      const categories = new Set(items.map(i => i.category).filter(Boolean));
      return Array.from(categories).sort();
  }, [items]);

  // Apply Filtering Logic
  const filteredItems = useMemo(() => {
      return items.filter(item => {
          // 1. Search Text (Global)
          const searchLower = searchText.toLowerCase();
          const matchesSearch = !searchText || 
              item.vendor.toLowerCase().includes(searchLower) ||
              item.item_description.toLowerCase().includes(searchLower) ||
              item.notes.toLowerCase().includes(searchLower) ||
              item.invoice_number.includes(searchLower);

          // 2. Vendor Filter
          const matchesVendor = vendorFilter === 'All Vendors' || item.vendor === vendorFilter;

          // 3. Category Filter
          const matchesCategory = categoryFilter === 'All Categories' || item.category === categoryFilter;

          // 4. Date Range
          let matchesDate = true;
          if (startDate) {
              matchesDate = matchesDate && item.invoice_date >= startDate;
          }
          if (endDate) {
              matchesDate = matchesDate && item.invoice_date <= endDate;
          }

          return matchesSearch && matchesVendor && matchesCategory && matchesDate;
      });
  }, [items, searchText, vendorFilter, categoryFilter, startDate, endDate]);

  if (isLoading) {
    return <div className="p-12 text-center text-gray-500">Loading Master Log...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="bg-white border border-gray-200 rounded-2xl shadow-sm p-5 space-y-5">
         
         {/* Header Row */}
         <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                    <Database className="w-5 h-5 text-[#017494]" />
                    Master Inventory Log
                </h2>
                <p className="text-sm text-gray-500 mt-1">
                    {filteredItems.length} records found {filteredItems.length !== items.length && `(filtered from ${items.length} total)`}
                </p>
            </div>
            <div className="flex items-center gap-3">
                 <button
                    onClick={() => downloadCSV(filteredItems)}
                    className="flex items-center gap-2 px-4 py-2 bg-[#017494] text-white rounded-lg hover:bg-[#015e7a] transition-colors shadow-sm text-sm font-medium"
                >
                    <Download className="w-4 h-4" /> Export CSV
                </button>
                <button
                    onClick={handleDeleteAll}
                    className="flex items-center gap-2 px-4 py-2 bg-white border border-red-200 text-red-600 rounded-lg hover:bg-red-50 transition-colors shadow-sm text-sm font-medium"
                >
                    <Trash2 className="w-4 h-4" /> Clear History
                </button>
            </div>
         </div>

         {/* Filter Bar */}
         <div className="grid grid-cols-1 md:grid-cols-12 gap-4 pt-4 border-t border-gray-100">
             
             {/* Search */}
             <div className="md:col-span-3 relative">
                 <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                 <input 
                    type="text" 
                    placeholder="Search all columns..." 
                    value={searchText}
                    onChange={(e) => setSearchText(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-[#017494] focus:ring-1 focus:ring-[#017494]"
                 />
             </div>

             {/* Vendor Dropdown */}
             <div className="md:col-span-2">
                 <select 
                    value={vendorFilter}
                    onChange={(e) => setVendorFilter(e.target.value)}
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-[#017494] text-gray-700"
                 >
                     <option>All Vendors</option>
                     {uniqueVendors.map(v => <option key={v} value={v}>{v}</option>)}
                 </select>
             </div>

             {/* Category Dropdown */}
             <div className="md:col-span-2">
                 <select 
                    value={categoryFilter}
                    onChange={(e) => setCategoryFilter(e.target.value)}
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-[#017494] text-gray-700"
                 >
                     <option>All Categories</option>
                     {uniqueCategories.map(c => <option key={c} value={c}>{c}</option>)}
                 </select>
             </div>

             {/* Date Range */}
             <div className="md:col-span-3 flex items-center gap-2">
                 <input 
                    type="date" 
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full px-2 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-[#017494] text-gray-600"
                 />
                 <span className="text-gray-400">-</span>
                 <input 
                    type="date" 
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="w-full px-2 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-[#017494] text-gray-600"
                 />
             </div>

             {/* Clear Button */}
             <div className="md:col-span-2 flex justify-end">
                <button 
                    onClick={clearFilters}
                    className="flex items-center gap-1.5 px-3 py-2 text-sm text-gray-500 hover:text-[#017494] hover:bg-gray-50 rounded-lg transition-colors"
                >
                    <X className="w-4 h-4" /> Clear Filters
                </button>
             </div>
         </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
        {filteredItems.length > 0 ? (
          <ResultsTable items={filteredItems} readonly />
        ) : (
          <div className="p-16 text-center">
             <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-50 mb-4">
                 <Filter className="w-8 h-8 text-gray-300" />
             </div>
             <h3 className="text-lg font-medium text-gray-900">No records found</h3>
             <p className="text-gray-500 mt-1">Try adjusting your filters or clearing them to see more results.</p>
             <button onClick={clearFilters} className="mt-4 text-[#017494] font-medium hover:underline">
                 Clear all filters
             </button>
          </div>
        )}
      </div>
    </div>
  );
};