import React, { useMemo, useState, useEffect } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, AreaChart, Area, LineChart, Line, Legend
} from 'recharts';
import {
  TrendingUp, TrendingDown, DollarSign, Package, User,
  AlertTriangle, ArrowUpRight, ArrowDownRight, Printer, Calendar
} from 'lucide-react';
import { InvoiceItem } from '../types';
import { getAllItems, SavedInvoiceItem } from '../services/db';

interface AnalyticsDashboardProps {
  items: InvoiceItem[];
  mode?: 'history' | 'batch';
}

const formatCurrency = (val: number) =>
  new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(val);

const COLORS = {
  ink: '#3B82F6',
  substrate: '#F59E0B',
  vinyl: '#017494',
  paper: '#10B981',
  laminate: '#8B5CF6',
  supplies: '#6B7280'
};

const YEAR_COLORS = ['#017494', '#F59E0B', '#10B981', '#8B5CF6', '#EF4444', '#3B82F6'];

const getCategoryColor = (name: any) => {
  const n = String(name || '').toLowerCase();
  if (n.includes('ink')) return COLORS.ink;
  if (n.includes('foam') || n.includes('substrate')) return COLORS.substrate;
  if (n.includes('vinyl')) return COLORS.vinyl;
  if (n.includes('paper') || n.includes('text') || n.includes('cover')) return COLORS.paper;
  if (n.includes('laminate')) return COLORS.laminate;
  return COLORS.supplies;
};

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({ items, mode = 'history' }) => {
  const [dbHistory, setDbHistory] = useState<SavedInvoiceItem[]>([]);
  const [dateRange, setDateRange] = useState('All Time');

  useEffect(() => {
    const fetchHistory = async () => {
      const history = await getAllItems();
      setDbHistory(history);
    };
    fetchHistory();
  }, []);

  // Filter items based on date range (Simplified for demo)
  const filteredItems = useMemo(() => {
    if (dateRange === 'All Time') return items;
    // Real implementation would filter by actual Date objects
    return items;
  }, [items, dateRange]);

  // Calculations
  const totalSpend = useMemo(() => filteredItems.reduce((sum, i) => sum + Number(i.total_line_price || 0), 0), [filteredItems]);
  const avgCost = useMemo(() => filteredItems.length > 0 ? totalSpend / filteredItems.length : 0, [totalSpend, filteredItems]);

  const spendByVendor = useMemo(() => {
    const map = new Map<string, number>();
    filteredItems.forEach(i => map.set(i.vendor, (map.get(i.vendor) || 0) + Number(i.total_line_price || 0)));
    return Array.from(map.entries()).map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value).slice(0, 5);
  }, [filteredItems]);

  const spendByCategory = useMemo(() => {
    const map = new Map<string, number>();
    filteredItems.forEach(i => map.set(i.category || 'Other', (map.get(i.category || 'Other') || 0) + Number(i.total_line_price || 0)));
    return Array.from(map.entries()).map(([name, value]) => ({ name, value }));
  }, [filteredItems]);

  // Aggregate Trend (All years combined) - Used for Sparklines
  const monthlyTrend = useMemo(() => {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const data = months.map(m => ({ name: m, value: 0 }));
    filteredItems.forEach(i => {
      const d = new Date(i.invoice_date);
      const monthIdx = d.getMonth();
      if (!isNaN(monthIdx)) data[monthIdx].value += Number(i.total_line_price || 0);
    });
    return data;
  }, [filteredItems]);

  // Multi-Year Trend - Used for Main Chart
  const multiYearTrend = useMemo(() => {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const yearSet = new Set<string>();

    // Init structure: [{ name: 'Jan', '2023': 0, '2024': 0 }, ...]
    const dataMap = months.map(m => ({ name: m } as Record<string, any>));

    filteredItems.forEach(i => {
      const d = new Date(i.invoice_date);
      if (!isNaN(d.getTime())) {
        const y = d.getFullYear().toString();
        yearSet.add(y);
        const mIdx = d.getMonth();

        if (dataMap[mIdx][y] === undefined) dataMap[mIdx][y] = 0;
        dataMap[mIdx][y] += Number(i.total_line_price || 0);
      }
    });

    const sortedYears = Array.from(yearSet).sort();

    // Ensure all years have a value (0) for every month to prevent broken lines
    dataMap.forEach(row => {
      sortedYears.forEach(y => {
        if (row[y] === undefined) row[y] = 0;
      });
    });

    return { data: dataMap, years: sortedYears };
  }, [filteredItems]);

  // Price Watch Logic
  const priceAlerts = useMemo(() => {
    const alerts: any[] = [];
    if (mode === 'batch' && dbHistory.length > 0) {
      items.slice(0, 5).forEach(item => {
        const history = dbHistory.find(h => h.sku === item.sku && h.sku !== '');
        if (history) {
          const currentPrice = Number(item.unit_price);
          const oldPrice = Number(history.unit_price);
          if (currentPrice !== oldPrice) {
            alerts.push({
              name: item.item_description,
              old: oldPrice,
              new: currentPrice,
              increase: currentPrice > oldPrice
            });
          }
        }
      });
    }
    return alerts;
  }, [items, dbHistory, mode]);

  const topPurchased = useMemo(() => {
    const map = new Map<string, { qty: number, spend: number }>();
    filteredItems.forEach(i => {
      const current = map.get(i.item_description) || { qty: 0, spend: 0 };
      map.set(i.item_description, {
        qty: current.qty + Number(i.quantity_ordered || 0),
        spend: current.spend + Number(i.total_line_price || 0)
      });
    });
    return Array.from(map.entries())
      .map(([name, stats]) => ({ name, ...stats }))
      .sort((a, b) => b.qty - a.qty).slice(0, 5);
  }, [filteredItems]);

  const handlePrint = () => window.print();

  return (
    <div className="space-y-6 pb-12 print:bg-white">

      {/* Header Controls */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4 print:hidden">
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-gray-400" />
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="bg-transparent text-sm font-semibold text-gray-600 outline-none cursor-pointer"
          >
            <option>All Time</option>
            <option>This Month</option>
            <option>Last 30 Days</option>
            <option>This Quarter</option>
            <option>This Year</option>
          </select>
        </div>
        <button
          onClick={handlePrint}
          className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-xl text-sm font-bold text-gray-700 hover:bg-gray-50 transition-all shadow-sm"
        >
          <Printer className="w-4 h-4" /> Export Report
        </button>
      </div>

      {/* ROW 1: KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <KPICard
          title="Total Spend"
          value={formatCurrency(totalSpend)}
          icon={<DollarSign className="w-5 h-5" />}
          sparkline={true}
          data={monthlyTrend}
          color="#10B981"
          variant="success"
        />
        <KPICard
          title="Items Extracted"
          value={filteredItems.length.toString()}
          icon={<Package className="w-5 h-5" />}
          trend="+12%"
          trendUp={true}
          variant="primary"
        />
        <KPICard
          title="Top Vendor"
          value={spendByVendor[0]?.name || 'N/A'}
          subValue={formatCurrency(spendByVendor[0]?.value || 0)}
          icon={<User className="w-5 h-5" />}
          variant="warning"
        />
        <KPICard
          title="Avg Unit Cost"
          value={formatCurrency(avgCost)}
          icon={<TrendingUp className="w-5 h-5" />}
          variant="purple"
        />
      </div>

      {/* ROW 2: Main Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Trend Chart - Updated for Multi-Year Lines */}
        <div className="lg:col-span-2 bg-white p-6 rounded-[16px] border border-gray-200 shadow-sm overflow-hidden relative">
          <h3 className="text-sm font-semibold text-gray-500 mb-6 uppercase tracking-wider">Monthly Spending Trend (YoY)</h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={multiYearTrend.data}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" vertical={false} />
                <XAxis dataKey="name" stroke="#6B7280" fontSize={11} tickLine={false} axisLine={false} dy={10} />
                <YAxis stroke="#6B7280" fontSize={11} tickLine={false} axisLine={false} tickFormatter={(v) => `$${v}`} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#FFFFFF', border: '1px solid #E5E7EB', borderRadius: '8px', fontSize: '12px' }}
                  itemStyle={{ padding: 0 }}
                />
                <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} iconType="circle" />
                {multiYearTrend.years.map((year, i) => (
                  <Line
                    key={year}
                    type="monotone"
                    dataKey={year}
                    stroke={YEAR_COLORS[i % YEAR_COLORS.length]}
                    strokeWidth={3}
                    dot={{ r: 4, strokeWidth: 0, fill: YEAR_COLORS[i % YEAR_COLORS.length] }}
                    activeDot={{ r: 6 }}
                  />
                ))}
                {multiYearTrend.years.length === 0 && (
                  <Line type="monotone" dataKey="value" stroke="#e5e7eb" strokeDasharray="5 5" />
                )}
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Category Donut */}
        <div className="bg-white p-6 rounded-[16px] border border-gray-200 shadow-sm flex flex-col">
          <h3 className="text-sm font-semibold text-gray-500 mb-6 uppercase tracking-wider">Spend by Category</h3>
          <div className="flex-1 min-h-[220px] relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={spendByCategory}
                  cx="50%" cy="50%"
                  innerRadius={65} outerRadius={95}
                  paddingAngle={5}
                  dataKey="value"
                  stroke="none"
                >
                  {spendByCategory.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={getCategoryColor(entry.name)} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-[10px] text-gray-500 font-bold uppercase">Total</span>
              <span className="text-xl font-bold text-gray-900">{formatCurrency(totalSpend)}</span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 mt-4">
            {spendByCategory.slice(0, 4).map((cat, i) => (
              <div key={i} className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: getCategoryColor(cat.name) }}></div>
                <span className="text-[10px] font-medium text-gray-600 truncate">{cat.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ROW 3: Insights */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

        {/* Vendor Bar Chart */}
        <div className="bg-white p-6 rounded-[16px] border border-gray-200 shadow-sm">
          <h3 className="text-sm font-semibold text-gray-500 mb-6 uppercase tracking-wider">Spend by Vendor</h3>
          <div className="space-y-4">
            {spendByVendor.map((vendor, i) => (
              <div key={i} className="space-y-1.5">
                <div className="flex justify-between text-xs font-medium">
                  <span className="text-gray-700">{vendor.name}</span>
                  <span className="text-gray-900 font-bold">{formatCurrency(vendor.value)}</span>
                </div>
                <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-[#017494] to-[#3B82F6] rounded-full"
                    style={{ width: `${(vendor.value / (spendByVendor[0]?.value || 1)) * 100}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Price Watch */}
        <div className="bg-white p-6 rounded-[16px] border border-gray-200 shadow-sm">
          <h3 className="text-sm font-semibold text-gray-500 mb-6 uppercase tracking-wider flex items-center justify-between">
            Price Watch
            {priceAlerts.length > 0 && <span className="bg-red-500 text-white text-[9px] px-1.5 py-0.5 rounded-full animate-pulse">Alert</span>}
          </h3>
          {priceAlerts.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-[160px] opacity-30">
              <AlertTriangle className="w-8 h-8 mb-2" />
              <p className="text-xs">No significant changes detected</p>
            </div>
          ) : (
            <div className="space-y-3">
              {priceAlerts.map((alert, i) => (
                <div key={i} className="p-3 bg-gray-50 rounded-xl flex items-center justify-between gap-2 border border-gray-100">
                  <div className="min-w-0 flex-1">
                    <p className="text-[11px] font-bold text-gray-900 truncate">{alert.name}</p>
                    <p className="text-[10px] text-gray-500">${alert.old.toFixed(2)} → ${alert.new.toFixed(2)}</p>
                  </div>
                  {alert.increase ? (
                    <div className="flex items-center text-red-600 font-bold text-[10px] bg-red-50 px-2 py-1 rounded border border-red-100">
                      <ArrowUpRight className="w-3 h-3 mr-1" /> {(((alert.new - alert.old) / alert.old) * 100).toFixed(0)}%
                    </div>
                  ) : (
                    <div className="flex items-center text-green-600 font-bold text-[10px] bg-green-50 px-2 py-1 rounded border border-green-100">
                      <ArrowDownRight className="w-3 h-3 mr-1" /> {(((alert.old - alert.new) / alert.old) * 100).toFixed(0)}%
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Top Items */}
        <div className="bg-white p-6 rounded-[16px] border border-gray-200 shadow-sm">
          <h3 className="text-sm font-semibold text-gray-500 mb-6 uppercase tracking-wider">Top Purchased Items</h3>
          <div className="space-y-3">
            {topPurchased.map((item, i) => (
              <div key={i} className="flex items-center justify-between group">
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-medium text-gray-900 truncate group-hover:text-[#017494] transition-colors">{item.name}</p>
                  <p className="text-[10px] text-gray-500">{item.qty} units</p>
                </div>
                <span className="text-xs font-bold text-gray-700">{formatCurrency(item.spend)}</span>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Spending Progress Bar Card */}
      <div className="bg-white p-6 rounded-[16px] border border-gray-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex-1">
          <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1">Monthly Spending Limit</h3>
          <div className="flex items-end gap-2">
            <span className="text-2xl font-bold text-gray-900">{formatCurrency(totalSpend)}</span>
            <span className="text-sm text-gray-500 mb-1">of $5,000.00</span>
          </div>
        </div>
        <div className="flex-[2] space-y-2">
          <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-1000 ${totalSpend > 4000 ? 'bg-red-500' : 'bg-[#10B981]'}`}
              style={{ width: `${Math.min((totalSpend / 5000) * 100, 100)}%` }}
            ></div>
          </div>
          <div className="flex justify-between text-[10px] font-bold text-gray-500 uppercase tracking-tighter">
            <span>0% Utilization</span>
            <span>100% (Budget Reached)</span>
          </div>
        </div>
      </div>
    </div>
  );
};

const KPICard = ({ title, value, subValue, icon, trend, trendUp, sparkline, data, color, variant = 'primary' }: any) => {
  const variants: Record<string, any> = {
    primary: { bg: 'bg-blue-50', text: 'text-blue-600', border: 'border-blue-100', iconBg: 'bg-blue-500/10' },
    success: { bg: 'bg-emerald-50', text: 'text-emerald-600', border: 'border-emerald-100', iconBg: 'bg-emerald-500/10' },
    warning: { bg: 'bg-amber-50', text: 'text-amber-600', border: 'border-amber-100', iconBg: 'bg-amber-500/10' },
    purple: { bg: 'bg-purple-50', text: 'text-purple-600', border: 'border-purple-100', iconBg: 'bg-purple-500/10' },
  };

  const v = variants[variant] || variants.primary;

  return (
    <div className="bg-white p-5 rounded-[24px] border border-slate-200/60 shadow-[0_8px_30px_rgb(0,0,0,0.02)] relative overflow-hidden group hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] hover:border-slate-300/60 transition-all duration-300">
      <div className="flex justify-between items-start mb-4">
        <div className={`p-2.5 rounded-2xl ${v.iconBg} ${v.text} transition-all duration-300 group-hover:scale-110`}>
          {icon}
        </div>
        {trend && (
          <div className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold border ${trendUp ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-rose-50 text-rose-600 border-rose-100'}`}>
            {trendUp ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
            {trend}
          </div>
        )}
      </div>

      <div className="relative z-10 flex justify-between items-end">
        <div>
          <h3 className="text-[11px] font-bold text-slate-400 uppercase tracking-[0.1em] mb-1.5">{title}</h3>
          <div className="flex flex-col">
            <span className="text-2xl font-extrabold text-slate-900 tracking-tight leading-none">{value}</span>
            {subValue && (
              <span className="text-[11px] text-slate-400 font-medium mt-1 inline-flex items-center gap-1">
                Total Share: {subValue}
              </span>
            )}
          </div>
        </div>

        {sparkline && data && (
          <div className="w-24 h-12 ml-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.slice(-7)}> {/* Just show last 7 for sparkline */}
                <defs>
                  <linearGradient id={`gradient-${color}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={color} stopOpacity={0.1} />
                    <stop offset="95%" stopColor={color} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke={color}
                  strokeWidth={2.5}
                  fill={`url(#gradient-${color})`}
                  dot={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* Decorative background element for luxury feel */}
      <div className={`absolute -right-4 -bottom-4 w-24 h-24 rounded-full ${v.iconBg} blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
    </div>
  );
};