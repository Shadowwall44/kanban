import React, { useCallback, useState, useRef } from 'react';
import { UploadCloud, FileUp, FolderUp } from 'lucide-react';

interface DropzoneProps {
  onFilesSelected: (files: File[]) => void;
  disabled?: boolean;
  compact?: boolean;
}

// Helper to recursively read entries
const scanFiles = async (item: any): Promise<File[]> => {
  if (item.isFile) {
    return new Promise((resolve) => {
        item.file((file: File) => resolve([file]));
    });
  } else if (item.isDirectory) {
    const dirReader = item.createReader();
    return new Promise((resolve) => {
      dirReader.readEntries(async (entries: any[]) => {
        const promises = entries.map((entry) => scanFiles(entry));
        const results = await Promise.all(promises);
        resolve(results.flat());
      });
    });
  }
  return [];
};

export const Dropzone: React.FC<DropzoneProps> = ({ onFilesSelected, disabled, compact = false }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessingDrop, setIsProcessingDrop] = useState(false);
  
  // Distinct refs for strict separation
  // 1. fileInputRef -> Standard file selection (NO webkitdirectory)
  // 2. folderInputRef -> Folder selection (HAS webkitdirectory)
  const fileInputRef = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    if (!disabled && !isProcessingDrop) setIsDragging(true);
  }, [disabled, isProcessingDrop]);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const filterAndEmitFiles = useCallback((files: File[]) => {
    const validFiles = files.filter(file => {
      const name = file.name.toLowerCase();
      const type = file.type.toLowerCase();
      
      return (
        name.endsWith('.pdf') || 
        name.endsWith('.zip') ||
        name.endsWith('.png') ||
        name.endsWith('.jpg') ||
        name.endsWith('.jpeg') ||
        name.endsWith('.webp') ||
        type === 'application/pdf' || 
        type.startsWith('image/') ||
        type.includes('zip') ||
        type.includes('compressed')
      );
    });

    if (validFiles.length > 0) {
      onFilesSelected(validFiles);
    } else if (files.length > 0) {
        alert("No supported files found (PDF, Image, or ZIP).");
    }
  }, [onFilesSelected]);

  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (disabled || isProcessingDrop) return;

    setIsProcessingDrop(true);
    
    try {
        const items = Array.from(e.dataTransfer.items);
        const promises = items.map((item: any) => {
            const entry = item.webkitGetAsEntry ? item.webkitGetAsEntry() : null;
            if (entry) {
                return scanFiles(entry);
            } else if (item.kind === 'file') {
                const file = item.getAsFile();
                if (file) return Promise.resolve([file]);
            }
            return Promise.resolve([]);
        });

        const results = await Promise.all(promises);
        const allFiles = results.flat().filter((f): f is File => f !== null);
        filterAndEmitFiles(allFiles);
    } catch (err) {
        console.error("Error scanning dropped files:", err);
        const droppedFiles = Array.from(e.dataTransfer.files);
        filterAndEmitFiles(droppedFiles);
    } finally {
        setIsProcessingDrop(false);
    }
  }, [disabled, isProcessingDrop, filterAndEmitFiles]);

  // Handler strictly for standard files
  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const files = Array.from(e.target.files) as File[];
    filterAndEmitFiles(files);
    e.target.value = ''; 
  }, [filterAndEmitFiles]);

  // Handler strictly for directory/folders
  const handleFolderChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const files = Array.from(e.target.files) as File[];
    filterAndEmitFiles(files);
    e.target.value = ''; 
  }, [filterAndEmitFiles]);

  const handleContainerClick = () => {
    if (!disabled && fileInputRef.current) {
        fileInputRef.current.click();
    }
  };

  const handleSelectFilesClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation(); // Stop bubbling to container
    if (!disabled && fileInputRef.current) {
        fileInputRef.current.click();
    }
  };

  const handleSelectFolderClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation(); // Stop bubbling to container
    if (!disabled && folderInputRef.current) {
        folderInputRef.current.click();
    }
  };

  return (
    <>
      {/* 
        STRICT INPUT SEPARATION 
        1. input-file-upload: Standard files, NO webkitdirectory
        2. input-folder-upload: Folders, HAS webkitdirectory
      */}
      <input
        ref={fileInputRef}
        id="input-file-upload"
        type="file"
        multiple
        accept=".pdf,image/*,.zip,application/zip,application/x-zip-compressed"
        onChange={handleFileChange}
        className="hidden"
        style={{ display: 'none' }} 
      />
      
      <input
        ref={folderInputRef}
        id="input-folder-upload"
        type="file"
        multiple
        {...({ webkitdirectory: "", directory: "" } as any)}
        onChange={handleFolderChange}
        className="hidden"
        style={{ display: 'none' }} 
      />

      {compact ? (
        // COMPACT UI
        <div 
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={handleContainerClick}
          className={`
              group relative flex flex-col items-center justify-center w-64 h-16 border-2 border-dashed rounded-xl transition-all duration-200 cursor-pointer overflow-hidden
              ${disabled || isProcessingDrop
                  ? 'opacity-50 cursor-not-allowed border-gray-300 bg-gray-50' 
                  : isDragging 
                    ? 'border-[#017494] bg-[#017494]/10 scale-105' 
                    : 'border-gray-300 dark:border-gray-600 hover:border-[#017494] dark:hover:border-[#90B8F0] hover:bg-gray-50 dark:hover:bg-gray-800'
              }
          `}
        >
          <div className="flex items-center gap-3 pointer-events-none">
              <div className={`p-1.5 rounded-lg transition-colors ${isDragging ? 'bg-[#017494] text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-500 dark:text-gray-400 group-hover:text-[#017494]'}`}>
                  {isDragging ? <FileUp className="w-5 h-5 animate-bounce" /> : <UploadCloud className="w-5 h-5" />}
              </div>
              <div className="flex flex-col">
                  <span className={`text-sm font-bold leading-tight ${isDragging ? 'text-[#017494]' : 'text-[#0F1011] dark:text-white'}`}>
                    {isProcessingDrop ? 'Scanning...' : isDragging ? 'Drop Files' : 'Upload Invoices'}
                  </span>
                  <span className="text-[10px] text-gray-500 dark:text-gray-400 font-medium">
                      PDF, Images, or ZIPs
                  </span>
              </div>
          </div>
        </div>
      ) : (
        // FULL UI
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={handleContainerClick}
          className={`
            relative border-2 rounded-xl p-6 transition-all duration-300 ease-in-out group cursor-pointer
            ${disabled || isProcessingDrop
              ? 'opacity-50 cursor-not-allowed bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700' 
              : isDragging 
                ? 'border-[#017494] dark:border-[#90B8F0] bg-cyan-50/80 dark:bg-cyan-900/30 scale-[1.01] shadow-xl' 
                : 'border-dashed border-[#017494]/30 dark:border-[#90B8F0]/30 bg-[#F0F9FF] dark:bg-[#0F1011] hover:border-[#017494] dark:hover:border-[#90B8F0] hover:bg-cyan-50/50 dark:hover:bg-gray-800 hover:shadow-md'
            }
          `}
        >
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 sm:gap-6">
            <div className="flex items-center gap-5 w-full sm:w-auto justify-center sm:justify-start">
                <div className={`
                    p-3.5 rounded-full transition-all duration-300 shadow-sm shrink-0
                    ${isDragging 
                        ? 'bg-[#017494] text-white scale-110' 
                        : 'bg-white dark:bg-gray-800 text-[#017494] dark:text-[#90B8F0] group-hover:text-white group-hover:bg-[#017494] dark:group-hover:bg-[#90B8F0] dark:group-hover:text-[#0F1011]'
                    }
                `}>
                  {isProcessingDrop ? <FolderUp className="w-8 h-8 animate-bounce" /> : <UploadCloud className="w-8 h-8" />}
                </div>
                
                <div className="text-center sm:text-left space-y-0.5">
                    <h3 className={`text-lg font-bold transition-colors ${isDragging ? 'text-[#017494]' : 'text-[#0F1011] dark:text-white'}`}>
                        {isProcessingDrop ? 'Scanning folder...' : isDragging ? 'Drop it like it\'s hot!' : 'Upload Invoices'}
                    </h3>
                    <p className="text-sm text-gray-600 dark:text-gray-300">
                        {isProcessingDrop 
                            ? 'Please wait while we gather all files...' 
                            : 'Drag folders or files here to start.'
                        } 
                        <span className="opacity-70 hidden sm:inline ml-1">Supports PDF, PNG, JPG, ZIP.</span>
                    </p>
                </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
                <button
                    type="button"
                    onClick={handleSelectFilesClick}
                    className={`
                        px-5 py-2.5 rounded-lg text-sm font-bold shadow-sm transition-all whitespace-nowrap w-full sm:w-auto text-center
                        ${isDragging 
                            ? 'bg-white text-[#017494]' 
                            : 'bg-[#017494] text-white hover:bg-[#015e7a] dark:bg-[#90B8F0] dark:text-[#0F1011] dark:hover:bg-[#7aa2e0]'
                        }
                    `}
                >
                    Select Files
                </button>
                <button
                    type="button"
                    onClick={handleSelectFolderClick}
                    className="text-xs font-semibold text-[#017494] dark:text-[#90B8F0] hover:underline whitespace-nowrap px-2 py-1"
                >
                    or Select Folder
                </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};