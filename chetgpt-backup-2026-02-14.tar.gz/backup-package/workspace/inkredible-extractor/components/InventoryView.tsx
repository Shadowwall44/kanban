import React, { useEffect, useState, useMemo } from 'react';
import { Package, AlertTriangle, CheckCircle, XCircle, ChevronDown, ChevronRight, RefreshCw, Search, X } from 'lucide-react';
import { InventoryItem, Lot } from '../types';
import { getInventory } from '../services/db';

export const InventoryView: React.FC = () => {
    const [inventory, setInventory] = useState<InventoryItem[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [expandedKeys, setExpandedKeys] = useState<Set<string>>(new Set());
    const [searchText, setSearchText] = useState('');

    const loadData = async () => {
        setIsLoading(true);
        const data = await getInventory();
        setInventory(data);
        setIsLoading(false);
    };

    useEffect(() => {
        loadData();
    }, []);

    const toggleExpand = (key: string) => {
        const newSet = new Set(expandedKeys);
        if (newSet.has(key)) {
            newSet.delete(key);
        } else {
            newSet.add(key);
        }
        setExpandedKeys(newSet);
    };

    const getStatus = (qty: number) => {
        if (qty <= 0) return { icon: <XCircle className="w-4 h-4 text-red-500" />, label: 'Out of Stock', color: 'text-red-600 bg-red-50 border-red-200' };
        if (qty < 500) return { icon: <AlertTriangle className="w-4 h-4 text-amber-500" />, label: 'Low Stock', color: 'text-amber-600 bg-amber-50 border-amber-200' };
        return { icon: <CheckCircle className="w-4 h-4 text-emerald-500" />, label: 'In Stock', color: 'text-emerald-600 bg-emerald-50 border-emerald-200' };
    };

    const filteredInventory = useMemo(() => {
        if (!searchText) return inventory;
        const lower = searchText.toLowerCase();
        return inventory.filter(item =>
            item.materialKey.toLowerCase().includes(lower) ||
            item.paperType.toLowerCase().includes(lower) ||
            item.paperWeight.toLowerCase().includes(lower)
        );
    }, [inventory, searchText]);

    // Helper to determine pricing mode
    const getPricingMode = (item: InventoryItem): 'SQFT' | 'UNIT' => {
        const mat = item.materialKey.toLowerCase();
        const size = item.size?.toLowerCase() || '';

        // Explicit Substrate/Board check -> UNIT
        if (mat.includes('substrate') || mat.includes('rigid') || mat.includes('foam') || mat.includes('gator') || mat.includes('sintra')) {
            return 'UNIT';
        }

        // Rolls -> SQFT
        // Check for "Roll" keyword or dimensions like 54"x100'
        if (size.includes("'") || size.includes("roll")) {
            return 'SQFT';
        }

        // Vinyl/Banner that isn't explicitly rigid usually implies Roll, but relying on Size is safer.
        // If it's "Vinyl" but size is 4x8, it might be rigid? No, usually vinyl is roll.
        // Let's stick to: If Size implies Roll (has feet ' indicator) -> SqFt.
        // Or if Material is Vinyl/Banner -> SqFt.
        if (mat.includes('vinyl') || mat.includes('banner') || mat.includes('adhesive')) {
            // Check if it looks like a sheet (e.g. 11x17) -> UNIT
            if (!size.includes("'") && !size.includes("roll") && size.includes('"')) {
                return 'UNIT'; // Pre-cut vinyl sheets
            }
            return 'SQFT';
        }

        return 'UNIT';
    };

    const calculateSqFt = (sizeStr: string): number | null => {
        if (!sizeStr) return null;
        const clean = sizeStr.toLowerCase().replace(/\s/g, '');
        // Match: 54"x150' or 54"x100ft
        const rollMatch = clean.match(/(\d+(\.\d+)?)"x(\d+(\.\d+)?)['f]/);
        if (rollMatch) {
            const widthInches = parseFloat(rollMatch[1]);
            const lengthFeet = parseFloat(rollMatch[3]);
            return (widthInches / 12) * lengthFeet;
        }
        return null;
    };

    if (isLoading) {
        return <div className="p-12 text-center text-gray-500">Loading Inventory...</div>;
    }

    return (
        <div className="space-y-6">
            <div className="bg-white border border-gray-200 rounded-2xl shadow-sm p-5 space-y-5">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                            <Package className="w-5 h-5 text-[#017494]" />
                            Paper Inventory
                        </h2>
                        <p className="text-sm text-gray-500 mt-1">
                            FIFO tracking for {inventory.length} distinct materials
                        </p>
                    </div>
                    <button
                        onClick={loadData}
                        className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50 transition-colors shadow-sm text-sm font-medium"
                    >
                        <RefreshCw className="w-4 h-4" /> Refresh
                    </button>
                </div>

                {/* Filter */}
                <div className="relative max-w-md">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                        type="text"
                        placeholder="Search materials..."
                        value={searchText}
                        onChange={(e) => setSearchText(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-[#017494] focus:ring-1 focus:ring-[#017494]"
                    />
                    {searchText && (
                        <button onClick={() => setSearchText('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                            <X className="w-4 h-4" />
                        </button>
                    )}
                </div>
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="min-w-full border-separate border-spacing-0">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider border-b border-gray-200">Material Spec</th>
                            <th className="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wider border-b border-gray-200">Total Qty</th>
                            <th className="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wider border-b border-gray-200">Cost (Unit/SqFt)</th>
                            <th className="px-6 py-3 text-center text-xs font-bold text-gray-500 uppercase tracking-wider border-b border-gray-200">Status</th>
                            <th className="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wider border-b border-gray-200">Avg Cost</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                        {filteredInventory.map((item) => {
                            const isExpanded = expandedKeys.has(item.materialKey);
                            const status = getStatus(item.totalQtyAvailable);

                            return (
                                <React.Fragment key={item.materialKey}>
                                    <tr
                                        className={`hover:bg-gray-50 transition-colors cursor-pointer ${isExpanded ? 'bg-gray-50' : ''}`}
                                        onClick={() => toggleExpand(item.materialKey)}
                                    >
                                        <td className="px-6 py-4">
                                            <div className="flex items-center gap-3">
                                                {isExpanded ? <ChevronDown className="w-4 h-4 text-gray-400" /> : <ChevronRight className="w-4 h-4 text-gray-400" />}
                                                <div>
                                                    <div className="text-sm font-bold text-gray-900">{item.paperWeight} {item.paperType}</div>
                                                    <div className="text-xs text-gray-500">{item.size} {item.paperFinish && `• ${item.paperFinish}`}</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 text-right text-sm text-gray-900 font-mono">
                                            {item.totalQtyAvailable.toLocaleString()} <span className="text-gray-400 text-xs">{getPricingMode(item) === 'SQFT' ? 'rolls' : 'units'}</span>
                                        </td>
                                        <td className="px-6 py-4 text-right text-sm font-bold text-[#017494]">
                                            {(() => {
                                                const mode = getPricingMode(item);
                                                const cost = item.oldestLotCost;

                                                if (mode === 'SQFT') {
                                                    // item.oldestLotCost is currently Cost/Sheet (or Cost/Unit). 
                                                    // For a roll, Cost/Unit = Cost Per Roll.
                                                    // We need Cost / SqFt.
                                                    const sqFt = calculateSqFt(item.size);
                                                    if (sqFt && sqFt > 0) {
                                                        return (
                                                            <span>${(cost / sqFt).toFixed(2)}<span className="text-xs font-normal text-gray-400">/sqft</span></span>
                                                        );
                                                    }
                                                }
                                                return <span>${cost.toFixed(4)}<span className="text-xs font-normal text-gray-400">/ea</span></span>;
                                            })()}
                                        </td>
                                        <td className="px-6 py-4 text-center">
                                            <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${status.color}`}>
                                                {status.icon} {status.label}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 text-right text-sm text-gray-500">
                                            ${item.avgCostPerSheet.toFixed(4)}
                                        </td>
                                    </tr>
                                    {isExpanded && (
                                        <tr className="bg-gray-50/50">
                                            <td colSpan={5} className="px-6 py-4 border-t border-gray-100 inset-shadow">
                                                <div className="ml-8 border-l-2 border-gray-200 pl-4">
                                                    <h4 className="text-xs font-bold text-gray-500 uppercase mb-3">Lot History (FIFO)</h4>
                                                    <table className="w-full text-sm">
                                                        <thead className="text-xs text-gray-400 text-left">
                                                            <tr>
                                                                <th className="pb-2">Date Received</th>
                                                                <th className="pb-2">Vendor</th>
                                                                <th className="pb-2">Invoice #</th>
                                                                <th className="pb-2 text-right">Original Qty</th>
                                                                <th className="pb-2 text-right">Remaining</th>
                                                                <th className="pb-2 text-right">Cost ({getPricingMode(item) === 'SQFT' ? '$/Roll' : '$/Unit'})</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody className="divide-y divide-gray-100">
                                                            {item.lots.map(lot => (
                                                                <tr key={lot.id} className={lot.currentQty === 0 ? 'text-gray-400 italic' : 'text-gray-700'}>
                                                                    <td className="py-2">{lot.invoiceDate}</td>
                                                                    <td className="py-2 text-[10px] uppercase font-bold tracking-wide">{lot.vendor}</td>
                                                                    <td className="py-2 font-mono text-xs">{lot.invoiceNumber}</td>
                                                                    <td className="py-2 text-right">{lot.originalQty.toLocaleString()}</td>
                                                                    <td className="py-2 text-right font-bold">{lot.currentQty.toLocaleString()}</td>
                                                                    <td className="py-2 text-right">${lot.costPerSheet.toFixed(4)}</td>
                                                                </tr>
                                                            ))}
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </td>
                                        </tr>
                                    )}
                                </React.Fragment>
                            );
                        })}
                        {filteredInventory.length === 0 && (
                            <tr>
                                <td colSpan={5} className="text-center py-12 text-gray-500">
                                    No inventory found matching your search.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
