import React, { useEffect, useState } from 'react';
import { Plus, Trash2, Save, BookOpen, AlertCircle } from 'lucide-react';
import { VendorRule } from '../types';
import { getVendorRules, saveVendorRule, deleteVendorRule } from '../services/db';

export const RulesManager: React.FC = () => {
  const [rules, setRules] = useState<VendorRule[]>([]);
  const [newVendor, setNewVendor] = useState('');
  const [newRuleText, setNewRuleText] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  const loadRules = async () => {
    setIsLoading(true);
    const data = await getVendorRules();
    setRules(data);
    setIsLoading(false);
  };

  useEffect(() => {
    loadRules();
  }, []);

  const handleAddRule = async () => {
    if (!newVendor.trim() || !newRuleText.trim()) return;

    await saveVendorRule({
      vendorName: newVendor.trim(),
      rule: newRuleText.trim(),
      isActive: true
    });

    setNewVendor('');
    setNewRuleText('');
    loadRules();
  };

  const handleDeleteRule = async (id?: number) => {
    if (id && window.confirm('Delete this rule?')) {
      await deleteVendorRule(id);
      loadRules();
    }
  };

  const handleToggleRule = async (rule: VendorRule) => {
    await saveVendorRule({ ...rule, isActive: !rule.isActive });
    loadRules();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">

      {/* Header */}
      <div className="bg-[#F0F9FF] dark:bg-cyan-900/20 border border-cyan-100 dark:border-cyan-800 rounded-2xl p-6">
        <h2 className="text-lg font-bold text-[#017494] dark:text-[#90B8F0] flex items-center gap-2">
          <BookOpen className="w-5 h-5" />
          Vendor Rules Engine
        </h2>
        <p className="text-gray-700 dark:text-gray-300 text-sm mt-2">
          Teach the AI how to handle specific vendors. These rules are injected into the prompt automatically when the vendor name matches.
        </p>
        <p className="text-xs text-[#017494] dark:text-[#90B8F0] mt-2 italic font-medium">
          Example: Vendor "Acme Corp" &rarr; Rule "Always ignore the 'Backorder' column and use 'Shipped' for quantity."
        </p>
      </div>

      {/* Add New Rule */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <h3 className="text-lg font-bold text-[#0F1011] dark:text-white mb-4">Add New Rule</h3>
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
          <div className="md:col-span-4 space-y-1">
            <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Vendor Name</label>
            <input
              type="text"
              value={newVendor}
              onChange={(e) => setNewVendor(e.target.value)}
              placeholder="e.g. Piedmont Plastics"
              className="w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-[#017494] outline-none text-gray-900 dark:text-white transition-all shadow-sm"
            />
          </div>
          <div className="md:col-span-6 space-y-1">
            <label className="text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Custom Instruction</label>
            <input
              type="text"
              value={newRuleText}
              onChange={(e) => setNewRuleText(e.target.value)}
              placeholder="e.g. Ignore items with SKU starting with 'FRT'"
              className="w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-[#017494] outline-none text-gray-900 dark:text-white transition-all shadow-sm"
            />
          </div>
          <div className="md:col-span-2">
            <button
              onClick={handleAddRule}
              disabled={!newVendor || !newRuleText}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-[#0F1011] hover:bg-[#2A2B2C] disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl transition-all font-bold shadow-lg hover:shadow-xl active:scale-95"
            >
              <Plus className="w-4 h-4" /> Add
            </button>
          </div>
        </div>
      </div>

      {/* Existing Rules List */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50">
          <h3 className="text-base font-bold text-[#0F1011] dark:text-white">Active Rules ({rules.length})</h3>
        </div>

        {isLoading ? (
          <div className="p-8 text-center text-gray-500">Loading rules...</div>
        ) : rules.length === 0 ? (
          <div className="p-12 text-center text-gray-500 dark:text-gray-400 flex flex-col items-center gap-2">
            <AlertCircle className="w-8 h-8 text-gray-300 dark:text-gray-600" />
            <p>No rules defined yet.</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-100 dark:divide-gray-700">
            {rules.map(rule => (
              <div key={rule.id} className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                <div className="flex items-start gap-4 flex-1">
                  <input
                    type="checkbox"
                    checked={rule.isActive}
                    onChange={() => handleToggleRule(rule)}
                    className="mt-1 w-5 h-5 text-[#017494] rounded border-gray-300 focus:ring-[#017494] cursor-pointer"
                  />
                  <div>
                    <h4 className={`font-bold text-[#0F1011] dark:text-white ${!rule.isActive && 'opacity-50 line-through'}`}>
                      {rule.vendorName}
                    </h4>
                    <p className={`text-sm text-gray-600 dark:text-gray-300 ${!rule.isActive && 'opacity-50'}`}>
                      {rule.rule}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => handleDeleteRule(rule.id)}
                  className="text-gray-400 hover:text-red-500 dark:hover:text-red-400 transition-colors p-2 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 self-end sm:self-center"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};