import React from 'react';
import { X, ExternalLink, FileText, Image as ImageIcon } from 'lucide-react';

interface PdfPreviewProps {
  file: File | null;
  onClose: () => void;
}

export const PdfPreview: React.FC<PdfPreviewProps> = ({ file, onClose }) => {
  if (!file) return null;

  // Create a stable object URL for the file
  const objectUrl = React.useMemo(() => {
    return URL.createObjectURL(file);
  }, [file]);

  // Cleanup the object URL when component unmounts or file changes
  React.useEffect(() => {
    return () => URL.revokeObjectURL(objectUrl);
  }, [objectUrl]);

  const isPdf = file.type === 'application/pdf';

  return (
    <div className="fixed inset-y-0 right-0 w-full md:w-1/2 lg:w-5/12 bg-white dark:bg-gray-800 shadow-2xl z-50 transform transition-transform duration-300 ease-in-out border-l border-gray-200 dark:border-gray-700 flex flex-col">
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
        <div className="flex items-center gap-2 overflow-hidden">
          {isPdf ? <FileText className="w-5 h-5 text-red-500" /> : <ImageIcon className="w-5 h-5 text-blue-500" />}
          <h3 className="font-semibold text-gray-900 dark:text-gray-100 truncate max-w-[200px]" title={file.name}>
            {file.name}
          </h3>
        </div>
        <div className="flex items-center gap-2">
            <a 
                href={objectUrl} 
                target="_blank" 
                rel="noreferrer"
                className="p-2 text-gray-500 hover:text-indigo-600 dark:text-gray-400 dark:hover:text-indigo-400 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
                title="Open in new tab"
            >
                <ExternalLink className="w-5 h-5" />
            </a>
            <button 
                onClick={onClose}
                className="p-2 text-gray-500 hover:text-red-600 dark:text-gray-400 dark:hover:text-red-400 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
            >
                <X className="w-5 h-5" />
            </button>
        </div>
      </div>
      
      <div className="flex-1 bg-gray-100 dark:bg-gray-900 overflow-hidden relative">
        {isPdf ? (
            <iframe 
                src={`${objectUrl}#toolbar=0&navpanes=0`} 
                className="w-full h-full border-none"
                title="PDF Preview"
            />
        ) : (
            <div className="w-full h-full flex items-center justify-center overflow-auto p-4 bg-checkerboard">
                <img 
                    src={objectUrl} 
                    alt="Invoice Preview" 
                    className="max-w-full max-h-full object-contain shadow-lg rounded-lg" 
                />
            </div>
        )}
      </div>
    </div>
  );
};