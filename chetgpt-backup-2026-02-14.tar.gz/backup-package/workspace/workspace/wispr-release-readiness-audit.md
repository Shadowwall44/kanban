# Wispr Desktop Release-Readiness Audit (Q9)

**Owner:** Aviel  
**Date:** 2026-02-14 (EST)  
**Scope:** Desktop voice-to-text app readiness for daily use, then 30-day consecutive usage streak  
**Primary repo audited:** `inkredible-voice` (full code audit already completed)  
**Inputs reviewed:**
- `goal-driven-roadmap.md` (Q9 target)
- `audits/inkredible-voice-audit.md`
- `inkredible-voice/CLAUDE.md`
- Spot-check of current source files (`.env.example`, `main.js`, `tray.js`, `windows.js`, `correction-monitor.js`, `package.json`)

---

## Executive Readiness Verdict

**Current state: NOT ready for daily use yet.**  
You are close. Core architecture is strong, but there are **4 hard blockers** (already identified) plus **3 release-critical blockers** that should be fixed before calling this “daily-driver ready.”

**Expected effort to shippable MVP:** **~8–12 hours** focused execution (consistent with previous audit).

---

## 1) Blocker List (Prioritized)

## P0 — Must Fix Before Daily Use (Non-Negotiable)

| Priority | Blocker | Why it blocks release | Evidence | Done when... |
|---|---|---|---|---|
| P0-1 | **Leaked API key in `.env.example`** | Security and account-risk issue; key may already be compromised if repo is shared/public | Real key present in `inkredible-voice/.env.example` | Key rotated/revoked, `.env.example` replaced with placeholder, new key only in local `.env`/settings |
| P0-2 | **Indicator window never created** | No user feedback during recording/processing/errors; fix popup flow unreachable | `main.js` never calls `createIndicatorWindow()` | Indicator visibly shows Listening → Processing → Pasted/Error across full cycle |
| P0-3 | **Tray menu bypasses state machine** | Tray Start/Stop unreliable; wrong call signatures and state drift can break recording flow | `tray.js` calls `pipeline.startRecording()` directly and passes API key to `stopAndProcess()` incorrectly | Tray Start/Stop uses same state-machine path as hotkey and works 100% |
| P0-4 | **Electron 28 vulnerability** (upgrade to **>=35.7.5**, target 40) | Known security vulnerability; unacceptable for release build | `package.json` has `electron:^28.3.3` | Electron upgraded (>=35.7.5), app boots, dictation works, build passes |

## P1 — Release-Critical (Fix before “shippable installer”)

| Priority | Blocker | Why it matters | Evidence | Done when... |
|---|---|---|---|---|
| P1-1 | **`read-focused-text.ps1` packaging path issue** | Correction monitor likely breaks in packaged/asar builds | Script referenced from repo root in `correction-monitor.js` | Script moved/packaged via `extraResources`, path resolves in installed app |
| P1-2 | **No automated smoke test gate** | Easy to regress core flow while fixing P0s | No test setup currently active | Basic automated smoke tests exist and pass before each release build |
| P1-3 | **Settings trust mismatch (hotkey/autostart UI not aligned to behavior)** | User confusion and “app feels broken” risk in daily use | Hotkey saved values do not drive runtime behavior; auto-start toggle appears non-functional | UI only shows real behavior OR behavior is implemented to match UI |

## P2 — Strongly Recommended (Can follow immediately after MVP)
- Add CSP/meta hardening across non-main renderer windows.
- Remove dead dependencies/config duplication for cleaner maintenance.
- Add persistent log files for easier bug triage.

---

## 2) Release Sequence (Exact Order: Current State → Shippable)

## Phase A — Freeze + Safety (30 min)
1. Create release branch: `release/wispr-mvp-rc1`.
2. Save current working state and tag baseline (`pre-q9-release-readiness`).
3. Define strict scope: **only blockers + tests + packaging** (no feature expansion).

## Phase B — Security First (20 min)
1. Revoke leaked Groq key.
2. Generate new key.
3. Update local environment/settings.
4. Replace `.env.example` with placeholder format only.
5. Verify no secrets in tracked files (`rg "gsk_"`).

## Phase C — Core Runtime Fixes (1.5–2.5 hrs)
1. Create indicator window during app init (`main.js`).
2. Refactor tray actions to call the same start/stop path as hotkey/state machine.
3. Fix/validate tray menu state refresh after transition.
4. Run manual loop: hotkey and tray each perform 5 full dictation cycles.

## Phase D — Packaging-Critical Fixes (45–75 min)
1. Move/package `read-focused-text.ps1` correctly for production.
2. Update path resolution for dev + packaged builds.
3. Build installer once and verify correction-monitor path in installed app.

## Phase E — Dependency/Security Upgrade (3–4.5 hrs)
1. Upgrade Electron to target modern secure line (minimum 35.7.5; preferred 40.x).
2. Upgrade electron-builder to current stable line.
3. Resolve breakages (preload/clipboard APIs and any Electron API deltas).
4. Re-run full dictation + tray + settings + history + dictionary flows.

## Phase F — Test Gate (1.5–2.5 hrs)
1. Add basic automated smoke tests for core modules.
2. Execute manual test matrix (see section 4).
3. Fix any regressions; rerun until pass.

## Phase G — Release Candidate Build (45–60 min)
1. Build signed/unsigned RC installer.
2. Install on clean Windows profile or VM.
3. Validate startup, permissions, dictation, tray, persistence.
4. Tag as `v1.0.0-rc1` only after all tests pass.

## Phase H — Daily-Use Launch (same day)
1. Install on Aviel’s production machine.
2. Use as primary dictation tool for workday.
3. Start 30-day tracker immediately (section 6).

---

## 3) Fix Estimates

| Blocker | Estimate |
|---|---:|
| P0-1 API key rotate + sanitize examples | 0.2–0.4 hr |
| P0-2 Indicator window creation + validation | 0.4–0.8 hr |
| P0-3 Tray/state-machine wiring fix | 0.8–1.5 hr |
| P0-4 Electron + builder security upgrade | 3.0–4.5 hr |
| P1-1 Packaged script path fix (`read-focused-text.ps1`) | 0.5–1.0 hr |
| P1-2 Automated smoke tests (minimum viable gate) | 1.5–2.5 hr |
| P1-3 Settings behavior alignment (hotkey/autostart truthfulness) | 0.8–1.5 hr |
| Final RC packaging + clean-machine verification | 0.8–1.2 hr |

**Total expected:** **8.0–13.4 hours**  
**Likely target with tight scope:** **8–12 hours**

---

## 4) Test Plan (Release Gate)

## A. Automated Smoke Tests (minimum)
- State machine transitions (IDLE → RECORDING → PROCESSING → PASTING → IDLE).
- Tray start/stop path invokes same lifecycle as hotkey path.
- Dictionary CRUD (create/edit/delete/persist after restart).
- Pipeline guards (silence/hallucination thresholds).
- Settings load/save sanity (only true behavior exposed).

## B. Manual Functional Tests (must pass)
1. **Hotkey dictation loop x10** in mixed apps (Notepad, Chrome field, internal app field).
2. **Tray dictation loop x10** with no failures/hangs.
3. Indicator states visible at each lifecycle stage.
4. Clipboard preserved before/after dictation.
5. Error path test: invalid API key shows user-facing failure and recovers.
6. Correction monitor test: intentional single-word correction is detected and learned.
7. Restart app and verify dictionary/history persistence.
8. Long dictation test (30–60 seconds) and quick short dictation (<2 seconds).

## C. Security/Release Tests
- Confirm no keys/tokens in repo-tracked files.
- `npm audit` review after upgrades (no known critical path issues unresolved for release).
- Packaged installer test on clean machine/profile.
- Verify app survives reboot and relaunch reliably.

## Release Exit Criteria
- All P0 + P1 blockers closed.
- Automated smoke tests pass.
- Manual matrix passes.
- Installer verified on clean environment.

---

## 5) Daily Use Checklist (Aviel’s Machine)

## One-Time Setup
- [ ] Windows 11 updated and mic permissions enabled.
- [ ] Install latest Wispr desktop RC build.
- [ ] Enter valid Groq key in app settings (new rotated key).
- [ ] Confirm hotkey works in real work apps.
- [ ] Confirm tray controls work.
- [ ] Confirm indicator feedback appears.
- [ ] Run one successful correction-learning cycle.

## Daily Startup Checklist (2–3 minutes)
- [ ] App running in tray.
- [ ] Microphone input level healthy.
- [ ] One test dictation sent successfully.
- [ ] History entry appears for that dictation.

## End-of-Day Check (1 minute)
- [ ] At least one meaningful dictation session completed.
- [ ] No unresolved crash/blocker from today.
- [ ] Usage streak metric updated (automated or manual).

---

## 6) 30-Day Usage Tracking Plan (Goal: 30 Consecutive Days)

## Define “Used Today” (binary pass/fail)
A day counts as **USED** if both are true:
1. **>= 3 successful dictations** recorded in history, and
2. **>= 120 total words** transcribed that day.

(Threshold prevents fake/accidental single-use check-ins.)

## Data Source
- Primary: existing history records in app database (timestamp, word count, text).
- Optional secondary: lightweight local JSON export for dashboard display.

## Streak Logic
- `streakDays`: consecutive days meeting USED criteria.
- Missed day resets streak to 0.
- `bestStreak`: max consecutive run achieved.
- Target reached at `streakDays >= 30`.

## Tracking Cadence
- Daily auto-calc at fixed local time (e.g., 9:00 PM).
- Weekly review every Sunday:
  - Days used / 7
  - Total dictations
  - Total words
  - Failure reasons on missed days

## Practical Implementation Across 3 Repos
1. **inkredible-voice**: generate daily usage summary from history DB.
2. **inkredible-tools**: show simple streak dashboard widget (today used?, current streak, best streak).
3. **kanban**: auto-create/maintain a “Wispr Day X/30” checklist card for accountability.

## Anti-dropout Rule (identity protection)
If a day is missed:
- Do **same-day recovery protocol**: minimum 10-minute focused dictation session before bed.
- Log root cause in one line (e.g., crash, forgot app open, mic issue, overwhelm).
- Apply one preventive fix the next morning.

---

## Suggested First Sprint (Tonight)
1. Rotate leaked key + sanitize `.env.example`.
2. Fix indicator window creation.
3. Fix tray-to-state-machine wiring.
4. If time remains: fix packaged script path.

This gets you from “fragile” to “trustable core,” which is the most important psychological and technical milestone for your first official app.
