#!/usr/bin/env python3
"""
NextDayFlyers Postcard Pricing Scraper
Uses Selenium to extract pricing from the calculator
"""

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
import json
import time

def get_postcard_pricing():
    # Setup headless Chrome
    chrome_options = Options()
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    
    driver = webdriver.Chrome(options=chrome_options)
    
    try:
        # 4x6 Postcard page
        url = "https://www.nextdayflyers.com/postcard-printing/standard-postcards.php"
        driver.get(url)
        
        # Wait for calculator to load
        wait = WebDriverWait(driver, 10)
        
        # Size should already be 4x6 (default)
        quantities = [100, 250, 500, 1000, 2500, 5000, 10000]
        turnarounds = {
            "22520": "Same Day",
            "22519": "Next Business Day", 
            "22518": "3 Business Days"
        }
        
        results = []
        
        for qty in quantities:
            print(f"\n=== Checking quantity: {qty} ===")
            
            # Select quantity
            qty_dropdown = wait.until(EC.element_to_be_clickable((By.ID, "attr_container_5")))
            qty_dropdown.click()
            time.sleep(0.5)
            
            # Find and click the quantity option
            qty_option = driver.find_element(By.XPATH, f"//a[@data-display='{qty:,}']")
            qty_option.click()
            time.sleep(1)  # Wait for price update
            
            # Single-sided (Full Color front, No Printing back)
            back_dropdown = wait.until(EC.element_to_be_clickable((By.ID, "attr_container_337")))
            back_dropdown.click()
            time.sleep(0.5)
            
            # Select "No Printing"
            no_print = driver.find_element(By.XPATH, "//a[@data-value='22404']")
            no_print.click()
            time.sleep(1)
            
            # Get prices for each turnaround
            for ta_value, ta_name in turnarounds.items():
                ta_radio = driver.find_element(By.XPATH, f"//input[@name='333-option'][@value='{ta_value}']")
                ta_radio.click()
                time.sleep(1)
                
                price_elem = wait.until(EC.presence_of_element_located((By.ID, "price")))
                price = price_elem.text.strip()
                
                unit_price_elem = driver.find_element(By.CSS_SELECTOR, "[data-qaid='originalUnitPrice']")
                unit_price = unit_price_elem.text.strip()
                
                results.append({
                    "size": "4x6",
                    "quantity": qty,
                    "sides": "Single-sided",
                    "turnaround": ta_name,
                    "price": price,
                    "unit_price": unit_price
                })
                print(f"  {ta_name}: {price} ({unit_price} each)")
            
            # Double-sided (Full Color both sides)
            back_dropdown.click()
            time.sleep(0.5)
            
            full_color = driver.find_element(By.XPATH, "//a[@data-value='22403']")
            full_color.click()
            time.sleep(1)
            
            for ta_value, ta_name in turnarounds.items():
                ta_radio = driver.find_element(By.XPATH, f"//input[@name='333-option'][@value='{ta_value}']")
                ta_radio.click()
                time.sleep(1)
                
                price_elem = wait.until(EC.presence_of_element_located((By.ID, "price")))
                price = price_elem.text.strip()
                
                unit_price_elem = driver.find_element(By.CSS_SELECTOR, "[data-qaid='originalUnitPrice']")
                unit_price = unit_price_elem.text.strip()
                
                results.append({
                    "size": "4x6",
                    "quantity": qty,
                    "sides": "Double-sided",
                    "turnaround": ta_name,
                    "price": price,
                    "unit_price": unit_price
                })
                print(f"  {ta_name} (DS): {price} ({unit_price} each)")
        
        # Save results
        with open("postcard_pricing_4x6.json", "w") as f:
            json.dump(results, f, indent=2)
        
        print(f"\n✅ Saved {len(results)} price points to postcard_pricing_4x6.json")
        return results
        
    finally:
        driver.quit()

if __name__ == "__main__":
    get_postcard_pricing()
