# MIS Floor Job Calendar + Quote Analytics Spec (Q8)

**Business:** INKredible Printing  
**Date:** 2026-02-14  
**Owner:** Aviel  
**Module:** MIS v1 Module 4 (Floor Graphics Calendar) + analytics extension for quote performance

---

## 0) Context + source alignment

This spec is built from:
- `goal-driven-roadmap.md` (Q8 target)
- `mis-v1-scope-lock.md` (Q7 schema + module boundaries)
- `memory/brain-dump-01.md` (explicit request: floor graphic tracking calendar)
- `dm-to-quote-sop.md` (Q6 lead/quote flow integration)
- `weekly-finance-scoreboard-template.md` (Q2 KPI feed integration)

> Note: `floor-graphics-pipeline-system.md` was not present. Pipeline stages are pulled from roadmap/Q7:  
**Lead → Quote → Booked → Production → Delivered/Installed → Paid**

---

## 1) Business objective (why this module exists)

Floor graphics are the primary revenue lever ($1K–$10K+ per job). This module must:
1. Give daily/weekly/monthly scheduling control for floor jobs.
2. Prevent production overbooking by machine capacity.
3. Show quote performance and pipeline value clearly.
4. Feed finance scoreboard metrics (especially floor graphics revenue share target **≥30%**).

---

## 2) Calendar View Spec

## 2.1 Required views

### A) Monthly view (planning + volume)
- Primary use: forecast volume, identify weak months, spot install clustering.
- Each day cell shows:
  - total floor jobs
  - total booked sqft
  - total quoted $ in-day
  - capacity status chip (Green/Yellow/Red)
- Click day → drill to day agenda panel.

### B) Weekly view (production control)
- Primary use: machine loading and install sequence.
- Shows 7-day columns + resource lanes:
  - HP Latex 700W lane
  - Roland VG2-540 lane
  - Install team lane
- Job bars render across prep/print/install windows.
- Capacity bars per resource per day + week.

### C) Daily view (execution)
- Primary use: run today’s production/install.
- Hourly schedule + task queue:
  - prepress/art approval
  - print block(s)
  - cut/finish block(s)
  - install window
- Day footer: planned hours vs available hours by machine.

---

## 2.2 Job card fields (all views)

Each floor job must show:
- **Client**
- **Size (sqft)**
- **Location** (venue/site)
- **Install date/time**
- **Quoted price**
- **Status**

Additional compact metadata:
- Job #
- Owner (Brandon/Aviel/user)
- Machines needed (HP, Roland, Both)
- Rush flag

---

## 2.3 Status model + color coding

| Status | Meaning | Calendar Color | Text/Icon |
|---|---|---|---|
| `quoted` | Quote sent, not committed | Slate/Gray | “Q” |
| `booked` | Client approved, slot reserved | Blue | “B” |
| `in_production` | Printing/finishing in progress | Amber | “P” |
| `installed` | Installed/delivered complete | Green | “I” |
| `paid` | Invoice paid | Purple | “$” |

Rules:
- Calendar defaults to these statuses for floor jobs.
- If status becomes `lost/cancelled`, dim card + strike-through title.
- Overdue jobs (install date past, not installed) get red border alert.

---

## 2.4 Capacity indicators (weekly production reality)

## Core concept
Capacity is machine-hour constrained, then translated to job throughput.

For each week, compute:
- `available_hp_hours_week`
- `available_roland_hours_week`
- `required_hp_hours_week`
- `required_roland_hours_week`
- `utilization_pct = required / available * 100`

### Capacity status colors
- **Green:** < 80% utilized
- **Yellow:** 80–95%
- **Red:** > 95% (collision risk)

### Collision warning triggers
- If any day utilization > 100% for required resource.
- If install windows overlap with same install crew and no alternate crew assigned.
- If rush job would force weekly utilization > 105%.

---

## 2.5 Print time estimation (HP Latex 700W + Roland VG2-540)

> Speeds are configurable profile values in admin settings and must be calibrated from real INKredible runs.

## A) Floor area formula
- `sqft = width_ft * height_ft`

## B) HP Latex 700W estimate
- `base_hp_time = sqft / hp_sqft_per_hour_effective`
- `hp_hours = base_hp_time + setup_hours + (base_hp_time * buffer_pct)`
- Default planning values (editable):
  - `hp_sqft_per_hour_effective = 150` (planning throughput)
  - `setup_hours = 0.5` per job
  - `buffer_pct = 0.10`
- If white ink required: apply slowdown factor (default 0.75x throughput).

## C) Roland VG2-540 estimate
- For print+cut dependent steps:
- `base_roland_time = sqft / roland_sqft_per_hour_effective`
- `roland_hours = base_roland_time + setup_hours + (base_roland_time * contour_cut_buffer_pct)`
- Default planning values (editable):
  - `roland_sqft_per_hour_effective = 60`
  - `setup_hours = 0.5`
  - `contour_cut_buffer_pct = 0.25`

## D) When both machines are required
Use bottleneck logic:
- `job_total_machine_hours = max(hp_hours, roland_hours)` if parallelizable
- `job_total_machine_hours = hp_hours + roland_hours` if sequential dependency

Calendar must display:
- HP load impact
- Roland load impact
- Bottleneck resource badge (“HP bottleneck” or “Roland bottleneck”)

---

## 2.6 Seed job (first required calendar entry)

Create first record from current context:
- **Client:** Lux Events (or confirmed client name)
- **Job type:** floor_graphics
- **Dimensions:** 25 ft × 88 ft
- **Calculated size:** **2,200 sqft**
- **Quoted price:** **$10,000**
- **Install date:** next week (exact date/time required in intake)
- **Status:** `booked` (or `quoted` if not approved yet)

---

## 3) Quote Analytics Dashboard Spec

## 3.1 Dashboard filters
Global filters:
- Date range (MTD, QTD, YTD, custom)
- Job type (default floor_graphics)
- Client segment (event planner, rental, etc.)
- Lead source (IG DM, referral, phone, email)
- Owner/user

---

## 3.2 Required KPI cards + formulas

1. **Win Rate**
   - `win_rate_pct = closed_won_quotes / total_quotes_sent * 100`
   - Closed-won = quotes converted to booked jobs.

2. **Average Deal Size Trend**
   - `avg_deal_size = closed_revenue / number_of_closed_jobs`
   - Trend line by month.

3. **Time-to-Close by Job Type**
   - `time_to_close_days = date_booked - quote_sent_at`
   - Show median + p75 by job_type.

4. **Revenue by Client**
   - Sum paid invoice revenue by customer for selected period.
   - Show Top 10 + “Long tail”.

5. **Floor Graphics % of Total Revenue**
   - `floor_share_pct = floor_graphics_revenue / total_revenue * 100`
   - Target line fixed at **30%**.

6. **Monthly / Quarterly Comparison**
   - MoM: current month vs previous month.
   - QoQ: current quarter vs previous quarter.
   - Include delta $ + delta %.

7. **Pipeline Value (Open Quotes)**
   - `pipeline_value = sum(quote_amount where status in [sent, revised, negotiating] and not closed)`
   - Split by aging bucket: 0–7d, 8–14d, 15–30d, 30+d.

---

## 3.3 Analytics visual layout (desktop)

- Row 1 KPI cards: Win Rate | Avg Deal | Time-to-Close | Pipeline Value
- Row 2: Floor % vs 30% target (area chart) + Revenue by Client (bar)
- Row 3: MoM/QoQ comparison table + Open pipeline aging funnel
- Row 4: Quote outcomes by lead source/owner

Alert badges:
- Red if floor share <20%
- Yellow if 20–29.9%
- Green if ≥30%

---

## 4) Data Model (Q7 extension)

Q7 base tables reused: `jobs`, `quotes`, `calendar_events`, `customers`, `invoices`, `payments`, `pipeline_weekly_metrics`, `margin_weekly`, `finance_scoreboard_weekly`.

## 4.1 Changes to existing tables

### `jobs` (extend)
Add:
- `install_start_at` (timestamp)
- `install_end_at` (timestamp)
- `install_location_name` (text)
- `install_address` (text)
- `sqft_total` (numeric)
- `production_status` (enum: quoted/booked/in_production/installed/paid/cancelled)
- `requires_hp700w` (bool)
- `requires_roland_vg2` (bool)

### `quotes` (extend)
Add:
- `quote_sent_at` (timestamp)
- `closed_at` (timestamp)
- `close_outcome` (enum: won/lost/open)
- `quoted_total` (numeric)
- `job_type` (text, denormalized for analytics speed)
- `loss_reason` (text)

### `calendar_events` (extend)
Add:
- `resource_type` (enum: hp700w/roland_vg2/install_team)
- `load_hours` (numeric)
- `capacity_pct_after_booking` (numeric)

### `invoices` (extend for QuickBooks sync)
Add:
- `quickbooks_invoice_id` (text)
- `quickbooks_customer_id` (text)
- `sync_status` (enum: pending/synced/error)
- `last_synced_at` (timestamp)

---

## 4.2 New module-specific tables

### `floor_job_specs`
- `job_id` (PK/FK -> jobs.id)
- `width_ft` (numeric)
- `height_ft` (numeric)
- `calculated_sqft` (numeric)
- `material_type` (text)
- `laminate_type` (text)
- `requires_white_ink` (bool)
- `requires_contour_cut` (bool)
- `print_mode` (text)
- `install_complexity` (enum: low/medium/high)
- `notes` (text)

### `resource_capacity_profiles`
- `id` (PK)
- `resource_type` (hp700w/roland_vg2/install_team)
- `effective_sqft_per_hour` (numeric)
- `setup_hours_per_job` (numeric)
- `default_buffer_pct` (numeric)
- `active` (bool)
- `updated_at` (timestamp)

### `resource_availability`
- `id` (PK)
- `resource_type` (hp700w/roland_vg2/install_team)
- `date` (date)
- `available_hours` (numeric)
- `blackout_reason` (text)
- `maintenance_flag` (bool)

### `job_resource_estimates`
- `id` (PK)
- `job_id` (FK)
- `resource_type` (hp700w/roland_vg2/install_team)
- `estimated_hours` (numeric)
- `actual_hours` (numeric, nullable)
- `calc_version` (text)
- `created_at` (timestamp)

### `quote_status_events`
- `id` (PK)
- `quote_id` (FK)
- `from_status` (text)
- `to_status` (text)
- `changed_at` (timestamp)
- `changed_by` (text)

---

## 4.3 Derived views (for dashboard performance)

### `vw_floor_calendar_jobs`
Flattened job+quote+customer+status for calendar rendering.

### `vw_quote_analytics_period`
Periodized facts for win rate, avg deal, time-to-close, pipeline value.

### `vw_client_revenue_rank`
Client revenue ranking from paid invoices (date-filterable).

---

## 5) UI Wireframes (text-based, mobile-first)

## 5.1 Calendar view wireframe

### Desktop / unfolded tablet
```text
+--------------------------------------------------------------------------------+
| Floor Jobs Calendar                 [Month|Week|Day] [Filters] [Add Job]      |
+-----------------------------+--------------------------------------+------------+
| Left Panel                  | Main Calendar Grid                    | Right Pane |
| - Capacity Summary          | Mon Tue Wed Thu Fri Sat Sun          | Job Detail |
|   HP: 72% (Y)               | [job chips w/ status colors]         | + Timeline |
|   Roland: 95% (R)           | [sqft/day + $/day]                   | + Notes    |
|   Install: 68% (G)          | [collision badges]                   | + Actions  |
+-----------------------------+--------------------------------------+------------+
| Bottom: Weekly Machine Load (HP hrs, Roland hrs, Install hrs, Utilization %)  |
+--------------------------------------------------------------------------------+
```

### Samsung Z Fold 7 — folded (cover screen)
```text
[Header]
Floor Calendar  [Week▼] [+]

[Capacity chips]
HP 72% | Roland 95% | Install 68%

[Today / Upcoming cards]
- Lux Events | 2200 sqft | $10,000 | Booked
  Brooklyn venue | Install Tue 8:00 PM
- ...

[Mini agenda]
08:00 Prepress
11:00 HP Print Block
15:00 Roland Cut
20:00 Install
```

### Samsung Z Fold 7 — unfolded (inner screen)
```text
Left: 3-day timeline
Right: selected job details + quote + status actions
Bottom sheet: machine load bars + warnings
```

---

## 5.2 Quote analytics dashboard wireframe

### Desktop / unfolded tablet
```text
+--------------------------------------------------------------------------------+
| Quote Analytics                        [Date] [Job Type] [Source] [Owner]      |
+----------------+----------------+----------------+-----------------------------+
| Win Rate       | Avg Deal Size  | Time to Close  | Pipeline Value              |
| 34%            | $4,850         | 6.2 days       | $41,300                     |
+----------------------------------------+---------------------------------------+
| Floor % of Total Revenue (Target 30%)  | Revenue by Client (Top 10)           |
| Area chart + target line                | Horizontal bars                       |
+----------------------------------------+---------------------------------------+
| MoM / QoQ Comparison Table              | Open Quote Aging (0-7/8-14/15-30/30+) |
+--------------------------------------------------------------------------------+
```

### Samsung Z Fold 7 — folded
```text
[Filters]
MTD | Floor Jobs | All Sources

[KPI stack cards]
1) Win Rate
2) Avg Deal
3) Time-to-Close
4) Pipeline Value
5) Floor Revenue % (target badge)

[Accordion sections]
- Top Clients
- MoM / QoQ
- Aging Pipeline
```

---

## 6) Integration Points

## 6.1 QuickBooks integration (invoice + payment sync)

Flow:
1. MIS quote marked `won`/job `booked`.
2. Job completion/installation triggers invoice creation workflow.
3. QuickBooks sync writes/updates `invoices` + `payments` with QB IDs.
4. Paid events update MIS job to `paid`.
5. Revenue facts become available to analytics and finance scoreboard.

Sync requirements:
- Idempotent by `quickbooks_invoice_id`
- Retry with backoff on API failure
- Keep `sync_status` visible in job detail panel

---

## 6.2 Feed into Weekly Finance Scoreboard (Q2)

This module provides source values for Q2 template fields:
- `floor_revenue_week`
- `floor_share_week_pct`
- `floor_share_4wk_pct`
- Pipeline context for “So What” narrative

Mapping:
- Paid floor invoices (from this module + QB sync) → weekly floor revenue
- Total paid invoices → total weekly revenue denominator
- Result writes to `margin_weekly` and `finance_scoreboard_weekly`

---

## 6.3 Brandon lead pipeline (Q6) → this module

From Q6 DM SOP:
1. Lead enters (`Leads` sheet / CRM) with source + event details.
2. Handoff creates MIS `job` at `lead` or `quote` stage.
3. Quote sent updates `quotes.quote_sent_at`.
4. If client approves, status becomes `booked` and appears in calendar immediately.
5. Production/install execution updates to `in_production` → `installed` → `paid`.

Key requirement:
- No booked floor job can exist without calendar slot + machine estimate rows.

---

## 7) Acceptance criteria (definition of done)

1. Calendar supports Month/Week/Day with required job fields visible.
2. Status colors and transitions work with audit trail.
3. HP/Roland capacity indicators update on each booking edit.
4. Quote analytics cards calculate correctly for selected date range.
5. Floor revenue share KPI displays target comparison (≥30%).
6. First seed $10K floor job is entered and visible.
7. Data exports can feed Q2 Monday scoreboard without manual rework.

---

## 8) Build notes for implementation handoff

- Keep machine speed/config values admin-editable; do not hardcode long-term.
- Prioritize mobile folded mode readability (single-column, large tap targets).
- Use optimistic UI updates for status changes, then reconcile on server response.
- Add row-level audit logs for stage/status edits (jobs + quotes).

---

## What changed / why it matters / next trigger

### What changed
- Defined full technical spec for floor job calendar + quote analytics (views, formulas, schema, wireframes, integrations).
- Added machine-capacity planning logic for HP Latex 700W and Roland VG2-540.
- Linked module outputs directly into Q2 finance scoreboard and Q6 lead pipeline.

### Why it matters
- Converts floor graphics from “memory-based scheduling” into measurable weekly production control.
- Gives direct visibility into whether floor graphics are hitting the 30% revenue target.
- Reduces missed installs, overbooked machines, and untracked open quote value.

### Next trigger
- Generate implementation tickets for: schema migration, calendar UI, capacity engine, analytics queries, and QuickBooks sync hooks.