# Engineer Lessons — Institutional Memory for Sub-Agents

**Read this file before starting ANY coding, deployment, or build task.**
Last updated: 2026-02-13

---

## Deployment

### GitHub Pages (CRITICAL — multiple past failures)
- NEVER include `node_modules/` in gh-pages branch. GitHub blocks files >100MB.
- Use temp-directory approach: copy ONLY build output (`out/`, `public/`, etc.) to clean temp dir, init git there, force-push to gh-pages.
- ALWAYS set git identity before committing:
  ```bash
  git config user.email "chetgpt@inkredible.com"
  git config user.name "ChetGPT"
  ```
- Add cache-busting meta tags to all HTML files (Samsung Internet caches aggressively):
  ```html
  <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="Expires" content="0">
  ```
- GitHub Pages CDN has 1-5 min cache delay. Not instant.

### File Paths
- Working directory is `/home/inkredible/.openclaw/workspace/`
- Do NOT create `workspace/workspace/` (double nesting bug). All output goes directly under `workspace/`.
- Repos live at: `workspace/kanban/`, `workspace/inkredible-tools/`, `workspace/inkredible-voice/`
- Secrets at: `workspace/.secrets/` (chmod 600)

## Coding

### Next.js (inkredible-tools)
- Next.js 16+ requires `src/app/global-error.tsx` for static export builds. Without it: `_global-error invariant` crash.
- Static export: `output: 'export'` in next.config.ts. No API routes, no server components with dynamic data.

### Electron (inkredible-voice)
- Windows ONLY. Never use bash/Linux/Mac commands.
- PowerShell: use semicolons (not &&), `$env:VAR=""` (not unset)
- Electron 28 has known security vulnerability. Target ≥35.7.5.
- contextIsolation: true, nodeIntegration: false, sandbox: true — ALWAYS.
- `npm view <package>` before ANY new install (slopsquatting prevention).

## API Integration

### Gemini / Google AI
- API key: read from `~/.openclaw/agents/main/agent/auth-profiles.json` — NEVER trust compacted/memorized values
- Gemma 3 27B model string: `gemma-3-27b-it` (separate free quota from Gemini Flash)
- OpenAI-compatible endpoint: `https://generativelanguage.googleapis.com/v1beta/openai/`

### NVIDIA NIM (Kimi K2.5)
- Model: `moonshotai/kimi-k2.5`
- Endpoint: `https://integrate.api.nvidia.com/v1/chat/completions`
- Uses OpenAI messages format with Bearer auth

### QuickBooks
- Sandbox: `https://sandbox-quickbooks.api.intuit.com/v3/company`
- Production: `https://quickbooks.api.intuit.com/v3/company`
- Tokens at: `.secrets/quickbooks-tokens.json`
- Access token expires in 1hr, refresh token ~101 days

## Design System

### Origin Design (all INKredible tools)
- Dark mode default, light mode toggle
- Glassmorphic panels: `background: rgba(255,255,255,0.05); backdrop-filter: blur(20px); border: 1px solid rgba(255,255,255,0.1);`
- Mesh gradient background
- Mobile-first, responsive breakpoints
- See `origin-design-system` skill for full spec (when available)

## Testing & Verification
- After building: write → read back → confirm output matches intent
- Save output files, then verify they exist and contain expected content
- For HTML: check that key elements render (don't just write and forget)

## Sabbath Rules for Sub-Agents (CRITICAL)
- Internal work IS allowed during Shabbat: file creation, code, analysis, research, git pushes to our own repos
- What is NOT allowed: customer-facing actions, emails to external parties, messages to anyone except Aviel
- Do NOT interpret Sabbath rules as "can't do anything" — that's wrong and caused a 6-hour work stoppage
- Git pushes to gh-pages = internal deployment = ALLOWED

## Communication
- Sub-agent completion format: `✅ [name] | 🧠 [model] | 📄 [result summary]`
- Always include model name in notifications
- Never say "Good morning" mid-conversation — only when Aviel's been offline
