# Research Lessons — Institutional Memory for Sub-Agents

**Read this file before starting ANY research, analysis, or content task.**
Last updated: 2026-02-13

---

## Web Research

### Search Patterns
- Max 5 consecutive web searches before pausing to assess results (AGENTS.md rule)
- Use Brave Search API via `web_search` tool — don't try curl-based searches
- For pricing data: check NDF API first, then competitor sites
- For printing industry: Wide Format Impressions, Printing Impressions, WhatTheyThink are best sources
- For AI news: TechCrunch, The Verge, Ars Technica, Anthropic/OpenAI blogs

### YouTube Transcripts
- Use `yt-dlp` for extraction (installed: v2026.02.04)
- Always confirm video URL with Aviel before pulling (AGENTS.md rule)
- Save to `workspace/transcripts/[video-id].md`
- Alex Finn transcripts: 14 total extracted and analyzed

### Output Quality
- AI news items: 2-3 sentences each with "so what" for INKredible's business
- Research reports: lead with actionable findings, then supporting detail
- Never produce empty files — if a task can't produce output, write an explanation of why

## Content & Analysis

### INKredible Business Context
- Custom printing shop in Brooklyn
- 3 machines: Konica C3080 (small format), Roland VG2-540 (wide format), HP Latex 700W (wide format, white ink)
- Team: Aviel (CEO), Brandon (COO, $33/hr), Diandra (secretary, $15/hr)
- Revenue: $686K/yr, Gross Margin 54.5%, Net Income -$10.7K
- Pricing: Three-tier markup over NextDayFlyers (floor/target/opening)
- 9 MVP products for pricing system

### Competitor Intelligence
- NextDayFlyers = primary pricing anchor
- NDF pricing CSV: `workspace/nextdayflyers_pricing_final.csv`
- 18 postcard combos scraped, 8 more products pending

### Brain Dump Context (CRITICAL for coaching/personal tasks)
- Aviel's goals: $1-2M revenue, work ON not IN business, custom build shop dream
- ADHD patterns: starts many things, finishes few; needs external accountability
- Core emotional thread: building self-confidence through business success
- Full context: `workspace/memory/brain-dump-01.md`

## Format & Tone
- Aviel has ADHD — bullet points, tables, short answers
- Lead with the answer, then explain
- Keep Telegram messages scannable for mobile
- Numbers and specifics, not vague suggestions
- "Smart friend catching you up" tone, not news ticker
