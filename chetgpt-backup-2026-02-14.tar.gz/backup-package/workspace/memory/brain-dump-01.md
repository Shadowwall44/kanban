# Brain Dump — Complete (Rounds 1-3) — Feb 13, 2026

---

# Round 3 — Feb 13, 2026 ~3:05 PM

## Instagram / Marie's Touch Inspiration
- Wants to follow @mariestouchpartyshop model (50K followers, Miami)
- They do custom foam board structures (carousels, ferris wheels) — huge market
- INKredible can do printed party elements NOW (backdrops, banners, dance floor wraps via HP Latex 700W + Roland)
- Foam board 3D structures = future play (needs flatbed printer + cutter, $300K dream shop)
- ColorCut FB550 = small format card stock only (custom tags, die-cut cards, mat replacements)
- Lux Events = new client, luxury event rentals, found INKredible via INSTAGRAM
- Next week: $10K job — 25ft x 88ft floor graphic

## Good Month vs Bad Month
- **Good month**: Floor graphics jobs. Even ONE floor graphic = $1,000+. Can go $3K, $5K, even $10K+
- **Bad month**: Quiet, smaller jobs (small format printing), no floor graphics
- **Target clients**: Event planners, rental companies, people doing custom foam boards + large format
- **Repeat customers are key** — rental people, event planners come back monthly
- **Messi Law**: Monthly recurring job (already in QuickBooks)
- **Cash tracking problem**: Gets a LOT of cash that isn't in QuickBooks. Has 2024 cash recorded, slacked on 2025. Makes financials look worse than reality.
- **Marketing**: Almost none. Best is Instagram reposts when tagged. Want Brandon on full marketing once pricing system is ready.
- **Wants in MIS**: Floor graphic tracking calendar — input each job, track weekly/monthly volume

## Typical Workday
- **6:00-6:30 AM**: Wake up, feed baby (8 months old — baby is his alarm)
- **6:45-7:00 AM**: Kids wake up. Daughter (6) → bus. Son (4) → drive to school.
- **7:45-8:00 AM**: Try to make breakfast (eggs + avocado, trying to eat healthier — historically skips meals at work, "been doing that for years")
- **8:30 AM**: Drop son at school (5 min drive)
- **9:00 AM**: Back home
- **9:00-10:00 AM**: Either making breakfast at home or heading to work. USED TO go to gym at 9:30 (bike 12-17 min), worked out, went to work with better mindset. Stopped because freezing cold, can't bike.
- **10:00 AM**: Store opens (Mon-Thu 10-6, Fri 10-2:30)
- **10:30-11:00 AM**: Gets to work late lately
- **11:00 AM-5:30 PM**: "Can't really answer hour by hour." Unproductive or tinkering with AI/YouTube. Brandon keeps asking for price list. Feels like working ON the business not IN it, but unsure how efficient. Gets lost in AI rabbit holes.
- **6:00 PM**: Leave work
- **6:30 PM**: Home, help wife with kids
- **7:15 PM**: Reading books with 2 kids
- **7:30 PM**: Baby goes to sleep
- **8:00 PM**: Kids in bed
- **After 8 PM**: Computer time — Telegram, AI work, system building
- **Time awareness**: "I don't know where the time goes. I don't pay attention and it's a problem."
- **Most productive**: "I'm not even sure. Every day is different."
- **Most stuck**: "I feel stuck all the time except when I have a certain flow, then that flow finishes because I have to go do something else."

## Therapy
- Currently seeing a therapist (notes to be shared with ChetGPT)
- Therapist recommended seeing a psychiatrist → Feb 24 appointment scheduled
- Will share therapy notes — significant trust

## Proudest Accomplishment
- **Building INKredible Voice** — his first desktop app (system tray, opens as a real program)
- "First time in a very very very long time... I don't think I've ever been proud of myself but that was the one time I actually felt pretty proud"
- "If I'm capable of this, then I could do something" — opened his eyes
- Also proud of: setting up OpenClaw (not easy, most people wouldn't do it)
- Loves learning AI, fan of Claude, addicted to vibe coding
- Building things = identity-level fulfillment

## The Directive (Aviel's exact words):
> "Where you really need to make sure that you understand me and build a system around yourself so you can help me get to the goal that I want without needing approval for everything. I want you to have the instinct — now I know Aviel, let me see if I can help him get to the goal that he wants."

---

# Round 1-2 — Feb 13, 2026 ~1:19 AM (original below)

## 3-Year Business Vision
- **Revenue**: $1-2M/year
- **Team**: Current (Brandon + Diandra) + 2-4 more workers for production, content creation, management
- **Aviel's role**: Overlook the company, work ON the business not IN it. Cost-cutting, vendor management, strategy, MIS development. NOT manual printing.
- **Current pain**: Aviel + Brandon doing manual work. 50 business cards = 30 min to 2 hours when Konica jams. Same-day pressure from customers. Stress.

## Key Business Shifts Already Happening
- **Outsourcing small format**: Started sending to wholesale trade printer. Huge stress relief. Frees time.
- **Konica C3080 issues**: Constant jamming, not in best condition. Small format jobs that should be 2 min turn into hour+ nightmares.
- **Large format = money maker**: Floor graphics, signage, wide format = highest margins. Small format (business cards, flyers) = time sink unless a dedicated worker handles it.

## Big Dream: Custom Build Shop
- Follows someone on Instagram doing custom builds with flatbed printer + flatbed cutter
- Custom bars with LED lighting, custom carousels, party pieces, beautiful designs
- Cut shapes, connect them, build massive 3D structures for events
- Same field as floor graphics — natural extension
- **Equipment needed**: Flatbed printer + flatbed cutter = ~$300K total
- This is the aspirational direction for INKredible

## MIS System Vision
- 16 years in printing industry, hasn't found a good system
- Most existing software focuses on screen printing (different workflow)
- All-in-one: CRM, inventory, AI assistant, pricing engine, financials
- Chat interface: ask it questions like "how many sales this week?" "how many quotes given?"
- Using INKredible as test trial — does both small and large format
- **Goal: build it right, then sell it to other printers**
- Competition is small in this space

## 3-Year Personal Vision
### Health & Fitness
- Wants to be very fit, get abs, nice physique (age 33 now)
- Started gym last month — went every day for a straight month BEFORE work
- Gym helped with anxiety and focus significantly
- Loves basketball, wants to get better, maybe hire a trainer
- Exercise = key to managing ADHD and anxiety

### Family
- Wants to buy a house
- Take better care of wife
- Be more present with kids — not stuck thinking about work
- Hire full-time maid to help wife at home
- Go on vacations when needed

### Mental Health (IMPORTANT CONTEXT)
- Deals with significant anxiety
- ADHD is a major factor in daily life
- "I have a hard time believing in myself"
- "A lot of my time it feels like it was wasted because I was so stressed"
- "People think I'm crazy" for obsessing over AI — but committed to not being left behind
- Personality: "overly obsessive" — this is a superpower AND a risk
- Has therapy notes to share (mentioned earlier)

### Parents
- Wants to call parents more, be there for them
- Mom isn't doing great health-wise
- Feels guilty about not being more present

### Finance
- Wants money in the bank
- Wake up and not worry about money
- Financial peace of mind is a core goal

### Hobbies
- Stock trading — used to be passionate but became an addiction
- Wants to try again WITH AI, for enjoyment not to make a ton of money
- If it happens naturally (making money), great
- Basketball — loves playing

### Core Emotional Theme
- Wants to enjoy life more — "that's the big goal"
- Be the best version of himself
- Has "a ton of ideas" beyond what he shared
- Invested in $200 Claude plan because he truly believes AI can help him get there
- This is deeply personal, not just business

## Round 2 — Deeper Answers (1:34 AM)

### Brandon
- They've talked about it — Brandon WANTS to be the content creator / marketing guy
- Been with Aviel from the start, took a big risk staying
- "He's always going to be right next to me, no matter what, no matter how big the company gets"
- Future role: right beside Aviel, not below him. True partner energy.
- Aviel treats loyalty with loyalty — this is a core value

### Stock Trading — Full Picture
- **11 years** of trading experience
- Options: puts, calls, day trading (buy/sell same day)
- Highest volatility window: 9:30 AM - 11 AM market open
- Had a good method but couldn't sell (discipline issue, not knowledge)
- Total losses over 11 years: ~$10-15K (not devastating, but never walked away positive)
- "Wasted a lot of time" — more time cost than money cost
- Used TradingView for indicators
- **What he wants**: Build a system with guardrails, right indicators, probability-based decisions
- Would do morning options trading, quick buy/sell day trading
- Excitement level: "Almost as much as building the MIS system"
- **Guardrail approach**: Make it fun but structured. AI helps with discipline (the selling part he struggles with)
- Currently: just watches market, occasionally buys 6-month-out contracts

### Wife
- Understands the vision, very supportive
- Recently opened up to her about ADHD, obsession, anxiety — "I have to be doing something"
- She's supportive of AI investment but "scared I'm gonna be too much into it"
- She can tell he's on the phone a lot — wants to show her more love
- Believes in him more now that coding is doable with AI
- Supportive of the MIS dream
- **Key tension**: Not opposition to the work, but wanting his presence. He needs to be more present.

### Aviel's Self-Awareness (CRITICAL for coaching)
- "I'm never confident and now I want to be confident"
- "I need you to help me become confident and organized"
- Wants to redirect the ADHD/obsessive energy toward self-improvement: organizing, scheduling, systems
- "If I'm going to have this ADHD over obsessive addiction I might as well do the parts that I need to fix myself in"
- "My anxiety will go towards that and I know it'll make me better no matter what"
- Has an eye for app design — loves it, came naturally
- 3 years of AI learning through obsessive YouTube watching — now it's paying off

### What Keeps Him Up at Night
- "Figuring out the system for INKredible Printing"
- How to make it more seamless, organized, structured
- Would LOVE to build the apps himself — "that would be so much fun"
- Wants to build apps toward the company's benefit
- Wants to be able to say "I created an amazing app"
- **This is identity-level stuff** — it's not just about the business, it's about proving to himself he can build something great

### Wispr Flow Clone App — FIRST OFFICIAL APP 🎯
- This is Aviel's personal app project — a Wispr Flow clone
- "My first official app that I will use everyday"
- "Very big goal — I don't want to give up on it"
- "Please help me get to that goal no matter what"
- Has 3 repos to push (mentioned earlier, not yet pushed)
- This is identity-level: proving he can BUILD something, ship it, use it daily
- ChetGPT role: project manager, code reviewer, accountability partner
- DO NOT let this fall off the radar. It's a promise.

### MIS Go-to-Market
- Doesn't know how to sell software
- "I'm misinformed about how to sell programs"
- Needs confidence + knowledge about SaaS distribution
- This is a future coaching topic once the product exists

## What This Means for ChetGPT
- Brain dump is the foundation for EVERYTHING: morning briefs, autonomous tasks, coaching, accountability
- Every task I generate should trace back to one of these goals
- Health accountability: gym tracking, basketball, trainer research
- Family: vacation planning, house hunting support, helping him be present
- Business: MIS is the legacy play, outsourcing is the immediate relief
- Mental health: reduce stress through systems, celebrate wins, no-guilt re-entry ramps
- Mom: gentle reminders to call
- Trading: approach carefully — he acknowledges addiction history. Keep it educational/fun, not high-stakes.
- Confidence building: this is the thread that ties EVERYTHING together. He doesn't lack ability — he lacks belief.
- Wife relationship: help him be present. Don't enable 2 AM work sessions that take him away from family (note: this brain dump is an exception, not the rule)
- Brandon = partner, not employee. Respect that in all planning.
- The MIS isn't just a product — it's proof to himself that he can build something great. Treat it accordingly.
- Redirect obsessive energy toward systems/organization = his own idea, his own insight. Powerful.
- Round 3 questions PENDING (Aviel will answer when he wakes up): Instagram builder account, monthly revenue, typical day, therapy status, proudest accomplishment

### Finances — FEAR & AVOIDANCE (1:54 AM)
- "It's really all over the place"
- "I don't know where to begin"
- "I got to a point where I'm too scared to look"
- This is financial anxiety — extremely common with ADHD + business owners
- Connected to every goal: house, maid, vacations, $1-2M revenue, financial peace
- QuickBooks export is the unlock — P&L + Balance Sheet
- ChetGPT builds the dashboard, makes it digestible, no judgment
- **This is the ⭐ CRITICAL task on the Kanban for a reason**
- Approach: gentle, supportive, but persistent. He NEEDS to do this.
- Has an 8-month-old baby — financial stability isn't optional anymore

### Financial Reality Check (2:09 AM) — BOTH REPORTS RECEIVED ✅
**P&L (Jan 2024 – Feb 13, 2026):**
- Revenue: $686K ($27K/mo avg)
- Gross Margin: 54.5%
- Net Operating Income: $7,237 (basically breakeven)
- Net Income: -$10,746 (after donations + depreciation)

**Balance Sheet (as of Feb 13, 2026):**
- Checking: NEGATIVE -$13,991
- Total Assets: $40,048
- Total Liabilities: $81,992
- Total Equity: -$41,944 (negative equity)
- CC Debt Owed: ~$71K
- Chase LOC: $43K
- Loan Payable: $60K
- Total Debt Exposure: ~$174K
- Owner Distributions: $31,700

**Red Flags to Discuss:**
1. Graphic Design $67K (biggest COGS — who?)
2. Bank Charges $18.6K (what fees?)
3. Meals/Entertainment $20.8K
4. Officers Payroll only $18K/year
5. Donations $13.5K while net negative
6. Checking overdrawn
7. Cash flow management

**Files saved at:** workspace/financials/
- inkredible-pnl-2024-2026.xlsx
- inkredible-balance-sheet-2024-2026.xlsx
- pnl-analysis.md

## Overnight Marching Orders (1:46 AM)
- Aviel said: "start working on all the things Alex Finn spoke about in the video"
- "I rather have you build it tonight so we can have momentum"
- "Make sure you ask yourself questions when working on projects to get better"
- "Go do your magic"
- Brain dump Round 3 continues when he wakes up
- Build as much as possible from the 6 use cases overnight
