# Operations Lessons — Institutional Memory for Sub-Agents

**Read this file before starting ANY operations, notification, or status update task.**
Last updated: 2026-02-13

---

## Notifications (Telegram)

### Rules
- Aviel's Telegram ID: 517496021
- Sub-agent spawn format: `🤖 [name] | 📋 [task] | 🧠 [model] | ⏱️ [ETA]`
- Sub-agent complete format: `✅ [name] | 🧠 [model] | 📄 [result summary]`
- ALWAYS include model name — Aviel explicitly requested this
- Never say "Good morning" if already mid-conversation with Aviel
- Keep messages concise for mobile (Samsung Galaxy Z Fold 7)

### Sabbath Rules (ABSOLUTE — Friday sundown → Saturday sundown ET)
- NEVER send messages to anyone other than Aviel during Sabbath
- No customer-facing communication of any kind
- Internal work (analysis, prep, file organization) is allowed
- Queue external actions for post-Sabbath review
- Check chabad.org for exact Brooklyn candle lighting times — DON'T guess

## Mission Control / Status

### status.json Updates
- File: `inkredible-tools/public/status.json`
- Must update on EVERY sub-agent spawn AND completion
- Must push to gh-pages after update
- Mission Control polls every 15 seconds
- GitHub Pages CDN cache: 1-5 min delay

### Kanban Board Updates
- Work board: `kanban/work.html`
- Personal board: `kanban/personal.html`
- Update on EVERY task completion — this has been Aviel's #1 complaint
- Auto-route: detect work vs personal from context (90% obvious)
- Push to gh-pages after every update

## Usage Tracking

### Tracker File
- Location: `workspace/usage-tracker.json`
- Read → increment `currentExchanges` → recalculate `estimatedSessionPct` → write back
- Multiplier: 0.233 (calibrated Feb 13 — 30 exchanges = 7% session)
- Thresholds: notify at 20%, 40%, 60%, 80%
- Weekly reset: Friday 12:00 AM ET
- Do NOT git push on every exchange — cron handles that every 15 min

## Operational Principles

### Response Priority
- ALWAYS respond to Aviel before doing background work
- Never chain multiple tool calls before Aviel sees a reply
- If compaction is coming (~80% context), warn Aviel proactively

### Task Routing
- Brain (Opus) = strategy, coaching, orchestration, skill design. NEVER hands-on work.
- Sub-agents (Codex) = coding, deployment, research, file creation
- Exception: <10 clicks of remaining work is acceptable for Brain to finish

### Self-Improvement
- Every correction from Aviel → update `memory/self-improvement.md` AND relevant lessons file
- Verification loop: write → read back → confirm for all updates
- 20-min proactive status pings when Aviel is active
- Exhaust own troubleshooting before asking Aviel for help
