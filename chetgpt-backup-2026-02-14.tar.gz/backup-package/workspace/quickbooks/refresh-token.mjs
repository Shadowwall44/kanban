#!/usr/bin/env node
import { ensureFreshAccessToken, getTokenHealth, refreshQuickBooksTokens } from './lib/auth.mjs';

const args = new Set(process.argv.slice(2));
const force = args.has('--force');
const checkOnly = args.has('--check');

function fmt(sec) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return `${h}h ${m}m ${s}s`;
}

async function main() {
  const before = getTokenHealth();
  console.log('🔐 QuickBooks token status');
  console.log(`   Realm: ${before.realmId}`);
  console.log(`   Expires in: ${fmt(before.expiresInSec)} (${before.expiresAt})`);

  if (checkOnly) {
    return;
  }

  if (force) {
    await refreshQuickBooksTokens({ reason: 'manual-force' });
    const after = getTokenHealth();
    console.log('\n✅ Token refreshed (forced)');
    console.log(`   New expiry: ${fmt(after.expiresInSec)} (${after.expiresAt})`);
    return;
  }

  await ensureFreshAccessToken({ minTtlSec: 300, reason: 'manual-check' });
  const after = getTokenHealth();
  const refreshed = after.expiresAt !== before.expiresAt;

  if (refreshed) {
    console.log('\n✅ Token was near expiry and has been refreshed');
  } else {
    console.log('\n✅ Token is still healthy (no refresh needed)');
  }
  console.log(`   Current expiry: ${fmt(after.expiresInSec)} (${after.expiresAt})`);
}

main().catch((err) => {
  console.error('❌', err.message);
  process.exit(1);
});
