#!/usr/bin/env node
/**
 * Export live QuickBooks metrics into a dashboard-friendly JSON file.
 *
 * Usage:
 *   node quickbooks/export-live-dashboard-data.mjs
 *   node quickbooks/export-live-dashboard-data.mjs --out inkredible-tools/public/data/quickbooks-live.json
 *   QBO_ENV=production node quickbooks/export-live-dashboard-data.mjs
 */

import { mkdirSync, writeFileSync } from 'fs';
import { dirname, resolve } from 'path';
import { getQuickBooksConfig } from './lib/auth.mjs';
import { qbQuery, qbRequest, parseMoney, round2 } from './lib/client.mjs';

function getArg(name, fallback = null) {
  const idx = process.argv.indexOf(name);
  if (idx === -1 || idx === process.argv.length - 1) return fallback;
  return process.argv[idx + 1];
}

function rowLabel(row) {
  return (
    row?.Header?.ColData?.[0]?.value ||
    row?.Summary?.ColData?.[0]?.value ||
    row?.ColData?.[0]?.value ||
    ''
  ).trim();
}

function rowValue(row) {
  return (
    row?.Summary?.ColData?.[1]?.value ||
    row?.ColData?.[1]?.value ||
    ''
  ).toString().trim();
}

function flattenSummaries(rows, list = []) {
  for (const row of rows || []) {
    const label = rowLabel(row);
    const value = rowValue(row);

    if (label) {
      list.push({
        label,
        valueRaw: value,
        value: parseMoney(value),
        type: row?.type || row?.group || 'Unknown',
      });
    }

    if (row?.Rows?.Row?.length) {
      flattenSummaries(row.Rows.Row, list);
    }
  }

  return list;
}

function pickSummary(entries, aliases) {
  const wanted = aliases.map((a) => a.toLowerCase());
  for (const entry of entries) {
    if (wanted.includes(entry.label.toLowerCase())) {
      return entry.value;
    }
  }
  return 0;
}

function topChildrenByLabel(topRows, sectionLabel, limit = 8) {
  const section = (topRows || []).find((row) => rowLabel(row).toLowerCase() === sectionLabel.toLowerCase());
  const children = section?.Rows?.Row || [];

  return children
    .map((row) => ({
      label: rowLabel(row),
      value: parseMoney(rowValue(row)),
    }))
    .filter((x) => x.label && Number.isFinite(x.value) && x.value !== 0)
    .sort((a, b) => Math.abs(b.value) - Math.abs(a.value))
    .slice(0, limit)
    .map((x) => ({ ...x, value: round2(x.value) }));
}

function toIsoDateOnly(dateLike) {
  return new Date(dateLike).toISOString().slice(0, 10);
}

async function main() {
  const outArg = getArg('--out');
  const outPath = resolve(
    process.cwd(),
    outArg || 'inkredible-tools/public/data/quickbooks-live.json'
  );

  const { env, realmId } = getQuickBooksConfig();

  const companyInfo = await qbRequest(`companyinfo/${realmId}`, {
    reason: 'dashboard-export-companyinfo',
  });

  const pnl = await qbRequest('reports/ProfitAndLoss?date_macro=This%20Fiscal%20Year-to-date', {
    reason: 'dashboard-export-pnl',
  });

  const balanceSheet = await qbRequest('reports/BalanceSheet?date_macro=Today', {
    reason: 'dashboard-export-balance-sheet',
  });

  const openInvoices = await qbQuery(
    "SELECT Id, DocNumber, CustomerRef, TxnDate, DueDate, TotalAmt, Balance FROM Invoice WHERE Balance > '0' ORDER BY Balance DESC MAXRESULTS 1000",
    { reason: 'dashboard-export-open-invoices' }
  );

  const topCustomers = await qbQuery(
    'SELECT Id, DisplayName, Balance FROM Customer ORDER BY Balance DESC MAXRESULTS 20',
    { reason: 'dashboard-export-customers' }
  );

  const pnlRows = pnl?.Rows?.Row || [];
  const pnlSummaries = flattenSummaries(pnlRows);
  const balanceRows = balanceSheet?.Rows?.Row || [];
  const balanceSummaries = flattenSummaries(balanceRows);

  const income = pickSummary(pnlSummaries, ['Income', 'Total Income']);
  const cogs = pickSummary(pnlSummaries, ['Cost of Goods Sold', 'Total Cost of Goods Sold']);
  const grossProfit = pickSummary(pnlSummaries, ['Gross Profit']);
  const expenses = pickSummary(pnlSummaries, ['Expenses', 'Total Expenses']);
  const netIncome = pickSummary(pnlSummaries, ['Net Income']);

  const totalAssets = pickSummary(balanceSummaries, ['ASSETS', 'Total Assets']);
  const totalLiabilities = pickSummary(balanceSummaries, ['Liabilities', 'Total Liabilities']);
  const totalEquity = pickSummary(balanceSummaries, ['Equity', 'Total Equity']);
  const currentAssets = pickSummary(balanceSummaries, ['Current Assets', 'Total Current Assets']);
  const currentLiabilities = pickSummary(balanceSummaries, ['Current Liabilities', 'Total Current Liabilities']);

  const invoices = openInvoices?.QueryResponse?.Invoice || [];
  const today = toIsoDateOnly(Date.now());

  const invoiceRows = invoices.map((inv) => {
    const balance = parseMoney(inv.Balance);
    const dueDate = inv.DueDate || null;
    const overdue = Boolean(dueDate && dueDate < today && balance > 0);

    return {
      id: inv.Id,
      docNumber: inv.DocNumber || null,
      customer: inv.CustomerRef?.name || null,
      txnDate: inv.TxnDate || null,
      dueDate,
      totalAmt: round2(parseMoney(inv.TotalAmt)),
      balance: round2(balance),
      overdue,
    };
  });

  const openBalance = round2(invoiceRows.reduce((sum, inv) => sum + inv.balance, 0));
  const overdueBalance = round2(invoiceRows.reduce((sum, inv) => sum + (inv.overdue ? inv.balance : 0), 0));
  const overdueCount = invoiceRows.filter((inv) => inv.overdue).length;

  const customers = (topCustomers?.QueryResponse?.Customer || [])
    .map((c) => ({
      id: c.Id,
      name: c.DisplayName || 'Unknown',
      balance: round2(parseMoney(c.Balance)),
    }))
    .filter((c) => c.balance > 0)
    .sort((a, b) => b.balance - a.balance)
    .slice(0, 10);

  const grossMarginPct = income ? round2((grossProfit / income) * 100) : 0;
  const netMarginPct = income ? round2((netIncome / income) * 100) : 0;
  const currentRatio = currentLiabilities ? round2(currentAssets / currentLiabilities) : null;

  const payload = {
    schemaVersion: 1,
    generatedAt: new Date().toISOString(),
    env,
    realmId,
    company: {
      name: companyInfo?.CompanyInfo?.CompanyName || null,
      legalName: companyInfo?.CompanyInfo?.LegalName || null,
      country: companyInfo?.CompanyInfo?.Country || null,
      email: companyInfo?.CompanyInfo?.Email?.Address || null,
    },
    periods: {
      pnl: {
        start: pnl?.Header?.StartPeriod || null,
        end: pnl?.Header?.EndPeriod || null,
      },
      balanceSheet: {
        asOf: balanceSheet?.Header?.EndPeriod || null,
      },
    },
    metrics: {
      income: round2(income),
      cogs: round2(cogs),
      grossProfit: round2(grossProfit),
      expenses: round2(expenses),
      netIncome: round2(netIncome),
      totalAssets: round2(totalAssets),
      totalLiabilities: round2(totalLiabilities),
      totalEquity: round2(totalEquity),
      currentAssets: round2(currentAssets),
      currentLiabilities: round2(currentLiabilities),
      currentRatio,
      openInvoicesCount: invoiceRows.length,
      openInvoicesBalance: openBalance,
      overdueInvoicesCount: overdueCount,
      overdueInvoicesBalance: overdueBalance,
      grossMarginPct,
      netMarginPct,
    },
    breakdowns: {
      incomeTop: topChildrenByLabel(pnlRows, 'Income'),
      expensesTop: topChildrenByLabel(pnlRows, 'Expenses'),
      openInvoicesTop: invoiceRows
        .sort((a, b) => b.balance - a.balance)
        .slice(0, 10),
      customersByBalanceTop: customers,
    },
    alerts: {
      negativeNetIncome: netIncome < 0,
      negativeEquity: totalEquity < 0,
      highOverdueReceivables: overdueBalance > 5000,
      currentRatioRisk: currentRatio !== null ? currentRatio < 1 : null,
    },
  };

  mkdirSync(dirname(outPath), { recursive: true });
  writeFileSync(outPath, JSON.stringify(payload, null, 2));

  // Local copy for audit/history outside public web root.
  const archivePath = resolve(process.cwd(), 'quickbooks/output/quickbooks-live-latest.json');
  mkdirSync(dirname(archivePath), { recursive: true });
  writeFileSync(archivePath, JSON.stringify(payload, null, 2));

  console.log(`✅ QuickBooks live dashboard data exported`);
  console.log(`   Environment: ${env}`);
  console.log(`   Output: ${outPath}`);
  console.log(`   Open invoices: ${payload.metrics.openInvoicesCount} ($${payload.metrics.openInvoicesBalance.toLocaleString()})`);
  console.log(`   Net income: $${payload.metrics.netIncome.toLocaleString()}`);
}

main().catch((err) => {
  console.error('❌ Export failed:', err.message);
  process.exit(1);
});
