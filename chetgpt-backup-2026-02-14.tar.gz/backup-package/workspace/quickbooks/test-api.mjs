#!/usr/bin/env node
/**
 * Test QuickBooks API - Pull company info and P&L
 */

import { readFileSync } from 'fs';

const tokens = JSON.parse(readFileSync('/home/inkredible/.openclaw/workspace/.secrets/quickbooks-tokens.json', 'utf-8'));

const BASE_URL = 'https://sandbox-quickbooks.api.intuit.com/v3/company';
const REALM_ID = tokens.realmId;

async function qbRequest(endpoint) {
  const url = `${BASE_URL}/${REALM_ID}/${endpoint}`;
  const res = await fetch(url, {
    headers: {
      'Authorization': `Bearer ${tokens.accessToken}`,
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    }
  });
  
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`QB API Error ${res.status}: ${text}`);
  }
  
  return res.json();
}

async function main() {
  console.log('📊 Testing QuickBooks API...\n');
  
  // 1. Company Info
  console.log('1️⃣  Company Info:');
  try {
    const companyInfo = await qbRequest('companyinfo/' + REALM_ID);
    const info = companyInfo.CompanyInfo;
    console.log(`   Name: ${info.CompanyName}`);
    console.log(`   Legal Name: ${info.LegalName || 'N/A'}`);
    console.log(`   Country: ${info.Country}`);
    console.log(`   Email: ${info.Email?.Address || 'N/A'}`);
    console.log('');
  } catch (e) {
    console.log('   Error:', e.message, '\n');
  }
  
  // 2. Profit and Loss
  console.log('2️⃣  Profit & Loss Report:');
  try {
    const pnl = await qbRequest('reports/ProfitAndLoss?date_macro=This Year-to-date');
    const header = pnl.Header;
    console.log(`   Report: ${header.ReportName}`);
    console.log(`   Period: ${header.StartPeriod} to ${header.EndPeriod}`);
    console.log(`   Currency: ${header.Currency}`);
    
    // Parse rows
    if (pnl.Rows?.Row) {
      for (const section of pnl.Rows.Row) {
        if (section.Summary?.ColData) {
          const label = section.Summary.ColData[0]?.value || '';
          const value = section.Summary.ColData[1]?.value || '';
          if (label && value) {
            console.log(`   ${label}: $${parseFloat(value).toLocaleString()}`);
          }
        }
        // Check for Net Income
        if (section.group === 'NetIncome' && section.Summary?.ColData) {
          const value = section.Summary.ColData[1]?.value || '0';
          console.log(`   💰 Net Income: $${parseFloat(value).toLocaleString()}`);
        }
      }
    }
    console.log('');
  } catch (e) {
    console.log('   Error:', e.message, '\n');
  }
  
  // 3. Balance Sheet
  console.log('3️⃣  Balance Sheet:');
  try {
    const bs = await qbRequest('reports/BalanceSheet?date_macro=Today');
    const header = bs.Header;
    console.log(`   Report: ${header.ReportName}`);
    console.log(`   As of: ${header.EndPeriod}`);
    
    if (bs.Rows?.Row) {
      for (const section of bs.Rows.Row) {
        if (section.Summary?.ColData) {
          const label = section.Summary.ColData[0]?.value || '';
          const value = section.Summary.ColData[1]?.value || '';
          if (label && value) {
            console.log(`   ${label}: $${parseFloat(value).toLocaleString()}`);
          }
        }
      }
    }
    console.log('');
  } catch (e) {
    console.log('   Error:', e.message, '\n');
  }
  
  // 4. Customer list
  console.log('4️⃣  Customers:');
  try {
    const customers = await qbRequest("query?query=SELECT * FROM Customer MAXRESULTS 5");
    if (customers.QueryResponse?.Customer) {
      for (const c of customers.QueryResponse.Customer) {
        console.log(`   - ${c.DisplayName} (Balance: $${c.Balance || 0})`);
      }
      console.log(`   Total customers: ${customers.QueryResponse.totalCount || customers.QueryResponse.Customer.length}`);
    }
    console.log('');
  } catch (e) {
    console.log('   Error:', e.message, '\n');
  }
  
  console.log('✅ API test complete!');
}

main().catch(console.error);
