# QuickBooks → Dashboard Live Data Bridge

## What this adds

A production-ready export script that pulls fresh QuickBooks data and writes a dashboard-ready JSON file.

### New files
- `quickbooks/lib/client.mjs`
  - Shared QuickBooks client (`qbRequest`, `qbQuery`)
  - Automatic token freshness check + one retry on 401
  - Money parsing helpers
- `quickbooks/export-live-dashboard-data.mjs`
  - Pulls company info, P&L, balance sheet, open invoices, top customers
  - Computes core financial KPIs + alert flags
  - Writes output to:
    - `inkredible-tools/public/data/quickbooks-live.json` (for dashboard)
    - `quickbooks/output/quickbooks-live-latest.json` (local archive)

## Run it

From workspace root:

```bash
node quickbooks/export-live-dashboard-data.mjs
```

Custom output path:

```bash
node quickbooks/export-live-dashboard-data.mjs --out inkredible-tools/public/data/quickbooks-live.json
```

Production mode (when credentials are approved):

```bash
QBO_ENV=production node quickbooks/export-live-dashboard-data.mjs
```

## Data contract (high level)

`quickbooks-live.json` contains:
- `company`
- `periods` (P&L period + balance sheet as-of date)
- `metrics`
  - income, cogs, gross profit, expenses, net income
  - assets, liabilities, equity
  - open/overdue invoice counts + balances
  - gross margin %, net margin %, current ratio
- `breakdowns`
  - top income lines
  - top expense lines
  - top open invoices
  - top customers by balance
- `alerts`
  - negative net income
  - negative equity
  - high overdue receivables
  - current ratio risk

## Next step to complete UI integration

Update `dashboard.html` to fetch `/data/quickbooks-live.json` first and fall back to static sample data if unavailable.
