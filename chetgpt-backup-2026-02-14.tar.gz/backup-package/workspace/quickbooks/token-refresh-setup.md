# QuickBooks Token Auto-Refresh (Sandbox + Production)

## What was added

1. `quickbooks/lib/auth.mjs`
   - Reads credentials/tokens from `.secrets/`
   - Checks token TTL
   - Refreshes access token when near expiry
   - Saves updated tokens securely (`chmod 600`)

2. `quickbooks/refresh-token.mjs`
   - Manual health check and refresh CLI

3. `quickbooks/test-api-auto.mjs`
   - API smoke test with automatic refresh + one retry on 401

---

## Commands

From workspace root:

```bash
node quickbooks/refresh-token.mjs --check
node quickbooks/refresh-token.mjs
node quickbooks/refresh-token.mjs --force
node quickbooks/test-api-auto.mjs
```

Use production API base when ready:

```bash
QBO_ENV=production node quickbooks/test-api-auto.mjs
```

---

## Files expected

- `.secrets/intuit-credentials.json`
- `.secrets/quickbooks-tokens.json`

Both should be `chmod 600`.

---

## Notes

- Access token is refreshed automatically if <5 minutes remain.
- If an API request returns `401`, the script refreshes once and retries.
- This setup keeps dashboard/backend integrations stable without manual re-auth every hour.
