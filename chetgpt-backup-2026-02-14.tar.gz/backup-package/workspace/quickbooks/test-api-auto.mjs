#!/usr/bin/env node
/**
 * Test QuickBooks API with automatic token refresh.
 *
 * Usage:
 *   node quickbooks/test-api-auto.mjs
 *   QBO_ENV=production node quickbooks/test-api-auto.mjs
 */

import { ensureFreshAccessToken, getQuickBooksConfig, refreshQuickBooksTokens } from './lib/auth.mjs';

async function qbRequest(endpoint, options = {}) {
  const { base, realmId } = getQuickBooksConfig();
  const method = options.method || 'GET';
  const body = options.body;

  const token = await ensureFreshAccessToken({ minTtlSec: 300, reason: 'api-request' });
  const url = `${base}/${realmId}/${endpoint}`;

  const makeCall = async (accessToken) => {
    return fetch(url, {
      method,
      headers: {
        Authorization: `Bearer ${accessToken}`,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: body ? JSON.stringify(body) : undefined,
    });
  };

  let res = await makeCall(token.accessToken);

  if (res.status === 401) {
    const refreshed = await refreshQuickBooksTokens({ reason: '401-retry' });
    res = await makeCall(refreshed.accessToken);
  }

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`QB API Error ${res.status}: ${text.slice(0, 500)}`);
  }

  return res.json();
}

async function main() {
  const { env, realmId } = getQuickBooksConfig();
  console.log(`📊 Testing QuickBooks API (env=${env}, realm=${realmId})...\n`);

  const companyInfo = await qbRequest('companyinfo/' + realmId);
  console.log('✅ Company:', companyInfo?.CompanyInfo?.CompanyName || 'Unknown');

  const pnl = await qbRequest('reports/ProfitAndLoss?date_macro=This%20Fiscal%20Year-to-date');
  const report = pnl?.Header?.ReportName || 'ProfitAndLoss';
  console.log('✅ Report:', report);

  const customers = await qbRequest('query?query=SELECT%20*%20FROM%20Customer%20MAXRESULTS%205');
  const count = customers?.QueryResponse?.totalCount || customers?.QueryResponse?.Customer?.length || 0;
  console.log('✅ Customers fetched:', count);

  console.log('\n🎉 QuickBooks API + token auto-refresh is working.');
}

main().catch((err) => {
  console.error('❌', err.message);
  process.exit(1);
});
