#!/usr/bin/env node
/**
 * QuickBooks OAuth2 Authorization Flow
 * 
 * 1. Start this server
 * 2. Open the printed URL in your browser
 * 3. Log into QuickBooks and authorize
 * 4. Server captures tokens and saves them
 */

import http from 'http';
import { readFileSync, writeFileSync } from 'fs';
import { URL } from 'url';

// Load credentials
const creds = JSON.parse(readFileSync('/home/inkredible/.openclaw/workspace/.secrets/intuit-credentials.json', 'utf-8'));

const CLIENT_ID = creds.clientId;
const CLIENT_SECRET = creds.clientSecret;
const REDIRECT_URI = 'http://localhost:8080/callback';
const SCOPES = 'com.intuit.quickbooks.accounting';

// Intuit OAuth2 endpoints (sandbox/development)
const AUTH_URL = 'https://appcenter.intuit.com/connect/oauth2';
const TOKEN_URL = 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer';

// Build authorization URL
const authUrl = new URL(AUTH_URL);
authUrl.searchParams.set('client_id', CLIENT_ID);
authUrl.searchParams.set('response_type', 'code');
authUrl.searchParams.set('scope', SCOPES);
authUrl.searchParams.set('redirect_uri', REDIRECT_URI);
authUrl.searchParams.set('state', 'inkredible-mis-' + Date.now());

console.log('\n🔗 QUICKBOOKS AUTHORIZATION');
console.log('='.repeat(60));
console.log('\nOpen this URL in your browser:\n');
console.log(authUrl.toString());
console.log('\n' + '='.repeat(60));
console.log('Waiting for callback on http://localhost:8080...\n');

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost:8080');
  
  if (url.pathname === '/callback') {
    const code = url.searchParams.get('code');
    const realmId = url.searchParams.get('realmId');
    const state = url.searchParams.get('state');
    const error = url.searchParams.get('error');
    
    if (error) {
      console.error('❌ Authorization error:', error);
      res.writeHead(400, { 'Content-Type': 'text/html' });
      res.end(`<h1>Authorization Failed</h1><p>${error}</p>`);
      server.close();
      return;
    }
    
    if (!code) {
      res.writeHead(400, { 'Content-Type': 'text/html' });
      res.end('<h1>Missing authorization code</h1>');
      return;
    }
    
    console.log('✅ Got authorization code!');
    console.log('   Realm ID (Company):', realmId);
    console.log('   Exchanging for tokens...\n');
    
    // Exchange code for tokens
    try {
      const basicAuth = Buffer.from(`${CLIENT_ID}:${CLIENT_SECRET}`).toString('base64');
      
      const tokenResponse = await fetch(TOKEN_URL, {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${basicAuth}`,
          'Content-Type': 'application/x-www-form-urlencoded',
          'Accept': 'application/json'
        },
        body: new URLSearchParams({
          grant_type: 'authorization_code',
          code: code,
          redirect_uri: REDIRECT_URI
        }).toString()
      });
      
      const tokenData = await tokenResponse.json();
      
      if (tokenData.access_token) {
        console.log('✅ Got tokens successfully!');
        console.log('   Access token expires in:', tokenData.expires_in, 'seconds');
        console.log('   Refresh token expires in:', tokenData.x_refresh_token_expires_in, 'seconds');
        
        // Save tokens
        const tokens = {
          accessToken: tokenData.access_token,
          refreshToken: tokenData.refresh_token,
          realmId: realmId,
          tokenType: tokenData.token_type,
          expiresIn: tokenData.expires_in,
          refreshTokenExpiresIn: tokenData.x_refresh_token_expires_in,
          obtainedAt: new Date().toISOString(),
          expiresAt: new Date(Date.now() + tokenData.expires_in * 1000).toISOString(),
          refreshExpiresAt: new Date(Date.now() + tokenData.x_refresh_token_expires_in * 1000).toISOString()
        };
        
        writeFileSync(
          '/home/inkredible/.openclaw/workspace/.secrets/quickbooks-tokens.json',
          JSON.stringify(tokens, null, 2)
        );
        
        // Set file permissions
        const { execSync } = await import('child_process');
        execSync('chmod 600 /home/inkredible/.openclaw/workspace/.secrets/quickbooks-tokens.json');
        
        console.log('\n💾 Tokens saved to .secrets/quickbooks-tokens.json');
        console.log('🎉 QuickBooks API is ready to use!\n');
        
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(`
          <html>
          <body style="font-family: -apple-system, sans-serif; text-align: center; padding: 50px; background: #1a1a2e; color: #eee;">
            <h1 style="color: #00d4aa;">✅ QuickBooks Connected!</h1>
            <p>INKredible MIS is now linked to your QuickBooks account.</p>
            <p style="color: #888;">Company ID: ${realmId}</p>
            <p>You can close this tab.</p>
          </body>
          </html>
        `);
      } else {
        console.error('❌ Token exchange failed:', JSON.stringify(tokenData, null, 2));
        res.writeHead(500, { 'Content-Type': 'text/html' });
        res.end(`<h1>Token Exchange Failed</h1><pre>${JSON.stringify(tokenData, null, 2)}</pre>`);
      }
    } catch (err) {
      console.error('❌ Error:', err.message);
      res.writeHead(500, { 'Content-Type': 'text/html' });
      res.end(`<h1>Error</h1><pre>${err.message}</pre>`);
    }
    
    // Close server after a short delay
    setTimeout(() => server.close(), 2000);
    
  } else {
    // Redirect root to auth URL
    res.writeHead(302, { 'Location': authUrl.toString() });
    res.end();
  }
});

server.listen(8080, () => {
  console.log('Server listening on port 8080');
});

// Handle shutdown
process.on('SIGINT', () => {
  console.log('\nShutting down...');
  server.close();
  process.exit(0);
});
