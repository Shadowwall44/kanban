#!/usr/bin/env node
// NDF Price Scraper - API-based approach with browser attribute extraction
// Extracted data is saved to ndf-raw-data.json, then compiled to Excel

import { writeFileSync, readFileSync, existsSync } from 'fs';

const API_URL = 'https://calculator.nextdayflyers.com/v1/computePrice';
const API_KEY = 'calculator.site';
const API_SECRET = 'KEfm75#XjwSMux92zUWD9T8AafG!vwV6';

// Key quantities to price (focus on common order sizes)
const KEY_QTYS = ['25','50','75','100','150','200','250','500','1,000','2,000','2,500','3,000','4,000','5,000','10,000','15,000','20,000','25,000','50,000'];

async function computePrice(priceData) {
  const token = Buffer.from(`${API_KEY}:${API_SECRET}`).toString('base64');
  
  const resp = await fetch(API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Basic ${token}`,
    },
    body: JSON.stringify(priceData),
  });
  
  if (!resp.ok) {
    const text = await resp.text();
    throw new Error(`API error ${resp.status}: ${text}`);
  }
  
  return resp.json();
}

async function getPricesForProduct(productConfig) {
  const { productName, productId, sizes, quantities, defaults, addonAttrId } = productConfig;
  const results = [];
  
  // Filter quantities to key ones that exist for this product
  const qtyOptions = quantities.filter(q => KEY_QTYS.includes(q.text));
  
  let count = 0;
  const total = sizes.length * qtyOptions.length;
  
  for (const size of sizes) {
    for (const qty of qtyOptions) {
      count++;
      // Build price_data with this size and quantity
      const priceReq = { ...defaults };
      priceReq[`attr${productConfig.sizeAttrId}`] = size.id;
      priceReq[`attr${productConfig.qtyAttrId}`] = qty.id;
      priceReq.product_id = productId;
      priceReq.addon_attributes = [addonAttrId];
      priceReq.addon_attributes_limit = [];
      priceReq.get_shipping_base_price = true;
      
      try {
        const data = await computePrice(priceReq);
        
        // Extract turnaround prices from addon_attrs
        const tatPrices = data.addon_attrs?.[addonAttrId] || {};
        
        for (const [tatId, tatData] of Object.entries(tatPrices)) {
          results.push({
            product: productName,
            size: size.text,
            quantity: qty.text.replace(/,/g, ''),
            paperStock: productConfig.paperStockName || 'Default',
            coating: productConfig.coatingName || 'Default',
            turnaround: tatData.attr_value,
            price: parseFloat(tatData.price),
            unitPrice: parseFloat(tatData.unit_price),
            inStock: tatData.item_data?.in_stock_flag === 'y',
          });
        }
        
        if (count % 10 === 0) {
          console.log(`  ${productName}: ${count}/${total} combinations done`);
        }
        
        // Small delay to avoid rate limiting
        await new Promise(r => setTimeout(r, 50));
      } catch (err) {
        console.error(`  Error for ${productName} ${size.text} qty ${qty.text}: ${err.message}`);
      }
    }
  }
  
  return results;
}

async function main() {
  // Load extracted page data
  const rawDataPath = '/home/inkredible/.openclaw/workspace/ndf-page-data.json';
  if (!existsSync(rawDataPath)) {
    console.error('No page data found. Run browser extraction first.');
    process.exit(1);
  }
  
  const pageData = JSON.parse(readFileSync(rawDataPath, 'utf8'));
  const allResults = [];
  
  for (const product of pageData) {
    console.log(`\nProcessing: ${product.productName} (${product.sizes?.length || 0} sizes × ${product.quantities?.length || 0} qtys)`);
    
    try {
      const results = await getPricesForProduct(product);
      allResults.push(...results);
      console.log(`  Got ${results.length} price points for ${product.productName}`);
    } catch (err) {
      console.error(`  Failed ${product.productName}: ${err.message}`);
    }
  }
  
  // Save raw results
  writeFileSync('/home/inkredible/.openclaw/workspace/ndf-prices-raw.json', JSON.stringify(allResults, null, 2));
  console.log(`\nTotal price points: ${allResults.length}`);
  console.log('Saved to ndf-prices-raw.json');
  
  // Build Excel
  await buildExcel(allResults);
}

async function buildExcel(allResults) {
  const XLSX = (await import('xlsx')).default;
  
  const wb = XLSX.utils.book_new();
  
  // Master sheet with all data + markup columns
  const masterRows = allResults.map(r => ({
    'Product': r.product,
    'Size': r.size,
    'Quantity': parseInt(r.quantity),
    'Paper Stock': r.paperStock,
    'Coating': r.coating,
    'Turnaround': r.turnaround,
    'NDF Price': r.price,
    'Per Unit': r.unitPrice,
    'In Stock': r.inStock ? 'Yes' : 'No',
    'Floor (=NDF)': r.price,
    'Target (+10%)': Math.round(r.price * 1.10 * 100) / 100,
    'Opening (+25%)': Math.round(r.price * 1.25 * 100) / 100,
    'Per Unit Floor': r.unitPrice,
    'Per Unit Target': Math.round(r.unitPrice * 1.10 * 10000) / 10000,
    'Per Unit Opening': Math.round(r.unitPrice * 1.25 * 10000) / 10000,
  }));
  
  const masterWs = XLSX.utils.json_to_sheet(masterRows);
  XLSX.utils.book_append_sheet(wb, masterWs, 'All Products');
  
  // Per-product sheets
  const products = [...new Set(allResults.map(r => r.product))];
  for (const prod of products) {
    const prodResults = allResults.filter(r => r.product === prod);
    
    // Create pivot-style: rows = Size×Qty, columns = turnaround prices
    const pivotRows = [];
    const combos = {};
    
    for (const r of prodResults) {
      const key = `${r.size}|${r.quantity}`;
      if (!combos[key]) {
        combos[key] = {
          'Size': r.size,
          'Quantity': parseInt(r.quantity),
          'Paper Stock': r.paperStock,
        };
      }
      
      const tatName = r.turnaround.includes('3') ? 'Standard' : 
                       r.turnaround.includes('Next') ? 'Next Day' : 'Same Day';
      combos[key][`${tatName} Price`] = r.price;
      combos[key][`${tatName} /ea`] = r.unitPrice;
    }
    
    const pivotArr = Object.values(combos).sort((a, b) => {
      if (a.Size !== b.Size) return a.Size.localeCompare(b.Size);
      return a.Quantity - b.Quantity;
    });
    
    // Add markup columns
    for (const row of pivotArr) {
      if (row['Standard Price']) {
        row['Floor'] = row['Standard Price'];
        row['Target (+10%)'] = Math.round(row['Standard Price'] * 1.10 * 100) / 100;
        row['Opening (+25%)'] = Math.round(row['Standard Price'] * 1.25 * 100) / 100;
      }
    }
    
    const sheetName = prod.substring(0, 31); // Excel limit
    const ws = XLSX.utils.json_to_sheet(pivotArr);
    XLSX.utils.book_append_sheet(wb, ws, sheetName);
  }
  
  // Save Excel
  XLSX.writeFile(wb, '/home/inkredible/.openclaw/workspace/ndf-pricing-complete.xlsx');
  console.log('Saved ndf-pricing-complete.xlsx');
  
  // Save CSV (master sheet)
  const csvContent = XLSX.utils.sheet_to_csv(masterWs);
  writeFileSync('/home/inkredible/.openclaw/workspace/ndf-pricing-complete.csv', csvContent);
  console.log('Saved ndf-pricing-complete.csv');
}

main().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
