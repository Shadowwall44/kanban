# Floor Graphics Revenue Pipeline System (Q3 Build)

**Goal:** Turn floor graphics into a predictable weekly revenue engine.

## 1) Why this matters
- Floor graphics are INKredible’s highest-value offer ($1K–$10K+ per job).
- Current state is reactive. This system makes pipeline health visible every week.
- Target outcome: more booked jobs, faster deposits, higher repeat rate.

## 2) Pipeline stages (with strict exit criteria)

1. **Lead Captured**
   - A qualified lead record exists with contact + event date + rough sq ft.
2. **Discovery Complete**
   - Use case, venue constraints, install date, and budget range documented.
3. **Quote Sent**
   - Formal quote delivered with total, production timeline, and expiration date.
4. **Deposit Received**
   - Minimum deposit received (recommended: 50%) and logged.
5. **Production Scheduled**
   - Print start date and installer/resource assigned.
6. **Delivered/Installed**
   - Job physically delivered or installed; proof documented.
7. **Paid in Full**
   - Remaining balance received.
8. **Follow-up / Reactivation**
   - 14-day post-job check-in and repeat-opportunity note logged.

## 3) Required fields per opportunity
Use this CSV schema: `workspace/templates/floor-graphics-pipeline-template.csv`

Core columns:
- `opportunity_id`, `lead_created_date`, `client_name`, `segment`, `referral_source`
- `event_date`, `event_type`, `venue`
- `estimated_sqft`, `quoted_amount`, `deposit_amount`, `balance_due`
- `stage`, `stage_entered_date`, `owner`, `next_action`, `next_action_due`
- `won_lost`, `loss_reason`, `days_to_quote`, `days_quote_to_deposit`, `days_deposit_to_delivery`

## 4) Weekly KPI scoreboard (non-negotiable)

### Volume + conversion
- **New leads/week**
- **Discovery completion rate** = discovery_complete / leads
- **Quote rate** = quotes_sent / leads
- **Close rate (booked)** = deposits_received / quotes_sent
- **Win rate** = won / (won + lost)

### Speed
- **Lead → Quote median days**
- **Quote → Deposit median days**
- **Deposit → Delivery median days**

### Revenue quality
- **Quoted value/week**
- **Booked revenue/week** (deposits received)
- **Delivered revenue/week**
- **Average job value (won)**
- **Repeat-client rate** = repeat won jobs / total won jobs

## 5) Red/Yellow/Green thresholds
- **Close rate (quotes→deposits)**
  - Green: >= 40%
  - Yellow: 25–39%
  - Red: < 25%
- **Lead→Quote median**
  - Green: <= 1 day
  - Yellow: 2 days
  - Red: >= 3 days
- **Quote→Deposit median**
  - Green: <= 3 days
  - Yellow: 4–6 days
  - Red: >= 7 days
- **Average won job value**
  - Green: >= $3,500
  - Yellow: $2,000–$3,499
  - Red: < $2,000

## 6) Operating cadence
- **Daily (10 min, end of day):** update stage + next action for all active opportunities.
- **Monday (20 min):** generate KPI report and pick exactly 3 actions for the week.
- **Friday (10 min):** log wins, losses, and top loss reason.

## 7) Immediate rollout (next 7 days)
1. Start tracking all new floor jobs in the template CSV.
2. Backfill the last 20 floor opportunities (won + lost if possible).
3. Run first weekly report using `workspace/scripts/floor_pipeline_report.py`.
4. Decide one bottleneck focus for next week (speed, close rate, or average ticket).

## 8) Execution rule
No opportunity is allowed to sit with blank `next_action` or missing `next_action_due`.
If it does, it is considered stale and must be touched same day.
