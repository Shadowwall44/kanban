# Brandon Content OS (90 Days)
**For:** Brandon (COO / Marketing Lead)  
**Business:** INKredible Printing (Brooklyn, NY)  
**Main goal:** Turn Instagram into a steady source of high-ticket floor graphic jobs ($1K–$10K+)  
**Secondary goal:** Build repeat relationships with event planners, rental companies, and luxury event teams.

---

## Quick Start (Do This First)

### This week (non-negotiable)
You have a **$10K, 25ft x 88ft floor graphic job next week**. This is your best content opportunity of the quarter.

1. **Capture the whole process**
   - Before (empty floor)
   - Print process (HP Latex 700W / Roland)
   - Install process (timelapse + close-ups)
   - Final reveal (wide shots + details)
   - Client reaction / event-ready shots

2. **Turn this one job into 10+ pieces of content**
   - 3 Reels
   - 2 Carousels
   - 1 Static post
   - Daily Stories for 5-7 days
   - 2 “tips” posts from lessons learned

3. **Post with simple CTA every time**
   - “DM ‘FLOOR’ for pricing and turnaround.”

---

## 1) 12-Week Content Calendar (3–4 Posts/Week + Daily Stories)

### Posting rhythm (default)
- **Monday:** Reel (behind-the-scenes)
- **Wednesday:** Carousel (before/after)
- **Friday:** Reel (install/reveal)
- **Sunday:** Static post (offer, testimonial, or proof)
- **Stories:** Daily (minimum 5 story frames)

### Best posting windows (start here, adjust after 4 weeks)
- Feed posts: **11:00 AM or 7:30 PM (ET)**
- Stories: Morning (9-11 AM), Afternoon (2-4 PM), Evening (7-9 PM)

---

### 12-Week Plan

| Week | Monday (Reel) | Wednesday (Carousel) | Friday (Reel) | Sunday (Static) |
|---|---|---|---|---|
| 1 | **$10K Job Teaser**: “Something huge is printing this week” | **Before Shots**: empty floor + design preview | **Install Day BTS** timelapse | **Offer Post**: “Custom floor graphics in Brooklyn/NYC” |
| 2 | **Big Reveal Reel** (final 25x88 floor) | **Before vs After** from same job | **Close-up Details Reel** (seams, finish, texture) | **Client Win**: Lux Events found us on IG (social proof) |
| 3 | **Machine BTS**: HP Latex 700W in action | **Step-by-step carousel**: design → print → install | **Fast Turnaround Reel**: rush workflow | **FAQ Post**: “How much does a floor wrap cost?” |
| 4 | **Wedding floor Reel**: monogram/logo concept | **Wedding before/after carousel** | **Install trick Reel**: how clean installs happen | **Tip Post**: “How to choose dance floor graphics” |
| 5 | **Mitzvah/Social event Reel** | **Theme transformation carousel** | **Team-at-work Reel** (Brandon + crew) | **Testimonial quote graphic** |
| 6 | **Corporate logo floor Reel** | **Brand activation before/after** | **Night install Reel** (real-life pace) | **CTA Post**: “DM FLOOR for quote” |
| 7 | **Venue transformation Reel** | **“5 angles from one install” carousel** | **Problem/Solution Reel** (damaged floor → branded finish) | **Mini case study graphic** |
| 8 | **Rental partner collab Reel** | **Bundle ideas carousel** (floor + backdrop + signage) | **Event day footage Reel** | **Partner spotlight post** |
| 9 | **Planner collab Reel** (tag planner) | **Moodboard to reality carousel** | **Install day checklist Reel** | **Offer Post**: monthly planner partnership spots |
| 10 | **“What $1K vs $5K vs $10K looks like” Reel** | **Budget options carousel** | **Material/finish comparison Reel** | **FAQ Post**: turnaround + lead time |
| 11 | **Top mistakes Reel** (what to avoid) | **“Best transformations this month” carousel** | **Behind-the-business Reel** (how you prep jobs) | **Client testimonial/Google review graphic** |
| 12 | **Quarter highlight Reel** | **Best before/after carousel** | **“Book your next event” Reel** | **Clear booking CTA** with contact + DM keyword |

---

### Daily Story Plan (Use Every Day)
Post at least 5 story slides daily:
1. **Morning:** Today’s installs/prints
2. **Midday:** In-progress clip
3. **Behind the scenes:** team/machine/material
4. **Result:** finished piece or install update
5. **CTA:** poll, question box, or DM prompt

Story CTA examples:
- “Need a custom floor for your event? DM ‘FLOOR’.”
- “Planner or rental company? Want partner pricing?”
- “Should we post a full install breakdown? Yes/No poll”

---

## 2) Hook Bank (40 Hooks)
Use these as your first line in Reels captions or on-screen text.

### Transformation Hooks
1. “This empty floor turned into the star of the whole event.”
2. “From plain to premium in one install.”
3. “Before/after that changed the entire room.”
4. “Watch this space transform in under 8 hours.”
5. “This is what a $10K floor graphic looks like.”
6. “You won’t believe this is the same venue.”
7. “We turned this floor into a full brand experience.”
8. “The floor made the whole event feel custom.”
9. “This is why floor graphics matter more than people think.”
10. “One detail changed everything.”

### Behind-the-Scenes Hooks
11. “What really happens before install day.”
12. “POV: You’re in a Brooklyn print shop during crunch time.”
13. “How we prep giant floor graphics without mistakes.”
14. “The part nobody sees before event day.”
15. “Our printer ran all night for this.”
16. “From file to floor: here’s the real process.”
17. “This is how we handle rush jobs.”
18. “A day in our shop before a big install.”
19. “What 25ft x 88ft actually looks like in production.”
20. “The install looked easy… because the prep was hard.”

### Value/Authority Hooks
21. “How much does a custom event floor actually cost?”
22. “3 mistakes that ruin event floor graphics.”
23. “What planners should send before requesting a quote.”
24. “If your event is in 7 days, read this.”
25. “How to make your dance floor look expensive.”
26. “What to ask your print vendor before booking.”
27. “The fastest way to get an accurate floor quote.”
28. “Gloss or matte? Here’s what works for events.”
29. “The one thing that saves install time every time.”
30. “How we keep floors looking clean in event lighting.”

### Social Proof / Credibility Hooks
31. “This client found us on Instagram—and booked immediately.”
32. “Another NYC event transformed this week.”
33. “Planner-approved floor install in Brooklyn.”
34. “From first DM to finished floor in days.”
35. “Why event teams keep coming back to us.”
36. “Repeat client. Bigger install. Better result.”
37. “This is what reliable turnaround looks like.”
38. “When the planner says ‘we need this fast’…”
39. “From concept to crowd reaction.”
40. “Proof that Instagram can bring real jobs.”

---

## 3) Caption Templates (Fill-in-the-Blank)

### A) Reel: Behind-the-Scenes
**Hook:** [use one hook]  
We printed and installed this for **[event type/client type]** in **[location]**.  
Size: **[dimensions]**  
Turnaround: **[time]**  
If you’re planning an event and want this look, DM **“FLOOR”** and we’ll send pricing + timing.

---

### B) Carousel: Before/After
Slide 1: Before  
Slide 2: During install  
Slide 3: After  
Slide 4: Close-up details  
Slide 5: CTA

Caption:
“From **[before condition]** to **[after result]** for **[event type]** in **[location]**.  
Best part: **[big win]**.  
Want this for your event? DM **‘FLOOR’**.”

---

### C) Reel: Install Day
“Install day for **[client/event]** ✅  
The goal: **[look/feeling]**  
The challenge: **[time/space/material]**  
Result: **[final outcome]**  
Need a reliable print/install partner in NYC? DM **‘INSTALL’**.”

---

### D) Static Post: Offer
“Planning an event in Brooklyn/NYC?  
We create custom floor graphics and large-format pieces that make venues look premium.  
✔ Fast turnaround  
✔ Install-ready  
✔ Built for planners + rental companies  
DM **‘QUOTE’** for pricing.”

---

### E) Static Post: Testimonial/Social Proof
“‘[Client quote]’ — **[Client Name/Company]**  
Appreciate the trust. We love helping events stand out.  
If you need custom floor graphics, DM **‘FLOOR’**.”

---

### F) Educational Post
“3 things to send before requesting a floor graphic quote:  
1) Exact dimensions  
2) Event date + install window  
3) Venue photos  
Send these and we can quote fast + accurately. DM **‘QUOTE’**.”

---

### G) Story Sequence Template (5 slides)
1. “Today’s project: [project name]”  
2. “Printing now 👀”  
3. “Install prep”  
4. “Final reveal”  
5. “Need this for your event? DM ‘FLOOR’”

---

## 4) Hashtag Strategy (Brooklyn/NYC + Industry + Event)

### Rules
- Use **12–18 hashtags per post** (not 30 every time).
- Mix hashtags from 4 buckets: local + industry + event type + branded.
- Rotate sets so posts don’t look repetitive.
- Keep 1 branded tag in every post: **#INKrediblePrinting**

### Local Set (NYC/Brooklyn)
#BrooklynBusiness #BrooklynEvents #BrooklynPrinter #NYCEvents #NYCEventPlanner #NYCVendors #NewYorkEvents #NYCWeddings #NYCPartyPlanner #BrooklynWeddings #BrooklynEventPlanner #NYCSmallBusiness

### Industry Set (Print + Large Format)
#FloorGraphics #DanceFloorWrap #LargeFormatPrinting #CustomPrinting #EventBranding #WideFormat #PrintShop #PrintProduction #EventInstall #CustomGraphics #BrandedExperiences #PrintAndInstall

### Event-Specific Set (Planner/Rental/Luxury)
#EventPlannerLife #EventProfessionals #LuxuryEvents #WeddingPlanner #MitzvahPlanner #CorporateEvents #BrandActivation #PartyRentals #EventDesign #EventDecor #ExperientialMarketing #EventInspo

### “Money Job” Set (Use on big installs)
#CustomFloorWrap #EventTransformation #FloorWrapDesign #LuxuryEventDesign #NYCActivation #BrandedEvent #VenueTransformation #HighImpactDesign #EventProduction #PremiumEvents #StatementFloor #InstallDay

### Recommended mix per post
- 4 local
- 5 industry
- 4 event-specific
- 1 branded
- 1 campaign-specific (example: #NYCFloorGraphics)

---

## 5) Content Production SOP (Shoot → Edit → Post → Engage)

## Step 1: Shoot (During Every Job)
Use your phone. Shoot vertical. Keep clips 5–12 seconds.

### Must-capture shot list (minimum 20 clips)
1. Exterior/shop opening shot
2. Material close-up
3. Printer running wide shot
4. Printer detail shot
5. Team prep shot
6. Design on screen (quick)
7. Packing/rolling graphics
8. Arrival at venue
9. Empty floor wide shot
10. Tape/measure setup
11. Install in progress (timelapse)
12. Install close-up hands/tools
13. Seam/detail close-up
14. Midway progress wide shot
15. Final full reveal
16. Low angle cinematic pass
17. Client/planner reaction (if possible)
18. Team photo/video
19. Event-ready atmosphere shot
20. End card clip (“DM FLOOR”)

## Step 2: Edit (Simple, Fast)
- Pick 6–10 best clips
- Keep video length around 12–25 seconds
- Add text on screen:
  - Hook line
  - Size / turnaround
  - CTA: “DM FLOOR”
- Add trending but clean background audio
- Export and save to folder: `Week-X/Reels`

## Step 3: Post
Checklist before posting:
- Hook in first line
- Clean cover image
- Location tag: Brooklyn or NYC
- 12–18 hashtags
- CTA in caption + on-screen
- Tag collaborator/client (if approved)

## Step 4: Engage (30 minutes right after posting)
- Reply to every comment
- Reply to all DMs
- Send 3 warm DMs to target accounts
- Comment on 10 planner/rental posts from Top-50 list
- Save best questions for future content

---

## 6) Engagement Playbook (Top-50 Accounts)

Use the Q4 list: `top-50-target-accounts.md`

### Tiering (Do this once)
- **Tier A (Top 15):** Highest value, recurring potential
- **Tier B (Next 20):** Strong fit
- **Tier C (Last 15):** Long-term nurture

### Weekly engagement schedule

#### Monday to Friday (45–60 min/day)
1. Engage with **3 Tier A accounts** (like + thoughtful comments)
2. Engage with **2 Tier B accounts**
3. Send **2 DMs/day** (only warm, personalized)
4. Track all activity in a simple sheet:
   - Account
   - Date touched
   - Action taken
   - Response (Y/N)
   - Next follow-up date

### Comment formula (never generic)
Use this structure:
- Compliment a specific detail
- Mention event result/outcome
- Soft credibility line

Example:
“Love how you layered the lighting + florals here—this setup feels premium. Custom floor graphics would look amazing with this layout too 👏”

### DM formula (warm)
“Hey [Name], loved your [specific event post]. We help planners in NYC/Brooklyn with custom floor graphics + installs. If helpful, we can mock up 2-3 floor concepts for one upcoming event.”

### Follow-up timing
- Follow-up 1: after 2 days
- Follow-up 2: after 7 days
- Follow-up 3: after 14 days (last touch, keep friendly)

### Weekly target numbers
- 25+ meaningful comments
- 10 warm DMs
- 5 conversations started
- 2 quote opportunities
- 1 booked call/job opportunity

---

## 7) Marie’s Touch Style Teardown (What Works + How INKredible Adapts It)

## What works in their model
From observed profile/site pattern:
1. **Clear niche**: party/event visuals only
2. **Strong visual transformations**: before/after is obvious
3. **High posting consistency**: audience always sees fresh work
4. **Easy-to-understand offer**: custom themed pieces
5. **Shop + social connected**: people can browse and buy
6. **Design-forward look**: bright, clean, celebratory content
7. **Social proof signals**: follower count, frequent posts, recurring themes

## How INKredible should adapt (Brooklyn version)
Do not copy style directly. Copy structure.

1. **Own one category publicly:**
   - “NYC/Brooklyn floor graphics + large-format event transformations”
2. **Show repeat format content:**
   - Before/After
   - Install BTS
   - Final reveal
   - Client result
3. **Use one simple CTA everywhere:**
   - DM “FLOOR”
4. **Build planner/rental trust:**
   - Tag collaborators
   - Post partner wins
   - Share reliable turnaround stories
5. **Turn each big job into content series:**
   - Teaser → process → reveal → details → testimonial

## 30-day adaptation sprint
- Week 1: Lock visual style (covers, font style, color consistency)
- Week 2: Publish 4 transformation posts + daily stories
- Week 3: Start planner/rental partner spotlights
- Week 4: Push a clear “book now” campaign with examples and pricing starter points

---

## 8) Weekly Metrics Dashboard (Track Every Monday)

## Core KPI table

| KPI | Good | Great | Red Flag |
|---|---|---|---|
| Posts published/week | 3 | 4 | <3 |
| Stories/day | 5+ frames | 8+ frames | <3 frames |
| Reel views (avg) | 1,500+ | 5,000+ | <800 |
| Saves per carousel | 10+ | 25+ | <5 |
| Profile visits/week | 150+ | 400+ | <80 |
| DMs received/week | 8+ | 20+ | <4 |
| Quote requests/week | 3+ | 7+ | <2 |
| Calls booked/week | 1+ | 3+ | 0 |
| Jobs closed from IG/month | 2+ | 4+ | 0–1 |
| Revenue from IG/month | $3K+ | $10K+ | <$1K |

## Weekly scorecard template
Fill this every Monday:
- Posts last week: __
- Stories posted: __
- Best Reel (views): __
- Best Carousel (saves): __
- New followers: __
- DMs received: __
- Quote requests: __
- Calls booked: __
- Jobs closed: __
- Revenue from IG leads: $__
- What worked best: __
- What to improve this week: __

---

## Weekly Execution Checklist (Print This)

### Monday
- Post Reel
- Engage 5 target accounts
- Send 2 warm DMs

### Tuesday
- Story-heavy day
- Follow up previous DMs
- Capture footage from live jobs

### Wednesday
- Post Carousel
- Engage 5 target accounts
- Send 2 warm DMs

### Thursday
- Story-heavy day
- Prep Friday Reel
- Follow-up touchpoints

### Friday
- Post Reel
- Strong CTA push
- Engage all fresh comments/DMs fast

### Saturday
- Story recap of week
- Save best clips into content folders

### Sunday
- Post Static (offer/testimonial)
- Plan next week’s 4 posts

---

## Content Folder System (Keep It Organized)

Create these folders once:
- `Week-01-Raw`
- `Week-01-Edited`
- `Week-01-Posted`
- Repeat each week

Inside each week:
- `Reels`
- `Carousels`
- `Stories`
- `Testimonials`

This keeps content from getting lost and makes posting easier.

---

## DM-to-Quote Hand-Off (Simple)
When a DM is interested:
1. Ask for: event date, venue, floor dimensions, design status
2. Confirm turnaround window
3. Move lead to quote pipeline immediately
4. Reply within same day whenever possible

Script:
“Awesome—happy to help. Can you send event date, venue, and floor size? Once I have that, I’ll send a quick pricing range and next steps.”

---

## Final Notes for Brandon
- You do **not** need perfect content. You need consistent proof.
- Big installs are your unfair advantage—film everything.
- Every post should do one job: **start a conversation that can become a quote.**
- Keep CTA simple and repeated: **DM ‘FLOOR’.**

---

## 90-Day Outcome Target
If you run this system consistently for 12 weeks:
- 36–48 feed posts published
- Daily story presence
- Stronger planner/rental relationships from Top-50 list
- Predictable inbound DMs and quote requests
- Clear path to recurring high-ticket floor jobs from Instagram
