# Competitor Price Watch Report — 2026-02-14

Compared:
- Old: 2026-02-07.csv
- New: 2026-02-14-auto.csv

## Summary
- Total tracked lines: 14
- Price changes: 0
- Increased: 0
- Decreased: 0
- Unchanged: 6
- Added lines: 0
- Removed lines: 0
- Newly priced (was blank -> now has price): 8
- Lost prices (had price -> now blank): 0
- Volatile (>=10% move): 0

## Changes
No price changes detected between the two snapshots.
## Newly Priced Rows
- NextDayFlyers | Standard Postcards | 14pt Gloss UV (Both Sides) | qty 100 | 3 Business Days | $73.95
- NextDayFlyers | Standard Postcards | 14pt Gloss UV (Both Sides) | qty 500 | 3 Business Days | $73.95
- NextDayFlyers | Standard Business Cards | 14pt Gloss | qty 500 | 3 Business Days | $49.95
- NextDayFlyers | Standard Business Cards | 14pt Gloss | qty 1000 | 3 Business Days | $49.95
- NextDayFlyers | Business Flyers | 100lb Gloss Text | qty 500 | 3 Business Days | $39.60
- NextDayFlyers | Business Flyers | 100lb Gloss Text | qty 1000 | 3 Business Days | $39.60
- NextDayFlyers | Brochures | 100lb Gloss Text Tri-Fold | qty 500 | 3 Business Days | $237.11
- NextDayFlyers | Banners | 13oz Vinyl 2x4 | qty 1 | Standard | $16.95

