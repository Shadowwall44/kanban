# Competitor Price Watch Report — 2026-02-14

Compared:
- Old: 2026-02-07.csv
- New: 2026-02-14-complete.csv

## Summary
- Total tracked lines: 14
- Price changes: 0
- Increased: 0
- Decreased: 0
- Unchanged: 0
- Added lines: 0
- Removed lines: 0
- Newly priced (was blank -> now has price): 14
- Lost prices (had price -> now blank): 0
- Volatile (>=10% move): 0

## Changes
No price changes detected between the two snapshots.
## Newly Priced Rows
- NextDayFlyers | Standard Postcards | 14pt Gloss UV (Both Sides) | qty 100 | 3 Business Days | $73.95
- NextDayFlyers | Standard Postcards | 14pt Gloss UV (Both Sides) | qty 500 | 3 Business Days | $73.95
- NextDayFlyers | Standard Business Cards | 14pt Gloss | qty 500 | 3 Business Days | $49.95
- NextDayFlyers | Standard Business Cards | 14pt Gloss | qty 1000 | 3 Business Days | $49.95
- NextDayFlyers | Business Flyers | 100lb Gloss Text | qty 500 | 3 Business Days | $39.60
- NextDayFlyers | Business Flyers | 100lb Gloss Text | qty 1000 | 3 Business Days | $39.60
- NextDayFlyers | Brochures | 100lb Gloss Text Tri-Fold | qty 500 | 3 Business Days | $237.11
- NextDayFlyers | Banners | 13oz Vinyl 2x4 | qty 1 | Standard | $16.95
- VistaPrint | Business Cards | Standard Matte | qty 500 | Standard | $10.00
- VistaPrint | Flyers | Glossy Full Color | qty 500 | Standard | $8.09
- VistaPrint | Brochures | Tri-Fold Glossy | qty 500 | Standard | $36.89
- VistaPrint | Postcards | Standard Full Color | qty 500 | Standard | $21.99
- VistaPrint | Banners | Vinyl Banner 2x4 | qty 1 | Standard | $5.95
- VistaPrint | Floor Decals | Round 12in | qty 1 | Standard | $17.39

