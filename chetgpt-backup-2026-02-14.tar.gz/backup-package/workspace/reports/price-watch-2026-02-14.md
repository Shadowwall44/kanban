# Competitor Price Watch Report — 2026-02-14

Compared:
- Old: 2026-02-07.csv
- New: 2026-02-14.csv

## Summary
- Total tracked lines: 14
- Price changes: 0
- Increased: 0
- Decreased: 0
- Unchanged: 14
- Added lines: 0
- Removed lines: 0
- Volatile (>=10% move): 0

## Changes
No price changes detected between the two snapshots.
