# Quote Tier Playbook v1 — Live Scripts + Close-Rate Tracking

**Date:** 2026-02-14  
**Built from:**
- `reports/ndf-pricing-playbook-2026-02-14.md`
- `research/price-watch/ndf-standard-min-price-anchors-2026-02-14.csv`
- `research/price-watch/ndf-vs-vistaprint-matchups-2026-02-14.csv`

## Why this matters
Idea #11 (Competitor Price Watch) is only valuable if it changes live quoting behavior.  
This playbook turns the pricing research into:
1. **copy/paste quote scripts** for Brandon/Aviel
2. **a concession ladder** (Opening → Target → Floor)
3. **a tracking experiment** to measure which starting tier closes best

---

## 1) Fast quote scripts by product (copy/paste)

> Rule: always send **2 options** (Best Value + Best Finish) when you feel price resistance.

### A) Business Cards (500)
- **Opening:** $78.69
- **Target:** $69.25
- **Floor:** $62.95
- **Market signal:** Vista gap is huge in commodity card products, so expect price shopping.

**Opening script:**
> For 500 business cards, your premium fast-turn option is **$78.69**.  
> If you want, I can also send a value option at a lower price point.

**Concession script (to Target):**
> I can bring it down to **$69.25** if we lock it in now and keep this standard finish/turnaround.

**Final guardrail script (Floor):**
> Best I can do on this exact spec is **$62.95**. Below that, quality/reliability gets compromised.

---

### B) Flyers (500)
- **Opening:** $35.63
- **Target:** $31.35
- **Floor:** $28.50
- **Rush framing:** Next Day median ≈ **1.69x** vs baseline.

**Opening script:**
> For 500 flyers, standard turnaround is **$35.63**.  
> If this is urgent, I can also quote a next-day rush option.

**Concession script (to Target):**
> I can do **$31.35** if we confirm today.

**Final guardrail script (Floor):**
> Lowest for this spec is **$28.50**. That keeps production quality where it should be.

---

### C) Postcards (500)
- **Opening:** $73.69
- **Target:** $64.85
- **Floor:** $58.95
- **Rush framing:** Next Day median ≈ **1.79x** vs baseline.

**Opening script:**
> For 500 postcards, your standard quote is **$73.69**.  
> I can also provide a value option if you want to optimize budget.

**Concession script (to Target):**
> I can bring this to **$64.85** with the same core spec.

**Final guardrail script (Floor):**
> Floor for this setup is **$58.95** — that’s the real minimum on this quality level.

---

### D) Brochures Tri-Fold (500)
- **Opening:** $164.44
- **Target:** $144.71
- **Floor:** $131.55
- **Checkpoint upsell:** 1000 qty has much better per-unit economics.

**Opening script:**
> For 500 tri-fold brochures, quote is **$164.44**.  
> If you’re distributing heavily, I can show 1000 qty pricing too — usually better value per piece.

**Concession script (to Target):**
> I can do **$144.71** if we proceed on this spec.

**Final guardrail script (Floor):**
> Lowest on this exact setup is **$131.55**.

---

### E) Banners (single-unit quick anchor)
- **Reference from matchup snapshot:** NDF $16.95 vs Vista $5.95 (large gap)
- **Use case:** customer has online quote screenshot and wants immediate response

**Script:**
> I hear you on online pricing — that’s valid.  
> Our quote includes local speed, real support, and deadline reliability.  
> If you share exact size/material/deadline, I’ll send both a budget and premium option so you can pick what fits.

---

## 2) Concession Ladder (non-negotiable rules)

1. Start at **Opening** for commodity/price-sensitive leads.  
2. Move to **Target** only after one of these:
   - customer gives clear deadline + full specs
   - customer gives competitor proof
   - customer commits to same-day approval
3. Move to **Floor** only for strategic reasons:
   - repeat account potential
   - bundle opportunity
   - dead production slot you want to fill
4. Never go below Floor without explicit Aviel approval.

---

## 3) 14-day close-rate experiment (simple)

**Goal:** determine best default starting tier by product + channel.

- Track every quote in `research/price-watch/quote-tier-close-rate-tracker-2026-02-14.csv`
- Compare close rates for:
  - Started at Opening
  - Started at Target
  - Started at Floor (should be rare)
- Also track average discount depth from first quote → final accepted price

### KPI targets for test window
- Quote-to-win rate: **+10%** improvement vs prior baseline
- Average realized tier: **Target or above** on ≥60% of won deals
- Floor-only wins: keep to **<25%** of won deals

---

## 4) Daily execution checklist (Brandon)
- [ ] Log every quote with first tier + amount
- [ ] Log final tier + amount when closed/lost
- [ ] Mark loss reason (price / timing / no response / spec mismatch)
- [ ] Flag repeat-potential customers
- [ ] End-of-day: send 3-line summary to Aviel

---

## 5) End-of-week readout format (for Aviel)
- Top 3 products by quote volume
- Close rate by starting tier
- Revenue won by starting tier
- Times we hit floor and why
- Recommended default tier changes for next week

If data shows no meaningful close-rate gain from opening high on a product, shift that product’s default start tier down to Target.
