# NDF Pricing Playbook — 2026-02-14

Built from `ndf-pricing-complete.csv` (4,086 rows) to push idea #11 (Competitor Price Watch) into an actionable quoting system.

## 1) Baseline price envelope by product

| Product | Baseline Turnaround | Rows | Min | Median | P90 | Max |
|---|---:|---:|---:|---:|---:|---:|
| Banners | 3 Business Days | 33 | $738.00 | $3818.09 | $9320.73 | $16923.61 |
| Brochures (Tri-fold) | 3 Business Days | 66 | $18.37 | $314.55 | $2635.00 | $7770.00 |
| Business Cards | 3 Business Days | 55 | $35.95 | $149.00 | $2789.50 | $5385.00 |
| Door Hangers | 3 Business Days | 55 | $72.91 | $239.73 | $3043.00 | $6660.00 |
| Flyers | 3 Business Days | 253 | $9.13 | $178.55 | $1982.00 | $27525.00 |
| Postcards | 3 Business Days | 110 | $23.95 | $212.97 | $1837.00 | $6685.00 |
| Posters | 3 Business Days | 90 | $240.95 | $2107.97 | $21168.75 | $59295.00 |
| Rack Cards | 3 Business Days | 22 | $18.42 | $170.22 | $1994.75 | $4050.00 |

## 2) Rush-turnaround multipliers vs 3 Business Days

| Product | Next Day Median Multiplier | Same Day Median Multiplier | Samples |
|---|---:|---:|---:|
| Banners | n/a | n/a | 0 |
| Booklets | n/a | n/a | 0 |
| Brochures (Tri-fold) | 1.88x | n/a | 66 |
| Business Cards | 1.95x | 5.38x | 55 |
| Door Hangers | 1.62x | n/a | 45 |
| Flyers | 1.69x | 2.32x | 253 |
| Postcards | 1.79x | 2.27x | 110 |
| Posters | 1.59x | 1.86x | 90 |
| Rack Cards | 1.22x | 1.81x | 22 |
| Stickers | n/a | n/a | 0 |

## 3) Biggest per-unit price-drop checkpoint (baseline turnaround)

| Product | Best Drop | From Qty/Unit | To Qty/Unit |
|---|---:|---:|---:|
| Banners | 6.8% | 25 @ $29.5200 | 50 @ $27.5254 |
| Brochures (Tri-fold) | 45.7% | 250 @ $0.4848 | 500 @ $0.2631 |
| Business Cards | 67.3% | 100 @ $0.5495 | 250 @ $0.1798 |
| Door Hangers | 47.7% | 100 @ $0.9768 | 250 @ $0.5106 |
| Flyers | 48.2% | 500 @ $0.0570 | 1000 @ $0.0295 |
| Postcards | 45.8% | 25 @ $0.9580 | 50 @ $0.5190 |
| Posters | 47.2% | 250 @ $1.3598 | 500 @ $0.7179 |
| Rack Cards | 46.8% | 500 @ $0.2805 | 1000 @ $0.1492 |

## 4) NDF vs VistaPrint direct snapshot matchups

| Product | Qty | NDF | VistaPrint | NDF-Vista | Gap % | Signal |
|---|---:|---:|---:|---:|---:|---|
| banners | 1 | $16.95 | $5.95 | $11.00 | 184.9% | Significant gap; open high, expect negotiation pressure. |
| brochures (tri-fold) | 500 | $237.11 | $36.89 | $200.22 | 542.7% | Large commodity gap; sell speed/service/local trust, avoid floor unless strategic. |
| business cards | 500 | $49.95 | $10.00 | $39.95 | 399.5% | Large commodity gap; sell speed/service/local trust, avoid floor unless strategic. |
| floor decals | 1 | n/a | $17.39 | n/a | n/a | No direct NDF benchmark in snapshot (capture needed) |
| flyers | 500 | $39.60 | $8.09 | $31.51 | 389.5% | Large commodity gap; sell speed/service/local trust, avoid floor unless strategic. |
| postcards | 500 | $73.95 | $21.99 | $51.96 | 236.3% | Significant gap; open high, expect negotiation pressure. |

## 5) How to use this on live calls (INKredible rule set)

- Start with **Opening (+25%)** when floor ticket is below ~$60 (commodity jobs where customers expect negotiation).
- Start with **Target (+10%)** on most tickets between ~$60 and ~$180.
- For high-ticket jobs (>$180 floor), hold **Target** as default and avoid dropping below floor unless strategic (volume/relationship).
- Use rush multipliers to pre-frame urgency pricing before discount talks.
- Anchor quantities at discount checkpoints (section 3) to upsell to a better per-unit tier.
- Where Vista gap is extreme (section 4), sell reliability/turnaround/service — not just price.

## Output files

- `research/price-watch/ndf-standard-min-price-anchors-2026-02-14.csv` — anchor quote sheet (by product + quantity)
- `research/price-watch/ndf-vs-vistaprint-matchups-2026-02-14.csv` — direct NDF vs Vista snapshot gaps
- `reports/ndf-pricing-playbook-2026-02-14.md` — this playbook report
