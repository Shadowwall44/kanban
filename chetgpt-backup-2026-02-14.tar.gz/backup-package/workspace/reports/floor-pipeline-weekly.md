# Floor Graphics Pipeline Weekly Report

Window: 2026-02-02 to 2026-02-08
Generated: 2026-02-14 00:14

## 1) Volume + Conversion
- New leads: **0**
- Discovery completion rate: **0.0%**
- Quote rate: **0.0%**
- Close rate (quotes→deposits): **0.0%** (Red)
- Win rate: **0.0%**

## 2) Speed
- Lead→Quote median days: **0.0** (Green)
- Quote→Deposit median days: **0.0** (Green)
- Deposit→Delivery median days: **0.0**

## 3) Revenue Quality
- Quoted value this week: **$0.00**
- Booked revenue (deposits): **$0.00**
- Delivered revenue: **$0.00**
- Average won job value: **$0.00** (Red)
- Repeat-client rate (won jobs): **0.0%**

## 4) Next 3 Moves
1. Speed up quote turnaround to <=1 day for all fresh leads.
2. Push quote follow-up cadence at 24h / 72h / 7d until deposit or clear loss reason.
3. Review losses and remove top 1 recurring objection this week.
