# Invoice Extraction Timeout Fix — 2026-02-14

## Why this was priority
`Invoice Extraction (6AM)` cron has consecutive timeouts. That blocks financial visibility and delays cleanup of remaining invoice backlog.

## What was implemented
Updated `extract-invoices.mjs` to be **cron-safe** and **resumable**:

1. **Removed hardcoded API key usage in script**
   - Script now loads key from:
     - `NVIDIA_NIM_API_KEY` env var, or
     - `workspace/.secrets/nvidia-nim-api-key.txt`

2. **Added runtime budget controls**
   - New CLI arg: `--max-runtime-sec <seconds>`
   - Default is `240s` (leaves headroom under 300s cron timeout)
   - Script stops cleanly when budget is reached and writes progress

3. **Added batch-size controls**
   - New CLI arg: `--max-pdfs <n>`
   - Useful to cap work per run

4. **Improved run summary + progress snapshots**
   - Summary now reports planned vs attempted PDFs
   - `progress.json` now includes `stoppedEarly`, `maxRuntimeSec`, and `maxPdfs`

## Validation completed
- `node --check extract-invoices.mjs` ✅ syntax ok
- Dry execution with a non-existent vendor filter ✅ argument parsing and budget logging confirmed

## Recommended cron invocation (next step)
Current cron command can stay as-is because script default budget is now safe.  
If we want stricter caps later, run with:

```bash
node workspace/extract-invoices.mjs --max-runtime-sec 240 --max-pdfs 2
```

## Expected impact
- Avoids hard timeout failures from long runs
- Ensures daily forward progress even with large backlog
- Makes extraction behavior predictable and resumable
