# Extraction Backlog Audit — 2026-02-14 (Nightly)

Generated from: `inkredible-invoices/` + `extraction-results/*-extracted.csv`

## Coverage Snapshot (by vendor folder)

| Folder | PDFs | Extracted | Remaining | Coverage |
|---|---:|---:|---:|---:|
| Ddpmsc | 73 | 20 | 53 | 27.4% |
| Lindenmeyr | 15 | 15 | 0 | 100.0% |
| Piedmontplastics | 43 | 0 | 43 | 0.0% |
| Plockmatic Document Finishing Inc | 4 | 0 | 4 | 0.0% |
| Sfsupplies | 7 | 0 | 7 | 0.0% |
| Shardarsp | 4 | 0 | 4 | 0.0% |
| Steadfast Papers Inc | 13 | 0 | 13 | 0.0% |
| Tri State Knife Grinding Corp | 3 | 0 | 3 | 0.0% |
| Uline | 1 | 0 | 1 | 0.0% |

## Priority Queue (largest remaining folders)

- **Ddpmsc** — 53 PDFs remaining (27.4% covered)
- **Piedmontplastics** — 43 PDFs remaining (0.0% covered)
- **Steadfast Papers Inc** — 13 PDFs remaining (0.0% covered)
- **Sfsupplies** — 7 PDFs remaining (0.0% covered)
- **Plockmatic Document Finishing Inc** — 4 PDFs remaining (0.0% covered)
- **Shardarsp** — 4 PDFs remaining (0.0% covered)

## Extracted Spend Signals (from currently extracted line items)

- **Diversified Display Products**: $19,063.64 across 95 line items
- **Lindenmeyr Munroe**: $16,502.00 across 28 line items

### Top Categories by Extracted Dollars
- Vinyl-Adhesive: $10,336.04
- Paper-Adhesive: $9,204.00
- Ink-Roland: $5,847.72
- Vinyl-Floor: $3,471.80
- Vinyl-Banner: $2,064.00
- Substrate-Foam: $1,567.50
- Paper-Copy: $1,344.00
- Other: $1,253.58
- Paper-Cover: $404.00
- Shipping-Fees: $73.00

## Likely Duplicate PDFs (review before extraction)

Potential duplicates detected with conservative filename matching (`(1)` variants + timestamped copy variants):
- **Ddpmsc**: 10 duplicate groups
- **Piedmontplastics**: 5 duplicate groups
- **Steadfast Papers Inc**: 5 duplicate groups
- **Plockmatic Document Finishing Inc**: 2 duplicate groups
- **Sfsupplies**: 1 duplicate groups

### Duplicate groups
- `Ddpmsc` → 2022-03-16_CA_INV2_dwarbeck(1).pdf; 2022-03-16_CA_INV2_dwarbeck.pdf
- `Ddpmsc` → CA_INV2_drosen1(1).pdf; CA_INV2_drosen1(2).pdf; CA_INV2_drosen1(3).pdf; CA_INV2_drosen1(4).pdf; CA_INV2_drosen1.pdf
- `Ddpmsc` → CA_INV2_dwarbeck(1).pdf; CA_INV2_dwarbeck(10).pdf; CA_INV2_dwarbeck(11).pdf; CA_INV2_dwarbeck(12).pdf; CA_INV2_dwarbeck(13).pdf; CA_INV2_dwarbeck(14).pdf; CA_INV2_dwarbeck(15).pdf; CA_INV2_dwarbeck(16).pdf; CA_INV2_dwarbeck(17).pdf; CA_INV2_dwarbeck(18).pdf; CA_INV2_dwarbeck(19).pdf; CA_INV2_dwarbeck(2).pdf; CA_INV2_dwarbeck(20).pdf; CA_INV2_dwarbeck(21).pdf; CA_INV2_dwarbeck(22).pdf; CA_INV2_dwarbeck(3).pdf; CA_INV2_dwarbeck(4).pdf; CA_INV2_dwarbeck(5).pdf; CA_INV2_dwarbeck(6).pdf; CA_INV2_dwarbeck(7).pdf; CA_INV2_dwarbeck(8).pdf; CA_INV2_dwarbeck(9).pdf; CA_INV2_dwarbeck.pdf
- `Ddpmsc` → CA_INV2_davidr(1).pdf; CA_INV2_davidr(2).pdf; CA_INV2_davidr(3).pdf; CA_INV2_davidr(4).pdf; CA_INV2_davidr(5).pdf; CA_INV2_davidr(6).pdf; CA_INV2_davidr.pdf
- `Ddpmsc` → INKredible sales order open 12-16-22(1).pdf; INKredible sales order open 12-16-22.pdf
- `Ddpmsc` → 2022-07-12_CA_INV2_dwarbeck(1).pdf; 2022-07-12_CA_INV2_dwarbeck(2).pdf; 2022-07-12_CA_INV2_dwarbeck(3).pdf; 2022-07-12_CA_INV2_dwarbeck.pdf
- `Ddpmsc` → 2022-05-09_CA_INV2_dwarbeck(1).pdf; 2022-05-09_CA_INV2_dwarbeck(2).pdf; 2022-05-09_CA_INV2_dwarbeck.pdf
- `Ddpmsc` → CA_INV2_drosen(1).pdf; CA_INV2_drosen(2).pdf; CA_INV2_drosen(3).pdf; CA_INV2_drosen(4).pdf; CA_INV2_drosen.pdf
- `Ddpmsc` → 2022-12-05_CA_INV2_davidr(1).pdf; 2022-12-05_CA_INV2_davidr.pdf
- `Ddpmsc` → Inkredible 91422(1).PDF; Inkredible 91422.PDF
- `Piedmontplastics` → Order NJ42302063R0(1).pdf; Order NJ42302063R0.pdf
- `Piedmontplastics` → Order NJ42213791R0(1).pdf; Order NJ42213791R0.pdf
- `Piedmontplastics` → 2025-07-17_16-31-22_Invoice NJ32487762.pdf; 2025-07-17_Invoice NJ32487762.pdf
- `Piedmontplastics` → NJ42217834(1).pdf; NJ42217834.pdf
- `Piedmontplastics` → 2024-01-23_16-14-14_Invoice NJ32011356.pdf; 2024-01-23_Invoice NJ32011356.pdf
- `Plockmatic Document Finishing Inc` → 2024-05-10_09-52-04_Invoice no 240302335 Plockmatic.pdf; 2024-05-10_Invoice no 240302335 Plockmatic.pdf
- `Plockmatic Document Finishing Inc` → 2024-06-03_16-05-15_Statement no 0103014861 Cust no ZI057.pdf; 2024-06-03_Statement no 0103014861 Cust no ZI057.pdf
- `Sfsupplies` → C_Users_rivkyp_AppData_Local_Temp_0001D90MP4XH_FRX(1).pdf; C_Users_rivkyp_AppData_Local_Temp_0001D90MP4XH_FRX.pdf
- `Steadfast Papers Inc` → 2024-11-27_12-31-44_Inv_30428_from_Steadfast_Papers_Inc._38192.pdf; 2024-11-27_Inv_30428_from_Steadfast_Papers_Inc._38192.pdf
- `Steadfast Papers Inc` → 2025-05-29_09-58-37_Inv_30968_from_STEADFAST_PAPERS_INC._31676.pdf; 2025-05-29_Inv_30968_from_STEADFAST_PAPERS_INC._31676.pdf
- `Steadfast Papers Inc` → 2024-10-15_09-04-35_Inv_30281_from_Steadfast_Papers_Inc._37460.pdf; 2024-10-15_Inv_30281_from_Steadfast_Papers_Inc._37460.pdf
- `Steadfast Papers Inc` → 2024-11-19_15-38-02_Inv_30394_from_Steadfast_Papers_Inc._18788.pdf; 2024-11-19_Inv_30394_from_Steadfast_Papers_Inc._18788.pdf
- `Steadfast Papers Inc` → 2025-03-24_08-00-47_Inv_30675_from_STEADFAST_PAPERS_INC._32724.pdf; 2025-03-24_Inv_30675_from_STEADFAST_PAPERS_INC._32724.pdf

## Recommended Next Overnight Batch (no Aviel input needed)
1. Finish **Piedmontplastics** extraction (43 PDFs) — currently 0% coverage.
2. Retry remaining **Ddpmsc** failures (53 PDFs) with stricter OCR fallback.
3. Run small folders in one pass: Plockmatic (4), Sfsupplies (7), Shardarsp (4), Steadfast (13), Tri State (3), Uline (1).
4. Use duplicate list to avoid double-processing obvious copies.

_Generated: 2026-02-14 01:02:23_