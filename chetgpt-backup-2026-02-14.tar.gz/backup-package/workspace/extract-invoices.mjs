#!/usr/bin/env node
/**
 * Batch Invoice Extractor — Node.js version of INKredible Extractor
 * Uses NVIDIA NIM (Kimi K2.5) API + same system prompt as the React app
 * Processes PDFs from inkredible-invoices/ and outputs CSV + JSON
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { pdf } from 'pdf-to-img';

const NVIDIA_NIM_URL = 'https://integrate.api.nvidia.com/v1/chat/completions';
const NVIDIA_NIM_MODEL = 'moonshotai/kimi-k2.5';

const INVOICES_DIR = path.join(process.env.HOME, '.openclaw/workspace/inkredible-invoices');
const OUTPUT_DIR = path.join(process.env.HOME, '.openclaw/workspace/extraction-results');
const SECRETS_DIR = path.join(process.env.HOME, '.openclaw/workspace/.secrets');
const NIM_KEY_PATH = path.join(SECRETS_DIR, 'nvidia-nim-api-key.txt');

function loadNvidiaApiKey() {
  const envKey = process.env.NVIDIA_NIM_API_KEY?.trim();
  if (envKey) return envKey;

  if (fs.existsSync(NIM_KEY_PATH)) {
    const fileKey = fs.readFileSync(NIM_KEY_PATH, 'utf-8').trim();
    if (fileKey) return fileKey;
  }

  throw new Error(
    `Missing NVIDIA NIM API key. Set NVIDIA_NIM_API_KEY or create ${NIM_KEY_PATH}`
  );
}

const NVIDIA_NIM_API_KEY = loadNvidiaApiKey();

const MIN_SPACING_MS = 2000; // 2s between requests (NVIDIA NIM has generous limits)
const MAX_RETRIES = 5;
const BACKOFF_MS = [3000, 8000, 15000, 30000, 60000];

const delay = ms => new Promise(r => setTimeout(r, ms));

function fallbackBackoffMs(retryAttemptNumber) {
  const idx = Math.min(retryAttemptNumber - 1, BACKOFF_MS.length - 1);
  return BACKOFF_MS[idx];
}

function parseDurationToMs(duration) {
  if (!duration || typeof duration !== 'string') return null;

  const trimmed = duration.trim();

  // Most common in Gemini error payloads, e.g. "41s" or "1.5s"
  const secondsMatch = trimmed.match(/^(\d+(?:\.\d+)?)s$/i);
  if (secondsMatch) return Math.ceil(parseFloat(secondsMatch[1]) * 1000);

  // Fallbacks
  const msMatch = trimmed.match(/^(\d+)ms$/i);
  if (msMatch) return parseInt(msMatch[1], 10);

  const integerMatch = trimmed.match(/^\d+$/);
  if (integerMatch) return parseInt(trimmed, 10);

  return null;
}

function findRetryDelayValue(value) {
  if (value == null) return null;

  if (typeof value === 'object') {
    if (typeof value.retryDelay === 'string') return value.retryDelay;
    if (Array.isArray(value)) {
      for (const item of value) {
        const found = findRetryDelayValue(item);
        if (found) return found;
      }
      return null;
    }

    for (const nested of Object.values(value)) {
      const found = findRetryDelayValue(nested);
      if (found) return found;
    }
  }

  return null;
}

function parseRetryDelayMs(errorText, retryAfterHeader = null) {
  // 1) Prefer explicit retryDelay in response body
  if (errorText) {
    try {
      const parsed = JSON.parse(errorText);
      const retryDelay = findRetryDelayValue(parsed);
      const retryMs = parseDurationToMs(retryDelay);
      if (retryMs != null) return retryMs;
    } catch {
      // ignore JSON parse errors, try regex fallback below
    }

    const regexMatch = errorText.match(/"retryDelay"\s*:\s*"([^"]+)"/i);
    if (regexMatch) {
      const retryMs = parseDurationToMs(regexMatch[1]);
      if (retryMs != null) return retryMs;
    }
  }

  // 2) Fallback: Retry-After header if present
  if (retryAfterHeader) {
    const retryAfterMs = parseDurationToMs(retryAfterHeader) ??
      (Number.isFinite(Number(retryAfterHeader)) ? Math.ceil(Number(retryAfterHeader) * 1000) : null);
    if (retryAfterMs != null) return retryAfterMs;
  }

  return null;
}

// Import system prompt from constants
const SYSTEM_PROMPT = fs.readFileSync(
  path.join(process.env.HOME, '.openclaw/workspace/inkredible-extractor/constants.ts'), 'utf-8'
).match(/export const SYSTEM_PROMPT = `([\s\S]*?)`;/)?.[1] || '';

const RESPONSE_SCHEMA = {
  type: "ARRAY",
  items: {
    type: "OBJECT",
    properties: {
      invoice_date: { type: "STRING" },
      vendor: { type: "STRING" },
      invoice_number: { type: "STRING" },
      item_description: { type: "STRING" },
      category: { type: "STRING" },
      sheet_size: { type: "STRING" },
      paper_weight: { type: "STRING" },
      paper_type: { type: "STRING" },
      paper_finish: { type: "STRING" },
      roll_width: { type: "STRING", nullable: true },
      roll_length: { type: "STRING", nullable: true },
      material_thickness: { type: "STRING", nullable: true },
      sku: { type: "STRING" },
      quantity_ordered: { type: "NUMBER" },
      unit_of_measure: { type: "STRING" },
      sheets_per_unit: { type: "NUMBER" },
      total_sheets_explicit: { type: "NUMBER", nullable: true },
      unit_price: { type: "NUMBER" },
      total_line_price: { type: "NUMBER" },
      cost_per_sheet: { type: "NUMBER" },
      notes: { type: "STRING" },
      confidence_score: { type: "STRING" },
      confidence_reason: { type: "STRING" }
    },
    required: [
      "invoice_date", "vendor", "invoice_number", "item_description",
      "category", "quantity_ordered", "unit_price", "total_line_price",
      "paper_weight", "paper_type", "sheets_per_unit"
    ]
  }
};

const CSV_HEADERS = [
  'invoice_date', 'vendor', 'invoice_number', 'item_description', 'category',
  'sheet_size', 'paper_weight', 'paper_type', 'paper_finish',
  'material_thickness', 'roll_width', 'roll_length',
  'sku', 'quantity_ordered', 'unit_of_measure', 'sheets_per_unit',
  'total_sheets_explicit', 'unit_price', 'total_line_price', 'cost_per_sheet',
  'notes', 'confidence_score', 'confidence_reason', 'source_file'
];

async function pdfToImages(pdfBuffer) {
  const pages = [];
  const doc = await pdf(pdfBuffer, { scale: 1.5 });
  for await (const image of doc) {
    pages.push(Buffer.from(image).toString('base64'));
  }
  return pages;
}

async function callNvidiaNim(pdfBase64, filename) {
  // Convert PDF to page images first (NVIDIA NIM doesn't accept raw PDFs)
  const pdfBuffer = Buffer.from(pdfBase64, 'base64');
  const pageImages = await pdfToImages(pdfBuffer);
  console.log(`  📸 Converted to ${pageImages.length} page image(s)`);

  let lastError;

  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    try {
      if (attempt > 0) {
        const retryWaitMs = lastError?.retryDelayMs ?? fallbackBackoffMs(attempt);
        const source = lastError?.retryDelayMs != null ? 'retryDelay' : 'fallback backoff';
        console.log(`  ⏳ Retry ${attempt}/${MAX_RETRIES} after ${Math.ceil(retryWaitMs / 1000)}s (${source})...`);
        await delay(retryWaitMs);
      }

      // Build content array with all page images
      const userContent = [
        ...pageImages.map((imgBase64, idx) => ({
          type: "image_url",
          image_url: { url: `data:image/png;base64,${imgBase64}` }
        })),
        {
          type: "text",
          text: "Analyze this invoice and extract all line items according to the system instructions. Respond with ONLY a valid JSON array, no markdown fences, no explanation."
        }
      ];

      const controller = new AbortController();
      const fetchTimer = setTimeout(() => controller.abort(), 180000); // 3 min timeout

      const res = await fetch(NVIDIA_NIM_URL, {
        method: 'POST',
        signal: controller.signal,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${NVIDIA_NIM_API_KEY}`
        },
        body: JSON.stringify({
          model: NVIDIA_NIM_MODEL,
          messages: [
            { role: 'system', content: SYSTEM_PROMPT + '\n\nYou MUST respond with ONLY a valid JSON array. No markdown code fences, no extra text.' },
            { role: 'user', content: userContent }
          ],
          temperature: 0.1,
          max_tokens: 16384
        })
      });

      clearTimeout(fetchTimer);

      if (!res.ok) {
        const errText = await res.text();
        const retryDelayMs = parseRetryDelayMs(errText, res.headers.get('retry-after'));
        const err = new Error(`API ${res.status}: ${errText.slice(0, 300)}`);
        err.status = res.status;
        err.retryDelayMs = retryDelayMs;

        if ((res.status === 429 || res.status === 503) && attempt < MAX_RETRIES) {
          lastError = err;
          continue;
        }
        throw err;
      }

      const data = await res.json();
      const text = data.choices?.[0]?.message?.content;
      const finishReason = data.choices?.[0]?.finish_reason;

      if (finishReason === 'length') {
        throw new Error('length finish_reason — PDF too large for single extraction');
      }
      if (!text) {
        throw new Error(`Empty response for ${filename}. Finish: ${finishReason}`);
      }

      return parseJSON(text);
    } catch (e) {
      lastError = e;
      const isRetryable = e?.status === 429 || e?.status === 503;
      if (isRetryable && attempt < MAX_RETRIES) continue;
      throw e;
    }
  }

  throw lastError;
}

function parseJSON(text) {
  // Strategy 1: direct
  try { return JSON.parse(text); } catch {}
  // Strategy 2: strip markdown
  let clean = text.replace(/```json/g, '').replace(/```/g, '').trim();
  try { return JSON.parse(clean); } catch {}
  // Strategy 3: find array brackets
  const s = clean.indexOf('['), e = clean.lastIndexOf(']');
  if (s !== -1 && e !== -1) {
    try { return JSON.parse(clean.substring(s, e + 1)); } catch {}
  }
  throw new Error('Failed to parse JSON from NVIDIA NIM response');
}

function escapeCsv(val) {
  if (val == null) return '';
  const s = String(val);
  if (s.includes(',') || s.includes('"') || s.includes('\n')) {
    return '"' + s.replace(/"/g, '""') + '"';
  }
  return s;
}

function itemToCsvRow(item) {
  return CSV_HEADERS.map(h => escapeCsv(item[h] ?? '')).join(',');
}

function findPdfs(dir, vendor = null) {
  const pdfs = [];
  if (vendor) {
    // Top level: only enter the matching vendor folder
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory() && entry.name.toLowerCase().includes(vendor.toLowerCase())) {
        // Found matching vendor dir — collect all PDFs inside
        pdfs.push(...findPdfs(full, null));
      }
    }
  } else {
    // Inside a folder: collect all PDFs recursively
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        pdfs.push(...findPdfs(full, null));
      } else if (entry.name.toLowerCase().endsWith('.pdf')) {
        pdfs.push(full);
      }
    }
  }
  return pdfs;
}

function parseArgs(argv) {
  const args = argv.slice(2);
  let retryFailed = false;
  let vendorFilter = null;
  let maxPdfs = Infinity;
  let maxRuntimeSec = 240;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--retry-failed') {
      retryFailed = true;
      const maybeVendor = args[i + 1];
      if (maybeVendor && !maybeVendor.startsWith('--')) {
        vendorFilter = maybeVendor;
        i += 1;
      }
      continue;
    }

    if (arg === '--max-pdfs') {
      const raw = args[i + 1];
      const parsed = Number.parseInt(raw, 10);
      if (!Number.isFinite(parsed) || parsed <= 0) {
        throw new Error(`Invalid --max-pdfs value: ${raw}`);
      }
      maxPdfs = parsed;
      i += 1;
      continue;
    }

    if (arg === '--max-runtime-sec') {
      const raw = args[i + 1];
      const parsed = Number.parseInt(raw, 10);
      if (!Number.isFinite(parsed) || parsed <= 30) {
        throw new Error(`Invalid --max-runtime-sec value: ${raw}`);
      }
      maxRuntimeSec = parsed;
      i += 1;
      continue;
    }

    if (!vendorFilter) {
      vendorFilter = arg;
    }
  }

  return { retryFailed, vendorFilter, maxPdfs, maxRuntimeSec };
}

function loadFailedPdfs(errorsPath, vendorFilter = null) {
  if (!fs.existsSync(errorsPath)) {
    console.log(`⚠️ --retry-failed requested but no errors file found: ${errorsPath}`);
    return [];
  }

  let errorEntries;
  try {
    errorEntries = JSON.parse(fs.readFileSync(errorsPath, 'utf-8'));
  } catch {
    console.log(`⚠️ Could not parse errors file: ${errorsPath}`);
    return [];
  }

  if (!Array.isArray(errorEntries)) {
    console.log(`⚠️ Invalid errors format in ${errorsPath}`);
    return [];
  }

  const relFiles = errorEntries
    .map(e => e?.file)
    .filter(Boolean)
    .map(String)
    .filter(file => file.toLowerCase().endsWith('.pdf'));

  const filteredRelFiles = vendorFilter
    ? relFiles.filter(file => file.toLowerCase().includes(vendorFilter.toLowerCase()))
    : relFiles;

  const uniqueRelFiles = [...new Set(filteredRelFiles)];

  return uniqueRelFiles
    .map(rel => path.isAbsolute(rel) ? rel : path.join(INVOICES_DIR, rel))
    .filter(abs => fs.existsSync(abs));
}

// ─── MAIN ───
async function main() {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });

  const { retryFailed, vendorFilter, maxPdfs, maxRuntimeSec } = parseArgs(process.argv);
  const errorsPath = path.join(OUTPUT_DIR, 'errors.json');

  let pdfs;
  if (retryFailed) {
    pdfs = loadFailedPdfs(errorsPath, vendorFilter);
    console.log('♻️ Retry-failed mode enabled');
  } else {
    pdfs = findPdfs(INVOICES_DIR, vendorFilter);
  }

  if (Number.isFinite(maxPdfs)) {
    pdfs = pdfs.slice(0, maxPdfs);
  }

  if (vendorFilter) {
    console.log(`🔍 Filtering for vendor: ${vendorFilter}`);
  }
  if (Number.isFinite(maxPdfs)) {
    console.log(`🎯 Max PDFs this run: ${maxPdfs}`);
  }
  console.log(`⏱️ Runtime budget: ${maxRuntimeSec}s`);
  console.log(`📄 Found ${pdfs.length} PDFs to process\n`);

  if (pdfs.length === 0) {
    console.log('No PDFs found. Exiting.');
    process.exit(0);
  }

  const allItems = [];
  const errors = [];
  let processed = 0;
  let lastRequestTime = 0;
  const startedAtMs = Date.now();
  let stoppedEarly = false;

  // CSV file
  const csvPath = path.join(OUTPUT_DIR, vendorFilter ? `${vendorFilter.toLowerCase()}-extracted.csv` : 'all-extracted.csv');
  const jsonPath = path.join(OUTPUT_DIR, vendorFilter ? `${vendorFilter.toLowerCase()}-extracted.json` : 'all-extracted.json');
  const progressPath = path.join(OUTPUT_DIR, 'progress.json');

  const appendCsv = retryFailed && fs.existsSync(csvPath) && fs.statSync(csvPath).size > 0;
  if (!appendCsv) {
    fs.writeFileSync(csvPath, CSV_HEADERS.join(',') + '\n');
  }

  for (const pdfPath of pdfs) {
    const elapsedSec = (Date.now() - startedAtMs) / 1000;
    if (elapsedSec >= maxRuntimeSec) {
      console.log(`⏱️ Runtime budget reached (${Math.round(elapsedSec)}s). Stopping cleanly for this run.`);
      stoppedEarly = true;
      break;
    }

    processed++;
    const relPath = path.relative(INVOICES_DIR, pdfPath);
    const filename = path.basename(pdfPath);

    // Rate limiting
    const now = Date.now();
    const elapsed = now - lastRequestTime;
    if (elapsed < MIN_SPACING_MS && lastRequestTime > 0) {
      await delay(MIN_SPACING_MS - elapsed);
    }

    console.log(`[${processed}/${pdfs.length}] 📋 ${relPath}`);

    try {
      const pdfBuffer = fs.readFileSync(pdfPath);
      const base64 = pdfBuffer.toString('base64');

      lastRequestTime = Date.now();
      const items = await callNvidiaNim(base64, filename);

      // Attach source file
      const tagged = items.map(item => ({ ...item, source_file: filename }));
      allItems.push(...tagged);

      // Append to CSV
      const csvRows = tagged.map(itemToCsvRow).join('\n') + '\n';
      fs.appendFileSync(csvPath, csvRows);

      console.log(`  ✅ ${items.length} line items extracted`);

      // Update progress file
      fs.writeFileSync(progressPath, JSON.stringify({
        total: pdfs.length,
        processed,
        succeeded: processed - errors.length,
        failed: errors.length,
        totalItems: allItems.length,
        lastFile: relPath,
        updatedAt: new Date().toISOString(),
        retryFailedMode: retryFailed
      }, null, 2));

    } catch (err) {
      console.error(`  ❌ FAILED: ${err.message}`);
      errors.push({ file: relPath, error: err.message });
    }
  }

  // Final progress snapshot
  fs.writeFileSync(progressPath, JSON.stringify({
    total: pdfs.length,
    processed,
    succeeded: processed - errors.length,
    failed: errors.length,
    totalItems: allItems.length,
    updatedAt: new Date().toISOString(),
    retryFailedMode: retryFailed,
    stoppedEarly,
    maxRuntimeSec,
    maxPdfs: Number.isFinite(maxPdfs) ? maxPdfs : null
  }, null, 2));

  // Write final JSON (this run's extracted items)
  fs.writeFileSync(jsonPath, JSON.stringify(allItems, null, 2));

  // Always refresh errors.json so retry-failed mode reflects latest state
  fs.writeFileSync(errorsPath, JSON.stringify(errors, null, 2));

  // Summary
  console.log('\n' + '='.repeat(60));
  console.log(`✅ EXTRACTION COMPLETE`);
  console.log(`   Planned PDFs: ${pdfs.length}`);
  console.log(`   Attempted: ${processed}`);
  console.log(`   Succeeded: ${processed - errors.length}`);
  console.log(`   Failed: ${errors.length}`);
  console.log(`   Total line items: ${allItems.length}`);
  console.log(`   CSV: ${csvPath}${appendCsv ? ' (appended)' : ''}`);
  console.log(`   JSON: ${jsonPath}`);

  if (stoppedEarly) {
    console.log('   Note: Stopped early due to runtime budget; resume next scheduled run.');
  }

  if (errors.length > 0) {
    console.log(`\n❌ FAILED FILES:`);
    errors.forEach(e => console.log(`   ${e.file}: ${e.error}`));
  }
}

const isDirectRun = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);

if (isDirectRun) {
  main().catch(err => {
    console.error('Fatal error:', err);
    process.exit(1);
  });
}
