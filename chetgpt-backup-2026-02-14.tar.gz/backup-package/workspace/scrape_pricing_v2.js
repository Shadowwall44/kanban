const puppeteer = require('puppeteer-core');
const fs = require('fs');

async function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function scrapePricing() {
  const browser = await puppeteer.connect({
    browserURL: 'http://localhost:18800',
    defaultViewport: { width: 1400, height: 900 }
  });
  
  const page = await browser.newPage();
  
  // Define the combinations to test
  const sizes = ['4 x 6', '5 x 7', '6 x 9'];
  const stocks = ['14 pt. Cardstock', '16 pt. Cardstock'];
  const quantities = ['100', '500', '1000'];
  
  const results = [];
  
  try {
    console.log('Loading page...');
    await page.goto('https://www.nextdayflyers.com/postcard-printing/standard-postcards.php', { waitUntil: 'networkidle2', timeout: 60000 });
    await delay(8000);
    
    console.log('Starting data collection...\n');
    
    for (const size of sizes) {
      for (const stock of stocks) {
        for (const quantity of quantities) {
          try {
            // Click on Size dropdown and select
            console.log(`Setting: ${size}, ${stock}, Qty ${quantity}`);
            
            // Find and click the size dropdown (first dropdown in the calculator)
            const sizeDropdown = await page.$('.site-dropdown');
            if (sizeDropdown) {
              await sizeDropdown.click();
              await delay(1000);
              
              // Find and click the size option
              const sizeOption = await page.$x(`//li[contains(text(), '${size}')]`);
              if (sizeOption.length > 0) {
                await sizeOption[0].click();
                await delay(1000);
              }
            }
            
            // Wait for price update
            await delay(3000);
            
            // Get current price
            const price = await page.evaluate(() => {
              const priceEl = document.querySelector('#price');
              return priceEl ? priceEl.textContent.trim() : 'N/A';
            });
            
            // Get turnaround prices
            const turnaroundPrices = await page.evaluate(() => {
              const prices = {};
              const containers = document.querySelectorAll('.turnaround-price-container');
              containers.forEach(container => {
                const label = container.querySelector('.turnaround-label');
                const price = container.querySelector('.original-price, .calc-price');
                if (label && price) {
                  prices[label.textContent.trim()] = price.textContent.trim();
                }
              });
              return prices;
            });
            
            results.push({
              size,
              stock,
              quantity,
              price,
              turnaroundPrices
            });
            
            console.log(`  Price: ${price}`);
            console.log(`  Turnarounds:`, turnaroundPrices);
            
          } catch (e) {
            console.log(`Error for ${size} ${stock} ${quantity}: ${e.message}`);
          }
        }
      }
    }
    
    // Save results
    fs.writeFileSync('pricing_results.json', JSON.stringify(results, null, 2));
    console.log('\n✓ Results saved to pricing_results.json');
    
  } catch (e) {
    console.error('Error:', e);
  } finally {
    await page.close();
    await browser.disconnect();
  }
}

scrapePricing();
