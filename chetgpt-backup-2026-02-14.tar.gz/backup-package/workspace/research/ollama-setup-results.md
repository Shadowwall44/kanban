# Ollama Setup Results — WSL2 Ubuntu on Dell XPS 8940

**Date:** 2026-02-13 (Friday night)
**Machine:** Dell XPS 8940 · i5-11400 (6C/12T @ 2.60 GHz) · 16 GB RAM · Intel UHD 730 (iGPU only)
**OS:** WSL2 Ubuntu · Kernel 6.6.87.2-microsoft-standard-WSL2
**Ollama version:** 0.16.1

---

## 1. Installation

### What worked
- **Local (no-sudo) install** to `~/.local/` — extracted the official `ollama-linux-amd64.tar.zst` release via Python `zstandard` since `zstd` CLI wasn't available and `sudo` isn't usable in the OpenClaw sandbox.
- Binary landed at `~/.local/bin/ollama`, libs at `~/.local/lib/ollama` (~4.3 GB total incl. CUDA/ROCm libs we don't use).
- Server started with `~/.local/bin/ollama serve` (backgrounded). API immediately available at `127.0.0.1:11434`.

### What didn't work
- `curl -fsSL https://ollama.com/install.sh | sh` **failed** — requires `sudo` for `/usr/local` install. Not available in this environment.
- The official `.tar.zst` could not be piped through `tar --zstd` because the `zstd` binary is not installed. Workaround: Python `zstandard` module + `tarfile`.
- systemd service setup was skipped (WSL2 default doesn't run systemd). Manual `ollama serve &` works fine.

### Install footprint
| Component | Size |
|---|---|
| Ollama binary + libs | 4.3 GB |
| phi3:mini model | 2.2 GB |
| gemma2:2b model | 1.6 GB |
| **Total disk** | **~8.1 GB** |

---

## 2. Models Tested

### phi3:mini (3.8B params, Q4_K_M, 2.2 GB)

| Metric | Cold Start | Warm |
|---|---|---|
| Model load | 6,654 ms | 45 ms |
| Prompt eval | 17 tok / 971 ms (**17.5 tok/s**) | 22 tok / 923 ms (**23.8 tok/s**) |
| Generation | 159 tok / 21,166 ms (**7.51 tok/s**) | 118 tok / 16,431 ms (**7.18 tok/s**) |
| Total wall time | 28.9 s | 17.5 s |

**Quality:** Good. Coherent multi-paragraph answers, solid reasoning on data structures, follows instructions well.

### gemma2:2b (2.6B params, Q4_K_M, 1.6 GB)

| Metric | Cold Start | Warm |
|---|---|---|
| Model load | 10,587 ms | 174 ms |
| Prompt eval | 17 tok / 640 ms (**26.6 tok/s**) | 21 tok / 518 ms (**40.5 tok/s**) |
| Generation | 239 tok / 41,773 ms (**5.72 tok/s**) | 95 tok / 21,783 ms (**4.36 tok/s**) |
| Total wall time | 53.8 s | 22.8 s |

**Quality:** Good for its size. Formatted output with markdown bullets. Slightly more verbose, slightly slower generation than phi3:mini despite fewer params.

---

## 3. Performance Summary

| Model | Generation Speed (warm) | RAM Used | Verdict |
|---|---|---|---|
| **phi3:mini** | **~7.2 tok/s** | ~4.5 GB | ✅ Best balance of speed + quality |
| gemma2:2b | ~4.4–5.7 tok/s | ~3.2 GB | ✅ Viable, lighter on RAM |

- At **7 tok/s**, phi3:mini produces roughly **one short sentence per second** — usable for interactive chat, somewhat slow for long generation.
- The system hit **87% RAM** with one model loaded (7.6 GB total, ~6.7 GB used). Running two models simultaneously would cause heavy swapping.
- Swap usage was 1.6 GB / 2.0 GB during testing, meaning the system is already memory-constrained.

---

## 4. Recommendations

### Best model for this hardware
**phi3:mini (3.8B)** — best speed-to-quality ratio on CPU at 7+ tok/s.

### Other viable models to try
| Model | Params | Size | Expected Speed | Notes |
|---|---|---|---|---|
| qwen2.5:1.5b | 1.5B | ~1 GB | ~12-15 tok/s | Fastest option, good for simple tasks |
| llama3.2:1b | 1B | ~0.7 GB | ~15-20 tok/s | Ultra-light, basic quality |
| phi3:mini | 3.8B | 2.2 GB | ~7 tok/s | **Sweet spot** ✅ |
| mistral:7b | 7B | 4.1 GB | ~3-4 tok/s | Slower but smarter; may OOM |

### Models to AVOID on this hardware
- Anything **7B+** will consume nearly all RAM and generate at 2-3 tok/s
- **13B+** models will not fit in 16 GB RAM (need 10+ GB just for weights)
- Quantized 7B models (Q4) might work if nothing else is running — borderline

### Configuration tips
```bash
# Add to ~/.bashrc for convenience
export PATH="$HOME/.local/bin:$PATH"

# Start Ollama on WSL boot (add to ~/.bashrc or a startup script)
if ! pgrep -x ollama > /dev/null; then
    nohup ~/.local/bin/ollama serve > /tmp/ollama.log 2>&1 &
fi

# Reduce context window to save RAM (default 4096)
# Use OLLAMA_CONTEXT_LENGTH=2048 for tighter memory

# API is at http://127.0.0.1:11434
# Can be accessed from Windows via localhost:11434
```

### RAM optimization
- WSL2 is allocated **8 GB** (half of 16 GB physical). Consider increasing via `.wslconfig`:
  ```ini
  # %UserProfile%\.wslconfig
  [wsl2]
  memory=12GB
  swap=4GB
  ```
- This would give Ollama more headroom and reduce swap thrashing.

---

## 5. Quick Reference

```bash
# Start server
~/.local/bin/ollama serve &

# Chat interactively
~/.local/bin/ollama run phi3:mini

# One-shot query
~/.local/bin/ollama run phi3:mini "Summarize this text: ..."

# API call
curl http://127.0.0.1:11434/api/generate -d '{"model":"phi3:mini","prompt":"Hello","stream":false}'

# List models
~/.local/bin/ollama list

# Remove a model
~/.local/bin/ollama rm gemma2:2b
```

---

## 6. Conclusion

Ollama runs well on this CPU-only Dell XPS 8940 with WSL2. The **phi3:mini** model at ~7 tokens/sec is the sweet spot — fast enough for interactive use, smart enough for real tasks. The main constraint is **RAM** (8 GB WSL2 allocation with 16 GB physical), not CPU. Increasing WSL2 memory to 12 GB via `.wslconfig` is the single biggest improvement available.
