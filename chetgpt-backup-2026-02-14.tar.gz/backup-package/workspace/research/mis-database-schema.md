# INKredible Printing — MIS Database Schema (PostgreSQL)

Created: 2026-02-13  
Scope: Internal MIS data model for jobs, inventory/FIFO, customers, vendors, pricing, machines, quotes, and invoices.

---

## 1) ER Diagram (text-based)

```text
pricing_tiers (1) ───< customers >───(1) jobs >───(1) products
       │                    │             │  │
       │                    │             │  └──< job_machine_usage >──(1) machines
       │                    │             └──< job_labor_entries
       │                    │             └──< job_material_usage >──(1) material_lots >──(1) materials
       │                    │                                              │                   │
       │                    │                                              └──(1) vendors      └──< vendor_material_prices >──(1) vendors
       │                    └──< quotes >──< quote_line_items >──(1) products
       │                                   
       └──< product_tier_pricing_rules >──(1) products

products ───< ndf_anchor_prices

jobs ───< inventory_transactions >── materials
jobs ───< invoices >──< invoice_line_items
quotes ───< invoices
invoices ───< payments
customers ───< quotes / invoices / payments
```

Notes:
- FIFO inventory is enforced operationally by consuming from `material_lots` ordered by `received_at` (oldest first), updating `qty_remaining`, and logging the movement in `job_material_usage` + `inventory_transactions`.
- `customers.outstanding_balance` is a denormalized convenience field (can also be computed from invoices/payments).

---

## 2) PostgreSQL DDL

```sql
-- =========================
-- ENUM TYPES
-- =========================
CREATE TYPE pricing_tier_code AS ENUM ('NDF_BASE', 'NDF_PLUS_10', 'NDF_PLUS_25');
CREATE TYPE job_status AS ENUM ('QUOTED', 'APPROVED', 'PREPRESS', 'PRINTING', 'FINISHING', 'READY', 'DELIVERED', 'CANCELLED');
CREATE TYPE quote_status AS ENUM ('DRAFT', 'SENT', 'ACCEPTED', 'REJECTED', 'EXPIRED');
CREATE TYPE invoice_status AS ENUM ('DRAFT', 'SENT', 'PARTIAL', 'PAID', 'OVERDUE', 'VOID');
CREATE TYPE payment_status AS ENUM ('UNPAID', 'PARTIAL', 'PAID', 'REFUNDED', 'VOID');
CREATE TYPE qb_sync_status AS ENUM ('NOT_SYNCED', 'QUEUED', 'SYNCED', 'SYNC_ERROR');
CREATE TYPE machine_status AS ENUM ('ACTIVE', 'MAINTENANCE', 'RETIRED');
CREATE TYPE inventory_txn_type AS ENUM (
  'PURCHASE_RECEIPT',
  'JOB_ALLOCATION',
  'JOB_CONSUMPTION',
  'ADJUSTMENT_POSITIVE',
  'ADJUSTMENT_NEGATIVE',
  'RETURN_TO_STOCK'
);

-- =========================
-- PRICING / CRM CORE
-- =========================
CREATE TABLE pricing_tiers (
  tier_id SMALLSERIAL PRIMARY KEY,
  tier_code pricing_tier_code NOT NULL UNIQUE,
  tier_name TEXT NOT NULL,
  markup_pct NUMERIC(6,4) NOT NULL CHECK (markup_pct >= 0),
  description TEXT,
  is_default BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE customers (
  customer_id BIGSERIAL PRIMARY KEY,
  customer_code TEXT NOT NULL UNIQUE,
  company_name TEXT NOT NULL,
  contact_name TEXT,
  email TEXT,
  phone TEXT,
  billing_address TEXT,
  shipping_address TEXT,
  pricing_tier_id SMALLINT NOT NULL REFERENCES pricing_tiers(tier_id),
  payment_terms_days INTEGER NOT NULL DEFAULT 0,
  credit_limit NUMERIC(12,2),
  outstanding_balance NUMERIC(12,2) NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE vendors (
  vendor_id BIGSERIAL PRIMARY KEY,
  vendor_code TEXT NOT NULL UNIQUE,
  vendor_name TEXT NOT NULL,
  contact_name TEXT,
  email TEXT,
  phone TEXT,
  lead_time_days INTEGER,
  payment_terms TEXT,
  address TEXT,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE machines (
  machine_id SMALLSERIAL PRIMARY KEY,
  machine_code TEXT NOT NULL UNIQUE,
  machine_name TEXT NOT NULL,
  machine_type TEXT NOT NULL,
  location TEXT,
  cost_rate_per_hour NUMERIC(10,2),
  status machine_status NOT NULL DEFAULT 'ACTIVE',
  notes TEXT
);

CREATE TABLE products (
  product_id BIGSERIAL PRIMARY KEY,
  product_code TEXT NOT NULL UNIQUE,
  product_name TEXT NOT NULL,
  description TEXT,
  unit_of_measure TEXT NOT NULL DEFAULT 'EA',
  standard_turnaround_days INTEGER,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE ndf_anchor_prices (
  anchor_price_id BIGSERIAL PRIMARY KEY,
  product_id BIGINT NOT NULL REFERENCES products(product_id),
  anchor_unit_price NUMERIC(12,4) NOT NULL CHECK (anchor_unit_price >= 0),
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  effective_from DATE NOT NULL,
  effective_to DATE,
  source_note TEXT,
  UNIQUE (product_id, effective_from)
);

CREATE TABLE product_tier_pricing_rules (
  rule_id BIGSERIAL PRIMARY KEY,
  product_id BIGINT NOT NULL REFERENCES products(product_id),
  tier_id SMALLINT NOT NULL REFERENCES pricing_tiers(tier_id),
  pricing_method TEXT NOT NULL CHECK (pricing_method IN ('MARKUP', 'FIXED')),
  markup_pct NUMERIC(6,4),
  fixed_unit_price NUMERIC(12,4),
  min_order_qty INTEGER,
  effective_from DATE NOT NULL DEFAULT CURRENT_DATE,
  effective_to DATE,
  CHECK (
    (pricing_method = 'MARKUP' AND markup_pct IS NOT NULL AND fixed_unit_price IS NULL)
    OR
    (pricing_method = 'FIXED' AND fixed_unit_price IS NOT NULL AND markup_pct IS NULL)
  ),
  UNIQUE (product_id, tier_id, effective_from)
);

-- =========================
-- INVENTORY / VENDOR COSTS
-- =========================
CREATE TABLE materials (
  material_id BIGSERIAL PRIMARY KEY,
  material_code TEXT NOT NULL UNIQUE,
  material_name TEXT NOT NULL,
  category TEXT NOT NULL,
  unit_of_measure TEXT NOT NULL,
  reorder_point_qty NUMERIC(14,3) NOT NULL DEFAULT 0,
  reorder_qty NUMERIC(14,3),
  preferred_vendor_id BIGINT REFERENCES vendors(vendor_id),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE vendor_material_prices (
  vendor_material_price_id BIGSERIAL PRIMARY KEY,
  vendor_id BIGINT NOT NULL REFERENCES vendors(vendor_id),
  material_id BIGINT NOT NULL REFERENCES materials(material_id),
  unit_cost NUMERIC(12,4) NOT NULL CHECK (unit_cost >= 0),
  min_order_qty NUMERIC(14,3),
  lead_time_days INTEGER,
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  effective_from DATE NOT NULL,
  effective_to DATE,
  UNIQUE (vendor_id, material_id, effective_from)
);

CREATE TABLE material_lots (
  lot_id BIGSERIAL PRIMARY KEY,
  material_id BIGINT NOT NULL REFERENCES materials(material_id),
  vendor_id BIGINT NOT NULL REFERENCES vendors(vendor_id),
  vendor_material_price_id BIGINT REFERENCES vendor_material_prices(vendor_material_price_id),
  lot_number TEXT NOT NULL,
  received_at TIMESTAMPTZ NOT NULL,
  qty_received NUMERIC(14,3) NOT NULL CHECK (qty_received > 0),
  qty_remaining NUMERIC(14,3) NOT NULL CHECK (qty_remaining >= 0),
  unit_cost NUMERIC(12,4) NOT NULL CHECK (unit_cost >= 0),
  invoice_ref TEXT,
  expires_at DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (material_id, lot_number)
);

-- =========================
-- PRODUCTION / JOBS
-- =========================
CREATE TABLE jobs (
  job_id BIGSERIAL PRIMARY KEY,
  job_number TEXT NOT NULL UNIQUE,
  customer_id BIGINT NOT NULL REFERENCES customers(customer_id),
  product_id BIGINT NOT NULL REFERENCES products(product_id),
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  primary_machine_id SMALLINT REFERENCES machines(machine_id),
  due_date DATE,
  status job_status NOT NULL DEFAULT 'QUOTED',
  estimated_labor_hours NUMERIC(8,2),
  actual_labor_hours NUMERIC(8,2),
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE job_machine_usage (
  job_machine_usage_id BIGSERIAL PRIMARY KEY,
  job_id BIGINT NOT NULL REFERENCES jobs(job_id) ON DELETE CASCADE,
  machine_id SMALLINT NOT NULL REFERENCES machines(machine_id),
  step_name TEXT,
  hours_used NUMERIC(8,2) NOT NULL CHECK (hours_used > 0),
  hourly_rate NUMERIC(10,2),
  started_at TIMESTAMPTZ,
  ended_at TIMESTAMPTZ
);

CREATE TABLE job_labor_entries (
  labor_entry_id BIGSERIAL PRIMARY KEY,
  job_id BIGINT NOT NULL REFERENCES jobs(job_id) ON DELETE CASCADE,
  employee_name TEXT NOT NULL,
  role TEXT,
  hours_worked NUMERIC(8,2) NOT NULL CHECK (hours_worked > 0),
  hourly_cost NUMERIC(10,2) NOT NULL CHECK (hourly_cost >= 0),
  entry_date DATE NOT NULL DEFAULT CURRENT_DATE,
  notes TEXT
);

CREATE TABLE job_material_usage (
  job_material_usage_id BIGSERIAL PRIMARY KEY,
  job_id BIGINT NOT NULL REFERENCES jobs(job_id) ON DELETE CASCADE,
  material_id BIGINT NOT NULL REFERENCES materials(material_id),
  lot_id BIGINT NOT NULL REFERENCES material_lots(lot_id),
  quantity_used NUMERIC(14,3) NOT NULL CHECK (quantity_used > 0),
  unit_cost NUMERIC(12,4) NOT NULL CHECK (unit_cost >= 0),
  waste_qty NUMERIC(14,3) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE inventory_transactions (
  transaction_id BIGSERIAL PRIMARY KEY,
  material_id BIGINT NOT NULL REFERENCES materials(material_id),
  lot_id BIGINT REFERENCES material_lots(lot_id),
  job_id BIGINT REFERENCES jobs(job_id),
  txn_type inventory_txn_type NOT NULL,
  quantity_delta NUMERIC(14,3) NOT NULL CHECK (quantity_delta <> 0),
  unit_cost NUMERIC(12,4),
  txn_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reference_doc TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =========================
-- QUOTES / INVOICES / PAYMENTS
-- =========================
CREATE TABLE quotes (
  quote_id BIGSERIAL PRIMARY KEY,
  quote_number TEXT NOT NULL UNIQUE,
  job_id BIGINT REFERENCES jobs(job_id),
  customer_id BIGINT NOT NULL REFERENCES customers(customer_id),
  pricing_tier_id SMALLINT NOT NULL REFERENCES pricing_tiers(tier_id),
  status quote_status NOT NULL DEFAULT 'DRAFT',
  issue_date DATE NOT NULL DEFAULT CURRENT_DATE,
  expiry_date DATE,
  subtotal NUMERIC(12,2) NOT NULL DEFAULT 0,
  tax_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  total_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  accepted_at TIMESTAMPTZ
);

CREATE TABLE quote_line_items (
  quote_line_item_id BIGSERIAL PRIMARY KEY,
  quote_id BIGINT NOT NULL REFERENCES quotes(quote_id) ON DELETE CASCADE,
  line_no INTEGER NOT NULL,
  product_id BIGINT REFERENCES products(product_id),
  description TEXT NOT NULL,
  quantity NUMERIC(12,3) NOT NULL CHECK (quantity > 0),
  uom TEXT NOT NULL DEFAULT 'EA',
  anchor_unit_price NUMERIC(12,4),
  markup_pct NUMERIC(6,4),
  unit_price NUMERIC(12,4) NOT NULL CHECK (unit_price >= 0),
  line_total NUMERIC(12,2) NOT NULL CHECK (line_total >= 0),
  UNIQUE (quote_id, line_no)
);

CREATE TABLE invoices (
  invoice_id BIGSERIAL PRIMARY KEY,
  invoice_number TEXT NOT NULL UNIQUE,
  job_id BIGINT NOT NULL REFERENCES jobs(job_id),
  quote_id BIGINT REFERENCES quotes(quote_id),
  customer_id BIGINT NOT NULL REFERENCES customers(customer_id),
  status invoice_status NOT NULL DEFAULT 'DRAFT',
  payment_status payment_status NOT NULL DEFAULT 'UNPAID',
  issue_date DATE NOT NULL DEFAULT CURRENT_DATE,
  due_date DATE,
  subtotal NUMERIC(12,2) NOT NULL DEFAULT 0,
  tax_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  total_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  balance_due NUMERIC(12,2) NOT NULL DEFAULT 0,
  quickbooks_sync_status qb_sync_status NOT NULL DEFAULT 'NOT_SYNCED',
  quickbooks_invoice_id TEXT,
  quickbooks_last_sync_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE invoice_line_items (
  invoice_line_item_id BIGSERIAL PRIMARY KEY,
  invoice_id BIGINT NOT NULL REFERENCES invoices(invoice_id) ON DELETE CASCADE,
  line_no INTEGER NOT NULL,
  description TEXT NOT NULL,
  quantity NUMERIC(12,3) NOT NULL CHECK (quantity > 0),
  unit_price NUMERIC(12,4) NOT NULL CHECK (unit_price >= 0),
  line_total NUMERIC(12,2) NOT NULL CHECK (line_total >= 0),
  job_material_usage_id BIGINT REFERENCES job_material_usage(job_material_usage_id),
  UNIQUE (invoice_id, line_no)
);

CREATE TABLE payments (
  payment_id BIGSERIAL PRIMARY KEY,
  invoice_id BIGINT NOT NULL REFERENCES invoices(invoice_id),
  customer_id BIGINT NOT NULL REFERENCES customers(customer_id),
  payment_date DATE NOT NULL,
  amount NUMERIC(12,2) NOT NULL CHECK (amount > 0),
  method TEXT NOT NULL,
  reference_no TEXT,
  notes TEXT,
  quickbooks_payment_id TEXT,
  quickbooks_sync_status qb_sync_status NOT NULL DEFAULT 'NOT_SYNCED',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =========================
-- RECOMMENDED INDEXES
-- =========================
CREATE INDEX idx_jobs_customer_status ON jobs(customer_id, status);
CREATE INDEX idx_jobs_due_date ON jobs(due_date);
CREATE INDEX idx_quotes_customer_status ON quotes(customer_id, status);
CREATE INDEX idx_invoices_customer_status ON invoices(customer_id, status, payment_status);
CREATE INDEX idx_material_lots_fifo ON material_lots(material_id, received_at) WHERE qty_remaining > 0;
CREATE INDEX idx_inventory_txn_material_date ON inventory_transactions(material_id, txn_at);
CREATE INDEX idx_job_material_usage_job ON job_material_usage(job_id);
```

---

## 3) Table-by-table dictionary (PK/FK, required vs optional, examples)

> Convention: **Required = NOT NULL fields** in DDL; **Optional = nullable fields**.

### 3.1 `pricing_tiers`
- **PK:** `tier_id`
- **FK:** none
- **Required:** `tier_code`, `tier_name`, `markup_pct`, `is_default`
- **Optional:** `description`
- **Example rows:**

| tier_id | tier_code     | tier_name         | markup_pct | is_default |
|---:|---|---|---:|---|
| 1 | NDF_BASE    | NDF Base        | 0.0000 | false |
| 2 | NDF_PLUS_10 | NDF +10% Tier   | 0.1000 | true |
| 3 | NDF_PLUS_25 | NDF +25% Tier   | 0.2500 | false |

### 3.2 `customers`
- **PK:** `customer_id`
- **FK:** `pricing_tier_id → pricing_tiers.tier_id`
- **Required:** `customer_code`, `company_name`, `pricing_tier_id`, `payment_terms_days`, `outstanding_balance`, `is_active`, `created_at`, `updated_at`
- **Optional:** `contact_name`, `email`, `phone`, `billing_address`, `shipping_address`, `credit_limit`
- **Example row:**

| customer_id | customer_code | company_name | contact_name | email | phone | pricing_tier_id | outstanding_balance |
|---:|---|---|---|---|---|---:|---:|
| 101 | CUST-000101 | Brooklyn Realty Group | Eli Weiss | eli@brooklynrealty.com | 718-555-0192 | 2 | 1240.50 |

### 3.3 `vendors`
- **PK:** `vendor_id`
- **FK:** none
- **Required:** `vendor_code`, `vendor_name`, `is_active`, `created_at`
- **Optional:** `contact_name`, `email`, `phone`, `lead_time_days`, `payment_terms`, `address`
- **Example row:**

| vendor_id | vendor_code | vendor_name | lead_time_days | payment_terms |
|---:|---|---|---:|---|
| 201 | VEND-PAPERCO | PaperCo Distribution | 3 | Net 30 |

### 3.4 `machines`
- **PK:** `machine_id`
- **FK:** none
- **Required:** `machine_code`, `machine_name`, `machine_type`, `status`
- **Optional:** `location`, `cost_rate_per_hour`, `notes`
- **Example rows (required shop machines):**

| machine_id | machine_code | machine_name | machine_type | cost_rate_per_hour | status |
|---:|---|---|---|---:|---|
| 1 | KONICA-C3080 | Konica C3080 | Digital Press | 55.00 | ACTIVE |
| 2 | ROLAND-VG2-540 | Roland VG2-540 | Wide Format Print/Cut | 65.00 | ACTIVE |
| 3 | HP-LATEX-700W | HP Latex 700W | Wide Format Printer | 72.00 | ACTIVE |
| 4 | INTEC-FB550 | Intec FB550 | Flatbed Cutter | 48.00 | ACTIVE |
| 5 | TRIUMPH-5260 | Triumph 5260 | Paper Cutter | 35.00 | ACTIVE |

### 3.5 `products`
- **PK:** `product_id`
- **FK:** none
- **Required:** `product_code`, `product_name`, `unit_of_measure`, `is_active`, `created_at`
- **Optional:** `description`, `standard_turnaround_days`
- **Example row:**

| product_id | product_code | product_name | unit_of_measure | standard_turnaround_days |
|---:|---|---|---|---:|
| 301 | PROD-BC-3.5x2 | Business Cards (3.5x2) | EA | 2 |

### 3.6 `ndf_anchor_prices`
- **PK:** `anchor_price_id`
- **FK:** `product_id → products.product_id`
- **Required:** `product_id`, `anchor_unit_price`, `currency`, `effective_from`
- **Optional:** `effective_to`, `source_note`
- **Example row:**

| anchor_price_id | product_id | anchor_unit_price | currency | effective_from | source_note |
|---:|---:|---:|---|---|---|
| 401 | 301 | 0.1800 | USD | 2026-02-01 | NDF benchmark Feb 2026 |

### 3.7 `product_tier_pricing_rules`
- **PK:** `rule_id`
- **FK:** `product_id → products.product_id`, `tier_id → pricing_tiers.tier_id`
- **Required:** `product_id`, `tier_id`, `pricing_method`, `effective_from`
- **Conditionally required:** `markup_pct` (if MARKUP), `fixed_unit_price` (if FIXED)
- **Optional:** `min_order_qty`, `effective_to`
- **Example rows:**

| rule_id | product_id | tier_id | pricing_method | markup_pct | effective_from |
|---:|---:|---:|---|---:|---|
| 501 | 301 | 1 | MARKUP | 0.0000 | 2026-02-01 |
| 502 | 301 | 2 | MARKUP | 0.1000 | 2026-02-01 |
| 503 | 301 | 3 | MARKUP | 0.2500 | 2026-02-01 |

### 3.8 `materials`
- **PK:** `material_id`
- **FK:** `preferred_vendor_id → vendors.vendor_id`
- **Required:** `material_code`, `material_name`, `category`, `unit_of_measure`, `reorder_point_qty`, `is_active`, `created_at`
- **Optional:** `reorder_qty`, `preferred_vendor_id`
- **Example row:**

| material_id | material_code | material_name | category | unit_of_measure | reorder_point_qty | reorder_qty | preferred_vendor_id |
|---:|---|---|---|---|---:|---:|---:|
| 601 | MAT-PAPER-100GC-12x18 | 100# Gloss Cover 12x18 | PAPER | SHEET | 500.000 | 2000.000 | 201 |

### 3.9 `vendor_material_prices`
- **PK:** `vendor_material_price_id`
- **FK:** `vendor_id → vendors.vendor_id`, `material_id → materials.material_id`
- **Required:** `vendor_id`, `material_id`, `unit_cost`, `currency`, `effective_from`
- **Optional:** `min_order_qty`, `lead_time_days`, `effective_to`
- **Example row:**

| vendor_material_price_id | vendor_id | material_id | unit_cost | effective_from | lead_time_days |
|---:|---:|---:|---:|---|---:|
| 701 | 201 | 601 | 0.0825 | 2026-02-01 | 3 |

### 3.10 `material_lots`
- **PK:** `lot_id`
- **FK:** `material_id → materials.material_id`, `vendor_id → vendors.vendor_id`, `vendor_material_price_id → vendor_material_prices.vendor_material_price_id`
- **Required:** `material_id`, `vendor_id`, `lot_number`, `received_at`, `qty_received`, `qty_remaining`, `unit_cost`, `created_at`
- **Optional:** `vendor_material_price_id`, `invoice_ref`, `expires_at`
- **Example rows (FIFO):**

| lot_id | material_id | lot_number | received_at | qty_received | qty_remaining | unit_cost |
|---:|---:|---|---|---:|---:|---:|
| 801 | 601 | LOT-2026-01-A | 2026-01-22 10:00:00-05 | 4000.000 | 900.000 | 0.0790 |
| 802 | 601 | LOT-2026-02-B | 2026-02-10 09:15:00-05 | 3000.000 | 3000.000 | 0.0825 |

### 3.11 `jobs`
- **PK:** `job_id`
- **FK:** `customer_id → customers.customer_id`, `product_id → products.product_id`, `primary_machine_id → machines.machine_id`
- **Required:** `job_number`, `customer_id`, `product_id`, `quantity`, `status`, `created_at`, `updated_at`
- **Optional:** `primary_machine_id`, `due_date`, `estimated_labor_hours`, `actual_labor_hours`, `notes`
- **Example row:**

| job_id | job_number | customer_id | product_id | quantity | primary_machine_id | status | estimated_labor_hours |
|---:|---|---:|---:|---:|---:|---|---:|
| 901 | JOB-2026-00091 | 101 | 301 | 5000 | 1 | PRINTING | 6.50 |

### 3.12 `job_machine_usage`
- **PK:** `job_machine_usage_id`
- **FK:** `job_id → jobs.job_id`, `machine_id → machines.machine_id`
- **Required:** `job_id`, `machine_id`, `hours_used`
- **Optional:** `step_name`, `hourly_rate`, `started_at`, `ended_at`
- **Example row:**

| job_machine_usage_id | job_id | machine_id | step_name | hours_used | hourly_rate |
|---:|---:|---:|---|---:|---:|
| 1001 | 901 | 1 | Print run | 4.25 | 55.00 |

### 3.13 `job_labor_entries`
- **PK:** `labor_entry_id`
- **FK:** `job_id → jobs.job_id`
- **Required:** `job_id`, `employee_name`, `hours_worked`, `hourly_cost`, `entry_date`
- **Optional:** `role`, `notes`
- **Example row:**

| labor_entry_id | job_id | employee_name | role | hours_worked | hourly_cost |
|---:|---:|---|---|---:|---:|
| 1101 | 901 | Brandon | Press Operator | 3.50 | 28.00 |

### 3.14 `job_material_usage`
- **PK:** `job_material_usage_id`
- **FK:** `job_id → jobs.job_id`, `material_id → materials.material_id`, `lot_id → material_lots.lot_id`
- **Required:** `job_id`, `material_id`, `lot_id`, `quantity_used`, `unit_cost`, `waste_qty`, `created_at`
- **Optional:** none
- **Example row:**

| job_material_usage_id | job_id | material_id | lot_id | quantity_used | waste_qty | unit_cost |
|---:|---:|---:|---:|---:|---:|---:|
| 1201 | 901 | 601 | 801 | 2200.000 | 45.000 | 0.0790 |

### 3.15 `inventory_transactions`
- **PK:** `transaction_id`
- **FK:** `material_id → materials.material_id`, `lot_id → material_lots.lot_id`, `job_id → jobs.job_id`
- **Required:** `material_id`, `txn_type`, `quantity_delta`, `txn_at`, `created_at`
- **Optional:** `lot_id`, `job_id`, `unit_cost`, `reference_doc`, `notes`
- **Example rows:**

| transaction_id | material_id | lot_id | job_id | txn_type | quantity_delta | unit_cost |
|---:|---:|---:|---:|---|---:|---:|
| 1301 | 601 | 802 | NULL | PURCHASE_RECEIPT | 3000.000 | 0.0825 |
| 1302 | 601 | 801 | 901 | JOB_CONSUMPTION | -2200.000 | 0.0790 |

### 3.16 `quotes`
- **PK:** `quote_id`
- **FK:** `job_id → jobs.job_id`, `customer_id → customers.customer_id`, `pricing_tier_id → pricing_tiers.tier_id`
- **Required:** `quote_number`, `customer_id`, `pricing_tier_id`, `status`, `issue_date`, `subtotal`, `tax_amount`, `total_amount`, `created_at`
- **Optional:** `job_id`, `expiry_date`, `notes`, `accepted_at`
- **Example row:**

| quote_id | quote_number | customer_id | job_id | pricing_tier_id | status | total_amount |
|---:|---|---:|---:|---:|---|---:|
| 1401 | Q-2026-01401 | 101 | 901 | 2 | ACCEPTED | 1575.00 |

### 3.17 `quote_line_items`
- **PK:** `quote_line_item_id`
- **FK:** `quote_id → quotes.quote_id`, `product_id → products.product_id`
- **Required:** `quote_id`, `line_no`, `description`, `quantity`, `uom`, `unit_price`, `line_total`
- **Optional:** `product_id`, `anchor_unit_price`, `markup_pct`
- **Example row:**

| quote_line_item_id | quote_id | line_no | product_id | description | quantity | anchor_unit_price | markup_pct | unit_price | line_total |
|---:|---:|---:|---:|---|---:|---:|---:|---:|---:|
| 1501 | 1401 | 1 | 301 | 5000 Premium Business Cards | 5000.000 | 0.1800 | 0.1000 | 0.1980 | 990.00 |

### 3.18 `invoices`
- **PK:** `invoice_id`
- **FK:** `job_id → jobs.job_id`, `quote_id → quotes.quote_id`, `customer_id → customers.customer_id`
- **Required:** `invoice_number`, `job_id`, `customer_id`, `status`, `payment_status`, `issue_date`, `subtotal`, `tax_amount`, `total_amount`, `balance_due`, `quickbooks_sync_status`, `created_at`, `updated_at`
- **Optional:** `quote_id`, `due_date`, `quickbooks_invoice_id`, `quickbooks_last_sync_at`
- **Example row:**

| invoice_id | invoice_number | job_id | customer_id | status | payment_status | total_amount | balance_due | quickbooks_sync_status |
|---:|---|---:|---:|---|---|---:|---:|---|
| 1601 | INV-2026-01601 | 901 | 101 | SENT | PARTIAL | 1575.00 | 575.00 | SYNCED |

### 3.19 `invoice_line_items`
- **PK:** `invoice_line_item_id`
- **FK:** `invoice_id → invoices.invoice_id`, `job_material_usage_id → job_material_usage.job_material_usage_id`
- **Required:** `invoice_id`, `line_no`, `description`, `quantity`, `unit_price`, `line_total`
- **Optional:** `job_material_usage_id`
- **Example row:**

| invoice_line_item_id | invoice_id | line_no | description | quantity | unit_price | line_total |
|---:|---:|---:|---|---:|---:|---:|
| 1701 | 1601 | 1 | 5000 Premium Business Cards | 5000.000 | 0.1980 | 990.00 |

### 3.20 `payments`
- **PK:** `payment_id`
- **FK:** `invoice_id → invoices.invoice_id`, `customer_id → customers.customer_id`
- **Required:** `invoice_id`, `customer_id`, `payment_date`, `amount`, `method`, `quickbooks_sync_status`, `created_at`
- **Optional:** `reference_no`, `notes`, `quickbooks_payment_id`
- **Example row:**

| payment_id | invoice_id | customer_id | payment_date | amount | method | quickbooks_sync_status |
|---:|---:|---:|---|---:|---|---|
| 1801 | 1601 | 101 | 2026-02-12 | 1000.00 | Card | SYNCED |

---

## 4) How this schema satisfies the requested MIS scope

1. **Jobs**: `jobs`, `job_machine_usage`, `job_material_usage`, `job_labor_entries` capture customer/product/qty/machine/materials/labor/status.  
2. **Materials/Inventory (FIFO)**: `materials`, `material_lots`, `inventory_transactions`, `vendor_material_prices` support lot-level FIFO + costing + reorder levels.  
3. **Customers**: `customers` includes contact, tier, balance; job history via `jobs` relationship.  
4. **Vendors**: `vendors` + `vendor_material_prices` + `material_lots` provide supplier profile, lead times, and price history.  
5. **Pricing**: `products`, `ndf_anchor_prices`, `pricing_tiers`, `product_tier_pricing_rules` encode NDF anchor + 3-tier markup.  
6. **Machines**: `machines` includes all five required machines and supports costing/time logging.  
7. **Quotes**: `quotes`, `quote_line_items`, optional link to `jobs`.  
8. **Invoices**: `invoices`, `invoice_line_items`, `payments` include payment status and QuickBooks sync status/IDs.
