# INKredible Printing — Debt Paydown Model (24 Months)

## Quick takeaways (scannable)

- **Current LOC interest burn:** $501.67/month ($6,020.00/year) at 14% APR.
- **If you only pay minimum (interest-only):** you pay about **$12,040.08 interest** over 24 months and still owe **$43,000.00**.
- **Aggressive (+$2K/mo principal):** debt is gone in **22 months**, 24-month interest about **$5,646.67** (saves **$6,393.41** vs minimum).
- **Refi to 8% with same payment ($501.67/mo):** 24-month interest about **$6,464.37** (saves **$5,575.71**) and balance drops to **$37,424.29** without increasing monthly cash outflow.

## Assumptions

- LOC starting balance: **$43,000**
- Scenario horizon: **24 months**
- Interest calculated monthly as APR/12, rounded to cents
- No fees/origination costs included for refinance (add those if quote received)
- “Minimum payment” modeled as interest-only on LOC (common for revolving LOCs)

## Scenario Summary (24 months)

| Scenario | Avg Monthly Payment | Total Paid (24 mo) | Interest Paid | Principal Paid | Ending Balance | Interest Saved vs Minimum |
|---|---:|---:|---:|---:|---:|---:|
| Minimum payments (interest-only at 14%) | $501.67 | $12,040.08 | $12,040.08 | $0.00 | $43,000.00 | $0.00 |
| Aggressive paydown (+$2,000 principal/month at 14%) | $2,026.94 | $48,646.67 | $5,646.67 | $43,000.00 | $0.00 | $6,393.41 |
| Refinance to 8% APR, keep payment at $501.67/month | $501.67 | $12,040.08 | $6,464.37 | $5,575.71 | $37,424.29 | $5,575.71 |

## Scenario 1 — Minimum payments (interest-only at 14%)

| Month | Beginning Balance | Payment | Interest | Principal | Ending Balance | Cumulative Interest |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $501.67 |
| 2 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $1,003.34 |
| 3 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $1,505.01 |
| 4 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $2,006.68 |
| 5 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $2,508.35 |
| 6 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $3,010.02 |
| 7 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $3,511.69 |
| 8 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $4,013.36 |
| 9 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $4,515.03 |
| 10 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $5,016.70 |
| 11 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $5,518.37 |
| 12 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $6,020.04 |
| 13 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $6,521.71 |
| 14 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $7,023.38 |
| 15 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $7,525.05 |
| 16 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $8,026.72 |
| 17 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $8,528.39 |
| 18 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $9,030.06 |
| 19 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $9,531.73 |
| 20 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $10,033.40 |
| 21 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $10,535.07 |
| 22 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $11,036.74 |
| 23 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $11,538.41 |
| 24 | $43,000.00 | $501.67 | $501.67 | $0.00 | $43,000.00 | $12,040.08 |

## Scenario 2 — Aggressive paydown (+$2,000 principal/month at 14%)

| Month | Beginning Balance | Payment | Interest | Principal | Ending Balance | Cumulative Interest |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | $43,000.00 | $2,501.67 | $501.67 | $2,000.00 | $41,000.00 | $501.67 |
| 2 | $41,000.00 | $2,478.33 | $478.33 | $2,000.00 | $39,000.00 | $980.00 |
| 3 | $39,000.00 | $2,455.00 | $455.00 | $2,000.00 | $37,000.00 | $1,435.00 |
| 4 | $37,000.00 | $2,431.67 | $431.67 | $2,000.00 | $35,000.00 | $1,866.67 |
| 5 | $35,000.00 | $2,408.33 | $408.33 | $2,000.00 | $33,000.00 | $2,275.00 |
| 6 | $33,000.00 | $2,385.00 | $385.00 | $2,000.00 | $31,000.00 | $2,660.00 |
| 7 | $31,000.00 | $2,361.67 | $361.67 | $2,000.00 | $29,000.00 | $3,021.67 |
| 8 | $29,000.00 | $2,338.33 | $338.33 | $2,000.00 | $27,000.00 | $3,360.00 |
| 9 | $27,000.00 | $2,315.00 | $315.00 | $2,000.00 | $25,000.00 | $3,675.00 |
| 10 | $25,000.00 | $2,291.67 | $291.67 | $2,000.00 | $23,000.00 | $3,966.67 |
| 11 | $23,000.00 | $2,268.33 | $268.33 | $2,000.00 | $21,000.00 | $4,235.00 |
| 12 | $21,000.00 | $2,245.00 | $245.00 | $2,000.00 | $19,000.00 | $4,480.00 |
| 13 | $19,000.00 | $2,221.67 | $221.67 | $2,000.00 | $17,000.00 | $4,701.67 |
| 14 | $17,000.00 | $2,198.33 | $198.33 | $2,000.00 | $15,000.00 | $4,900.00 |
| 15 | $15,000.00 | $2,175.00 | $175.00 | $2,000.00 | $13,000.00 | $5,075.00 |
| 16 | $13,000.00 | $2,151.67 | $151.67 | $2,000.00 | $11,000.00 | $5,226.67 |
| 17 | $11,000.00 | $2,128.33 | $128.33 | $2,000.00 | $9,000.00 | $5,355.00 |
| 18 | $9,000.00 | $2,105.00 | $105.00 | $2,000.00 | $7,000.00 | $5,460.00 |
| 19 | $7,000.00 | $2,081.67 | $81.67 | $2,000.00 | $5,000.00 | $5,541.67 |
| 20 | $5,000.00 | $2,058.33 | $58.33 | $2,000.00 | $3,000.00 | $5,600.00 |
| 21 | $3,000.00 | $2,035.00 | $35.00 | $2,000.00 | $1,000.00 | $5,635.00 |
| 22 | $1,000.00 | $1,011.67 | $11.67 | $1,000.00 | $0.00 | $5,646.67 |
| 23 | $0.00 | $0.00 | $0.00 | $0.00 | $0.00 | $5,646.67 |
| 24 | $0.00 | $0.00 | $0.00 | $0.00 | $0.00 | $5,646.67 |

## Scenario 3 — Refinance to 8% APR, keep payment at $501.67/month

| Month | Beginning Balance | Payment | Interest | Principal | Ending Balance | Cumulative Interest |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | $43,000.00 | $501.67 | $286.67 | $215.00 | $42,785.00 | $286.67 |
| 2 | $42,785.00 | $501.67 | $285.23 | $216.44 | $42,568.56 | $571.90 |
| 3 | $42,568.56 | $501.67 | $283.79 | $217.88 | $42,350.68 | $855.69 |
| 4 | $42,350.68 | $501.67 | $282.34 | $219.33 | $42,131.35 | $1,138.03 |
| 5 | $42,131.35 | $501.67 | $280.88 | $220.79 | $41,910.56 | $1,418.91 |
| 6 | $41,910.56 | $501.67 | $279.40 | $222.27 | $41,688.29 | $1,698.31 |
| 7 | $41,688.29 | $501.67 | $277.92 | $223.75 | $41,464.54 | $1,976.23 |
| 8 | $41,464.54 | $501.67 | $276.43 | $225.24 | $41,239.30 | $2,252.66 |
| 9 | $41,239.30 | $501.67 | $274.93 | $226.74 | $41,012.56 | $2,527.59 |
| 10 | $41,012.56 | $501.67 | $273.42 | $228.25 | $40,784.31 | $2,801.01 |
| 11 | $40,784.31 | $501.67 | $271.90 | $229.77 | $40,554.54 | $3,072.91 |
| 12 | $40,554.54 | $501.67 | $270.36 | $231.31 | $40,323.23 | $3,343.27 |
| 13 | $40,323.23 | $501.67 | $268.82 | $232.85 | $40,090.38 | $3,612.09 |
| 14 | $40,090.38 | $501.67 | $267.27 | $234.40 | $39,855.98 | $3,879.36 |
| 15 | $39,855.98 | $501.67 | $265.71 | $235.96 | $39,620.02 | $4,145.07 |
| 16 | $39,620.02 | $501.67 | $264.13 | $237.54 | $39,382.48 | $4,409.20 |
| 17 | $39,382.48 | $501.67 | $262.55 | $239.12 | $39,143.36 | $4,671.75 |
| 18 | $39,143.36 | $501.67 | $260.96 | $240.71 | $38,902.65 | $4,932.71 |
| 19 | $38,902.65 | $501.67 | $259.35 | $242.32 | $38,660.33 | $5,192.06 |
| 20 | $38,660.33 | $501.67 | $257.74 | $243.93 | $38,416.40 | $5,449.80 |
| 21 | $38,416.40 | $501.67 | $256.11 | $245.56 | $38,170.84 | $5,705.91 |
| 22 | $38,170.84 | $501.67 | $254.47 | $247.20 | $37,923.64 | $5,960.38 |
| 23 | $37,923.64 | $501.67 | $252.82 | $248.85 | $37,674.79 | $6,213.20 |
| 24 | $37,674.79 | $501.67 | $251.17 | $250.50 | $37,424.29 | $6,464.37 |

## Interest Savings Snapshot

- Baseline (minimum): **$12,040.08** interest over 24 months
- Aggressive: **$5,646.67** interest (**$6,393.41 saved**) and LOC fully paid
- Refinance at 8% (same payment): **$6,464.37** interest (**$5,575.71 saved**) with no payment increase

## Recommendation (given tight cash flow)

**Best immediate move: Refinance to lower APR first, then step up principal as cash allows.**

Why this is most realistic now:
- You are roughly break-even, so a hard +$2,000/month commitment may be risky for operations.
- Refinance to ~8% can cut interest materially **without increasing monthly payment**.
- Keeping payment at $501.67 starts principal reduction automatically at 8% APR.
- If monthly cash improves, add even **$500–$1,000 extra principal** to accelerate payoff.

Suggested sequence:
1. **Refi LOC / consolidate to lower APR** (target <=8–10%, low fees, no prepayment penalty).
2. **Autopay at least $501.67** monthly (or higher).
3. Add a variable “sweep” payment from positive weeks (e.g., 10–20% of weekly surplus).
4. Freeze new high-APR revolving debt while paydown is active.

## Credit Card Debt Consolidation Options

### 1) Estimate current CC interest burden (from available data)

- Total annual bank finance charges reported: **$18,600.00**
- Estimated LOC interest component: **$6,020.00**
- Estimated CC interest component: **$12,580.00** per year

| Assumed Avg CC APR | Implied Avg CC Balance |
|---:|---:|
| 20% | $62,900.00 |
| 24% | $52,416.67 |
| 28% | $44,928.57 |
| 30% | $41,933.33 |

> This implies CC balances may be roughly **$42K–$63K** depending on actual card APRs.

### 2) Consolidation paths (pros/cons)

| Option | Typical Rate | Pros | Risks / Watch-outs |
|---|---|---|---|
| Business term loan / LOC refi | ~8–14% (credit-dependent) | Predictable payment, lower APR than cards, possible single payment | Fees, collateral/personal guarantee, underwriting time |
| SBA micro/7(a) working-capital refinance | Often below unsecured card APRs | Longer terms can lower monthly payment | Slower approval, paperwork, sometimes collateral/PG |
| 0% intro balance transfer (business/personal cards) | 0% for promo period, then high APR | Fast interest relief | Transfer fees (3–5%), cliff when promo ends, utilization impact |
| Nonprofit Debt Management Plan (DMP) for personal cards (if applicable) | Reduced negotiated APR | Can lower rates/payments without new loan | May require account closure, setup/admin fees |
| Merchant cash advance / daily-debit products | Very high effective APR | Fast funding | Usually expensive; avoid unless true emergency |

### 3) Practical consolidation checklist

- Pull exact balances/APRs/minimums for each card (build a debt ladder).
- Compare **all-in cost**: APR + origination + transfer fees + prepay penalties.
- Prioritize cards >22% APR for immediate consolidation/paydown.
- Keep utilization from re-expanding after consolidation (freeze unused cards if needed).

## Next data to tighten this model

If you provide exact card balances + APRs + minimums, I can add:
- A full **LOC + all cards** combined payoff waterfall
- Exact debt-free date under each strategy
- Weekly cash-safe payment targets based on seasonality
