# VistaPrint Capture Notes — 2026-02-14

Purpose: document how missing VistaPrint prices were filled for the weekly competitor snapshot.

## What was done
- Source snapshot used: `research/price-watch/snapshots/2026-02-14-auto.csv`
- Filled missing VistaPrint prices and saved:
  - `research/price-watch/snapshots/2026-02-14-complete.csv`
- Generated report:
  - `reports/price-watch-2026-02-14-complete.md`

## Capture method
- Used browser capture on live product pages (not web_fetch), because VistaPrint pricing is JS-rendered.
- Filled each row with page-level default/starting offer visible at capture time.
- `source` set to: `manual:browser-vp-default-offer-2026-02-14`

## Captured VistaPrint prices used
- Business Cards: **$10.00** (page text showed "From $10.00")
- Flyers: **$8.09** (current sale price shown in default selection)
- Brochures: **$36.89** (Tri-Fold card showed current sale price)
- Postcards: **$21.99** (Standard postcards showed "From $21.99")
- Banners: **$5.95** (Vinyl Banners current sale price)
- Floor Decals: **$17.39** (default 1-unit selection)

## Important caveat
- VistaPrint values are **default offer snapshots**, and may not correspond exactly to the `spec/quantity` fields in the watchlist rows.
- This is acceptable for baseline trend monitoring, but for strict apples-to-apples comparison we should add product-option automation (exact qty/spec) in next iteration.

## Next improvement
- Extend `scripts/price-watch-capture.js` with Playwright/browser-option selection for VistaPrint exact quantities/specs so weekly diffs are strict and reproducible.
