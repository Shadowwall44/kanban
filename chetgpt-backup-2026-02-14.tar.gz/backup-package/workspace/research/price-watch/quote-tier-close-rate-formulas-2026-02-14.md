# Quote Tier Close-Rate Formulas (Google Sheets)

Use this with:
`research/price-watch/quote-tier-close-rate-tracker-2026-02-14.csv`

## Recommended calculated columns

### A) Discount Depth %
```gs
=IFERROR((Q2-S2)/Q2,0)
```
- Q = `first_quote_amount`
- S = `final_price`

### B) Win Flag
```gs
=IF(U2="Won",1,0)
```
- U = `outcome`

### C) Close Rate by Starting Tier (pivot)
- Rows: `first_quote_tier`
- Values: AVG of `win_flag`

### D) Revenue by Starting Tier (pivot)
- Rows: `first_quote_tier`
- Values: SUM of `revenue_closed`

## Weekly decision rule
- If `Opening` close rate is >10 percentage points lower than `Target` for a product,
  change default start tier for that product to `Target` next week.
- If `Target` close rate holds and margin remains healthy, keep `Opening` only for rush/unclear specs.
