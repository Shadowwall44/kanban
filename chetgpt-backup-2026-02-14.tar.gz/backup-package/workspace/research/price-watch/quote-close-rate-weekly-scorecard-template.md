# Weekly Quote Scorecard Template

## Week of: ____

### Volume
- Total quotes sent: 
- Total won: 
- Total lost: 
- Close rate: 

### By Start Tier
| Start Tier | Quotes | Wins | Close Rate | Avg Discount % | % Ended at Floor |
|---|---:|---:|---:|---:|---:|
| Opening |  |  |  |  |  |
| Target |  |  |  |  |  |
| Floor |  |  |  |  |  |

### By Product (Top 5)
| Product | Quotes | Wins | Close Rate | Avg Ticket | Most Common Objection |
|---|---:|---:|---:|---:|---|
|  |  |  |  |  |  |

### Objections Seen
1. 
2. 
3. 

### Actions for Next Week (max 3)
1. 
2. 
3. 
