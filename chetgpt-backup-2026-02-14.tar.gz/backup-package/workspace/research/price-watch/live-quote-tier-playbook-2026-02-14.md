# Live Quote Tier Playbook — v1 (2026-02-14)

Purpose: turn competitor price watch into a **sales execution system** that improves close rate while protecting margin.

Built from:
- `reports/ndf-pricing-playbook-2026-02-14.md`
- `research/price-watch/ndf-standard-min-price-anchors-2026-02-14.csv`
- `research/price-watch/ndf-vs-vistaprint-matchups-2026-02-14.csv`

---

## 1) Quote Ladder Rules (non-negotiable)

For every quote, pre-calc all 3 numbers before sending:

1. **Opening** = NDF + 25%
2. **Target** = NDF + 10%
3. **Floor** = NDF base

Default movement:
- First send: Opening (or Target for larger-ticket jobs)
- If negotiated once: Target
- If final push and strategic account: Floor

Never go below floor without explicit strategic reason logged in tracker.

---

## 2) Fast Tier Selection by Ticket Type

### Commodity jobs (business cards, flyers, basic postcards)
- Start at **Opening**
- Expected path: Opening → Target
- Goal: avoid dropping to Floor unless volume/repeat account

### Mid-ticket jobs ($60-$180 floor)
- Start at **Target**
- Hold at Target if timeline or service requirements are strict

### High-ticket jobs (>$180 floor)
- Start at **Target**
- Use urgency/service framing early
- Floor only for strategic accounts or bundled deals

---

## 3) Objection Scripts (short + practical)

### "VistaPrint is cheaper"
"Totally fair — if lowest online price is the only goal, they can win that. If you need it done right, on time, and with local support if anything changes last minute, we’ll save you headaches."

### "Can you do better on price?"
"Yes — I can sharpen it if we lock one of these: higher quantity, flexible turnaround, or repeat schedule. Which one works for you?"

### "I need this by tomorrow"
"We can rush it. Rush pricing is higher because it bumps production priority, but I can give you the fastest option that still protects quality."

### "I got another quote"
"Send it over and I’ll do a line-by-line match on specs, turnaround, and finish so we compare apples to apples."

---

## 4) Upsell via Quantity Checkpoints

Use these before discounting:
- Business Cards: 100 → 250 is major per-unit drop
- Flyers: 500 → 1000 is major per-unit drop
- Postcards: 25 → 50 and 500 → 1000 are strong checkpoints
- Posters: 250 → 500 is strong checkpoint

Script:
"Before I discount, let me show you where quantity drops your per-piece cost more than a discount would."

---

## 5) What to log on every quote (for close-rate optimization)

Track in `templates/quote-close-rate-tracker.csv`:
- Product + qty + turnaround
- Opening/Target/Floor values
- First tier offered
- Final tier sold (or lost)
- Win/loss reason code
- Whether competitor was mentioned (NDF, Vista, local shop)

This is the data needed to answer:
- Where are we discounting too early?
- Which products should start at Target (not Opening)?
- Which objections kill deals most often?

---

## 6) Weekly 20-minute review cadence

Every week, review:
1. Close rate by **first tier sent** (Opening vs Target)
2. Close rate by **final tier**
3. Average drop from Opening to final sold
4. Top 3 loss reasons
5. One pricing rule change for next week

Goal: convert price watch from "interesting report" into a **margin + win-rate control loop**.
