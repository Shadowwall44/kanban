#!/usr/bin/env python3
"""
NDF Comprehensive Price Scraper - Final Version
Uses the NDF calculator API with known product configurations.
"""
import json
import subprocess
import csv
from datetime import datetime

API_URL = "https://calculator.nextdayflyers.com/v1/computePrice"
AUTH = "calculator.site:KEfm75#XjwSMux92zUWD9T8AafG!vwV6"
DATE = "2026-02-14"

def api_call(payload):
    cmd = ["curl", "-s", API_URL, "-u", AUTH, "-H", "Content-Type: application/json",
           "-d", json.dumps(payload)]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
    try:
        return json.loads(result.stdout)
    except:
        return None

# Product configurations extracted from browser Angular scope
PRODUCTS = {
    "Standard Postcards": {
        "family": "postcards",
        "spec": "14pt Gloss UV (Both Sides)",
        "url": "https://www.nextdayflyers.com/postcard-printing/standard-postcards.php",
        "base_payload": {
            "attr3": "22396", "attr5": "22413", "attr333": "22519",
            "attr336": "22402", "attr337": "22403", "attr338": "22406",
            "attr339": "22408", "attr340": "22412", "attr356": "27443",
            "mailing_service": "on", "product_id": "459",
            "addon_attributes": ["333"], "addon_attributes_limit": [],
            "get_shipping_base_price": True
        },
        "default_attr5": 22413,  # qty=100
        "target_qtys": [100, 500, 1000]
    },
    "Standard Business Cards": {
        "family": "business_cards",
        "spec": "14pt Gloss",
        "url": "https://www.nextdayflyers.com/business-card-printing/standard-business-cards.php",
        "base_payload": {
            "attr3": "22652", "attr5": "22665", "attr332": "32377",
            "attr333": "22770", "attr336": "22655", "attr337": "22656",
            "attr338": "22659", "attr339": "22660", "attr340": "22664",
            "attr356": "27446", "product_id": "461",
            "addon_attributes": ["333"], "addon_attributes_limit": [],
            "get_shipping_base_price": True
        },
        "default_attr5": 22665,  # qty=100
        "target_qtys": [100, 500, 1000]
    },
    "Business Flyers": {
        "family": "flyers",
        "spec": "100lb Gloss Text",
        "url": "https://www.nextdayflyers.com/flyer-printing/business-flyers.php",
        "base_payload": {
            "attr3": "24092", "attr5": "116338", "attr331": "24104",
            "attr333": "24217", "attr336": "24094", "attr337": "24095",
            "attr338": "24099", "attr340": "24110", "mailing_service": "on",
            "product_id": "475",
            "addon_attributes": ["333"], "addon_attributes_limit": [],
            "get_shipping_base_price": True
        },
        "default_attr5": 116338,  # qty=25
        "target_qtys": [100, 500, 1000]
    },
    "Brochures": {
        "family": "brochures",
        "spec": "100lb Gloss Text Tri-Fold",
        "url": "https://www.nextdayflyers.com/brochure-printing/",
        "base_payload": {
            "attr3": "22522", "attr5": "22536", "attr331": "22532",
            "attr333": "22642", "attr336": "22526", "attr337": "22527",
            "attr338": "22528", "attr340": "22535", "attr341": "22646",
            "attr364": "27836", "mailing_service": "on", "product_id": "460",
            "addon_attributes": ["333"], "addon_attributes_limit": [],
            "get_shipping_base_price": True
        },
        "default_attr5": 22536,  # qty=100
        "target_qtys": [100, 500, 1000]
    },
    "Vinyl Banners": {
        "family": "banners",
        "spec": "13oz Vinyl 2x4",
        "url": "https://www.nextdayflyers.com/banner-printing/vinyl-banners.php",
        "base_payload": {
            "attr3": "25166", "attr5": "25175", "attr333": "25196",
            "attr336": "25172", "attr337": "25173", "attr338": "25174",
            "attr348": "35581", "product_id": "484",
            "addon_attributes": ["333"], "addon_attributes_limit": [],
            "get_shipping_base_price": True
        },
        "default_attr5": 25175,  # qty=1
        "target_qtys": [1, 5, 10]
    },
    "Floor Graphics": {
        "family": "floor_graphics",
        "spec": "12in Circle Vinyl Indoor",
        "url": "https://www.nextdayflyers.com/floor-graphics.html",
        "base_payload": {
            "attr3": "867166", "attr5": "867177", "attr10": "1086985",
            "attr309": "867173", "attr333": "1019453", "attr336": "867175",
            "attr337": "867176", "attr338": "867171", "attr1381": "1018985",
            "product_id": "25328",
            "addon_attributes": ["333"], "addon_attributes_limit": [],
            "get_shipping_base_price": True
        },
        "default_attr5": 867177,  # qty=1
        "target_qtys": [1, 5, 10, 25, 50]
    }
}

all_results = []

for product_name, config in PRODUCTS.items():
    print(f"\n{'='*60}")
    print(f"  {product_name} ({config['spec']})")
    print(f"{'='*60}")
    
    payload = config["base_payload"].copy()
    default_id = config["default_attr5"]
    target_qtys = set(config["target_qtys"])
    
    # Discover quantity attr5 IDs by scanning a range around the default
    qty_map = {}
    # Some products need wider scan ranges (flyers jump from 200->250->500)
    scan_range = 50 if product_name == "Business Flyers" else 30
    
    for offset in range(-5, scan_range):
        test_id = default_id + offset
        p = payload.copy()
        p["attr5"] = str(test_id)
        data = api_call(p)
        if data and "qty" in data and data["qty"] > 0:
            qty = data["qty"]
            qty_map[qty] = test_id
            if qty in target_qtys:
                # Get all turnaround prices
                addons = data.get("addon_attrs", {}).get("333", {})
                for ta_id, ta_data in addons.items():
                    price = ta_data.get("price")
                    unit_price = ta_data.get("unit_price")
                    if price is None:
                        continue
                    row = {
                        "date": DATE,
                        "competitor": "NextDayFlyers",
                        "product_family": config["family"],
                        "product": product_name,
                        "spec": config["spec"],
                        "url": config["url"],
                        "quantity": qty,
                        "turnaround": ta_data["attr_value"],
                        "price_usd": float(price),
                        "unit_price_usd": float(unit_price) if unit_price else 0
                    }
                    all_results.append(row)
                    print(f"  Qty {qty:>6}, {ta_data['attr_value']:>30}: ${price:>8}")
    
    found_qtys = sorted(qty_map.keys())
    missing = target_qtys - set(found_qtys)
    if missing:
        print(f"  WARNING: Missing quantities: {sorted(missing)}")
    print(f"  Available quantities: {found_qtys[:20]}...")

# Write CSV
output_path = "/home/inkredible/.openclaw/workspace/research/price-watch/nextdayflyers_pricing.csv"
fieldnames = ["date", "competitor", "product_family", "product", "spec", "url",
              "quantity", "turnaround", "price_usd", "unit_price_usd"]
with open(output_path, 'w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(sorted(all_results, key=lambda r: (r["product_family"], r["quantity"], r["turnaround"])))

print(f"\n{'='*60}")
print(f"  COMPLETE: Wrote {len(all_results)} price points to")
print(f"  {output_path}")
print(f"{'='*60}")

# Print 3BD summary for guardrails comparison
print(f"\n  3 BUSINESS DAYS PRICE SUMMARY (for guardrails comparison):")
print(f"  {'Product':<25} {'Qty':>6} {'3BD Price':>10} {'Guardrail':>10} {'Delta':>8}")
print(f"  {'-'*25} {'-'*6} {'-'*10} {'-'*10} {'-'*8}")

guardrails = {
    ("banners", 1): 16.95,
    ("brochures", 500): 237.11,
    ("business_cards", 500): 49.95,
    ("business_cards", 1000): 49.95,
    ("flyers", 500): 39.60,
    ("flyers", 1000): 39.60,
    ("postcards", 100): 73.95,
    ("postcards", 500): 73.95,
}

for r in all_results:
    if "3 Business Days" in r["turnaround"] or "6 Business Days" in r["turnaround"]:
        gkey = (r["product_family"], r["quantity"])
        guard = guardrails.get(gkey, "")
        delta = ""
        if guard:
            delta = f"{((r['price_usd'] - guard) / guard * 100):+.1f}%"
        print(f"  {r['product']:<25} {r['quantity']:>6} ${r['price_usd']:>8.2f}  ${str(guard):>8}  {delta:>8}")
