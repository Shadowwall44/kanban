#!/usr/bin/env python3
"""
Validate scraped NDF pricing against existing guardrails CSV.
"""
import csv

# Load guardrails
guardrails = {}
with open("/home/inkredible/.openclaw/workspace/research/price-watch/quote-guardrails-2026-02-14.csv") as f:
    reader = csv.DictReader(f)
    for row in reader:
        key = (row["product_family"], row["ndf_product"], int(row["quantity"]), row["turnaround"])
        guardrails[key] = row

# Load new pricing
new_prices = {}
with open("/home/inkredible/.openclaw/workspace/research/price-watch/nextdayflyers_pricing.csv") as f:
    reader = csv.DictReader(f)
    for row in reader:
        key = (row["product_family"], row["product"], int(row["quantity"]), row["turnaround"])
        new_prices[key] = row

print("=" * 80)
print("  NDF PRICING VALIDATION REPORT — 2026-02-14")
print("=" * 80)

# Compare guardrail entries with new data
print("\n1. GUARDRAILS vs SCRAPED PRICES")
print(f"   {'Product':<25} {'Qty':>5} {'Turnaround':<20} {'Guardrail':>10} {'Scraped':>10} {'Delta':>8}")
print(f"   {'-'*25} {'-'*5} {'-'*20} {'-'*10} {'-'*10} {'-'*8}")

issues = []
for gkey, grow in guardrails.items():
    family, product, qty, turnaround = gkey
    old_price = float(grow["ndf_price_usd"]) if grow["ndf_price_usd"] else None
    
    # Map guardrail turnaround to NDF turnaround naming
    turnaround_map = {
        "3 Business Days": "3 Business Days",
        "Standard": "3 Business Days",  # Banner "Standard" likely maps to 3BD
    }
    ndf_turnaround = turnaround_map.get(turnaround, turnaround)
    
    # Try to find matching new price
    nkey = (family, product, qty, ndf_turnaround)
    new_row = new_prices.get(nkey)
    
    if new_row:
        new_price = float(new_row["price_usd"])
        if old_price:
            delta_pct = ((new_price - old_price) / old_price) * 100
            flag = "⚠️" if abs(delta_pct) > 10 else "✅"
            print(f"   {product:<25} {qty:>5} {ndf_turnaround:<20} ${old_price:>8.2f}  ${new_price:>8.2f}  {delta_pct:>+7.1f}% {flag}")
            if abs(delta_pct) > 10:
                issues.append(f"{product} qty {qty} {ndf_turnaround}: guardrail=${old_price:.2f}, actual=${new_price:.2f} ({delta_pct:+.1f}%)")
        else:
            print(f"   {product:<25} {qty:>5} {ndf_turnaround:<20} {'N/A':>10}  ${new_price:>8.2f}  {'NEW':>8}")
    else:
        # Check if the guardrail price matches a different turnaround
        found = False
        for ta in ["3 Business Days", "Next Business Day", "Ready Today (in by 10am)"]:
            nk = (family, product, qty, ta)
            nr = new_prices.get(nk)
            if nr and old_price and abs(float(nr["price_usd"]) - old_price) < 0.01:
                print(f"   {product:<25} {qty:>5} {turnaround:<20} ${old_price:>8.2f}  MATCH→{ta}")
                issues.append(f"{product} qty {qty}: guardrail turnaround '{turnaround}' actually matches '{ta}' price")
                found = True
                break
        if not found:
            print(f"   {product:<25} {qty:>5} {turnaround:<20} ${old_price:>8.2f}  {'NO MATCH':>10}")

# CRITICAL FINDING: Check if guardrails used NBD prices labeled as 3BD
print("\n2. CRITICAL FINDING — TURNAROUND MISMATCH ANALYSIS")
print("   The original guardrails appear to have captured 'Next Business Day' prices")
print("   but labeled them as '3 Business Days'. Evidence:")
print()
mismatches = [
    ("postcards", "Standard Postcards", 100, "3 Business Days", 73.95, 30.95, 73.95),
    ("postcards", "Standard Postcards", 500, "3 Business Days", 73.95, 68.95, 109.95),
    ("business_cards", "Standard Business Cards", 500, "3 Business Days", 49.95, 33.95, 79.95),
    ("business_cards", "Standard Business Cards", 1000, "3 Business Days", 49.95, 46.00, 119.00),
    ("flyers", "Business Flyers", 500, "3 Business Days", 39.60, 179.50, 242.30),
    ("flyers", "Business Flyers", 1000, "3 Business Days", 39.60, 224.00, 302.40),
    ("brochures", "Brochures", 500, "3 Business Days", 237.11, 220.70, 389.15),
]

print(f"   {'Product':<25} {'Qty':>5} {'Guardrail':>10} {'Actual 3BD':>10} {'Actual NBD':>10} {'GuardMatch':>12}")
print(f"   {'-'*25} {'-'*5} {'-'*10} {'-'*10} {'-'*10} {'-'*12}")
for family, product, qty, ta, guard_price, bd3_price, nbd_price in mismatches:
    if abs(guard_price - nbd_price) < 0.10:
        match = "NBD ✅"
    elif abs(guard_price - bd3_price) < 0.10:
        match = "3BD ✅"
    else:
        # Check if guard matches a different qty's NBD
        match = "MISMATCH ⚠️"
    print(f"   {product:<25} {qty:>5} ${guard_price:>8.2f}  ${bd3_price:>8.2f}  ${nbd_price:>8.2f}  {match}")

# FINDINGS DETAIL
print("\n   EXPLANATION:")
print("   • Postcards qty 100: Guardrail $73.95 = NBD price (not 3BD $30.95)")
print("   • Business Cards qty 500: Guardrail $49.95 = NBD price for QTY 100 (not 500)")
print("   • Business Cards qty 1000: Same $49.95 value = NBD price for QTY 100")
print("   • Flyers qty 500/1000: Guardrail $39.60 = NBD price for QTY 25")
print("   • Brochures qty 500: Guardrail $237.11 = NBD price for QTY 100 (not 500)")
print("   → Previous scrape likely captured default calculator state (qty 100, NBD selected)")

# Print new complete pricing table
print("\n3. COMPLETE NDF PRICING TABLE (3 Business Days)")
print(f"   {'Product':<25} {'Spec':<30} {'Qty':>6} {'3BD':>8} {'NBD':>8} {'Today':>8}")
print(f"   {'-'*25} {'-'*30} {'-'*6} {'-'*8} {'-'*8} {'-'*8}")

# Group by product
products = {}
with open("/home/inkredible/.openclaw/workspace/research/price-watch/nextdayflyers_pricing.csv") as f:
    reader = csv.DictReader(f)
    for row in reader:
        pkey = (row["product"], row["quantity"])
        if pkey not in products:
            products[pkey] = {"spec": row["spec"]}
        ta = row["turnaround"]
        if "3 Business" in ta:
            products[pkey]["3BD"] = row["price_usd"]
        elif "Next" in ta:
            products[pkey]["NBD"] = row["price_usd"]
        elif "Today" in ta:
            products[pkey]["Today"] = row["price_usd"]
        elif "6 Business" in ta:
            products[pkey]["3BD"] = row["price_usd"]  # Floor graphics only has 6BD

for (product, qty), data in sorted(products.items()):
    bd3 = data.get("3BD", "—")
    nbd = data.get("NBD", "—")
    today = data.get("Today", "—")
    print(f"   {product:<25} {data['spec']:<30} {qty:>6} ${bd3:>7} ${nbd:>7} ${today:>7}")

# Recommend updated guardrails
print("\n4. RECOMMENDED GUARDRAIL CORRECTIONS")
print("   Use 3 Business Days as the consistent turnaround baseline:")
corrections = [
    ("postcards", "Standard Postcards", "14pt Gloss UV (Both Sides)", 100, "3 Business Days", 30.95),
    ("postcards", "Standard Postcards", "14pt Gloss UV (Both Sides)", 500, "3 Business Days", 68.95),
    ("business_cards", "Standard Business Cards", "14pt Gloss", 500, "3 Business Days", 33.95),
    ("business_cards", "Standard Business Cards", "14pt Gloss", 1000, "3 Business Days", 46.00),
    ("flyers", "Business Flyers", "100lb Gloss Text", 500, "3 Business Days", 179.50),
    ("flyers", "Business Flyers", "100lb Gloss Text", 1000, "3 Business Days", 224.00),
    ("brochures", "Brochures", "100lb Gloss Text Tri-Fold", 500, "3 Business Days", 220.70),
    ("banners", "Vinyl Banners", "13oz Vinyl 2x4", 1, "3 Business Days", 24.43),
    ("floor_graphics", "Floor Graphics", "12in Circle Vinyl Indoor", 1, "6 Business Days", 12.95),
    ("floor_graphics", "Floor Graphics", "12in Circle Vinyl Indoor", 10, "6 Business Days", 109.95),
    ("floor_graphics", "Floor Graphics", "12in Circle Vinyl Indoor", 25, "6 Business Days", 245.95),
]

print(f"\n   product_family,ndf_product,spec,quantity,turnaround,ndf_price_usd,ink_target_plus_10,ink_opening_plus_25")
for family, product, spec, qty, ta, price in corrections:
    target = round(price * 1.10, 2)
    opening = round(price * 1.25, 2)
    print(f"   {family},{product},{spec},{qty},{ta},{price},{target},{opening}")

print("\n" + "=" * 80)
print("  VALIDATION COMPLETE")
print("=" * 80)
