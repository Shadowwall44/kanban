# Brooklyn Floor Graphics Competitor Intel — 2026-02-14

## Why this matters
Floor graphics are INKredible's highest-value line item. This brief turns current competitor signals into quote guardrails and positioning moves that protect margin.

## Pricing guardrails generated
- Source snapshot: `research/price-watch/snapshots/2026-02-14-complete.csv`
- Output CSV: `research/price-watch/quote-guardrails-2026-02-14.csv` (8 rows)
- Comparable NDF vs Vista lines: **5** | avg NDF premium: **350.6%**
- Largest NDF premium observed: **brochures qty 500** at **542.7%**

## Competitor capability map (NYC/Brooklyn)
- **Gorilla Printing NYC**: Claims same-day large format with "3 hour turnarounds" and Brooklyn pickup; promotes waterproof/UV-resistant laminated vinyl and heavy-traffic durability.
- **Signs NYC**: Positions as end-to-end dance floor wrap vendor (design + install + removal), with urgency text support and event guest-count sizing guidance.
- **Same Day Rush Printing**: Aggressive speed positioning (24/7, same-day/overnight framing) across many SKUs; strong urgency messaging.
- **NY Printing Solutions**: Focuses on removable no-residue decals, indoor/outdoor usage, and heavy-duty aluminum option for concrete/outdoor surfaces.
- **Printing New York**: Educational long-form content around materials/laminates and maintenance, signaling technical competence for facility buyers.

## 5 execution moves for next sales cycle
1. Package floor graphics as a premium event service: **print + install + removal + post-event cleanup**. Competitors are selling the full service, not just print.
2. Create two offer lanes: **Rush (same day/next day)** and **Premium Finish (anti-slip laminate + white ink option)** to avoid pure price comparison.
3. For postcard/business card/flyer anchors, start at **Opening (+25%)** and pre-authorize drop to **Target (+10%)** in one negotiation step.
4. Only match NDF floor pricing for strategic accounts (recurring event/rental clients) and set a minimum order or bundled upsell requirement.
5. Add a visible "Brooklyn rapid install window" promise with concrete SLA language (e.g., mockup in 2h, install slot within 24h).

## Notes on data confidence
- Current watch snapshot contains a small baseline set (14 rows). Treat this as directional until the expanded NDF API scrape is fully stabilized.
- Current environment returned empty responses from the NDF calculator API endpoint during this cycle; page-level capture remains usable for guardrails while API path is debugged.

## Immediate usage by team
- Aviel/Brandon can use the CSV during quoting: start at `ink_opening_plus_25`, drop to `ink_target_plus_10` once, and reserve `ink_floor_match_ndf` for strategic deals only.