# Competitor Price Watch v1

Created: 2026-02-14
Purpose: Track weekly price movement across core print SKUs (NDF + VistaPrint) and flag margin-risk changes fast.

## Why this is high-impact
- Protects INKredible's three-tier pricing model (NDF anchor + markup).
- Catches undercut risk early before quotes go out.
- Builds historical pricing data for negotiation and sales scripts.

## Core SKU Watchlist (v1)

### NextDayFlyers (anchor baseline)
- Postcards: https://www.nextdayflyers.com/postcard-printing/standard-postcards.php
- Standard Business Cards: https://www.nextdayflyers.com/business-card-printing/standard-business-cards.php
- Business Flyers: https://www.nextdayflyers.com/flyer-printing/business-flyers.php
- Brochures: https://www.nextdayflyers.com/brochure-printing/
- Banners: https://www.nextdayflyers.com/banner-printing/

### VistaPrint (market pressure comparator)
- Business Cards: https://www.vistaprint.com/business-cards
- Flyers: https://www.vistaprint.com/marketing-materials/flyers
- Brochures: https://www.vistaprint.com/marketing-materials/brochures
- Postcards: https://www.vistaprint.com/marketing-materials/postcards
- Banners: https://www.vistaprint.com/signs-posters/banners
- Floor Decals: https://www.vistaprint.com/signs-posters/floor-decals

## File Structure
- `research/price-watch/watchlist.csv` → what to check every week
- `research/price-watch/snapshots/` → raw weekly captures (CSV)
- `scripts/price-watch-diff.js` → compares 2 snapshots and writes markdown report
- `reports/price-watch-YYYY-MM-DD.md` → generated weekly summary

## Snapshot Format
Use this exact header (see `snapshot-template.csv`):

`date,currency,competitor,product,url,spec,quantity,turnaround,price,source`

Example row:
`2026-02-14,USD,NextDayFlyers,Standard Business Cards,https://www.nextdayflyers.com/business-card-printing/standard-business-cards.php,14pt Gloss,500,3 Business Days,49.95,auto:ndf-page-default`

## Weekly Workflow (semi-automated capture + automated diff)
1. Run auto-capture for NextDayFlyers rows:
   `node scripts/price-watch-capture.js`
   - Writes: `research/price-watch/snapshots/YYYY-MM-DD-auto.csv`
   - Fills NDF rows automatically (`source=auto:ndf-page-default`)
   - Leaves VistaPrint rows blank for browser capture (`source=pending:browser-capture`)
2. (Optional) Add VistaPrint prices manually into the generated `-auto.csv` file.
3. Run diff:
   `node scripts/price-watch-diff.js --old research/price-watch/snapshots/<last.csv> --new research/price-watch/snapshots/YYYY-MM-DD-auto.csv --out reports/price-watch-YYYY-MM-DD-auto.md`
4. Read generated report in `reports/` and apply pricing guardrails.

## Guardrail Rules
- If NDF drops >5% on a core SKU → review opening/target tiers same day.
- If VistaPrint undercuts NDF by >8% on overlapping SKU → update quote objection scripts.
- If any SKU shifts >10% week-over-week → mark as volatile and price manually until stable.
