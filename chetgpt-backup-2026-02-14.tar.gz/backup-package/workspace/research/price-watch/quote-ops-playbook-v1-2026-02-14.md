# Quote Ops Playbook v1 — Price-Watch to Live Sales

**Date:** 2026-02-14  
**Purpose:** Turn NDF + Vista price-watch data into a repeatable quoting system that protects margin and improves close rate.

---

## 1) Start Tier Rules (fast decision)

Use `research/price-watch/ndf-standard-min-price-anchors-2026-02-14.csv` as the floor/target/opening source.

### Rule set
- **Opening (+25%)** if floor ticket is **<$60** (commodity jobs, expected negotiation)
- **Target (+10%)** if floor ticket is **$60–$180**
- **Target (+10%)** if floor ticket is **>$180**, and protect margin hard
- Only go to **Floor** when at least one is true:
  - customer is strategic repeat buyer
  - order size is large enough to recover margin later
  - production slot would otherwise be idle

---

## 2) 4-Step Negotiation Ladder (copy-ready)

### Step 1 — Anchor value + quote
> "For **[product/qty/turnaround]**, your total is **$[opening_or_target]**. That includes production quality check, local turnaround reliability, and real human support if anything shifts."

### Step 2 — Controlled concession (Opening → Target)
> "I can work with you a little and bring it to **$[target]** while keeping the same specs and timeline."

### Step 3 — Quantity reframe (keep margin, improve unit economics)
> "If you can move from **[qty A]** to **[qty B]**, your per-piece drops and your total value improves."

### Step 4 — Floor protection close
> "My best possible on this exact spec is **$[floor]**. Below that I’d be cutting quality or reliability, and I won’t do that to your job."

---

## 3) Objection Handling by Competitor Mention

### "VistaPrint is cheaper"
> "You’re right on raw commodity price. Where we win is speed, color consistency, and zero runaround if anything needs a fix. If this is event-critical, reliability is usually worth more than the dollar gap."

### "NextDayFlyers gave me lower"
> "Totally fair. Our pricing is anchored to the same market. Let me match the best tier I can for your exact spec and timeline so you can compare apples-to-apples."

### "Can you do better?"
> "Yes — I can improve either price at current spec, or value by increasing quantity for a better unit rate. Which matters more for this order, total spend or per-piece cost?"

---

## 4) Rush Pricing Script

Use known median multipliers from `reports/ndf-pricing-playbook-2026-02-14.md`.

- Brochures next-day ≈ **1.88x**
- Business cards next-day ≈ **1.95x**, same-day ≈ **5.38x**
- Flyers next-day ≈ **1.69x**, same-day ≈ **2.32x**
- Postcards next-day ≈ **1.79x**, same-day ≈ **2.27x**

Script:
> "Standard is **$[base]**. For **[rush level]**, market pricing runs about **[multiplier]x**, so your rush total is **$[rush_price]**."

---

## 5) Daily Execution SOP (10 minutes)

1. Log every quote in `research/price-watch/quote-close-rate-log-template.csv`.
2. Mark start tier (opening/target/floor) and final tier.
3. Record win/loss reason in plain English.
4. At day end, total:
   - close rate by start tier
   - average discount from first quote to close
   - top 3 loss reasons

---

## 6) Weekly Optimization Questions

- Which products close best from **Opening** without dropping to floor?
- Where are we discounting too early?
- Which competitor objection appears most?
- Which quantity upsell script creates the biggest margin lift?

If 2+ weeks show low close rate at a given tier for the same product class, revise opening script (not floor) first.

---

## 7) Success Metrics (first 25 quotes)

- **Target close rate:** 35%+ overall
- **Target floor usage:** <30% of closed deals
- **Target average discount from first quote:** ≤12%
- **Target tracked quote compliance:** 100% (every quote logged)

When 25 quotes are logged, produce a product-by-product pricing adjustment recommendation.
