# Competitor Price Watch v1 (NDF + VistaPrint)

**Date:** 2026-02-14 (Shabbat overnight autonomous run)
**Status:** Built (research + monitoring framework)
**Idea Queue Link:** #11 Competitor Price Watch (`queued` → now has v1 execution doc)

## Why this is the highest-impact unblocked task
INKredible’s pricing model anchors to NextDayFlyers (NDF) and negotiation pressure in Brooklyn is constant. A tight weekly competitor watch protects margin and helps us defend quotes faster.

## Scope (Phase 1)
Track high-frequency / high-visibility SKUs where price perception drives close rate:

1. Standard Business Cards
2. Vinyl Banners
3. Step & Repeat Banners
4. Floor Graphics / Decals
5. Postcards (4x6, 5x7, 6x9)

## Canonical product URLs to monitor

### NextDayFlyers (NDF)
- Standard business cards: https://www.nextdayflyers.com/business-card-printing/standard-business-cards.php
- Vinyl banners: https://www.nextdayflyers.com/banner-printing/vinyl-banners.php
- Step & repeat banners: https://www.nextdayflyers.com/banner-printing/step-and-repeat-banners.php
- Floor graphics: **no stable NDF public URL confirmed** (previous `/floor-graphics.html` returned 404 during validation on 2026-02-14 02:10 ET)

### VistaPrint
- Standard business cards: https://www.vistaprint.com/business-cards/standard
- Business cards (hub): https://www.vistaprint.com/business-cards
- Vinyl banners: https://www.vistaprint.com/signs-posters/vinyl-banners
- Banners (hub): https://www.vistaprint.com/signs-posters/banners

## Baseline signals captured tonight

### Hard price points found in source content
- **NDF (Standard Business Cards sample)** for 500 cards, 14 pt, full-color both sides, high-gloss UV both sides:
  - 3 Business Days: **$19.95**
  - Next Business Day: **$39.95**
  - Ready Today: **$89.95**
  - Source page: NDF standard business cards FAQ section.

- **VistaPrint (Standard Business Cards marketing snippet):**
  - “starting at **50 for $10**”
  - Source: Brave search result snippet pointing to Vista standard business cards page.

### Non-priced but operationally useful signals
- NDF floor graphics: standard turnaround noted as 6 business days.
- NDF vinyl banners: same-day/next-day options highlighted; pricing requires calculator selections.
- Vista vinyl banners: shipping tiers shown (express 3 business days / standard 6 / economy 8), but calculator-dependent pricing.

## Monitoring spec (what to capture every run)
For each SKU + competitor, capture:
- date_time_et
- competitor (NDF / VistaPrint)
- product
- url
- size
- material/stock
- quantity
- print_sides
- turnaround
- listed_price_usd
- shipping_included (yes/no)
- promo_code_seen
- notes

## Rule-of-thumb alert thresholds
- **Red alert:** competitor drops >8% week-over-week on any core SKU.
- **Yellow alert:** competitor drops 3–8% or introduces promo stacking.
- **Margin response:** default to INKredible tier logic (Opening/Target/Floor), do not panic-discount below floor unless strategic account.

## Weekly runbook (10-15 min)
1. Open canonical URLs above.
2. Enter fixed spec presets (same size/qty/material each week).
3. Capture prices into tracker CSV.
4. Compare WoW deltas.
5. Post 3-bullet pricing intel summary:
   - Biggest mover
   - Risk SKU for this week
   - Recommended quote posture adjustment

## Next automation step (Phase 2)
Use Browser Relay to script the exact preset selections and export a fresh CSV weekly (no manual clicking).

## Deliverables created in this run
- `workspace/research/competitor-price-watch-v1.md` (this file)
- `workspace/research/competitor-price-watch-log-template.csv` (capture template)

## Automation extension (02:16 AM ET)
- Added structured toolkit in `workspace/research/price-watch/`:
  - `README.md` (weekly operating procedure + alert guardrails)
  - `watchlist.csv` (canonical SKU matrix)
  - `snapshot-template.csv` + `snapshots/2026-02-07.csv` + `snapshots/2026-02-14.csv`
- Added diff engine: `workspace/scripts/price-watch-diff.js`
  - Compares two snapshots
  - Outputs markdown report to `workspace/reports/price-watch-YYYY-MM-DD.md`
- Generated first report: `workspace/reports/price-watch-2026-02-14.md`
