# Intuit Compliance Questionnaire — Completion Strategy

**App:** INKredible Claude MCP  
**URL:** https://help.developer.intuit.com  
**Status:** Tab 1 (General Questions) ✅ COMPLETE | Tabs 2–6 ❌ REMAINING  
**Platform:** Salesforce Lightning Web Components (LWC) with Shadow DOM  
**Date:** 2026-02-13

---

## 1. The Shadow DOM Problem

Salesforce LWC components use **open shadow DOM** to encapsulate their internals:

- `document.querySelectorAll('input[type=checkbox]')` → **0 results** (inputs live inside shadow roots)
- OpenClaw snapshot refs (e.g., `@e12`) go **stale between snapshots** — clicking often fails with "Element not found"
- Standard CSS selectors cannot cross shadow boundaries
- Multiple layers of nested shadow DOMs (Salesforce stacks components: `lightning-input` → `lightning-primitive-input-checkbox` → `<input>`)

### Why Refs Go Stale
OpenClaw's snapshot system generates temporary element references from the accessibility tree. These are **ephemeral pointers** — any DOM mutation (Salesforce LWC re-renders frequently) invalidates them. The gap between taking a snapshot and issuing a click is enough for Salesforce to re-render components.

---

## 2. Technical Approaches (Ranked by Reliability)

### Approach A: `browser act kind=evaluate` with Recursive Shadow DOM Traversal ⭐ RECOMMENDED

OpenClaw's `browser act kind=evaluate` executes arbitrary JavaScript in the page context via CDP. This is the **most reliable** approach because:

1. **JavaScript `element.shadowRoot` works on open shadow DOM** — Salesforce LWC uses open shadow DOM
2. **No stale refs** — we find elements in real-time and act immediately in a single JS execution
3. **No timing gaps** — find + click happens atomically within one evaluate call

#### Core Utility Function: Deep Shadow DOM Query

```javascript
function deepQuerySelectorAll(selector, root) {
  root = root || document;
  const results = Array.from(root.querySelectorAll(selector));
  const pushNestedResults = function(r) {
    deepQuerySelectorAll(selector, r).forEach(elem => {
      if (!results.includes(elem)) results.push(elem);
    });
  };
  if (root.shadowRoot) pushNestedResults(root.shadowRoot);
  for (const elem of root.querySelectorAll('*')) {
    if (elem.shadowRoot) pushNestedResults(elem.shadowRoot);
  }
  return results;
}
```

#### For Checkboxes (lightning-input type="checkbox")

```javascript
// Find all checkboxes by traversing shadow DOM
const checkboxes = deepQuerySelectorAll('input[type="checkbox"]');
// Find by label text
const allLabels = deepQuerySelectorAll('label, span.slds-checkbox__label, .slds-form-element__label');
const target = [...allLabels].find(l => l.textContent.includes('App Scratch'));
if (target) {
  // Navigate up to find the associated checkbox input
  const container = target.closest('lightning-input') || target.parentElement;
  const checkbox = container.shadowRoot 
    ? container.shadowRoot.querySelector('input[type="checkbox"]')
    : container.querySelector('input[type="checkbox"]');
  if (checkbox && !checkbox.checked) {
    checkbox.click();
    // Dispatch change event so LWC framework picks it up
    checkbox.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
  }
}
```

#### For Dual-Listbox (lightning-dual-listbox)

```javascript
// Dual listboxes have option elements in the "source" list
// Click the option to select it, then click the "move right" button
const dualListbox = deepQuerySelectorAll('lightning-dual-listbox')[0];
if (dualListbox) {
  const sr = dualListbox.shadowRoot;
  // Find all option items in the source (left) list
  const sourceOptions = sr.querySelectorAll('[data-type="source"] .slds-listbox__option');
  // Or find by text content
  const allOptions = sr.querySelectorAll('.slds-listbox__option');
  const targetOption = [...allOptions].find(o => o.textContent.includes('Web/SaaS'));
  if (targetOption) {
    targetOption.click(); // Select it
    // Then click the "move right" button
    const moveRightBtn = sr.querySelector('button[title="Move selection to Chosen"]') 
      || sr.querySelector('.slds-button_icon-border-filled[data-value="right"]');
    if (moveRightBtn) moveRightBtn.click();
  }
}
```

#### Alternative: Set Dual-Listbox Value Directly

LWC components expose public properties. You can set the `value` property directly:

```javascript
const dualListbox = deepQuerySelectorAll('lightning-dual-listbox')[0];
if (dualListbox) {
  // Set the selected values (these are the "Chosen" items)
  dualListbox.value = ['Web/SaaS'];
  // Dispatch change event
  dualListbox.dispatchEvent(new CustomEvent('change', { 
    detail: { value: ['Web/SaaS'] },
    bubbles: true, 
    composed: true 
  }));
}
```

### Approach B: OpenClaw Snapshot + Immediate Click (Timing-Sensitive)

Take a snapshot with `refs="aria"` for more stable references, then immediately click:

```
1. browser snapshot refs=aria → get refs
2. browser act kind=click ref=<ref> → click immediately
3. browser snapshot refs=aria → verify and get new refs
```

**Risk:** Refs still go stale. This approach only works if:
- The page is fully loaded and stable (no background re-renders)
- You act within milliseconds of the snapshot
- The tab is focused and visible

### Approach C: Keyboard Navigation (Tab + Space)

Navigate form elements using keyboard:
1. Focus the form area
2. Tab to reach each checkbox/listbox
3. Press Space to toggle checkboxes
4. Use Arrow keys to navigate listbox options

```
browser act kind=press key=Tab    → move to next element
browser act kind=press key=Space  → toggle checkbox
browser act kind=press key=Enter  → activate button
```

**Risk:** Tab order is unpredictable in Salesforce LWC. Hard to know which element has focus.

### Approach D: Manual Guide for Aviel (Fallback) ✅ GUARANTEED TO WORK

If all automation fails, provide Aviel with a click-by-click guide. See Section 5.

---

## 3. Recommended Execution Plan

### Phase 1: Reconnaissance (5 min)

First, take a snapshot of Tab 2 to understand the exact component structure:

```
browser snapshot profile=chrome refs=aria
```

Then run a diagnostic JavaScript to map out the shadow DOM:

```javascript
// Run via: browser act kind=evaluate
(function() {
  const results = [];
  function scan(node, path) {
    if (node.shadowRoot) {
      const children = node.shadowRoot.querySelectorAll('*');
      children.forEach(c => {
        if (c.tagName.toLowerCase().includes('lightning-') || 
            c.tagName.toLowerCase().includes('input') ||
            c.tagName.toLowerCase().includes('listbox')) {
          results.push({
            path: path + ' > #shadow > ' + c.tagName.toLowerCase(),
            type: c.getAttribute('type') || c.tagName,
            label: c.getAttribute('label') || c.textContent?.substring(0, 50)
          });
        }
        scan(c, path + ' > #shadow > ' + c.tagName.toLowerCase());
      });
    }
    node.querySelectorAll('*').forEach(c => {
      if (c.shadowRoot) scan(c, path + ' > ' + c.tagName.toLowerCase());
    });
  }
  scan(document.body, 'body');
  return JSON.stringify(results.slice(0, 50), null, 2);
})()
```

### Phase 2: Attempt JavaScript Automation (10 min)

For each field, execute the appropriate `browser act kind=evaluate` script from Approach A above. After each field:

1. Take a screenshot to verify the change took effect
2. If it didn't work, try the alternative approach (setting property directly)

### Phase 3: Navigate Tabs and Repeat

After completing Tab 2:
1. Click the "Next" button or Tab 3 header to advance
2. Snapshot the new tab
3. Repeat field-by-field automation

### Phase 4: Submit

After all tabs are complete, click the Submit button.

---

## 4. Pre-Filled Answers — All Tabs

### Tab 2: App Information

| # | Question | Answer | Component Type |
|---|----------|--------|---------------|
| 1 | How was the app built? | Check **"App Scratch"** (built from scratch) | Checkbox |
| 2 | What platforms? | Move **"Web/SaaS"** to Chosen | Dual-listbox |
| 3 | How does app interact with Intuit? | Move **"It reads data from Intuit product(s)"** to Chosen | Dual-listbox |
| 4 | Private or public app? | Select **"This is a private app"** | Radio/Dropdown |
| 5 | Which user types? | Select **"All QuickBooks Online user types"** | Radio/Dropdown |
| 6 | Integrates with other platforms? | **"Yes"** — integrates with NVIDIA NIM for AI-powered financial chat | Radio + Text |

### Tab 3: Authorization and Authentication

| # | Question | Answer |
|---|----------|--------|
| 1 | Authentication method | **OAuth 2.0** (standard Intuit flow) |
| 2 | Where are tokens stored? | **Server-side** (localhost OAuth server, file-based) |
| 3 | Refresh token handling? | **Yes** — automatic refresh before expiry |
| 4 | Webhooks? | **No** — no webhooks currently |

### Tab 4: API Usage

| # | Question | Answer |
|---|----------|--------|
| 1 | What data does app read? | Company Info, Profit & Loss, Balance Sheet, Cash Flow Statement, Customers, Invoices, Vendors, Items, Expenses |
| 2 | What data does app write? | **None** — read-only financial dashboard |
| 3 | Batch operations? | **No** |
| 4 | Real-time sync? | **No** — on-demand data retrieval |

### Tab 5: Error Handling

| # | Question | Answer |
|---|----------|--------|
| 1 | How are errors handled? | **401**: automatic token refresh; **429**: rate limiting with exponential backoff; **500**: retry with exponential backoff |
| 2 | Error logging? | **Yes** — all API errors logged to console and error handler |
| 3 | Graceful degradation? | **Yes** — shows cached/static data if API is unavailable |

### Tab 6: Security

| # | Question | Answer |
|---|----------|--------|
| 1 | HTTPS? | **Yes** — HTTPS only for all communications |
| 2 | Token storage security | Tokens in chmod 600 files, never in logs, never client-side |
| 3 | PII handling | No PII stored beyond what QuickBooks provides via API |
| 4 | Data sharing | **No** third-party data sharing |
| 5 | Hosting | Private server (WSL2 on local machine), not publicly hosted |

---

## 5. Fallback: Manual Click Guide for Aviel

If JavaScript automation fails, here's the step-by-step manual guide:

### Tab 2: App Information
1. **Look for checkboxes** about how the app was built → Check **"App Scratch"** (or "Built from scratch")
2. **Dual listbox for platforms** → In the left "Available" list, click **"Web/SaaS"**, then click the **right arrow (→)** button to move it to "Chosen"
3. **Dual listbox for interaction type** → Click **"It reads data from Intuit product(s)"** in left list, click **→** button
4. **Private/public dropdown or radio** → Select **"This is a private app"**
5. **User types** → Select **"All QuickBooks Online user types"**
6. **Integrates with other platforms?** → Select **"Yes"**
7. **If a text field appears** → Type: *"Integrates with NVIDIA NIM for AI-powered financial analysis and natural language chat about QuickBooks data"*
8. Click **Next** / advance to Tab 3

### Tab 3: Authorization and Authentication
1. Authentication method → **OAuth 2.0**
2. Token storage → **Server-side**
3. Refresh tokens → **Yes**
4. Webhooks → **No**
5. Click **Next**

### Tab 4: API Usage
1. Data read → Select all that apply: **Company Info, Profit & Loss, Balance Sheet, Cash Flow, Customers, Invoices, Vendors, Items, Expenses**
2. Data write → **None** (or leave unchecked)
3. Batch operations → **No**
4. Real-time sync → **No**
5. Click **Next**

### Tab 5: Error Handling
1. Error handling → Describe: *"Handles 401 with automatic token refresh, 429 with rate limiting and exponential backoff, 500 with retry and exponential backoff. All errors logged. Graceful degradation shows cached data when API unavailable."*
2. Click **Next**

### Tab 6: Security
1. HTTPS → **Yes**
2. Token security → *"OAuth tokens stored server-side in chmod 600 permission files. Never logged, never exposed client-side."*
3. PII → *"No PII stored beyond what QuickBooks API provides. No additional data collection."*
4. Data sharing → **No**
5. Hosting → *"Private server running on local machine (WSL2). Not publicly hosted."*
6. Click **Submit**

---

## 6. JavaScript Automation Scripts (Ready to Paste)

### Script 1: Diagnostic — Map All Interactive Elements

```javascript
// Paste into: browser act kind=evaluate fn=<this>
(function() {
  function deepQuery(sel, root) {
    root = root || document;
    let results = [...root.querySelectorAll(sel)];
    if (root.shadowRoot) {
      results = results.concat(deepQuery(sel, root.shadowRoot));
    }
    for (const el of root.querySelectorAll('*')) {
      if (el.shadowRoot) results = results.concat(deepQuery(sel, el.shadowRoot));
    }
    return results;
  }
  
  const checkboxes = deepQuery('input[type="checkbox"]');
  const radios = deepQuery('input[type="radio"]');
  const selects = deepQuery('select');
  const dualListboxes = deepQuery('lightning-dual-listbox');
  const lightningInputs = deepQuery('lightning-input');
  const buttons = deepQuery('button');
  
  return JSON.stringify({
    checkboxes: checkboxes.length,
    radios: radios.length,
    selects: selects.length,
    dualListboxes: dualListboxes.length,
    lightningInputs: lightningInputs.length,
    buttons: buttons.map(b => b.textContent.trim().substring(0, 40)).filter(t => t),
    checkboxLabels: lightningInputs
      .filter(li => li.getAttribute('type') === 'checkbox')
      .map(li => li.getAttribute('label') || 'unlabeled'),
  }, null, 2);
})()
```

### Script 2: Check a Checkbox by Label Text

```javascript
// Replace TARGET_LABEL with the checkbox label text
(function() {
  const TARGET_LABEL = 'App Scratch';
  
  function deepQuery(sel, root) {
    root = root || document;
    let results = [...root.querySelectorAll(sel)];
    if (root.shadowRoot) results = results.concat(deepQuery(sel, root.shadowRoot));
    for (const el of root.querySelectorAll('*')) {
      if (el.shadowRoot) results = results.concat(deepQuery(sel, el.shadowRoot));
    }
    return results;
  }
  
  // Find lightning-input checkboxes
  const inputs = deepQuery('lightning-input');
  const target = inputs.find(i => 
    i.getAttribute('type') === 'checkbox' && 
    (i.getAttribute('label') || '').toLowerCase().includes(TARGET_LABEL.toLowerCase())
  );
  
  if (!target) return 'NOT FOUND: No checkbox with label containing "' + TARGET_LABEL + '"';
  
  // Try clicking the inner input
  const innerInput = target.shadowRoot?.querySelector('input[type="checkbox"]');
  if (innerInput && !innerInput.checked) {
    innerInput.click();
    return 'CLICKED: ' + TARGET_LABEL;
  } else if (innerInput?.checked) {
    return 'ALREADY CHECKED: ' + TARGET_LABEL;
  }
  
  // Fallback: click the lightning-input itself
  target.click();
  return 'FALLBACK CLICK: ' + TARGET_LABEL;
})()
```

### Script 3: Move Item in Dual-Listbox

```javascript
// Replace TARGET_VALUE and LISTBOX_INDEX as needed
(function() {
  const TARGET_VALUE = 'Web/SaaS';
  const LISTBOX_INDEX = 0; // 0 for first dual-listbox on page, 1 for second, etc.
  
  function deepQuery(sel, root) {
    root = root || document;
    let results = [...root.querySelectorAll(sel)];
    if (root.shadowRoot) results = results.concat(deepQuery(sel, root.shadowRoot));
    for (const el of root.querySelectorAll('*')) {
      if (el.shadowRoot) results = results.concat(deepQuery(sel, el.shadowRoot));
    }
    return results;
  }
  
  const dualListboxes = deepQuery('lightning-dual-listbox');
  if (dualListboxes.length === 0) return 'NO DUAL LISTBOXES FOUND';
  
  const dlb = dualListboxes[LISTBOX_INDEX];
  if (!dlb) return 'LISTBOX INDEX ' + LISTBOX_INDEX + ' NOT FOUND (found ' + dualListboxes.length + ')';
  
  const sr = dlb.shadowRoot;
  if (!sr) return 'NO SHADOW ROOT ON DUAL LISTBOX';
  
  // Find source list options
  const options = sr.querySelectorAll('.slds-listbox__option, [role="option"]');
  const targetOpt = [...options].find(o => 
    o.textContent.toLowerCase().includes(TARGET_VALUE.toLowerCase())
  );
  
  if (!targetOpt) {
    const available = [...options].map(o => o.textContent.trim().substring(0, 40));
    return 'OPTION NOT FOUND. Available: ' + JSON.stringify(available);
  }
  
  // Click to select, then move right
  targetOpt.click();
  
  // Find and click the "move right" button
  const moveBtn = sr.querySelector('button[title*="Move"]') 
    || sr.querySelector('button[title*="move"]')
    || sr.querySelector('.slds-button_icon-border-filled');
  
  if (moveBtn) {
    setTimeout(() => moveBtn.click(), 100);
    return 'MOVED: ' + TARGET_VALUE;
  }
  
  // Fallback: try setting value property directly
  const currentVal = dlb.value || [];
  dlb.value = [...currentVal, TARGET_VALUE];
  dlb.dispatchEvent(new CustomEvent('change', {
    detail: { value: dlb.value },
    bubbles: true, composed: true
  }));
  return 'SET VALUE DIRECTLY: ' + TARGET_VALUE;
})()
```

### Script 4: Select Radio Button / Dropdown

```javascript
(function() {
  const TARGET_TEXT = 'This is a private app';
  
  function deepQuery(sel, root) {
    root = root || document;
    let results = [...root.querySelectorAll(sel)];
    if (root.shadowRoot) results = results.concat(deepQuery(sel, root.shadowRoot));
    for (const el of root.querySelectorAll('*')) {
      if (el.shadowRoot) results = results.concat(deepQuery(sel, el.shadowRoot));
    }
    return results;
  }
  
  // Try radio buttons first
  const radios = deepQuery('input[type="radio"]');
  for (const radio of radios) {
    const label = radio.closest('label') || radio.parentElement;
    if (label && label.textContent.toLowerCase().includes(TARGET_TEXT.toLowerCase())) {
      radio.click();
      radio.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
      return 'RADIO SELECTED: ' + TARGET_TEXT;
    }
  }
  
  // Try combobox / dropdown
  const combos = deepQuery('lightning-combobox, lightning-radio-group');
  for (const combo of combos) {
    const options = combo.shadowRoot?.querySelectorAll('option, [role="option"]') || [];
    const target = [...options].find(o => 
      o.textContent.toLowerCase().includes(TARGET_TEXT.toLowerCase())
    );
    if (target) {
      target.click();
      return 'COMBOBOX SELECTED: ' + TARGET_TEXT;
    }
  }
  
  return 'NOT FOUND: ' + TARGET_TEXT;
})()
```

---

## 7. Decision Matrix

| Approach | Reliability | Speed | Risk | Best For |
|----------|------------|-------|------|----------|
| **A: JS evaluate** | ⭐⭐⭐⭐ | Fast | Low — single atomic operation | Checkboxes, dual-listboxes |
| **B: Snapshot + click** | ⭐⭐ | Medium | High — stale refs | Simple buttons, text inputs |
| **C: Keyboard nav** | ⭐⭐ | Slow | Medium — unpredictable tab order | Fallback for individual fields |
| **D: Manual guide** | ⭐⭐⭐⭐⭐ | Slow (human) | None | Guaranteed fallback |

### Recommendation

**Start with Approach A** (JavaScript evaluate). Run the diagnostic script first to understand the DOM structure, then use the targeted scripts for each field type. If any field resists automation, fall back to **Approach D** (tell Aviel exactly what to click).

The entire questionnaire has roughly **15-20 fields across 5 tabs**. Even if automation only handles half of them, that cuts Aviel's manual work significantly. And if it handles all of them, we're done in under 5 minutes.

---

## 8. Important Notes

- **Sabbath check**: It's Friday afternoon (Feb 13, 2026 is a Friday). If sundown has passed, **do NOT submit the form** — queue it for Saturday night/Sunday. Intuit review is async anyway; a few hours won't matter.
- **Save progress**: If the form has a "Save Draft" or "Save" button, use it after completing each tab. Salesforce forms sometimes have auto-save, but don't count on it.
- **Screenshot verification**: After each automation step, take a screenshot (`browser screenshot`) to confirm the change visually before moving to the next field.
