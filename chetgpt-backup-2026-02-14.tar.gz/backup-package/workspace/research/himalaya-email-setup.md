# Himalaya CLI Email Setup — INKredible Printing Inbox Monitor

> **Research Date:** 2026-02-13
> **Purpose:** Enable ChetGPT to scan the business inbox 3×/day and send Telegram summaries of urgent emails to Aviel (ID: 517496021)
> **Status:** Research Complete — Awaiting Aviel's credentials to proceed

---

## 1. What is Himalaya?

[Himalaya](https://github.com/pimalaya/himalaya) is a Rust-based CLI tool for managing emails via IMAP/SMTP. Key features for our use case:

- **CLI-native** — runs headless, perfect for cron jobs and scripting
- **JSON output** (`--output json`) — easy to parse programmatically
- **IMAP backend** — works with Gmail, Google Workspace, Outlook, any IMAP provider
- **Lightweight** — single binary, no GUI, minimal resource usage
- **Active project** — latest release v1.1.0, actively maintained by Pimalaya

---

## 2. Installation Steps

### Option A: Pre-built Binary (Recommended — fastest)

```bash
# As regular user (installs to ~/.local/bin)
curl -sSL https://raw.githubusercontent.com/pimalaya/himalaya/master/install.sh | PREFIX=~/.local sh

# Make sure ~/.local/bin is in PATH
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc

# Verify
himalaya --version
```

### Option B: Cargo (if Rust toolchain is available)

```bash
# Install Rust first (if needed)
curl https://sh.rustup.rs -sSf | sh

# Install himalaya
cargo install himalaya --locked
```

### Option C: From GitHub Release directly

```bash
# Download latest x86_64 Linux binary
curl -sLo /tmp/himalaya.tgz https://github.com/pimalaya/himalaya/releases/latest/download/himalaya.x86_64-linux.tgz
tar xzf /tmp/himalaya.tgz -C ~/.local/bin/
chmod +x ~/.local/bin/himalaya
```

**Our system:** Linux x86_64 (WSL2) — all options work. Option A is simplest.

---

## 3. Configuration Needed from Aviel

### What I need from you:

| Item | Details | Example |
|------|---------|---------|
| **Business email address** | The inbox to monitor | `info@inkredibleprinting.com` or `aviel@...` |
| **Email provider** | Gmail / Google Workspace / Outlook / Other | Google Workspace |
| **App Password** | A 16-character app-specific password (see below) | `abcd efgh ijkl mnop` |
| **Which folders to scan** | Inbox only? Or also specific labels? | INBOX |

### How to Generate a Google App Password:

1. Go to [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords)
2. **Prerequisite:** 2-Step Verification must be enabled on the Google account
3. Select **"Mail"** as the app
4. Select **"Other"** and name it `ChetGPT-Himalaya`
5. Click **Generate** — copy the 16-character password
6. Send it to me securely (Telegram is fine, I'll store it in the system keyring, not plaintext)

> ⚠️ **Google Workspace accounts**: The admin may need to enable "Less secure app access" or allow App Passwords in the Google Admin console.

### For Non-Gmail (IMAP) Accounts:

I'll need:
- IMAP host (e.g., `imap.yourdomain.com`)
- IMAP port (usually `993` for SSL)
- SMTP host + port (if we ever want to send replies)
- Username & password

---

## 4. Configuration File

Once credentials are received, the config goes at `~/.config/himalaya/config.toml`:

### Gmail / Google Workspace Example:

```toml
[accounts.inkredible]
default = true
email = "info@inkredibleprinting.com"
display-name = "INKredible Printing"

folder.aliases.inbox = "INBOX"
folder.aliases.sent = "[Gmail]/Sent Mail"
folder.aliases.drafts = "[Gmail]/Drafts"
folder.aliases.trash = "[Gmail]/Trash"

# IMAP backend (reading)
backend.type = "imap"
backend.host = "imap.gmail.com"
backend.port = 993
backend.login = "info@inkredibleprinting.com"
backend.auth.type = "password"
backend.auth.cmd = "cat /home/inkredible/.config/himalaya/.imap-secret"
# Or use keyring: backend.auth.keyring = "inkredible-imap"

# SMTP backend (sending — optional, only if we need to reply)
message.send.backend.type = "smtp"
message.send.backend.host = "smtp.gmail.com"
message.send.backend.port = 465
message.send.backend.login = "info@inkredibleprinting.com"
message.send.backend.auth.type = "password"
message.send.backend.auth.cmd = "cat /home/inkredible/.config/himalaya/.smtp-secret"
```

> **Security note:** Password stored via `auth.cmd` pointing to a permission-restricted file (`chmod 600`), NOT as plaintext `auth.raw` in the config.

---

## 5. How It Would Work: Inbox Monitoring Pipeline

### Architecture:

```
Cron (3×/day) → Shell Script → Himalaya CLI → JSON email data → ChetGPT analysis → Telegram summary
```

### Step-by-step flow:

1. **Cron triggers** at configured times (e.g., 8:00 AM, 12:00 PM, 5:00 PM ET)
2. **Shell script** runs:
   ```bash
   # List recent unread envelopes (JSON format)
   himalaya envelope list --folder INBOX --output json --page-size 50
   
   # For each unread/flagged email, read the content:
   himalaya message read <id> --output json
   ```
3. **ChetGPT processes** the JSON output:
   - Filters for unread messages since last check
   - Identifies urgent items (keywords: "urgent", "rush", "ASAP", "deadline", "payment", "invoice", customer complaints)
   - Categorizes: 🔴 Urgent | 🟡 Important | 🟢 FYI
4. **Sends Telegram summary** to Aviel (ID: 517496021):
   ```
   📬 INKredible Inbox Summary (12:00 PM)
   
   🔴 URGENT (2):
   • John Smith — "Rush order needed by Friday" (2h ago)
   • ABC Corp — "Invoice #1234 payment issue" (4h ago)
   
   🟡 IMPORTANT (3):
   • New quote request from XYZ LLC
   • Vendor price update from paper supplier
   • Customer follow-up on order #5678
   
   🟢 FYI (5 others)
   Total unread: 10
   ```

### Key Himalaya Commands:

| Command | Purpose |
|---------|---------|
| `himalaya envelope list --output json` | List email envelopes (subject, sender, date, flags) |
| `himalaya envelope list --folder INBOX` | Target specific folder |
| `himalaya message read <id> --output json` | Read full message content |
| `himalaya message read <id> --header From --header Subject` | Read specific headers |
| `himalaya flag add <id> seen` | Mark as seen (avoid re-alerting) |

### Sample Cron Job:

```bash
# Scan inbox 3x/day: 8 AM, 12 PM, 5 PM ET (weekdays only)
0 8,12,17 * * 1-5 /home/inkredible/.openclaw/workspace/scripts/inbox-monitor.sh
```

> **Sabbath compliance:** Cron runs normally; ChetGPT queues summaries but doesn't send during Sabbath hours (Friday sundown → Saturday sundown). Summaries accumulate and send after Sabbath ends.

---

## 6. Estimated Setup Time

| Task | Time |
|------|------|
| Install Himalaya binary | 2 minutes |
| Configure IMAP connection (once credentials received) | 10 minutes |
| Write inbox monitoring script | 20 minutes |
| Test end-to-end (read → summarize → Telegram) | 15 minutes |
| Set up cron job | 5 minutes |
| **Total** | **~50 minutes** |

**Blocker:** Cannot proceed without email credentials (email address + app password from Aviel).

---

## 7. Security Considerations

### ✅ Good Practices (we'll follow):
- **App Password** — not the main Google password; can be revoked independently
- **Password stored via `auth.cmd`** — reads from a `chmod 600` file, not stored in plaintext config
- **Read-only by default** — we only need to LIST and READ; no sending/deleting
- **Local processing** — email content stays on our server, sent only as summaries via Telegram
- **No email content stored** — process in memory, discard after summarizing

### ⚠️ Risks to be aware of:
- **App Password grants full IMAP access** — anyone with it can read ALL emails. Keep the secret file locked down
- **Email content in transit** — IMAP connection is TLS-encrypted (port 993), but the content passes through our script
- **Telegram summaries** — contain email subjects/senders, which could be sensitive. Telegram messages are encrypted in transit
- **WSL2 persistence** — ensure the credential file survives WSL restarts
- **Cron reliability** — if the system is off/sleeping, cron jobs don't run. Consider a health check

### 🔒 Recommendations:
1. Create a **dedicated Google App Password** just for this — easy to revoke if compromised
2. Consider a **dedicated monitoring email** (e.g., `monitor@inkredibleprinting.com`) that receives a copy/forward of important emails, rather than giving access to the primary inbox
3. Set file permissions: `chmod 600 ~/.config/himalaya/.imap-secret` and `chmod 600 ~/.config/himalaya/config.toml`
4. **Audit log** — log each scan run and what was summarized (without full email content)
5. Periodic **App Password rotation** (every 90 days)

---

## 8. Alternative Approaches Considered

| Approach | Pros | Cons |
|----------|------|------|
| **Himalaya CLI** ✅ | Lightweight, JSON output, scriptable, active project | Needs Rust binary, no built-in summarization |
| **Python imaplib** | No extra binary, native Python | More code to write, handle MIME parsing |
| **Google Apps Script** | Runs in Google's cloud, no server needed | Requires Google Workspace admin, harder to integrate with Telegram |
| **Gmail API (OAuth)** | Most "proper" approach | Complex OAuth setup, token refresh management |
| **fetchmail + procmail** | Classic Unix approach | Overkill, harder to parse output |

**Verdict:** Himalaya is the best fit — clean JSON output, simple config, minimal footprint.

---

## 9. Next Steps

1. ⏳ **Aviel provides:** business email address + app password
2. 🔧 **I install** Himalaya and configure the IMAP connection
3. 🧪 **Test:** verify we can list and read emails
4. 📝 **Build:** inbox monitoring script with urgency classification
5. ⏰ **Deploy:** cron job for 3×/day scans
6. ✅ **Verify:** end-to-end test with real Telegram delivery

---

*Research by ChetGPT | For INKredible Printing's email monitoring system*
