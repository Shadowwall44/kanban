# INKredible Printing — Custom Skill Proposals (Based on Anthropic Skill Guide)

## Key rules from the Anthropic Skill Guide we should strictly follow

1. **Use the required skill structure exactly**
   - Every skill folder must be kebab-case and include a file named **exactly** `SKILL.md` (case-sensitive).
   - Optional folders: `scripts/`, `references/`, `assets/`.
   - Do **not** put `README.md` inside the skill folder (repo-level README is fine for GitHub distribution).

2. **Frontmatter quality determines auto-triggering success**
   - `name` and `description` are required.
   - `description` must include: **what the skill does + when to use it**, with realistic trigger phrases users actually say.
   - Keep description under 1024 chars; no XML angle brackets (`<` `>`); avoid reserved names containing “claude” or “anthropic”.

3. **Design for progressive disclosure**
   - Level 1: Frontmatter (always loaded).
   - Level 2: `SKILL.md` body (loaded when relevant).
   - Level 3: linked files in `references/` and scripts loaded only as needed.
   - Keep core instructions concise; move heavy detail to `references/`.

4. **Write deterministic, actionable instructions**
   - Use clear numbered steps, explicit checks, concrete commands, and expected outputs.
   - Include error handling and troubleshooting sections.
   - For critical validations, prefer scripts (deterministic) over prose-only instructions.

5. **Test in three layers before rollout**
   - Trigger tests (should trigger + should not trigger).
   - Functional tests (correct output/tool calls/error handling).
   - Performance comparison (with vs without skill: fewer retries, fewer tokens, less back-and-forth).

6. **Iterate using under/over-trigger signals**
   - Under-triggering: add specific keywords/trigger phrases.
   - Over-triggering: narrow scope and add “do not use when…” constraints.
   - Treat skills as living documents with regular revisions.

7. **Keep skills composable and portable**
   - Assume multiple skills may load together.
   - Don’t hard-code assumptions that block cooperation with other skills.
   - Use optional `compatibility` and `metadata` fields for environment/tooling clarity.

8. **Mind context budget**
   - Keep `SKILL.md` lean (guide suggests under ~5,000 words).
   - Use `references/` for long docs.
   - Avoid enabling too many skills at once without curation.

---

## Proposed custom skills for OpenClaw (INKredible setup)

## 1) `mission-control-daily-brief`
- **Who uses it:** Brain
- **What it does:** Generates a structured daily command brief from Mission Control, Kanban boards, Financial Dashboard, and cron health status. It outputs a tight ADHD-friendly plan: **Now / Next / Later**, plus top blockers and first 15-minute action.
- **Files/scripts it would include:**
  - `SKILL.md`
  - `scripts/fetch_ops_snapshot.py`
  - `scripts/generate_daily_brief.py`
  - `references/dashboard-data-map.md`
  - `assets/daily-brief-template.md`
- **Priority:** **HIGH**

## 2) `quote-intake-to-estimate`
- **Who uses it:** Both
- **What it does:** Standardizes quote intake so Brain/Sub-agents stop missing key specs (size, quantity, stock, finishing, turnaround, shipping). It asks only missing questions, runs Quote Tool logic, and outputs both a customer-ready estimate and an internal margin/risk note.
- **Files/scripts it would include:**
  - `SKILL.md`
  - `scripts/validate_quote_inputs.py`
  - `scripts/run_quote_calculation.py`
  - `references/required-quote-fields.md`
  - `references/pricing-logic-cheatsheet.md`
  - `assets/quote-response-template.md`
- **Priority:** **HIGH**

## 3) `approved-quote-to-job-ticket`
- **Who uses it:** Sub-agent
- **What it does:** Converts approved quotes into production-ready job tickets with machine routing, materials, finishing steps, and QC checkpoints. It reduces execution errors by enforcing a preflight checklist before any production handoff.
- **Files/scripts it would include:**
  - `SKILL.md`
  - `scripts/build_job_ticket.py`
  - `scripts/preflight_validation.py`
  - `references/machine-capability-matrix.md`
  - `references/material-compatibility-rules.md`
  - `assets/job-ticket-template.md`
- **Priority:** **HIGH**

## 4) `quickbooks-cash-and-ar-pulse`
- **Who uses it:** Both
- **What it does:** Pulls key QuickBooks data (A/R aging, unpaid invoices, upcoming payables, cash position) and converts it into a daily/weekly action list. It highlights cash risk early and prepares owner-facing recommendations instead of raw accounting dumps.
- **Files/scripts it would include:**
  - `SKILL.md`
  - `scripts/qb_fetch_metrics.py`
  - `scripts/cash_risk_scoring.py`
  - `references/financial-thresholds.md`
  - `assets/financial-pulse-template.md`
- **Priority:** **HIGH**

## 5) `kanban-focus-sprint-coach`
- **Who uses it:** Brain
- **What it does:** Translates backlog chaos into bite-sized execution blocks tailored for ADHD workflows (single focus target, 15-minute starter step, explicit done criteria). It enforces WIP limits and creates realistic “today plans” that reduce context switching.
- **Files/scripts it would include:**
  - `SKILL.md`
  - `scripts/prioritize_kanban_cards.py`
  - `scripts/create_focus_sprint_plan.py`
  - `references/wip-policy.md`
  - `references/adhd-workflow-patterns.md`
  - `assets/focus-sprint-template.md`
- **Priority:** **HIGH**

## 6) `github-pages-release-guard`
- **Who uses it:** Sub-agent
- **What it does:** Enforces a safe release workflow for Mission Control, Quote Tool, Financial Dashboard, and Second Brain pages. It runs preflight checks, deploy validation, and post-deploy smoke tests, then generates rollback-ready notes.
- **Files/scripts it would include:**
  - `SKILL.md`
  - `scripts/predeploy_checks.sh`
  - `scripts/deploy_pages.sh`
  - `scripts/postdeploy_smoke_test.py`
  - `references/release-checklist.md`
  - `assets/deploy-report-template.md`
- **Priority:** **HIGH**

## 7) `browser-relay-pricing-scout`
- **Who uses it:** Sub-agent
- **What it does:** Provides a repeatable competitor pricing research workflow via browser relay, so research output is structured and comparable instead of ad hoc screenshots. It normalizes findings into a standard CSV and flags pricing opportunities for INKredible.
- **Files/scripts it would include:**
  - `SKILL.md`
  - `scripts/normalize_competitor_prices.py`
  - `scripts/build_pricing_delta_report.py`
  - `references/competitor-source-list.md`
  - `references/spec-matching-rules.md`
  - `assets/pricing-research-template.csv`
- **Priority:** **MEDIUM**

## 8) `telegram-ops-notifier`
- **Who uses it:** Both
- **What it does:** Standardizes internal Telegram alerts (deploys, quote milestones, cron failures, financial anomalies) with severity labels, owner assignment, and next-action format. It prevents noisy, vague notifications and ensures critical issues are actionable on mobile.
- **Files/scripts it would include:**
  - `SKILL.md`
  - `scripts/build_alert_message.py`
  - `scripts/send_telegram_notification.py`
  - `references/alert-severity-matrix.md`
  - `assets/telegram-alert-templates.md`
- **Priority:** **HIGH**

## 9) `cron-health-and-recovery`
- **Who uses it:** Sub-agent
- **What it does:** Monitors scheduled jobs, detects stale or failed runs, performs safe first-line recovery steps, and escalates with a diagnostic packet if unresolved. This skill gives Codex agents a consistent runbook instead of improvised cron debugging.
- **Files/scripts it would include:**
  - `SKILL.md`
  - `scripts/check_cron_health.sh`
  - `scripts/retry_safe_failures.sh`
  - `scripts/collect_failure_context.py`
  - `references/cron-runbook.md`
  - `assets/incident-summary-template.md`
- **Priority:** **MEDIUM**

## 10) `second-brain-action-extractor`
- **Who uses it:** Both
- **What it does:** Converts transcripts, brain dumps, and daily notes into structured outputs: decisions, tasks, follow-ups, and tags aligned to your Second Brain taxonomy. It also creates an end-of-day recap that maps directly to tomorrow’s first actions.
- **Files/scripts it would include:**
  - `SKILL.md`
  - `scripts/extract_decisions_and_tasks.py`
  - `scripts/tag_and_route_notes.py`
  - `references/tag-taxonomy.md`
  - `references/task-routing-rules.md`
  - `assets/eod-recap-template.md`
- **Priority:** **MEDIUM**

---

## Suggested implementation order (fastest ROI)

1. `quote-intake-to-estimate`
2. `kanban-focus-sprint-coach`
3. `mission-control-daily-brief`
4. `github-pages-release-guard`
5. `quickbooks-cash-and-ar-pulse`
6. `approved-quote-to-job-ticket`
7. `telegram-ops-notifier`
8. `cron-health-and-recovery`
9. `second-brain-action-extractor`
10. `browser-relay-pricing-scout`

This order front-loads immediate operational stability + revenue workflow consistency, then adds intelligence and optimization layers.
