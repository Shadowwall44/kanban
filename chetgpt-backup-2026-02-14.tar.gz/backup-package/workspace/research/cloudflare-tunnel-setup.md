# Cloudflare Tunnel Setup (WSL2 / Ubuntu)

_Last updated: 2026-02-13 (ET)_

This guide is for INKredible internal setup: install `cloudflared` on WSL2 Ubuntu, create a **free** Cloudflare Tunnel, and expose a local directory over HTTPS.

---

## 0) Prerequisites

- Cloudflare account (free is fine)
- A domain in Cloudflare (required for a **named** tunnel like `files.yourdomain.com`)
- WSL2 Ubuntu terminal
- Python 3 (for quick local file server)

Check basics:

```bash
uname -a
lsb_release -a
python3 --version
```

---

## 1) Install cloudflared on WSL2 Ubuntu

> Source: Cloudflare package repo (`pkg.cloudflare.com`)

```bash
# 1) Add Cloudflare GPG key
sudo mkdir -p --mode=0755 /usr/share/keyrings
curl -fsSL https://pkg.cloudflare.com/cloudflare-main.gpg \
  | sudo tee /usr/share/keyrings/cloudflare-main.gpg >/dev/null

# 2) Add cloudflared apt repo (recommended generic Debian/Ubuntu channel)
echo 'deb [signed-by=/usr/share/keyrings/cloudflare-main.gpg] https://pkg.cloudflare.com/cloudflared any main' \
  | sudo tee /etc/apt/sources.list.d/cloudflared.list

# 3) Install
sudo apt-get update
sudo apt-get install -y cloudflared

# 4) Verify
cloudflared --version
```

If `cloudflared --version` prints version info, install is complete.

---

## 2) Serve a local directory in WSL2

Pick a directory to publish temporarily:

```bash
mkdir -p ~/public-share
cd ~/public-share
echo "Hello from WSL2" > index.html
```

Start a local HTTP server:

```bash
python3 -m http.server 8080 --bind 127.0.0.1
```

Keep this terminal open.

---

## 3) Option A — Fast temporary tunnel (free, no DNS setup)

In a second terminal:

```bash
cloudflared tunnel --url http://127.0.0.1:8080
```

Cloudflared will print a URL like:

`https://random-words.trycloudflare.com`

Use this for quick testing/sharing. Stop with `Ctrl+C`.

---

## 4) Option B — Named tunnel (free, stable hostname)

Use this for repeatable setup.

### 4.1 Authenticate cloudflared

```bash
cloudflared tunnel login
```

This opens a browser. Log in and authorize the zone (domain).

### 4.2 Create a named tunnel

```bash
cloudflared tunnel create inkredible-files
```

This returns a **Tunnel UUID** and creates credentials JSON in `~/.cloudflared/`.

### 4.3 Route DNS hostname to tunnel

Replace with your real domain/host:

```bash
cloudflared tunnel route dns inkredible-files files.yourdomain.com
```

### 4.4 Create config file

Create `~/.cloudflared/config.yml`:

```yaml
tunnel: <TUNNEL-UUID>
credentials-file: /home/<linux-user>/.cloudflared/<TUNNEL-UUID>.json

ingress:
  - hostname: files.yourdomain.com
    service: http://127.0.0.1:8080
  - service: http_status:404
```

### 4.5 Run the tunnel

```bash
cloudflared tunnel run inkredible-files
```

Now `https://files.yourdomain.com` should proxy to your local WSL2 directory server.

---

## 5) One-command test flow (quick sanity check)

Terminal A:

```bash
cd ~/public-share
python3 -m http.server 8080 --bind 127.0.0.1
```

Terminal B (temporary tunnel):

```bash
cloudflared tunnel --url http://127.0.0.1:8080
```

Open printed HTTPS URL and confirm `index.html` loads.

---

## 6) WSL2-specific notes

- Bind local dev server to `127.0.0.1` for safest local exposure.
- Cloudflare Tunnel handles inbound HTTPS; no router port-forwarding needed.
- If using Windows browser with WSL2 services, localhost forwarding is usually automatic in current WSL2.
- If tunnel cannot reach origin, verify local server is running and port matches (`8080` in examples).

---

## 7) Troubleshooting

### `cloudflared: command not found`
- Re-open shell, run `which cloudflared`
- Re-run install steps and ensure apt repo file exists:
  - `/etc/apt/sources.list.d/cloudflared.list`

### `Failed to reach the origin service`
- Confirm local server is live:
  ```bash
  curl -I http://127.0.0.1:8080
  ```
- Confirm config `service:` port matches running server

### DNS host not resolving
- Ensure `cloudflared tunnel route dns ...` succeeded
- Wait a minute for DNS propagation
- Confirm hostname is in same Cloudflare-managed zone

### Auth problems
- Re-run:
  ```bash
  cloudflared tunnel login
  cloudflared tunnel list
  ```

---

## 8) Security checklist (recommended)

- Do **not** expose sensitive directories.
- Use a dedicated share folder (`~/public-share`).
- Prefer Cloudflare Access policies for protected endpoints (email / OTP / identity checks).
- Rotate or remove old tunnels when no longer needed.

---

## 9) Aviel step-by-step (minimal path)

1. Install `cloudflared` (Section 1).
2. Create `~/public-share` and run Python server on `8080` (Section 2).
3. Run temporary free tunnel:
   ```bash
   cloudflared tunnel --url http://127.0.0.1:8080
   ```
4. Confirm HTTPS link works.
5. For persistent hostname, complete named tunnel steps (Section 4).

Done.
