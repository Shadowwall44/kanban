# Q4 — Top-50 High-Value Account Builder (NYC/Brooklyn)

**Business:** INKredible Printing  
**Focus offer:** Custom floor graphics / dance floor wraps / large-format event graphics  
**Target job size:** **$1K–$10K+** per project  
**Ideal buyer:** Event planners + rental/event production firms with recurring monthly events

---

## 1) Top-50 Curated Prospect List

> Notes:
> - Built for **NYC/Brooklyn-first** outreach, with some tri-state firms that regularly execute in NYC.
> - List is prioritized for accounts likely to generate recurring floor graphic jobs (weddings, mitzvahs, corporate activations, brand events).

| # | Company | Type | What they do | Why they fit INKredible | Est. Job Value | Contact Approach |
|---|---|---|---|---|---|---|
| 1 | EMRG Media | Event Planner / Production | Full-service NYC corporate + social events | High event volume + branded event surfaces | $4K–$12K | IG follow + email partnerships inbox + call ops manager with “fast-turn floor wrap partner” angle |
| 2 | Colin Cowie Lifestyle | Luxury Planner | Ultra-luxury weddings + destination events | Premium clients, high design standards, big-ticket installs | $6K–$15K+ | Warm intro attempt + concise luxury portfolio email + sample kit offer |
| 3 | Eventique | Corporate Event Production | Corporate events + brand experiences | Repeat corporate clients and stage/floor branding | $3K–$10K | Email producer team + LinkedIn/IG touch + 15-min capability call ask |
| 4 | Cristina Verger Event Planning & Production | Luxury Planner | High-end weddings/social events | Fewer but high-value events needing custom floors | $5K–$12K | Personalized IG DM referencing portfolio + tailored email with premium finishes |
| 5 | Amy Katz Events | Planner (Luxury + Mitzvah/Corporate) | Weddings, mitzvahs, milestone and nonprofit events | Great fit for custom dance floors + logo moments | $3K–$9K | IG DM + email with mitzvah/wedding floor examples + follow-up call |
| 6 | Kate Edmonds Events | Luxury Planner | High-end social + corporate events | Repeat high-touch clients with design-heavy installs | $3K–$10K | Email planner directly + send quick lookbook link + phone follow-up |
| 7 | Two Kindred Event Planners | Planner | Weddings, mitzvahs, galas | Recurring social event formats needing dance floors | $2.5K–$8K | IG + email sequence with “white-label production partner” message |
| 8 | Fête NY | Luxury Planner | High-end weddings and social events | Elevated aesthetic, frequent custom floor opportunities | $4K–$12K | Personalized email with 3 mockup concepts + IG engagement first |
| 9 | Brilliant Event Planning | Luxury Planner | Boutique luxury wedding planning | Style-conscious clients; recurring referral network | $3K–$9K | IG DM + intro email + offer 24-hour render turnaround |
| 10 | Andrea Freeman Events | Planner | Weddings, nonprofit + corporate events | Mixed event types = recurring graphics needs | $2K–$7K | Email with segmented offers (wedding/corporate) + call coordinator |
| 11 | Coco Events NYC | Planner | Corporate + social party planning | High cadence and broad vendor relationships | $2K–$8K | IG DM + email with “rush install” USP + follow-up call |
| 12 | Jove Meyer | Planner/Designer | Design-forward weddings + celebrations | Social-first brand; great for Instagrammable floor installs | $3K–$10K | IG-first outreach with visual sample + email with before/after photos |
| 13 | Cerbelli Creative | Luxury/Event Design | Large, high-profile experiential/social events | Big budgets + complex custom fabrication ecosystems | $6K–$20K | Executive email + concise capability deck + referral intro request |
| 14 | Marcy Blum Events | Luxury Planner | Premium weddings + social events | Strong fit for high-end custom dance floor wraps | $5K–$15K | High-touch email + premium material swatch drop-off offer |
| 15 | David Tutera | Luxury Events | Celebrity-style weddings/events | Large design budgets and premium personalization | $6K–$18K | PR/vendor channel email + polished one-page capabilities PDF |
| 16 | Rafanelli Events | Luxury Planner | High-end private + charity + corporate events | Big production environments, multi-element branding | $5K–$15K | Email procurement/production + intro from shared vendor if possible |
| 17 | Chandelier Events | Planner/Designer | Weddings, mitzvahs, experiential events | Recurring social events with floor-centric visual moments | $3K–$9K | IG + email with mitzvah floor package + call production contact |
| 18 | Ali Barone Events | Boutique Planner | Social + corporate events | Boutique planner with repeat local clients | $2K–$7K | Personalized email + IG engagement + quick consult call ask |
| 19 | NY Lux Events | Planner | Weddings, milestone + corporate events | Brand already luxury-positioned; floor wraps align | $3K–$10K | IG DM + email with “luxury texture/finish” options |
| 20 | Sonal J. Shah Event Consultants | Luxury Wedding Planner | High-end wedding productions | Premium wedding clientele with custom décor appetite | $4K–$12K | Email wedding producer + culturally tailored sample concepts |
| 21 | Florie Huppert Design | Planner/Designer | Mitzvah + milestone + corporate events | Frequent dance floor personalization demand | $2K–$7K | IG + email featuring mitzvah logo floor examples |
| 22 | LC Events | Planner | Milestone and birthday events | Repeat celebration format, quick-turn visual upgrades | $1.5K–$5K | IG-first + simple package card + phone follow-up |
| 23 | Julie Lindenman Events | Planner | Social/corporate/nonprofit events | Diverse event mix and recurring production needs | $2K–$8K | Email + IG + offer “event-week rush production window” |
| 24 | Emily Monus Events | Planner | Personalized wedding/event planning | Boutique planner with high personalization demand | $1.5K–$6K | Personalized IG message + case-study email |
| 25 | Dhalia Events | Planner | Bespoke wedding + social planning | High design-focus clients suited for custom floors | $2.5K–$8K | Email with curated image board + IG DM |
| 26 | David Stark Design and Production | Event Design/Production | Immersive, large-scale brand/social events | Strong fit for statement floors in immersive environments | $6K–$20K+ | Email production team + capability reel + shortlist pilot offer |
| 27 | 23 Layers | Experiential Agency | Brand activations + social/corporate | Recurring branded environments needing floor graphics | $4K–$12K | LinkedIn/email producer outreach + IG support proof |
| 28 | Impulse Event Productions | Event Production | Large-scale corporate/charity/social events | Operationally complex projects where reliable print wins | $4K–$12K | Email ops lead + call with installation reliability pitch |
| 29 | AKC Productions | Event Production | Bespoke NYC events | Boutique, design-led projects ideal for custom floor work | $2.5K–$9K | IG + email with design mockup offer |
| 30 | Events & Company (IGC Hospitality) | Hospitality Events | Full-service planning + venues | In-house venue/events ecosystem = recurring demand | $3K–$10K | Email partnerships + venue manager call + “preferred print partner” ask |
| 31 | NYC Event Pro | Event Production | Brand popups + experiential + private events | Frequent branded experiences needing decals/wraps | $2K–$8K | Email + IG + quick turnaround case sample |
| 32 | Wizard Studios | Live Event Production | Corporate/fundraiser/live productions | Staging environments with recurring branded floor needs | $3K–$10K | Email production ops + call technical producer |
| 33 | Ray Bloch Productions | Event Production Agency | Live + corporate + activation events | Repeat enterprise event calendars | $4K–$12K | LinkedIn/email with reliability + white-label install angle |
| 34 | ShimmerNYC | Event Production | Weddings, mitzvahs, milestone, corporate | Fits recurring social event pipeline in NYC | $2K–$8K | IG DM + email with social proof and rush capabilities |
| 35 | NYFF Events | Event Agency | Corporate/social/nonprofit events | Broad event base and recurring opportunities | $2K–$8K | Email agency inbox + follow-up phone with package pricing |
| 36 | RISE & SET | Luxury Experiential Agency | Luxury brand activations | Premium client budgets and visual-first production | $6K–$20K+ | Executive outreach + visual deck + pilot project proposal |
| 37 | ADM Creative Group | Global Events Agency | Corporate/live/marketing events | Large B2B events with branded ground graphics | $5K–$15K | Email strategic partnerships + call production procurement |
| 38 | Marauder | Experiential/Conference Producer | Music/culture conferences + activations | Multi-location event programming and recurring installs | $3K–$10K | Email producer + IG + emphasize multi-venue support |
| 39 | Pretty Good Show | Brooklyn Event Collective | Festivals + immersive + private events | Brooklyn-based creative events, social amplification potential | $2K–$8K | IG-first (brand tone match) + follow-up email with bold visuals |
| 40 | Party Rental Ltd. | Rental Company | Large East Coast event rental provider | Serves many planners; potential channel/referral multiplier | $3K–$10K (per referred job) | Vendor partnership email + branch visit + co-marketing offer |
| 41 | Broadway Party Rentals | Rental Company | Full-service event rentals in NYC market | Deep planner relationships; frequent floor upgrade opportunities | $2.5K–$8K | IG + vendor partnerships email + showroom intro ask |
| 42 | Luxe Event Rentals | Rental Company | Boutique luxury furnishings (Brooklyn) | Aesthetic overlap with premium dance floor installs | $2K–$7K | IG DM + email collab pitch (“bundle lounge + floor”) |
| 43 | Big Dawg Party Rentals | Rental Company | Brooklyn full-service rentals | Local high-volume events and fast-turn opportunities | $2K–$7K | Phone-first local outreach + email packages + IG touch |
| 44 | Atlas Party Rentals | Rental Company | Tents/linens/tableware + event rentals | High event throughput, likely repeat referral source | $2K–$7K | Partnerships email + outbound call to sales team |
| 45 | High Style Event Rentals | Rental Company | Brooklyn furniture + décor rentals | Design-forward installs pair with custom floor wraps | $2K–$7K | IG + email with visual bundle concepts |
| 46 | Ace Party and Tent Rental | Rental Company | NYC upscale tents + event rentals | Large-format events where floor branding adds value | $2K–$8K | Phone + email to account manager + trial referral offer |
| 47 | AllState Party & Tent Rentals | Rental Company | Tents/furniture/decor for NYC events | Broad event footprint and recurring partner potential | $2K–$7K | Partnerships email + follow-up call with trade pricing sheet |
| 48 | Taylor Creative Inc. | Luxury Furniture Rental | Modern lounge/event furniture | Works with top planners, strong aesthetic overlap | $3K–$10K | High-touch vendor intro email + portfolio link + showroom meeting ask |
| 49 | Smith Party Rentals | Rental Company | Tri-state rental provider w/ NYC showroom | Established planner base and recurring event pipeline | $2.5K–$8K | Email showroom sales + call + co-branded sample package |
| 50 | Please B Seated (Elite/PBS Tents & Events) | Rental/Tent Company | Full rental + tent services for NYC/LI/Westchester | Large tented events often need floor graphics/logos | $3K–$10K | Phone + vendor partnerships email + offer first-job preferred pricing |

---

## 2) Outreach Scripts (3 Versions)

### A) Instagram DM Script (short + visual-first)

**Version to send:**

> Hey {{FirstName}} — love the work your team is doing at **{{Company}}** 👏  
> We’re a Brooklyn print partner specializing in **custom floor graphics / dance floor wraps** for weddings, mitzvahs, and brand events (fast turnaround + install-ready).  
> If helpful, I can send **3 mockup ideas** for one upcoming event this week — no pressure.  
> Worth sharing a quick concept?

**Follow-up (48h later):**

> Quick bump in case this got buried — happy to send a few floor concepts sized to your venue format.

---

### B) Email Script (professional + conversion-focused)

**Subject options:**
- `Quick idea for {{Company}} event floors (NYC/Brooklyn)`
- `Fast-turn custom floor graphics for your upcoming events`
- `Partner option: dance floor wraps + branded floor graphics`

**Email body:**

Hi {{FirstName}},

I run production with **INKredible Printing** in Brooklyn. We help event planners and production teams with:

- Custom **dance floor wraps**
- Branded **event floor graphics**
- Fast-turn, install-ready large-format print

Given the style of events your team produces at **{{Company}}**, I think we could be a strong fit — especially for high-impact branded moments and last-minute floor upgrades.

If useful, I can send:
1. 2–3 concept mockups for an upcoming event
2. Typical turnaround windows
3. Quick budget ranges by floor size

Open to a 10-minute intro this week?

Best,  
{{YourName}}  
INKredible Printing  
{{Phone}} | {{Email}} | {{Instagram}}

---

### C) Phone Script (for planner/rental account manager)

**Opening:**

> Hey {{FirstName}}, this is {{YourName}} at INKredible Printing in Brooklyn — did I catch you at a bad time?

**If okay to continue:**

> We support NYC event teams with custom floor graphics and dance floor wraps, usually in the **$1K–$10K+** range depending on size/finish.  
> I’m reaching out because your team at {{Company}} looks like a strong fit for recurring floor installs.

**Qualifying question:**

> Do you have upcoming events where branded/décor floor treatment would add value?

**Offer:**

> I can send a mini package today: sample visuals, turnaround windows, and budget bands. If it looks useful, we can run one pilot job and build from there.

**Close:**

> What’s the best email for you, and should I send examples focused on weddings, mitzvahs, or corporate activations?

---

## 3) Referral Template (for existing clients like Lux Events)

### A) Text / WhatsApp style

> Hey {{ClientName}} — quick favor 🙏  
> We’re expanding our floor graphics side and looking to support more planners/rental teams doing recurring events in NYC/Brooklyn.  
> If 1–2 companies come to mind that care about quality + reliability, would you be open to making a quick intro?  
> I’ll take great care of them.

### B) Email referral ask

**Subject:** `Quick intro request`  

Hi {{ClientName}},

Appreciate all the trust you’ve given us. We’re growing our custom floor graphics offering and are looking for a few more high-quality partners in the NYC event space.

If you know 1–2 planners/rental teams who would benefit from a reliable print partner, would you be open to introducing us?

I can draft a short intro blurb to make it easy.

Thank you — really appreciate it.

— {{YourName}}

### C) Forwardable intro blurb (client can paste)

> Introducing {{YourName}} at INKredible Printing (Brooklyn). They’ve handled our floor graphics / large-format projects and are strong on quality + turnaround. Thought it could be useful for your upcoming events.

---

## 4) Qualification Criteria (Lead Scoring)

## Scoring Model (100 points)

### 1) Recurring Potential — **40 pts**
- 0–10: Occasional one-off events
- 11–25: Regular seasonal events
- 26–40: Monthly/weekly event cadence

### 2) Average Job Size Potential — **30 pts**
- 0–10: Likely <$1.5K floor spend
- 11–20: Typical $1.5K–$4K
- 21–30: Typical $4K–$10K+

### 3) Payment Reliability — **20 pts**
- 0–7: Slow pay / unclear process
- 8–14: Standard terms, occasional delays
- 15–20: Professional PO/AP flow, consistent payments

### 4) Fit + Speed (Operational Match) — **10 pts**
- 0–3: Difficult timing/spec communication
- 4–7: Mostly workable
- 8–10: Clear specs, realistic timelines, repeatable workflows

### Lead Tier Thresholds
- **A-Tier (80–100):** Prioritize immediately; weekly touchpoints
- **B-Tier (60–79):** Nurture; bi-weekly follow-up
- **C-Tier (<60):** Low-touch; monthly check-ins / referral-only

### Red Flags (auto-downgrade)
- Chronic rush + price-only shopping
- Repeated payment issues
- Scope creep without approvals
- Consistent misalignment on production timelines

---

## 5) Execution Plan (recommended)

- Start with **Top 15** accounts (rows 1–15) over next 2 weeks
- Daily cadence: **10 IG touches + 5 emails + 3 calls**
- KPI targets:
  - 30% response rate on warm DM/email
  - 10 discovery calls booked per month
  - 3 pilot jobs/month
  - 1+ recurring account/month

---

## What changed / why it matters / next trigger

### What changed
- Built a complete **Top-50 target account system** for Q4 with account-level fit + value + approach.
- Added ready-to-send scripts (IG, email, phone), referral asks, and scoring model.

### Why it matters
- Directly supports recurring floor-graphics revenue (the highest-margin growth lane).
- Converts outreach from ad-hoc to a repeatable system focused on **$1K–$10K+** jobs.

### Next trigger
- Move top 50 into CRM/tracker and score each lead.
- Begin outreach on Top 15 this week.
- After first 10 calls, refine scripts based on objection patterns.
