# Quote Close-Rate Reason Codes (v1)

Use these exact codes in `templates/quote-close-rate-tracker.csv` for clean weekly analysis.

- `price_too_high` — lost on price
- `turnaround_too_slow` — could not meet deadline
- `spec_mismatch` — required finish/stock/process not matched
- `went_silent` — no response after quote
- `internal_delay` — we replied too slowly
- `chose_existing_vendor` — loyalty/relationship elsewhere
- `budget_froze` — customer paused spend
- `other` — anything else (explain in notes)
