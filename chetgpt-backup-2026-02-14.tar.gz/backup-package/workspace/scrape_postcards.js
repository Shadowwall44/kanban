const puppeteer = require('puppeteer-core');
const fs = require('fs');

async function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function scrapePricing() {
  const browser = await puppeteer.connect({
    browserURL: 'http://localhost:18800',
    defaultViewport: { width: 1280, height: 800 }
  });
  
  const page = await browser.newPage();
  
  const sizes = ['4 x 6', '4 x 9', '5 x 7', '5.5 x 8.5', '6 x 9', '6 x 11'];
  const stocks = ['14 pt. Cardstock', '16 pt. Cardstock', '17 pt. Cardstock'];
  const quantities = ['100', '250', '500', '1000', '2500', '5000'];
  const turnarounds = ['Standard', 'Next Day', 'Same Day'];
  
  const results = [];
  
  try {
    console.log('Loading page...');
    await page.goto('https://www.nextdayflyers.com/postcard-printing/standard-postcards.php', { waitUntil: 'networkidle2', timeout: 60000 });
    await delay(5000);
    
    console.log('Page loaded. Starting data collection...\n');
    
    for (const size of sizes) {
      for (const stock of stocks) {
        for (const quantity of quantities) {
          const row = { size, stock, quantity };
          
          for (const turnaround of turnarounds) {
            try {
              // Select Size
              await page.select('select[name="size"]', size);
              await delay(800);
              
              // Select Stock
              await page.select('select[name="paper_stock"]', stock);
              await delay(800);
              
              // Select Quantity
              await page.select('select[name="quantity"]', quantity);
              await delay(800);
              
              // Select Turnaround
              await page.select('select[name="printing_turnaround"]', turnaround);
              await delay(2000);
              
              // Get price - try multiple selectors
              const price = await page.evaluate(() => {
                const selectors = [
                  '.calc-total-price',
                  '.price-total', 
                  '[data-price]',
                  '.total-price',
                  '.price',
                  '.total'
                ];
                for (const sel of selectors) {
                  const el = document.querySelector(sel);
                  if (el && el.textContent.includes('$')) {
                    return el.textContent.trim();
                  }
                }
                // Try to find any element with dollar sign
                const allElements = document.querySelectorAll('*');
                for (const el of allElements) {
                  if (el.children.length === 0 && el.textContent.includes('$')) {
                    return el.textContent.trim();
                  }
                }
                return 'N/A';
              });
              
              row[turnaround] = price;
              console.log(`${size} | ${stock} | Qty ${quantity} | ${turnaround}: ${price}`);
              
            } catch (e) {
              row[turnaround] = 'Error';
              console.log(`Error: ${size} ${stock} ${quantity} ${turnaround}: ${e.message}`);
            }
          }
          
          results.push(row);
        }
      }
    }
    
    // Save to CSV
    const headers = ['Size', 'Stock', 'Quantity', 'Standard', 'Next Day', 'Same Day'];
    const csv = [headers.join(',')];
    
    for (const row of results) {
      csv.push([
        `"${row.size}"`,
        `"${row.stock}"`,
        row.quantity,
        `"${(row['Standard'] || '').replace(/"/g, '""')}"`,
        `"${(row['Next Day'] || '').replace(/"/g, '""')}"`,
        `"${(row['Same Day'] || '').replace(/"/g, '""')}"`
      ].join(','));
    }
    
    fs.writeFileSync('nextdayflyers_postcards_pricing.csv', csv.join('\n'));
    console.log('\n✓ CSV saved to nextdayflyers_postcards_pricing.csv');
    console.log(`Total rows: ${results.length}`);
    
  } catch (e) {
    console.error('Error:', e);
  } finally {
    await page.close();
    await browser.disconnect();
  }
}

scrapePricing();
