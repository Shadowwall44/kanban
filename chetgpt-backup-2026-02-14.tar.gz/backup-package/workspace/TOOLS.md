# TOOLS.md - Local Setup Notes

## Local LLM (Ollama)
- **Ollama v0.16.1** installed at `~/.local/`
- Server: `127.0.0.1:11434`
- **phi3:mini (3.8B)**: ~7.2 tok/s, ~4.5 GB RAM — best pick for local tasks
- **gemma2:2b (2.6B)**: ~4.4 tok/s, ~3.2 GB RAM — lighter alternative
- Hardware: Dell XPS 8940, i5-11400 (6 cores), 16GB RAM, Intel UHD 730 (CPU-only, no GPU)
- WSL2 gets ~8GB of 16GB physical. 7B+ models borderline unusable.
- Performance tip: increase WSL2 memory to 12GB via `.wslconfig`

## Browser
- Chrome Browser Relay available on port 18792
- Headless Chrome at `/usr/bin/google-chrome-stable`
- Default profile: `openclaw`
- Use for: research, form filling, competitor analysis. NOT for banking/financial accounts.

## QuickBooks OAuth
- Server: `workspace/quickbooks/oauth-server.mjs`
- Credentials: `.secrets/intuit-credentials.json` (chmod 600)
- Sandbox Company ID: 9341456363972482
- Production: Awaiting Intuit compliance review
- Token refresh: `~/.openclaw/skills/quickbooks-api/scripts/refresh-token.sh`

## GitHub
- User: Shadowwall44
- PAT stored in git credential helper
- Repos: kanban, inkredible-tools, inkredible-voice
- Deployment: `gh-pages-deploy` skill (temp dir approach, avoids node_modules contamination)

## APIs & Keys
- **Brave Search**: Configured in openclaw.json
- **Gemini**: API key for embeddings (gemini-embedding-001) + Gemma 3 27B extraction
- **NVIDIA NIM**: Kimi K2.5 for dashboard chatbot — endpoint: `https://integrate.api.nvidia.com/v1/chat/completions`
- **Auth profiles**: `~/.openclaw/agents/main/agent/auth-profiles.json`
  - anthropic:max (subscription token)
  - openai-codex:default (OAuth)
  - google:default (free-tier API key)

## Telegram
- Bot: @AvielAI_Bot
- Owner: Aviel (ID: 517496021, +13475741814)
- Stream mode: partial
- DM policy: pairing

## File Paths
- Workspace: `/home/inkredible/.openclaw/workspace`
- Config: `/home/inkredible/.openclaw/openclaw.json`
- Skills: `/home/inkredible/.openclaw/skills/`
- Sessions: `/home/inkredible/.openclaw/agents/main/sessions/`
- Windows desktop: `/mnt/c/Users/inkre/OneDrive/Desktop/`
