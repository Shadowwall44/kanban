# Extraction Notes — ChetGPT Batch Processing

## What Was Created
- **`extract-invoices.mjs`** — Standalone Node.js batch script for processing invoice PDFs
- Located at: `~/.openclaw/workspace/extract-invoices.mjs`
- **This is NOT part of the INKredible Extractor app** — the original app is untouched

## Why a Separate Script?
The INKredible Extractor is a browser-based React app (upload PDFs in the UI, see results on screen). To process 159 PDFs automatically without clicking through a browser, I wrote a CLI script that:
1. Reads PDF files directly from the `inkredible-invoices/` folder
2. Calls the same Gemini API with the same system prompt from `constants.ts`
3. Outputs CSV + JSON results to `extraction-results/`

## How to Use
```bash
# Extract one vendor at a time
node extract-invoices.mjs Lindenmeyr
node extract-invoices.mjs Ddpmsc
node extract-invoices.mjs Piedmontplastics

# Extract ALL vendors
node extract-invoices.mjs
```

## What's Different from the Original App
| Feature | Original Extractor (App.tsx) | Batch Script (extract-invoices.mjs) |
|---------|------------------------------|-------------------------------------|
| Model | Gemini 2.0 Flash | Gemini 2.5 Flash (2.0 quota was exhausted) |
| Input | Upload via browser UI | Reads from `inkredible-invoices/` folder |
| Output | Browser display + localStorage | CSV + JSON files in `extraction-results/` |
| Rate limiting | 1s spacing | 8s spacing (safer for free tier) |
| Retries | 3 retries (2s, 5s, 10s) | 5 retries (fallback backoff: 3s, 8s, 15s, 30s, 60s; also respects API retryDelay when provided) |
| Prompt | `constants.ts` SYSTEM_PROMPT | Same — reads directly from `constants.ts` |
| Schema | Full response_schema | Same schema |

## Changes Log
- **2026-02-12 5:25 PM** — Created `extract-invoices.mjs`
- **2026-02-12 5:30 PM** — Fixed vendor filter bug (was grabbing all PDFs instead of filtering)
- **2026-02-12 5:32 PM** — Switched from Gemini 2.0 Flash to 2.5 Flash (2.0 daily quota exhausted)
- **2026-02-12 5:32 PM** — Lindenmeyr extraction complete: 15/15 PDFs, 28 line items, 0 failures
- **2026-02-12 5:33 PM** — Started all-vendor run, but rate limits causing ~60% failure rate. Switching to vendor-by-vendor approach.
- **2026-02-12 8:06 PM** — Added dual-key rotation, parsed `retryDelay` support, and increased retries to improve free-tier resilience.
- **2026-02-13 1:02 AM** — Added overnight extraction coverage snapshots (`overnight-extraction-summary-2026-02-13.md`, `overnight-extraction-status.csv`).

## Output Files
- `extraction-results/<vendor>-extracted.csv` — per-vendor extracted rows (current run appends in `--retry-failed` mode)
- `extraction-results/<vendor>-extracted.json` — per-vendor extracted rows as JSON
- `extraction-results/all-extracted.csv` / `all-extracted.json` — when run without a vendor filter
- `extraction-results/progress.json` — live progress for the active run
- `extraction-results/errors.json` — failed files from the latest run
- `extraction-results/overnight-extraction-summary-2026-02-13.md` — human-readable overnight status snapshot
- `extraction-results/overnight-extraction-status.csv` — vendor-level extraction coverage snapshot

## Original App Status
- **INKredible Extractor** at `~/.openclaw/workspace/inkredible-extractor/` is UNCHANGED
- `npm install` was run (node_modules exist)
- Dev server was tested (Vite starts at localhost:5173)
- Gemini API key in `.env`: works but 2.0 Flash daily quota is exhausted (resets tomorrow)

## Next Steps
1. Run remaining vendors one at a time (Ddpmsc, Piedmont, Steadfast, etc.)
2. Compile all results into single Excel/CSV for Aviel to verify
3. Use verified data to fill vault gaps (paper costs, substrate costs)
4. Feed into MIS pricing engine
