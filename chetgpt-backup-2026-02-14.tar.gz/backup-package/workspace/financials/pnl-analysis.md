# INKredible Printing — P&L Analysis
## Period: Jan 2024 – Feb 13, 2026 (~25.5 months, Cash Basis)

### Summary
- **Total Revenue**: $686,179 ($26,909/month avg)
- **Gross Profit**: $374,129 (54.5% margin)
- **Total Expenses**: $366,892
- **Net Operating Income**: $7,237
- **Net Income (after other)**: -$10,746 (donations + depreciation push it negative)

### Revenue Breakdown
- Main Sales (4000): $581,653 (85%)
- Large Format NEW: $67,955 (10%)
- Small Format NEW: $29,521 (4%)
- UPS Shipping: $2,078
- Design Fees: $339
- Etsy: negligible

### COGS Breakdown ($312,050 total — 45.5% of revenue)
- Graphic Design: $67,006 (21.5% of COGS) ← WHO IS THIS?
- Large Format Supplies: $47,983
- Paper Supply: $43,454
- Third Party Printing: $41,820
- Supplies & Materials: $28,379
- Cost Per Click: $26,986
- COGS General: $18,727
- Printing Costs + Afinia: $16,764
- Label Supply: $6,699
- Printing Supplies: $6,654
- Job Supplies: $3,994
- Binding: $1,933
- Printing Services: $1,572
- Seller Fees: $77

### Top Expenses ($366,892 total)
- **Rent: $75,990** (11.1% of rev — $2,980/mo)
- **Salaries/Wages: $41,658** (Brandon + Diandra?)
- **Postage/Shipping: $41,518** (huge — is this pass-through?)
- **Officers Payroll: $39,185** (Aviel — ~$1,537/mo or $18.4K/yr)
- **Auto: $23,043** (high — delivery vehicle?)
- **Meals/Entertainment: $20,766** (⚠️ RED FLAG)
- **Bank Charges: $18,641** (⚠️ RED FLAG — what is this?)
- **Utilities: $14,367** ($563/mo)
- **Travel: $12,481**
- **Payroll Taxes: $9,158**
- **Office Supplies: $8,877 + $2,385**
- **Dues/Subscriptions: $6,204**
- **Medical Insurance: $5,433**
- **Independent Contractors: $4,951 + $1,684**
- **Fuel: $4,736**
- **Telephone: $4,141**
- **Accounting: $4,676**
- **Hartford Insurance: $3,399**

### Red Flags — ANSWERED by Aviel (Feb 13, 7:51 AM)
1. **Graphic Design $67K = Brandon's pay** — Correctly categorized as COGS. ~$2,680/mo. ✅
2. **Bank Charges $18.6K = interest on $43K line of credit** — ~17-18% APR. 🔴 NEEDS REFINANCING. Could save $4-5K/yr at 8-10%.
3. **Meals/Entertainment $20.8K = mostly personal** — 🔴 IRS audit risk. Must separate going forward.
4. **Postage/Shipping $41.5K = Messilot account (biggest customer, monthly recurring, lots of shipping)** — Likely pass-through. Need to confirm Messilot pays for shipping / built into pricing.
5. **Officers Payroll $39K + distributions** = Aviel takes salary + periodic transfers as distributions. Need to track total owner comp.
6. **Third Party Printing $41.8K** — The outsourcing. Good move but need to track margin on these.
7. **Charitable Donations $13.5K = Jewish tithing (maaser)** — Religious obligation but halachically based on NET profit, not gross. Currently donating while net negative. Worth recalibrating with rabbi.

### Still Need from Aviel
- Approximate total distributions taken over this period
- Confirmation: does Messilot pay for shipping or is it built into pricing?
- LOC details: which bank, current rate, when taken out?

### Key Insights
- Company is basically **breaking even** — $7.2K operating income over 2+ years
- Revenue is solid at $27K/month but ALL the profit gets eaten by expenses
- The path to $1-2M revenue requires 3-4x growth
- Current trajectory annualized: ~$323K revenue, ~$0 profit
- Gross margin of 54.5% is decent for printing — problem is expense structure
