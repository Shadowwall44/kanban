# 💡 Idea Capture Queue

> Last updated: 2026-02-14 06:16 PM
> Total ideas: 15 | Queued: 9 | Blocked: 5 | Building: 4 | Implementing: 1 | Done: 1

---

## 🔴 High Priority

### 1. Personal Task App (ADHD-Optimized)
- **Captured:** 2026-02-13
- **Description:** Push-based task app designed for ADHD — gamified with streaks, stats, and dopamine-friendly UX. Not a pull system; tasks come to you.
- **Status:** `queued` 🔒 BLOCKED
- **Priority:** high
- **Depends on:** Therapy notes from Aviel (task structure insights)
- **Notes:** Progress dashboard (#4) is a sub-feature of this. Design around momentum, not willpower.

### 2. Wispr Flow Desktop (Finish & Push)
- **Captured:** 2026-02-13 (older item)
- **Description:** Three repos for desktop Wispr Flow clone still not pushed. Needs finishing and deployment before moving to Android.
- **Status:** `building` 🔒 BLOCKED
- **Priority:** high
- **Depends on:** Dedicated dev session to finish & push all 3 repos
- **Notes:** Blocks Android voice keyboard (#3). This is the critical path.

### 3. Android Voice Keyboard (Wispr Flow IME)
- **Captured:** 2026-02-13
- **Description:** Wispr Flow-style voice input IME for Samsung/Android. System-wide voice-to-text keyboard replacement.
- **Status:** `queued` 🔒 BLOCKED
- **Priority:** high
- **Depends on:** Wispr Flow desktop (#2) finished first
- **Notes:** Target Samsung devices initially. Research Android IME framework.

### 4. Task Notification System (Sub-Agent Visibility)
- **Captured:** 2026-02-13 12:09 PM
- **Description:** Telegram notification every time a sub-agent is spawned or completes. Aviel needs to see delegation happening. Kanban updated simultaneously.
- **Status:** `implementing` ✅
- **Priority:** high
- **Depends on:** Nothing — implementing NOW
- **Notes:** Aviel: "I need to monitor and see if you're actually sending out tasks to sub agents." Trust-building requirement. Also update Kanban board on every task change. 2026-02-14 progress: built `scripts/subagent-visibility-report.mjs` + generated `reports/subagent-visibility-report-2026-02-14.md` to auto-extract spawn/completion proof from session transcripts. 2026-02-14 4:13 PM ET update: shipped `scripts/subagent-visibility-delta.mjs` with persistent state (`.state/subagent-visibility-state.json`) and Telegram-ready delta output (`reports/subagent-visibility-delta-*.md`) so only NEW spawn/completion events are surfaced each run. 2026-02-14 6:15 PM ET update: shipped `scripts/subagent-active-alert.mjs` + report `reports/subagent-active-alert-*.md` to estimate in-flight workload in a rolling window and trigger an alert when active estimate crosses threshold (default 5+), matching Aviel's "5+ tasks running" visibility requirement.

### 5. QuickBooks API Live Integration
- **Captured:** 2026-02-13 (older item)
- **Description:** Connect Mission Control dashboard to live QuickBooks data via Intuit API. Replace manual CSV exports.
- **Status:** `building`
- **Priority:** high
- **Depends on:** Compliance approval + production credential unlock
- **Notes:** Sandbox OAuth is connected. Added token auto-refresh layer (`quickbooks/lib/auth.mjs`, `quickbooks/refresh-token.mjs`, `quickbooks/test-api-auto.mjs`) and verified API calls work with refreshed tokens. Live export bridge shipped: `quickbooks/lib/client.mjs` + `quickbooks/export-live-dashboard-data.mjs` writes to `inkredible-tools/public/data/quickbooks-live.json`. ✅ Dashboard now fetches live JSON with fallback to static sample data (`public/dashboard.html`, `out/dashboard.html`), including live P&L, breakdowns, alerts, balance summary, and ratios. Remaining blocker is production credential unlock from Intuit compliance.

---

## 🟡 Medium Priority

### 5. Dashboard Time Period Filters
- **Captured:** 2026-02-13
- **Description:** Add daily/weekly/monthly/yearly toggle to expense dashboard with trend charts and vendor breakdown views.
- **Status:** `queued` 🔒 BLOCKED
- **Priority:** medium
- **Depends on:** QuickBooks API integration (#4) — needs live data to be useful
- **Notes:** Design filter UI now, wire up when API is ready.

### 6. Personal Progress Dashboard / Tracker
- **Captured:** 2026-02-13
- **Description:** Visual dashboard showing streaks, completion rates, and progress metrics. Needs to look good enough to be motivating.
- **Status:** `building`
- **Priority:** medium
- **Depends on:** Personal task app (#1) architecture decisions
- **Notes:** Prototype v1 shipped standalone at `inkredible-tools/public/aviel-dashboard.html` (also synced to `out/`). Includes daily push planner, wins/confidence logging, streak + execution score, and 14-day history via localStorage. Next step: wire optional JSON export/import + Telegram reminder hooks.

### 7. Calendar Integration for Mission Control
- **Captured:** 2026-02-13
- **Description:** Expand Mission Control schedule view to pull in personal calendar appointments alongside work tasks.
- **Status:** `queued`
- **Priority:** medium
- **Depends on:** Calendar API access (Google Calendar or similar)
- **Notes:** Unified daily view = less context switching.

### 8. Mission Control Org Chart Revision
- **Captured:** 2026-02-13
- **Description:** Rebuild org chart to be role-based instead of model-based, following Alex Finn analysis recommendations.
- **Status:** `done` ✅
- **Priority:** medium
- **Depends on:** Completed (analysis reviewed + implemented)
- **Notes:** Shipped in Mission Control v1.1 with role cards: Quote Calculator, Workflow Operator, Invoice Processor.

### 9. Browser Relay for Usage Tracking
- **Captured:** 2026-02-13
- **Description:** Auto-check claude.ai/settings/usage via Chrome extension browser relay to track API spend without manual screenshots.
- **Status:** `queued`
- **Priority:** medium
- **Depends on:** Chrome extension relay working reliably
- **Notes:** Would replace manual usage calibration in usage-tracker.json.

### 10. Himalaya Email Scanning
- **Captured:** 2026-02-13
- **Description:** Set up Himalaya CLI email client to scan business inbox for quotes, orders, and actionable items.
- **Status:** `queued` 🔒 BLOCKED
- **Priority:** medium
- **Depends on:** Business email credentials + App Password from Aviel
- **Notes:** Himalaya already installed. Just needs auth config.

### 11. Competitor Price Watch
- **Captured:** 2026-02-13 (older item)
- **Description:** Weekly automated scraping of NDF and VistaPrint pricing for competitive intelligence.
- **Status:** `building`
- **Priority:** medium
- **Depends on:** Schedule approval for recurring automation (capture + report)
- **Notes:** v1 foundation shipped: watchlist, snapshot template, diff script, and report output flow in `research/price-watch/` + `scripts/price-watch-diff.js`. 2026-02-14 baseline capture completed (`snapshots/2026-02-14-complete.csv`) with report at `reports/price-watch-2026-02-14-complete.md` and capture notes in `research/price-watch/2026-02-14-vistaprint-capture-notes.md`. Added actionable playbook outputs: `reports/ndf-pricing-playbook-2026-02-14.md`, `research/price-watch/ndf-standard-min-price-anchors-2026-02-14.csv`, and `research/price-watch/ndf-vs-vistaprint-matchups-2026-02-14.csv`. ✅ 2026-02-14 execution layer added: `research/price-watch/live-quote-tier-playbook-2026-02-14.md`, `templates/quote-close-rate-tracker.csv`, and `templates/quote-close-rate-reason-codes.md` so quotes can be tracked by tier and converted into weekly close-rate optimization.

---

## 🟢 Low Priority

### 12. Content Factory / Instagram Pipeline
- **Captured:** 2026-02-13 (older item)
- **Description:** Build content creation pipeline with Brandon as content creator. Systematize Instagram posting and content repurposing.
- **Status:** `queued`
- **Priority:** low
- **Depends on:** Brandon availability, content strategy defined
- **Notes:** Need to define brand voice, posting cadence, content types.

### 13. App Review Sessions
- **Captured:** 2026-02-13
- **Description:** Scheduled walkthroughs of each built tool to test functionality, catch bugs, and identify refinements.
- **Status:** `queued`
- **Priority:** low
- **Depends on:** Calendar slot committed (recurring)
- **Notes:** Process, not a build. Maybe biweekly 30-min sessions.

### 14. Weekly Review Process
- **Captured:** 2026-02-13
- **Description:** Structured weekly review of all tools and systems — what's working, what's collecting dust, what needs attention.
- **Status:** `queued`
- **Priority:** low
- **Depends on:** Review template created, calendar slot committed
- **Notes:** Complements App Review Sessions (#13). Could be same session or adjacent.

---

## 📊 Status Legend

| Status | Meaning |
|---|---|
| `queued` | Captured, not started |
| `researching` | Actively investigating approach |
| `building` | In development |
| `done` | Shipped and working |
| 🔒 BLOCKED | Waiting on dependency |

---

## 🔄 Quick Blockers Summary

| # | Idea | Blocked By |
|---|---|---|
| 1 | Personal Task App | Therapy notes from Aviel |
| 2 | Wispr Flow Desktop | Dev time to finish 3 repos |
| 3 | Android Voice Keyboard | Wispr Desktop (#2) |
| 4 | QuickBooks API | Intuit Developer Portal signup |
| 5 | Dashboard Filters | QuickBooks API (#4) |
| 10 | Himalaya Email | Business email creds from Aviel |
