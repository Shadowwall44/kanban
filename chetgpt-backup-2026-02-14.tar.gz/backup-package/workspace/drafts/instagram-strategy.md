# Instagram Growth Strategy for INKredible Printing
## Modeled on the Marie’s Touch Party Shop Playbook (visual-first, installation-led growth)

## 1) Executive Summary
INKredible can grow Instagram by becoming **the most visible “event transformation printer” in Brooklyn/NYC**—not by posting products, but by posting **finished event results** (especially floor wraps and full installs) the way Marie’s Touch does.

### What Marie’s Touch does well (and what to adapt)
Observed strengths from @mariestouchpartyshop:
- **Reels-heavy posting** with dramatic finished visuals
- **High frequency + consistency**
- **Strong social proof** (planner/event tags, reviews, highlights)
- **Narrative captions** that explain design intent, build complexity, and business value
- **Clear niche positioning** (fabrication studio for event experiences)

### INKredible opportunity
INKredible already has the technical edge:
- **HP Latex 700W** (white ink, premium wide-format, specialty media)
- **Roland VG2-540** (print + cut, contour precision)
- **Konica Minolta C3080** (fast high-quality small format)

But current marketing is under-leveraged (mostly reposts when tagged). The strategy below turns existing jobs into a repeatable content engine that attracts:
1. Event planners
2. Luxury rental companies
3. Premium direct clients planning high-budget events

---

## 2) Content Strategy: What to Post + How Often

## Core content mix (monthly)
Use a **70 / 20 / 10 model**:
- **70% Proof-of-result content** (finished installs, before/after, room reveals)
- **20% Process + expertise** (printing, cutting, install methods, materials, quality control)
- **10% Conversion content** (offers, booking windows, testimonials, “how to book”)

## Posting cadence (realistic but aggressive)
- **Reels:** 4 per week (primary growth engine)
- **Carousel posts:** 2 per week (portfolio + educational case studies)
- **Stories:** Daily (5–12 frames on active days; minimum 3 on light days)
- **Pinned posts:** 3 always pinned
- **Live/Collab Reel:** 2 per month (with planners/rental vendors)

## Recommended weekly structure
- **Mon:** Reel – finished event transformation (hero reveal)
- **Tue:** Story sequence – behind the scenes + poll (“Which floor style?”)
- **Wed:** Carousel – case study (challenge → solution → result)
- **Thu:** Reel – install timelapse (print-to-floor)
- **Fri:** Reel – luxury detail shots + testimonial quote
- **Sat:** Stories – on-site install snippets + vendor tags
- **Sun:** Carousel or Reel – best-of-week recap / planner spotlight

---

## 3) Content Types (Reels, Stories, Posts)

## Reels (top priority)
Reels should be **9:16 vertical, hook in first 1 second**, and show “WOW” fast.

### Reel concepts to repeat
1. **Floor Wrap Transformation**
   - Start with plain floor → final luxury install
   - Text hook: “From blank floor to $X-worthy centerpiece in 6 hours”
2. **Before/After Venue Flip**
   - Split-screen venue before + after graphics installed
3. **Print-to-Install Journey**
   - HP/Roland printing clips + trimming + transport + install reveal
4. **Planner Win Reel**
   - “How we helped [planner handle] deliver this setup under deadline”
5. **Detail Reel**
   - White ink, contour cuts, texture closeups, seams, edge finishing
6. **Reaction Reel**
   - Guest/client reactions to floor graphics

## Stories (daily trust builder)
Use Stories to show recency and reliability.

Story pillars:
- In-production proof (“Today’s print queue”)  
- On-site install snippets  
- Vendor/planner shoutouts  
- Polls/questions (“Round or monogram floor center?”)  
- FAQ cards (turnaround, file setup, delivery zones)

## Feed posts / carousels (authority + saves)
Use carousels for high-intent users who evaluate vendors.

Carousel formats:
- “5 Floor Wrap Styles for Luxury Events”
- “Case Study: 24-hour turnaround for Brooklyn ballroom event”
- “Material guide: when to use matte vs gloss vs textured vinyl”
- “Event signage package examples by budget tier”

---

## 4) How to Photograph Floor Graphics + Installations for Maximum Impact

## Shot list for every job (non-negotiable)
Capture these every time:
1. **Hero wide shot** (full room, clean composition)
2. **Elevated angle** (shows floor graphic geometry/pattern)
3. **Low-angle shot** (adds scale and drama)
4. **Detail closeups** (print quality, edges, texture, white ink effects)
5. **People-in-frame shot** (scale + emotion)
6. **Brand/context shot** (signage + floor + decor together)
7. **5–10 sec video clips** of each phase (for reels)

## Capture rules (simple but critical)
- Shoot vertical first (9:16), then horizontal backups
- Use lens equivalent around 24–28mm for room depth
- Stabilize: tripod/gimbal whenever possible
- Get one clean room pass **before guests enter**
- Turn off clutter (bins, tape rolls, cases) before hero shot
- Record in 4K when possible; export 1080x1920 for IG
- Avoid blown highlights on glossy floors (slight underexposure helps)

## On-site content workflow (10-minute protocol)
- 3 min: clean hero photos
- 3 min: before/after angle match
- 2 min: detail clips
- 2 min: planner/vendor tag clip (“with @plannername”)

This tiny system creates enough assets for 3–5 posts from one job.

---

## 5) Hashtag Strategy for Brooklyn/NYC Events Market

Hashtags should be targeted, rotated, and tied to buyer intent (not generic spam).

## Framework per post (10–18 tags)
- **3–5 Geo tags** (Brooklyn/NYC)
- **4–6 Service tags** (floor wraps, signage, backdrops)
- **2–4 Audience tags** (event planners, rentals)
- **1–3 Occasion tags** (wedding, mitzvah, sweet 16, corporate)

## Core NYC/Brooklyn hashtag bank
Geo:
- #BrooklynEvents
- #BrooklynEventPlanner
- #NYCEvents
- #NYCEventPlanner
- #BrooklynWeddings
- #NYCWeddings
- #NYCSmallBusiness

Service:
- #DanceFloorWrap
- #CustomDanceFloor
- #EventSignage
- #BackdropDesign
- #StepAndRepeatNYC
- #CustomVinylGraphics
- #WideFormatPrinting

Audience/industry:
- #EventPlannersOfInstagram
- #LuxuryEventPlanner
- #EventProfs
- #NYCVendors
- #PartyRentalNYC

Occasion:
- #Sweet16NYC
- #MitzvahPlanner
- #LuxuryBabyShower
- #WeddingReceptionDecor
- #CorporateEventDesign

## Hashtag best practice
- Build 6–8 rotating hashtag sets (not one repeated block)
- Keep at least 30–40% unique tags per post
- Put niche + geo tags first; broad tags last
- Track which tags correlate with profile visits and DMs

---

## 6) How to Attract Event Planners Specifically

Event planners care about: reliability, speed, quality, and vendor professionalism.

## Planner-focused positioning
Profile should say (in plain language):
- What you do: custom event print + installs
- Where you do it: Brooklyn/NYC
- For whom: planners + luxury events
- How to book: DM + link + fast quote turnaround

## Planner acquisition playbook
1. **Tag every planner/vendor involved in each project**
2. **Use Collab Post feature** with planner accounts (shared audience)
3. **Weekly planner outreach:**
   - Engage with 15 target planners/week (meaningful comments, not emojis)
   - DM 5 planners/week with relevant work sample
4. **Planner spotlight series:**
   - “Planner of the Week” Story/Reel featuring their event and credits
5. **Proof-based content:**
   - Post deadlines met, load-in speed, install reliability, teardown cleanliness
6. **Fast-response SLA:**
   - Reply to planner DMs within 1 business hour during workday

## Suggested DM opener (non-spam)
“Hey [Name], loved the design direction on your [event type] at [venue]. We specialize in premium floor wraps/signage installs in Brooklyn + NYC. If useful, I can send a quick lookbook with event-ready options and turnaround windows.”

---

## 7) Realistic Growth Timeline (from low activity to meaningful engagement)

Assuming INKredible starts from low posting consistency and limited current engagement.

## Phase 1: Foundation (Weeks 1–4)
Goals:
- Profile optimization complete
- 20+ high-quality posts published
- Content system running weekly

KPIs:
- Consistent posting cadence achieved
- Reach begins expanding beyond followers
- First planner DMs from proactive outreach

## Phase 2: Consistency + Social Proof (Months 2–3)
Goals:
- 35–50 additional feed posts/reels
- Highlights organized (Floors, Backdrops, Reviews, Process, How to Book)
- 8+ planner/vendor collab tags per month

KPIs:
- Engagement rate on strong posts: 4%+
- 5–15 saves on carousel case studies
- 3–8 qualified inquiries/month from Instagram

## Phase 3: Momentum + Lead Engine (Months 4–6)
Goals:
- Establish recognizable “INKredible look”
- Repeat inbound from planners/rental companies
- Regular bookings that cite Instagram discovery

KPIs:
- 8–20 qualified inquiries/month (depending on event season)
- 2–6 higher-ticket jobs/month influenced by Instagram
- Consistent vendor referrals and story mentions

### What “meaningful engagement” should mean for INKredible
- Frequent saves/shares from planners
- Repeat comments from local event pros
- Monthly inbound inquiries tied to specific posted installs
- At least 1–2 partnership conversations/month with planner/rental brands

---

## 8) Role Split: What Brandon (COO) Handles vs What Needs Aviel

## Brandon (COO) can own
Operational + consistency functions:
- Build weekly content calendar
- Make sure every install is captured using the shot list
- Coordinate photo/video capture by team or freelancer
- Upload/schedule posts and stories
- Manage hashtag rotation sheets
- Daily engagement block (comments, tags, reposts)
- Basic inbound DM triage + quote intake routing
- KPI tracking dashboard (weekly)

## Aviel should own
High-leverage brand + relationship functions:
- Final brand voice and positioning decisions
- Relationship-building with top planners/luxury vendors
- Strategic collab approvals and premium partnerships
- Offer/package architecture (pricing presentation, premium bundles)
- Reviewing monthly analytics and adjusting growth strategy
- Closing high-value partner conversations

## Optional support hire (recommended)
Part-time content creator/editor (8–12 hrs/week):
- Reel editing
- Caption formatting
- Story packaging
- Thumbnail consistency

This keeps Brandon out of editing bottlenecks and preserves execution speed.

---

## 9) 30-Day Action Plan (Practical Launch)

Week 1
- Optimize bio, link, highlights, pinned posts
- Create 3 content templates (Reel, carousel, story)
- Build hashtag banks and caption structure

Week 2
- Publish 4 reels + 2 carousels
- Launch planner outreach (5 DMs + 15 engagements)
- Start “Project of the Week” series

Week 3
- Publish 4 reels + 2 carousels
- Post 1 testimonial/review proof asset
- Add 1 planner collab post

Week 4
- Publish 4 reels + 2 carousels
- Review analytics (reach, saves, DMs, follows)
- Double down on top 3 content formats

---

## 10) Non-Negotiables for INKredible’s Instagram Success
1. **No more random repost-only presence**
2. **Every major install must generate content assets**
3. **Reels-first execution every week**
4. **Planner/vendor tags on every relevant post**
5. **Fast DM response + clear booking CTA**
6. **Monthly review and iteration, not “set and forget”**

If INKredible executes this consistently for 90–180 days, Instagram can become a real lead channel (not just a portfolio archive), especially for higher-ticket dance floor wraps and event transformation packages.