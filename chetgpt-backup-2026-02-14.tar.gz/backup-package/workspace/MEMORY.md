# MEMORY.md — ChetGPT Permanent Brain

> Curated long-term memory. Survives every compaction. Update regularly.
> Last updated: 2026-02-14

---

## Owner
- **Name**: Aviel
- **Location**: Brooklyn, NY
- **Phone**: +13475741814
- **Telegram ID**: 517496021
- **Business**: INKredible Printing (owner)
- **Family**: Wife, daughter (6), son (4), baby (8 months)
- **Observes Sabbath**: Friday sundown → Saturday sundown (no electronics for Aviel; ChetGPT works 24/7)

## Business — INKredible Printing
- **What**: Custom printing shop — dance floor wraps, signage, fabric printing, business cards, banners
- **Team**: Brandon (COO, $33/hr, PARTNER not employee), Diandra (secretary, $15/hr)
- **Store hours**: Mon–Thu 10am–6pm, Fri 10am–2pm, Sat–Sun closed
- **Revenue**: ~$686K annual, ~$27K/month average
- **Gross margin**: 54.5%
- **Net income**: -$10.7K (negative — debt servicing)
- **Total debt**: ~$174K
- **Checking**: -$14K (overdrawn)
- **Cash tracking gap**: Lots of cash income NOT in QuickBooks. Makes financials look worse than reality.

### Machines
- Konica Minolta AccurioPress C3080 (small format digital press, click charge $0.045/color)
- Roland VG2-540 (wide format, print & cut)
- HP Latex 700W (wide format, latex ink, white ink capable)
- Intec ColorCut FB550 (digital die cutter, small format card stock only)
- Triumph 5260 (guillotine cutter)

### Money Makers
- **Floor graphics** = biggest money maker. ONE job = $1K-$10K+. Good month = floor graphic jobs. Bad month = no floor graphics.
- **Target clients**: Event planners, rental companies, luxury events (Lux Events = new client via Instagram)
- **Repeat customers are key** — rental/event people come back monthly
- **Outsourcing small format**: Started sending to wholesale trade printer — huge stress relief
- **Konica C3080**: Constant jamming, time sink for small format. Large format = real margin.

### Pricing Model
- Three-tier markup against NextDayFlyers (NDF):
  - Opening: NDF + 25%
  - Target: NDF + 10%
  - Floor: NDF base
- Market is negotiation-heavy Brooklyn print shop; customers anchor to competitors

## Aviel — Personal Profile

### ADHD & Work Style
- Has ADHD — needs bite-sized tasks with clear "done" criteria
- Experiences "all or nothing" momentum collapse — missing a day → weeks of abandonment
- Needs system-oriented (not goal-oriented) approaches
- Recovery: no-guilt re-entry ramps — summarize where left off, suggest smallest next step
- **Redirect obsessiveness toward systems/organization** — Aviel's own insight, superpower not problem
- Uses TickTick for task management
- Biggest risk: starting 10 things, finishing none. Help him stay focused.

### Emotional Profile
- "I'm never confident and now I want to be confident"
- "I need you to help me become confident and organized"
- Building things = identity-level fulfillment
- MIS isn't just a product — it's proving to himself he can build something great
- Financial fear: was "too scared to look" at finances. Approached with gentleness.
- Personal tasks = executive dysfunction (no dopamine). Business gives external accountability.

### Key Relationships
- **Wife**: Help him be present. Don't enable late-night work sessions.
- **Brandon**: Partner, not employee. "He's always going to be right next to me." Has QuickBooks access.
- **Mom**: Not doing great health-wise. Aviel feels guilty about not being more present. Gentle reminders to call.
- **Daughter (6)**: Takes bus to school
- **Son (4)**: Aviel drives to school (5 min)
- **Baby (8 months)**: Baby is his alarm clock (6-6:30 AM)

### Goals (from Brain Dump)
1. **Financial peace of mind** — money in the bank, wake up without worry
2. **MIS system** — custom built, then sell to other print shops (Phase 1: INKredible, Phase 2: commercial)
3. **Wispr Flow clone** — "My first official app, don't let me give up on it." Identity-level.
4. **Enjoy life more** — "that's the big goal"
5. **Be the best version of himself** — confidence, organization, presence
6. **$1M revenue** — scale through systematization

### Communication Preferences
- Be direct, skip pleasantries
- Lead with answers, then explain
- ONE thing per day when pushing tasks (ADHD rule)
- Format for TickTick when creating task lists
- Mobile-first (Samsung Galaxy Z-Fold 7, Samsung Internet browser)
- Learns by doing — give exact commands to copy-paste

## ChetGPT Identity & Rules

### Who I Am
- Name: Chet (ChetGPT)
- Role: COO advisor + business/life coach + operations assistant
- Telegram: @AvielAI_Bot
- Two hats: Operations (execute) + Coach (advise)

### Permanent Operating Rules
- **Brain (Opus) NEVER does hands-on work**: Browser automation, coding, file work = sub-agents. Exception: <10 clicks remaining.
- **Brain designs ALL skills personally**: Strategic work, not delegated.
- **Respond first, work second**: Never chain tool calls before Aviel sees a reply.
- **COO drives the agenda**: Don't ask "what do you want to do" — push highest-impact next action.
- **Self-learning mandate**: Every correction → ask WHY → update behavior permanently.
- **Proactive value creation**: "What gets Aviel to $1M faster that he hasn't thought of yet?" → build it overnight.
- **20-min status pings when Aviel active**: Push updates, don't wait to be chased.
- **Always have sub-agents working**: No dead time. Idle = dispatch on backlog.
- **Stop validating, start executing**: No "you're right" filler.
- **Auto-route tasks**: Detect work vs personal board automatically.
- **Verification loop**: Write → read back → confirm.
- **Enhancement Loop for all features**: Ask + Answer + Recommend → confirm → research → build.
- **Sub-agent notification format**: Spawn: 🤖 name | 📋 task | 🧠 model | ⏱️ ETA. Complete: ✅ name | 🧠 model | 📄 result.
- **Exhaust own troubleshooting before asking Aviel**
- **Sabbath external rule**: No actions visible to non-Aviel humans. Internal work continues 24/7.

### Model Routing
- Brain: Opus 4.6 (PERMANENT DEFAULT)
- Sub-agents/crons: Codex 5.3 via OpenAI OAuth
- Lightweight: Codex Mini via OpenAI OAuth
- Dashboard chatbot: Kimi K2.5 via NVIDIA NIM
- Invoice extraction: Gemma 3 27B via Google AI free tier
- Heartbeat: Haiku
- **ALL models are subscription or free tier — no pay-per-token**

## Active Projects & Status

### QuickBooks API
- Sandbox CONNECTED ✅ (Company ID: 9341456363972482)
- Dashboard live bridge + UI wiring COMPLETE in sandbox ✅ (`quickbooks/export-live-dashboard-data.mjs` → `inkredible-tools/public/data/quickbooks-live.json` → `dashboard.html`)
- Production: Compliance questionnaire SUBMITTED, awaiting Intuit review (1-5 business days)
- Credentials: `.secrets/intuit-credentials.json` (chmod 600)
- OAuth server: `workspace/quickbooks/oauth-server.mjs`

### Repos & URLs
- **Kanban**: github.com/Shadowwall44/kanban → shadowwall44.github.io/kanban/work.html | personal.html
- **INKredible Tools**: github.com/Shadowwall44/inkredible-tools → shadowwall44.github.io/inkredible-tools/
  - Hub: /inkredible-tools/
  - Dashboard + AI Chat: /inkredible-tools/dashboard.html
  - Second Brain: /inkredible-tools/second-brain/
  - Mission Control: /inkredible-tools/mission-control.html
- **INKredible Voice**: github.com/Shadowwall44/inkredible-voice (desktop voice-to-text, audit complete)
- **GitHub user**: Shadowwall44

### Custom Skills (installed at ~/.openclaw/skills/)
1. gh-pages-deploy — deploy.sh + repo-map + troubleshooting
2. inkredible-context — machines, pricing, repos references
3. origin-design-system — design tokens, components, responsive
4. mission-control-sync — sync.sh + schema (jq-based)
5. quickbooks-api — refresh-token.sh + endpoints + oauth
6. deep-research — structured multi-source research methodology
7. coach-business — E-Myth, EOS/Traction, Hormozi, GROW model (INKredible-tailored)
8. coach-personal — ADHD/Barkley EF model, Atomic Habits, Tiny Habits, Fogg B=MAP
9. coach-financial — Profit First, debt snowball, cash flow management

### Key Files
- Brain dump: `memory/brain-dump-01.md`
- Self-improvement: `memory/self-improvement.md`
- Learning files: `memory/engineer-lessons.md`, `memory/research-lessons.md`, `memory/operations-lessons.md`
- Idea queue: `workspace/idea-queue.md` (15 items)
- Financial analysis: `workspace/financials/pnl-analysis.md`
- Skill proposals: `workspace/research/skill-proposals.md` (12 skills, 3 tiers)
- Zoho blueprint: `workspace/research/zoho-mis-blueprint.md`

### Goal Engine — ALL 10 ITEMS COMPLETE (Feb 14 overnight)
- Q1 ✅ Financial Command Center (`workspace/financial-command-center-v1.md`)
- Q2 ✅ Weekly Finance Scoreboard (`workspace/weekly-finance-scoreboard-template.md`)
- Q3 ✅ Floor Graphics Pipeline (`workspace/floor-graphics-pipeline-system.md`)
- Q4 ✅ Top-50 Target Accounts (`workspace/top-50-target-accounts.md`)
- Q5 ✅ Brandon Content OS 90-day (`workspace/brandon-content-os-90-day.md`)
- Q6 ✅ DM-to-Quote SOP (`workspace/dm-to-quote-sop.md`)
- Q7 ✅ MIS v1 Scope Lock (`workspace/mis-v1-scope-lock.md`)
- Q8 ✅ Floor Calendar + Quote Analytics (`workspace/mis-floor-calendar-quote-analytics-spec.md`)
- Q9 ✅ Wispr Release Readiness (`workspace/wispr-release-readiness-audit.md`)
- Q10 ✅ ADHD Execution System (`workspace/adhd-execution-system.md`)

### Also Completed Feb 14 Overnight
- MEMORY.md created (permanent brain)
- Session memory search enabled
- OpenClaw updated 2026.2.9 → 2026.2.13
- All workspace MD files rewritten (IDENTITY, USER, AGENTS, TOOLS, SOUL)
- BOOTSTRAP.md deleted
- Alex Finn "6 Use Cases" transcript + deep INKredible analysis
- Goal-driven roadmap built (8 goals, priority-scored)
- Mission Control status.json updated + deployed

### Blocked Items
- QuickBooks production credentials (awaiting Intuit review)
- Personal task system (therapy notes would refine Q10, but v1 built without them)
- Android keyboard (finish desktop Wispr Flow first — E-Myth)
- Brandon meeting recording (on Aviel's phone, not uploaded)
- Wispr Flow repos (Aviel needs to push research + Developer Mode folders)

### Feb 14 Afternoon Completions
- ✅ NDF Pricing Database — 4,086 price points across 10 products (Excel + CSV + JSON)
- ✅ NDF Pricing Playbook — competitor analysis, quote guardrails, objection scripts
- ✅ Coaching Skills Suite — 4 skills, 1,265 lines, all framework-sourced
- ✅ Emergency Stop Protocol — "STOP ALL" kill switch + 8 immutable control principles
- ✅ Security Audit — 0 critical issues
- ✅ Aviel Report v1 — living progress document (`memory/aviel-report.md`)
- ✅ Nightly Digest Cron — 8:30 PM daily
- ✅ Review Queue — 12 items loaded for post-Shabbat implementation walkthrough
- ✅ Kanban board FINALLY updated (22 operations, 95 tasks)

### Post-Shabbat Priorities
1. Implementation walkthrough with Aviel (Review Queue, one item at a time)
2. Test coaching skills in live conversation
3. WHY MEMORY.md wasn't created earlier — judgment failure discussion
4. Profit First conversation (financial coaching)
5. Aviel Dashboard build (personal progress visualization)

## Key Decisions Log
- Custom MIS over SaaS ($0 vs $6K-24K/3yr)
- Separate apps from Kanban (inkredible-tools = own repo)
- Zoho as feature blueprint, NOT subscription
- Sandbox first, production later for QuickBooks
- ALL crons on Codex — approved by Aviel
- Heartbeat intentionally empty — crons are more precise
- Kanban auto-sync via cron every 30 min
- Post-Shabbat two-tier timing: autonomous = 20 min after, Aviel tasks = 2 hours after
- Skills serve BOTH Brain and sub-agents
- Instagram strategy drafted but not yet executing
- Coaching skills use real frameworks (Hormozi, Gerber, Wickman, Barkley, Clear, Fogg, Michalowicz)
- Aviel wants AI safety controls — Emergency Stop Protocol is IMMUTABLE
- Review Queue serves items one at a time via Telegram (ADHD-friendly)
- Building ≠ Implementing — shift focus to helping Aviel USE what's built
- Voice notes work for coaching sessions — low friction, ADHD-friendly
- Monitor @steipete (Peter Steinberger, OpenClaw creator) on X for updates — include in morning briefs
- Reverse prompting is now SYSTEMATIC — proactively recommend next actions after every task/session
