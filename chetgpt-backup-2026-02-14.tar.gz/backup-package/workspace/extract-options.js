/**
 * Alternative: Manual Price Extraction Helper
 * 
 * Run this in Antigravity to help extract pricing from NextDayFlyers
 * Uses the site structure without requiring full browser automation
 */

const axios = require('axios');
const cheerio = require('cheerio');
const XLSX = require('xlsx');
const fs = require('fs');

// Pages to check for embedded pricing data
const PAGES = [
  'https://www.nextdayflyers.com/postcard-printing/standard-postcards.php',
  'https://www.nextdayflyers.com/marketing-materials/business-flyers.html',
  'https://www.nextdayflyers.com/catalogs-and-booklets/booklets.html',
  'https://www.nextdayflyers.com/boxes-and-packages/hang-tags.html',
];

async function extractFromPage(url, productName) {
  console.log(`\n📄 Checking: ${productName}`);
  
  try {
    const response = await axios.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    
    const $ = cheerio.load(response.data);
    
    // Extract calculator configuration
    const configScript = $('script').filter((i, el) => {
      return $(el).html().includes('calculator_widget') || 
             $(el).html().includes('price_data_override');
    });
    
    const configHtml = configScript.html() || '';
    
    // Look for product info
    const data = {
      product: productName,
      url: url,
      sizes: [],
      paperStocks: [],
      coatings: [],
      quantities: [],
      turnarounds: [],
      prices: [],
      scrapedAt: new Date().toISOString()
    };
    
    // Extract size options
    try {
      $('[id*="attr_container_3"] .attr-value, #attr3 option').each((i, el) => {
        const value = $(el).data('value') || $(el).attr('value');
        const display = $(el).data('display') || $(el).text() || String($(el).attr('aria-label') || '');
        if (value && display && !data.sizes.find(s => s.value === value)) {
          data.sizes.push({ value, display: String(display).trim() });
        }
      });
    } catch (e) {}
    
    // Extract paper stock options
    try {
      $('[id*="attr_container_338"] .attr-value, #attr338 option').each((i, el) => {
        const value = $(el).data('value') || $(el).attr('value');
        const display = $(el).data('display') || $(el).text() || String($(el).attr('aria-label') || '');
        if (value && display && !data.paperStocks.find(p => p.value === value)) {
          data.paperStocks.push({ value, display: String(display).trim() });
        }
      });
    } catch (e) {}
    
    // Extract coating options
    try {
      $('[id*="attr_container_339"] .attr-value, #attr339 option').each((i, el) => {
        const value = $(el).data('value') || $(el).attr('value');
        const display = $(el).data('display') || $(el).text() || String($(el).attr('aria-label') || '');
        if (value && display && !data.coatings.find(c => c.value === value)) {
          data.coatings.push({ value, display: String(display).trim() });
        }
      });
    } catch (e) {}
    
    // Extract quantity options
    try {
      $('[id*="attr_container_5"] .attr-value, #attr5 option').each((i, el) => {
        const value = $(el).data('value') || $(el).attr('value');
        const display = $(el).data('display') || $(el).text() || String($(el).attr('aria-label') || '');
        if (value && display && !data.quantities.find(q => q.value === value)) {
          data.quantities.push({ value, display: String(display).trim() });
        }
      });
    } catch (e) {}
    
    // Extract turnaround options
    $('input[name*="333-option"]').each((i, el) => {
      const value = $(el).attr('value');
      const label = $(el).closest('label').find('.radio-label').text();
      if (value && label && !data.turnarounds.find(t => t.value === value)) {
        data.turnarounds.push({ value, display: label.trim() });
      }
    });
    
    // Look for any displayed prices
    $('[id*="price"], .price, [class*="price"]').each((i, el) => {
      const text = $(el).text().trim();
      if (text.match(/\$\d+/)) {
        data.prices.push(text);
      }
    });
    
    console.log(`   Sizes: ${data.sizes.length}`);
    console.log(`   Papers: ${data.paperStocks.length}`);
    console.log(`   Coatings: ${data.coatings.length}`);
    console.log(`   Quantities: ${data.quantities.length}`);
    console.log(`   Turnarounds: ${data.turnarounds.length}`);
    
    return data;
    
  } catch (error) {
    console.error(`   Error: ${error.message}`);
    return { product: productName, url, error: error.message };
  }
}

async function main() {
  console.log('📊 NextDayFlyers Price Extractor');
  console.log('================================\n');
  
  const results = [];
  
  for (const page of PAGES) {
    const productName = page.split('/').pop().replace('.php', '').replace('.html', '');
    const data = await extractFromPage(page, productName);
    results.push(data);
  }
  
  // Save JSON
  fs.writeFileSync('extracted-options.json', JSON.stringify(results, null, 2));
  console.log('\n💾 Saved to extracted-options.json');
  
  // Create summary Excel
  const workbook = XLSX.utils.book_new();
  
  for (const result of results) {
    if (result.error) continue;
    
    const sheetName = result.product.substring(0, 30).replace(/[\/\\?*\[\]]/g, '_');
    
    // Options sheet
    const optionsData = [];
    
    result.sizes.forEach(s => {
      optionsData.push({ Type: 'Size', Option: s.display, Value: s.value });
    });
    result.paperStocks.forEach(p => {
      optionsData.push({ Type: 'Paper Stock', Option: p.display, Value: p.value });
    });
    result.coatings.forEach(c => {
      optionsData.push({ Type: 'Coating', Option: c.display, Value: c.value });
    });
    result.quantities.forEach(q => {
      optionsData.push({ Type: 'Quantity', Option: q.display, Value: q.value });
    });
    result.turnarounds.forEach(t => {
      optionsData.push({ Type: 'Turnaround', Option: t.display, Value: t.value });
    });
    
    if (optionsData.length > 0) {
      const sheet = XLSX.utils.json_to_sheet(optionsData);
      XLSX.utils.book_append_sheet(workbook, sheet, sheetName);
    }
  }
  
  XLSX.writeFile(workbook, 'nextdayflyers-options.xlsx');
  console.log('📊 Saved to nextdayflyers-options.xlsx');
  
  console.log('\n⚠️  Note: Full pricing requires browser automation.');
  console.log('   Run scrape-prices.js with Puppeteer for complete data.');
}

main().catch(console.error);
