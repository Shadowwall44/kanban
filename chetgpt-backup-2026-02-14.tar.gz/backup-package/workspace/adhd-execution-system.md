# Aviel’s ADHD Execution System v1
**Q10 — Push Planner + Confidence Scorecard**  
**Built for:** Aviel (not generic ADHD advice)  
**Date:** 2026-02-14  

---

## Why this system exists (for YOU)
You don’t have a motivation problem. You have an **activation + momentum protection** problem.

Your pattern:
- You can enter intense flow.
- A disruption happens (kids, work fire, fatigue).
- Momentum drops.
- One missed day feels like failure.
- Then avoidance stretches to days/weeks.

This system is designed to stop that loop.

**Core rule:** We do not chase perfect days. We protect **restart speed**.

---

## System Rules (non-negotiable)
1. **Not a to-do list.** Every day has only:
   - 1 Business Push task
   - 1 Personal Push task
2. Each task is **15–30 minutes max**.
3. Each task has exact **Done = ...** criteria (no ambiguity).
4. Each task has a **Lowest-Energy Version** (2–5 min) for rough days.
5. If a day is missed: **no debt, no guilt, no catch-up stack**. Fresh day starts next morning.
6. Confidence is built by logging wins, not by being perfect.

---

## Daily Push Planner (Telegram-first)

## Timing anchors (fits your real day)
- **6:00–6:30 AM:** Baby wake/feed
- **8:30 AM:** Drop son at school
- **9:05 AM (Telegram):** Daily Push message sent
- **5:50 PM (Telegram):** Shutdown prompt (before going fully into family mode)

> If morning is chaos, push can be sent at **9:30 AM latest**. No penalty.

---

## Morning PUSH message format (what ChetGPT sends)

```text
🌅 Fresh Day, Aviel. No backlog debt.

🎯 Business Push (20 min): [task]
Done = [binary finish line]
Low-energy version (3 min) = [smallest step]

🏠 Personal Push (15 min): [task]
Done = [binary finish line]
Low-energy version (2 min) = [smallest step]

Why today matters: [one sentence tied to confidence/$1M/family]
```

---

## How tasks are selected each morning

### Business Push selector (priority order)
1. Unblocks revenue (floor graphics pipeline, quotes, collections, pricing clarity)
2. Unblocks MIS/Wispr progress (identity/confidence builder)
3. Reduces anxiety by creating clarity (money, schedule, decisions)

### Personal Push selector (priority order)
1. Health activation (food, movement, recovery)
2. Family presence (wife/kids/parents)
3. Environment order (small reset that lowers friction)

### Task quality gate (must pass all)
- Can finish in 15–30 minutes
- Produces visible output
- Has clear “Done = …”
- Has a 2–5 minute fallback version

---

## Push Task Card Template (used daily)

```text
Task Type: Business / Personal
Task: 
Timebox: 15 / 20 / 30 min
Done = 
Lowest-Energy Version = 
Proof of completion = (photo / message / file / yes-no check)
```

---

## Real examples built for your life

### Business Push examples
- **Task:** Finalize 3 price items Brandon keeps asking for.
  - Done = 3 items sent in one Telegram message to Brandon.
  - Low-energy = Write only item #1 and send draft.
- **Task:** Update floor graphics tracker with this week’s jobs.
  - Done = 5 rows filled (lead/quote/booked/paid fields).
  - Low-energy = Add just today’s latest job row.
- **Task:** Wispr repo micro-ship.
  - Done = 1 commit pushed with clear commit message.
  - Low-energy = Open issue + write acceptance criteria.

### Personal Push examples
- **Task:** 20-minute walk (or indoor bike equivalent).
  - Done = 20 minutes completed + one ✅ message.
  - Low-energy = 5-minute walk outside.
- **Task:** Call Mom.
  - Done = 10+ minute call completed.
  - Low-energy = Send voice note + schedule call time.
- **Task:** Wife presence block.
  - Done = 20 distraction-free minutes (phone away).
  - Low-energy = 5-minute focused check-in: “How are you really?”

---

## Confidence Scorecard (daily + weekly + monthly)

## Daily logging (takes 2 minutes)
Log this at shutdown:

```text
Date:
Wins (1-3):
1)
2)
3)
Self-confidence today (1-10):
Energy today (Low / Medium / High):
```

**Rule:** tiny wins count.
- “Sent one hard message” counts.
- “Showed up after 4 missed days” counts big.
- “Did low-energy version instead of disappearing” counts.

---

## Streak logic
- **Win Streak =** consecutive days with at least 1 win logged.
- Missed day = streak resets, but language is: **“streak restarted”** (never “you failed”).
- Re-entry day after absence = **bonus confidence credit**.

---

## Weekly trend visualization (simple, visual, ADHD-friendly)
Use this format every Sunday:

```text
Week: YYYY-MM-DD to YYYY-MM-DD
Win days: ✅✅✅⬜✅✅⬜  (5/7)
Streak end-of-week: 3 days
Avg self-confidence: 6.4/10
Observed execution score: 7.1/10
Trend: ↗ improving / ↘ dipping / → stable
```

### Observed execution score (ChetGPT, 1-10)
- Business push completed: 0-4
- Personal push completed: 0-3
- Shutdown logged: 0-2
- Re-entry after miss (showed up): +1 bonus

---

## Monthly confidence score (combined)

**Formula:**
- `Monthly Confidence = (Avg Self Score × 0.6) + (Avg Observed Score × 0.4)`

This keeps your internal feeling primary, while still grounding in behavior.

### Milestone celebrations
- **7-day win streak:** “🔥 Consistency unlocked. You are now reliable to yourself.”
- **14-day streak:** “🧠 Momentum is becoming identity.”
- **30-day streak:** “🏆 New baseline established. Confidence is now evidence-based.”

---

## Morning Checklist (5 min max)
Use exactly this sequence:

```text
[ ] Feed baby
[ ] Breakfast: eggs + avocado
[ ] Read today’s ONE business + ONE personal push
[ ] 1-minute intention: “What kind of husband/father/builder am I today?”
```

If rushed: do intention while standing before leaving.

---

## Shutdown Checklist (5 min max)
Target time: **5:50 PM** (before full family transition)

```text
[ ] Log 1-3 wins (tiny wins count)
[ ] Review tomorrow’s task preview (already pre-chosen draft)
[ ] Close laptop (work boundary)
```

If work exploded and you missed shutdown: do a 90-second mini version on phone before bed.

---

## Re-Entry Ramp Protocol (after 2+ missed days)
This is the anti-abandonment protocol.

### Re-entry message format (no guilt)

```text
Welcome back. No catch-up debt.
Here’s where we left off:
- Last completed: [x]
- Current focus: [y]
- Not urgent right now: [z]

Your only move today (3-10 min): [smallest step]
If you do this, today is a WIN.
```

### Re-entry rules
1. Never mention “behind.”
2. Never dump old incomplete tasks.
3. Give one smallest next step only.
4. Log “showed up” as Win #1 immediately.
5. Next day returns to normal 1+1 push structure.

---

## Sunday Weekly Review Template (10 min)
Time suggestion: **Sunday 8:30 PM** (after kids settle)

```text
WEEKLY REVIEW (10 MIN)
Week of:

1) Wins from this week (top 3)
- 
- 
- 

2) What got stuck (no shame, just pattern)
- 

3) Why it got stuck
- Too big?
- No clear done criteria?
- Wrong time of day?
- Low energy/no fallback step?

4) Next week focus (one business theme + one personal theme)
Business theme:
Personal theme:

5) Confidence trend
- Avg self-confidence:
- Avg observed score:
- Win streak:
- Trend direction: ↗ / ↘ / →

6) Adjustment for next week (one change only)
- 
```

---

## Anti-All-or-Nothing Safeguards (designed from your exact pattern)
1. **Task size cap:** anything over 30 min must be split.
2. **Binary done line:** avoids “half-done so I failed” spiral.
3. **Low-energy fallback always present:** protects hard days.
4. **Fresh-day reset language daily:** no compounding guilt.
5. **Show-up credit:** re-entry is rewarded, not punished.
6. **Family boundary lock:** shutdown = confidence + marriage protection.

---

## Implementation Starter (what starts immediately)

### Daily automation behavior
- 9:05 AM: send morning push (1 business + 1 personal)
- 5:50 PM: send shutdown checklist + win log prompt
- If no reply for 2+ days: auto-trigger Re-Entry Ramp message
- Sunday evening: send weekly review template prompt

### Minimum success criteria for first 14 days
- 10/14 days with at least 1 logged win
- 8/14 business pushes attempted
- 8/14 personal pushes attempted
- 0 guilt language in prompts

If this is hit, system is working.

---

## Final note to Aviel
This system is built to convert your obsessive energy into **organized proof** that you are becoming the man you described:
- confident,
- present at home,
- focused at work,
- and steadily building toward $1M + product ownership.

Not by intensity. By repeatable daily wins.
