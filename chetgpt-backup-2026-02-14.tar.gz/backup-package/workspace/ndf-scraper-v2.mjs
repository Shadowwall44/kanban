#!/usr/bin/env node
/**
 * NDF Price Scraper v2 - Uses curl subprocess for reliability
 */

import { execSync } from 'child_process';
import fs from 'fs';
import XLSX from 'xlsx';

const API_URL = 'https://calculator.digitalroom.com/v1/computePrice';

function computePrice(productId, attrs) {
  const payload = {
    productType: 'offset',
    publishedVersion: true,
    product_id: productId,
    addon_attributes: ['333'],
    mailing_service: 'on',
    ...attrs
  };
  
  const body = JSON.stringify(payload).replace(/'/g, "'\\''");
  
  try {
    const result = execSync(`curl -s --max-time 10 -X POST '${API_URL}' \
      -u 'calculator.site:KEfm75#XjwSMux92zUWD9T8AafG!vwV6' \
      -H 'Content-Type: application/json' \
      -H 'Origin: https://www.nextdayflyers.com' \
      -H 'User-Agent: Mozilla/5.0 Chrome/120' \
      -d '${body}'`, { encoding: 'utf8', timeout: 15000 });
    
    return JSON.parse(result);
  } catch (e) {
    return null;
  }
}

function sleep(ms) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}

// ==================== PRODUCTS ====================

const PRODUCTS = [
  {
    key: 'business_cards', name: 'Standard Business Cards', category: 'Business Cards', pid: '461',
    defaults: { attr3:'22652',attr5:'22665',attr332:'32377',attr333:'22770',attr336:'22655',attr337:'22656',attr338:'22659',attr339:'22660',attr340:'22664',attr341:'32376',attr356:'27446' },
    sizes: [{id:'36770',n:'1.75 x 3.5 Slim'},{id:'22652',n:'2 x 3.5 Standard'},{id:'86212',n:'2.5 x 2.5'},{id:'86213',n:'3 x 3'}],
    papers: [{id:'22659',n:'14 pt. Cardstock'},{id:'69261',n:'16 pt. Cardstock'},{id:'86214',n:'17 pt. Cardstock'}],
    qtys: [{id:'22665',n:'100'},{id:'22666',n:'250'},{id:'22667',n:'500'},{id:'22668',n:'1,000'},{id:'22809',n:'2,500'},{id:'22672',n:'5,000'},{id:'22677',n:'10,000'}],
    tas: [{id:'22769',n:'3 Business Days'},{id:'22770',n:'Next Business Day'},{id:'22771',n:'Ready Today'}],
  },
  {
    key: 'postcards', name: 'Standard Postcards', category: 'Postcards', pid: '459',
    defaults: { attr3:'22396',attr5:'22413',attr333:'22519',attr336:'22402',attr337:'22403',attr338:'22406',attr339:'22408',attr340:'22412',attr356:'27443' },
    sizes: [{id:'22396',n:'4 x 6'},{id:'108285',n:'4 x 9'},{id:'22397',n:'5 x 7'},{id:'22398',n:'5.5 x 8.5'},{id:'22399',n:'6 x 9'},{id:'22400',n:'6 x 11'},{id:'22401',n:'8.5 x 11'}],
    papers: [{id:'22406',n:'14 pt. Cardstock'},{id:'69259',n:'16 pt. Cardstock'},{id:'108287',n:'17 pt. Cardstock'}],
    qtys: [{id:'22413',n:'100'},{id:'22414',n:'250'},{id:'22415',n:'500'},{id:'22416',n:'1,000'},{id:'22418',n:'2,500'},{id:'22421',n:'5,000'},{id:'22426',n:'10,000'}],
    tas: [{id:'22518',n:'3 Business Days'},{id:'22519',n:'Next Business Day'},{id:'22520',n:'Ready Today'}],
  },
  {
    key: 'flyers', name: 'Custom Flyers', category: 'Flyers', pid: '475',
    defaults: { attr3:'24079',attr5:'116338',attr331:'24103',attr333:'24217',attr336:'24094',attr337:'24095',attr338:'24102',attr339:'24106',attr340:'24110',attr356:'27234' },
    sizes: [{id:'116333',n:'4 x 6'},{id:'24090',n:'5.5 x 8.5'},{id:'24092',n:'8.5 x 11'},{id:'116337',n:'8.5 x 14'},{id:'86531',n:'11 x 17'}],
    papers: [{id:'24100',n:'70 lb. Paper'},{id:'24101',n:'80 lb. Paper'},{id:'24099',n:'100 lb. Paper'},{id:'24098',n:'14 pt. Cardstock'}],
    qtys: [{id:'24111',n:'100'},{id:'24112',n:'250'},{id:'24113',n:'500'},{id:'24114',n:'1,000'},{id:'24116',n:'2,500'},{id:'24119',n:'5,000'},{id:'24124',n:'10,000'}],
    tas: [{id:'24216',n:'3 Business Days'},{id:'24217',n:'Next Business Day'},{id:'24218',n:'Ready Today'}],
  },
  {
    key: 'trifold', name: 'Tri-Fold Brochure', category: 'Brochures', pid: '460',
    defaults: { attr3:'22522',attr5:'22536',attr331:'22532',attr333:'22642',attr336:'22526',attr337:'22527',attr338:'22528',attr339:'80614',attr340:'22535',attr341:'22646',attr364:'27835' },
    sizes: [{id:'22522',n:'8.5 x 11'},{id:'22523',n:'8.5 x 14'},{id:'22524',n:'11 x 17'}],
    papers: [{id:'22529',n:'70 lb. Paper'},{id:'22530',n:'80 lb. Paper'},{id:'22528',n:'100 lb. Paper'}],
    qtys: [{id:'22536',n:'100'},{id:'22537',n:'250'},{id:'22538',n:'500'},{id:'22539',n:'1,000'},{id:'22541',n:'2,500'},{id:'22544',n:'5,000'}],
    tas: [{id:'22641',n:'3 Business Days'},{id:'22642',n:'Next Business Day'},{id:'22643',n:'Ready Today'}],
  },
  {
    key: 'bifold', name: 'Bi-Fold Brochure', category: 'Brochures', pid: '460',
    defaults: { attr3:'22522',attr5:'22536',attr331:'22532',attr333:'22642',attr336:'22526',attr337:'22527',attr338:'22528',attr339:'80614',attr340:'22535',attr341:'22644',attr364:'27835' },
    sizes: [{id:'22522',n:'8.5 x 11'},{id:'22523',n:'8.5 x 14'},{id:'22524',n:'11 x 17'}],
    papers: [{id:'22529',n:'70 lb. Paper'},{id:'22530',n:'80 lb. Paper'},{id:'22528',n:'100 lb. Paper'}],
    qtys: [{id:'22536',n:'100'},{id:'22537',n:'250'},{id:'22538',n:'500'},{id:'22539',n:'1,000'},{id:'22541',n:'2,500'},{id:'22544',n:'5,000'}],
    tas: [{id:'22641',n:'3 Business Days'},{id:'22642',n:'Next Business Day'},{id:'22643',n:'Ready Today'}],
  },
  {
    key: 'banners', name: 'Vinyl Banners', category: 'Large Format', pid: '484',
    defaults: { attr3:'25166',attr5:'25175',attr310:'0',attr333:'25196',attr336:'25172',attr337:'25173',attr338:'25174',attr347:'25199',attr348:'35581' },
    sizes: [{id:'100659',n:'24 x 36'},{id:'25166',n:'48 x 24'},{id:'25167',n:'72 x 36'},{id:'25168',n:'96 x 36'},{id:'25169',n:'96 x 48'},{id:'25171',n:'120 x 60'}],
    papers: [{id:'100660',n:'Mesh 9oz Vinyl'},{id:'25174',n:'13oz Standard Vinyl'},{id:'100661',n:'18oz Heavy Duty Vinyl'}],
    qtys: [{id:'25175',n:'1'},{id:'25176',n:'2'},{id:'25179',n:'5'},{id:'25184',n:'10'}],
    tas: [{id:'25195',n:'3 Business Days'},{id:'25196',n:'Next Business Day'},{id:'67445',n:'Ready Today'}],
  },
  {
    key: 'posters', name: 'Bulk Posters', category: 'Large Format', pid: '478',
    defaults: { attr3:'24469',attr5:'24522',attr331:'24499',attr333:'24628',attr336:'24486',attr337:'24488',attr338:'24491',attr339:'24495',attr340:'24501',attr356:'27527' },
    sizes: [{id:'91350',n:'8.5 x 11'},{id:'24468',n:'11 x 17'},{id:'24469',n:'12 x 18'},{id:'24471',n:'18 x 24'},{id:'24473',n:'24 x 36'}],
    papers: [{id:'24492',n:'80 lb. Paper'},{id:'24491',n:'100 lb. Paper'},{id:'24490',n:'14 pt. Cardstock'}],
    qtys: [{id:'24522',n:'100'},{id:'24523',n:'250'},{id:'24524',n:'500'},{id:'24525',n:'1,000'},{id:'24527',n:'2,500'},{id:'24530',n:'5,000'}],
    tas: [{id:'24627',n:'3 Business Days'},{id:'24628',n:'Next Business Day'},{id:'24629',n:'Ready Today'}],
  },
  {
    key: 'stickers', name: 'Bulk Stickers', category: 'Specialty', pid: '486',
    defaults: { attr3:'34297',attr5:'25056',attr333:'25159',attr336:'25046',attr337:'25047',attr338:'25048',attr339:'25049',attr340:'25052',attr384:'32133',attr636:'59670',attr4:'34792',attr10:'34668',attr17:'34780',attr25:'34772',attr27:'34787',attr315:'34785',attr859:'159772' },
    sizes: [{id:'34297',n:'2 x 2'},{id:'34298',n:'2 x 3'},{id:'25026',n:'2 x 3.5'},{id:'25027',n:'2 x 4'}],
    papers: [{id:'1777189',n:'Gloss White Paper'},{id:'1777191',n:'Matte White Paper'},{id:'1777194',n:'Outdoor BOPP'}],
    qtys: [{id:'25056',n:'1,000'},{id:'25058',n:'2,500'},{id:'25061',n:'5,000'},{id:'25066',n:'10,000'}],
    tas: [{id:'25158',n:'3 Business Days'},{id:'25159',n:'Next Business Day'}],
  },
  {
    key: 'doorhangers', name: 'Door Hangers', category: 'Specialty', pid: '481',
    defaults: { attr3:'24345',attr5:'24357',attr333:'24462',attr336:'24346',attr337:'24347',attr338:'24350',attr339:'24352',attr340:'24356',attr356:'27452' },
    sizes: [{id:'68039',n:'3.5 x 8.5'},{id:'24345',n:'4.25 x 11'},{id:'68041',n:'5.25 x 8.5'}],
    papers: [{id:'24351',n:'10 pt. Cardstock'},{id:'24350',n:'14 pt. Cardstock'},{id:'69275',n:'16 pt. Cardstock'}],
    qtys: [{id:'24357',n:'100'},{id:'24358',n:'250'},{id:'24359',n:'500'},{id:'24360',n:'1,000'},{id:'24362',n:'2,500'},{id:'24365',n:'5,000'}],
    tas: [{id:'24462',n:'3 Business Days'},{id:'24463',n:'Next Business Day'},{id:'24464',n:'Ready Today'}],
  },
  {
    key: 'rackcards', name: 'Custom Rack Cards', category: 'Specialty', pid: '467',
    defaults: { attr3:'22933',attr5:'22945',attr333:'23051',attr334:'158401',attr336:'22934',attr337:'22935',attr338:'22938',attr339:'69266',attr340:'22944',attr341:'86760',attr356:'27533' },
    sizes: [{id:'86756',n:'3.5 x 8.5'},{id:'22933',n:'4 x 9'}],
    papers: [{id:'22938',n:'14 pt. Cardstock'},{id:'69265',n:'16 pt. Cardstock'},{id:'86759',n:'17 pt. Cardstock'}],
    qtys: [{id:'22945',n:'100'},{id:'22946',n:'250'},{id:'22947',n:'500'},{id:'22948',n:'1,000'},{id:'22950',n:'2,500'},{id:'22952',n:'4,000'}],
    tas: [{id:'23050',n:'3 Business Days'},{id:'23051',n:'Next Business Day'},{id:'23052',n:'Ready Today'}],
  },
  {
    key: 'greetingcards', name: 'Custom Greeting Cards', category: 'Specialty', pid: '485',
    defaults: { attr3:'26166',attr5:'24918',attr333:'25024',attr336:'24904',attr337:'24905',attr338:'24908',attr339:'66445',attr340:'24914',attr341:'32127',attr345:'29996',attr356:'27458',attr359:'136191',attr364:'136193' },
    sizes: [{id:'82671',n:'4 x 6 Flat'},{id:'82672',n:'5 x 7 Flat'},{id:'26166',n:'8x6 (Folds to 4x6)'},{id:'26167',n:'10x7 (Folds to 5x7)'}],
    papers: [{id:'24908',n:'14 pt. Cardstock'},{id:'69279',n:'16 pt. Cardstock'}],
    qtys: [{id:'24918',n:'100'},{id:'24919',n:'250'},{id:'24920',n:'500'},{id:'24921',n:'1,000'},{id:'24923',n:'2,500'},{id:'24926',n:'5,000'}],
    tas: [{id:'25023',n:'3 Business Days'},{id:'25024',n:'Next Business Day'},{id:'25025',n:'Ready Today'}],
  },
  {
    key: 'booklets', name: 'Booklets', category: 'Specialty', pid: '464',
    defaults: { attr3:'23805',attr5:'23842',attr8:'23819',attr331:'23815',attr333:'23817',attr336:'23808',attr337:'23809',attr338:'23813',attr339:'80616',attr345:'0',attr354:'67714',attr357:'28890',attr358:'28891',attr359:'136741',attr364:'0' },
    sizes: [{id:'23805',n:'5.5 x 8.5'},{id:'23807',n:'8.5 x 11'}],
    papers: [{id:'23811',n:'70 lb. Paper'},{id:'23813',n:'80 lb. Paper'},{id:'23810',n:'100 lb. Paper'}],
    qtys: [{id:'23842',n:'100'},{id:'23843',n:'250'},{id:'23844',n:'500'},{id:'23845',n:'1,000'},{id:'23847',n:'2,500'}],
    tas: [{id:'23817',n:'3 Business Days'},{id:'23818',n:'Next Business Day'}],
  },
  {
    key: 'letterhead', name: 'Letterhead', category: 'Specialty', pid: '465',
    defaults: { attr3:'23174',attr5:'23182',attr333:'23290',attr336:'23175',attr337:'23177',attr338:'23178',attr339:'80613',attr340:'23181',attr344:'23288' },
    sizes: [{id:'23174',n:'8.5 x 11'},{id:'83206',n:'8.5 x 14'}],
    papers: [{id:'23178',n:'70 lb. Paper'}],
    qtys: [{id:'23182',n:'100'},{id:'23183',n:'250'},{id:'23184',n:'500'},{id:'23185',n:'1,000'},{id:'23187',n:'2,500'},{id:'23190',n:'5,000'}],
    tas: [{id:'23289',n:'3 Business Days'},{id:'23290',n:'Next Business Day'},{id:'65792',n:'Ready Today'}],
  },
  {
    key: 'envelopes_10', name: '#10 Envelopes', category: 'Specialty', pid: '490',
    defaults: { attr1:'34363',attr4:'34370',attr5:'34371',attr11:'34367',attr333:'34403',attr3:'27118',attr336:'27124',attr337:'27125',attr338:'27126',attr339:'80617',attr392:'35050',attr394:'35052' },
    sizes: [{id:'27118',n:'#10 (4.125 x 9.5)'}],
    papers: [{id:'27126',n:'Standard'}],
    qtys: [{id:'34371',n:'250'},{id:'34372',n:'500'},{id:'34373',n:'1,000'},{id:'34375',n:'3,000'},{id:'34377',n:'5,000'},{id:'34382',n:'10,000'}],
    tas: [{id:'34403',n:'3 Business Days'}],
  },
  {
    key: 'envelopes_9', name: '#9 Envelopes', category: 'Specialty', pid: '490',
    defaults: { attr3:'27117',attr5:'27128',attr333:'27233',attr336:'27124',attr337:'27125',attr338:'27126',attr339:'80617',attr392:'35050',attr394:'35052' },
    sizes: [{id:'27117',n:'#9 (3.875 x 8.875)'}],
    papers: [{id:'27126',n:'Standard'}],
    qtys: [{id:'27128',n:'250'},{id:'27129',n:'500'},{id:'27130',n:'1,000'},{id:'27132',n:'3,000'},{id:'27134',n:'5,000'}],
    tas: [{id:'27233',n:'3 Business Days'}],
  },
];

// ==================== MAIN ====================

console.log('╔══════════════════════════════════════════════════╗');
console.log('║  NDF Price Scraper v2 (curl-based)               ║');
console.log('╚══════════════════════════════════════════════════╝');

const totalCalls = PRODUCTS.reduce((s, p) => s + p.sizes.length * p.papers.length * p.qtys.length * p.tas.length, 0);
console.log(`Products: ${PRODUCTS.length}, Estimated API calls: ${totalCalls}`);
console.log(`Started: ${new Date().toISOString()}\n`);

const allRows = [];
let totalApiCalls = 0;
let totalErrors = 0;

for (const product of PRODUCTS) {
  const expected = product.sizes.length * product.papers.length * product.qtys.length * product.tas.length;
  console.log(`--- ${product.name} (${expected} calls) ---`);
  
  let productRows = 0;
  let productErrors = 0;
  
  for (const size of product.sizes) {
    for (const paper of product.papers) {
      for (const qty of product.qtys) {
        let stdPrice = null, stdUnit = null;
        let ndPrice = null, ndUnit = null;
        let sdPrice = null, sdUnit = null;
        let aSize = size.n, aPaper = paper.n, aQty = qty.n, aCoating = 'Default';
        let gotPrice = false;
        
        for (const ta of product.tas) {
          const attrs = { ...product.defaults, attr3: size.id, attr338: paper.id, attr5: qty.id, attr333: ta.id };
          const result = computePrice(product.pid, attrs);
          totalApiCalls++;
          
          if (result && parseFloat(result.total_price) > 1 && (result.qty > 0 || result.sheet_qty > 0)) {
            gotPrice = true;
            const price = parseFloat(result.total_price);
            const unit = parseFloat(result.unit_price);
            
            if (result.display_specs) {
              for (const s of result.display_specs) {
                if (s.attribute_name?.includes('Size') || s.attribute_name === 'Page Size') aSize = s.attr_value;
                if (['Paper Stock','Paper','Material','Inside Pages'].includes(s.attribute_name)) aPaper = s.attr_value;
                if (s.attribute_name === 'Quantity') aQty = s.attr_value;
                if (s.attribute_name === 'Coating') aCoating = s.attr_value;
              }
            }
            
            if (result.turnaround >= 3) { stdPrice = price; stdUnit = unit; }
            else if (result.turnaround >= 1) { ndPrice = price; ndUnit = unit; }
            else { sdPrice = price; sdUnit = unit; }
          } else if (!result) {
            productErrors++;
            totalErrors++;
          }
          
          // Small delay between calls
          sleep(300);
        }
        
        if (gotPrice) {
          productRows++;
          allRows.push({
            cat: product.category, type: product.name, size: aSize, paper: aPaper,
            coating: aCoating, qty: parseInt(String(aQty).replace(/,/g,'')) || aQty,
            stdPrice, stdUnit, ndPrice, ndUnit, sdPrice, sdUnit
          });
        }
      }
    }
  }
  
  console.log(`  ✓ ${productRows} rows, ${productErrors} errors`);
}

// ==================== GENERATE OUTPUT ====================

console.log(`\n=== Generating files ===`);
console.log(`Total rows: ${allRows.length}, Total API calls: ${totalApiCalls}, Errors: ${totalErrors}`);

const enriched = allRows.map(r => {
  const floor = r.stdPrice || r.ndPrice || 0;
  return {
    'Product Category': r.cat, 'Product Type': r.type, 'Size': r.size,
    'Paper Stock': r.paper, 'Coating': r.coating, 'Quantity': r.qty,
    'Standard Price': r.stdPrice, 'Standard Per Unit': r.stdUnit,
    'Next Day Price': r.ndPrice, 'Next Day Per Unit': r.ndUnit,
    'Same Day Price': r.sdPrice, 'Same Day Per Unit': r.sdUnit,
    'NDF Floor': floor || null,
    'Target (+10%)': floor ? Math.round(floor * 1.10 * 100) / 100 : null,
    'Opening (+25%)': floor ? Math.round(floor * 1.25 * 100) / 100 : null,
  };
});

const wb = XLSX.utils.book_new();
const ws1 = XLSX.utils.json_to_sheet(enriched);
ws1['!cols'] = [{wch:18},{wch:24},{wch:22},{wch:24},{wch:20},{wch:10},{wch:14},{wch:16},{wch:14},{wch:16},{wch:14},{wch:16},{wch:12},{wch:14},{wch:14}];
XLSX.utils.book_append_sheet(wb, ws1, 'All Pricing');

// Category sheets
const cats = [
  ['Business Cards', r => r['Product Category'] === 'Business Cards'],
  ['Postcards', r => r['Product Category'] === 'Postcards'],
  ['Flyers', r => r['Product Category'] === 'Flyers'],
  ['Large Format', r => r['Product Category'] === 'Large Format'],
  ['Specialty', r => ['Specialty','Brochures'].includes(r['Product Category'])],
];
for (const [name, fn] of cats) {
  const d = enriched.filter(fn);
  if (d.length > 0) { const ws = XLSX.utils.json_to_sheet(d); ws['!cols'] = ws1['!cols']; XLSX.utils.book_append_sheet(wb, ws, name); }
}

const xlsxPath = '/home/inkredible/.openclaw/workspace/ndf-pricing-complete.xlsx';
XLSX.writeFile(wb, xlsxPath);
console.log(`Excel: ${xlsxPath}`);

const csvPath = '/home/inkredible/.openclaw/workspace/ndf-pricing-complete.csv';
fs.writeFileSync(csvPath, XLSX.utils.sheet_to_csv(ws1));
console.log(`CSV: ${csvPath}`);

// Summary
console.log('\n╔══════════════════════════════════════════════════╗');
console.log('║  COMPLETE                                        ║');
console.log('╚══════════════════════════════════════════════════╝');
console.log(`Products: ${PRODUCTS.length}`);
console.log(`Price rows: ${allRows.length}`);
console.log(`API calls: ${totalApiCalls}`);
console.log(`Errors: ${totalErrors}`);

console.log('\nSample (first 10):');
enriched.slice(0, 10).forEach((r, i) => {
  console.log(`  ${i+1}. ${r['Product Type']} | ${r.Size} | ${r['Paper Stock']} | Qty ${r.Quantity} | Std $${r['Standard Price']||'-'} | ND $${r['Next Day Price']||'-'} | SD $${r['Same Day Price']||'-'}`);
});

console.log(`\nFinished: ${new Date().toISOString()}`);
