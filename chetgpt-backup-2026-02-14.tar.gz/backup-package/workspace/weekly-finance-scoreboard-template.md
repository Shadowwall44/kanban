# Weekly Finance Scoreboard Template (Q2 Automation)

**Purpose:** Auto-generate a Monday morning finance snapshot that is fast to read, action-oriented, and consistent with Q1 schema (`financial-command-center-v1.md`).

**Run cadence:** Every Monday, 8:00 AM ET  
**Reporting window:** Previous Monday 00:00:00 ET → Sunday 23:59:59 ET  
**Primary audience:** Aviel (Telegram, mobile-first)

---

## 1) Canonical Weekly Template (Auto-Populated)

```markdown
# Weekly Finance Scoreboard — {{week_start}} to {{week_end}}
Generated: {{generated_at_et}}

🟩🟨🟥 Overall: {{overall_status}}  
(Logic: worst status among Cash, Debt, Margin, Floor Share)

## 1) Cash Control
- Real Cash Position: **${{real_cash_position}}**
- Checking Balance: **${{checking_balance}}**
- Reserve Floor / Target: **${{reserve_floor}} / ${{reserve_target}}**
- Reserve Coverage: **{{reserve_coverage_pct}}%** ({{reserve_status}})

## 2) Revenue + Margin
- Revenue (Week): **${{revenue_week}}** (Target: **${{revenue_week_target}}**)
- Gross Profit (Week): **${{gross_profit_week}}**
- Gross Margin (Week): **{{gross_margin_week_pct}}%** ({{gross_margin_status}})
- Gross Margin (4-Week): **{{gross_margin_4wk_pct}}%**

## 3) Floor Graphics (Primary Profit Engine)
- Floor Graphics Revenue (Week): **${{floor_revenue_week}}**
- Floor Graphics Share: **{{floor_share_week_pct}}%** ({{floor_share_status}})
- Floor Graphics 4-Week Share: **{{floor_share_4wk_pct}}%**

## 4) Debt + Obligations
- Total Debt: **${{total_debt}}**
- Debt Change WoW: **${{debt_change_wow}}** ({{debt_trend_status}})
- Estimated Monthly Interest Burn: **${{monthly_interest_estimate}}**
- A/R Open: **${{ar_open_total}}** | >30 Days: **{{ar_over_30_pct}}%**
- A/P Due Next 7 Days: **${{ap_due_7d}}**

## 5) So What (Narrative)
{{so_what_paragraph}}

## 6) This Week’s 3 Moves
1. {{action_1}}
2. {{action_2}}
3. {{action_3}}

## 7) Risk Alerts
- {{risk_1}}
- {{risk_2}}

## 8) Win
- {{weekly_win}}
```

---

## 2) Exact Field Definitions + Formulas

> Use these exact formulas so weekly outputs are consistent and trendable.

### Date Window
- `week_start` = previous Monday (ET)
- `week_end` = previous Sunday (ET)

### Revenue / Margin
- `revenue_week` = sum(weekly income accounts)
- `cogs_week` = sum(weekly COGS accounts)
- `gross_profit_week` = `revenue_week - cogs_week`
- `gross_margin_week_pct` = `(gross_profit_week / revenue_week) * 100`
- `gross_margin_4wk_pct` = `(sum(gross_profit_last_4_weeks) / sum(revenue_last_4_weeks)) * 100`

### Floor Graphics
- `floor_revenue_week` = sum(revenue lines tagged as floor graphics)
- `floor_share_week_pct` = `(floor_revenue_week / revenue_week) * 100`
- `floor_share_4wk_pct` = `(sum(floor_revenue_last_4_weeks) / sum(revenue_last_4_weeks)) * 100`

### Cash
- `bank_cash_total` = sum(bank + petty cash balances from Balance Sheet)
- `offbooks_cash_undeposited` = sum(`offbooks_cash_log.amount_received` where `deposited_flag=false`)
- `uncleared_cash_expenses` = known uncleared cash outflows (manual adjustments)
- `real_cash_position` = `bank_cash_total + offbooks_cash_undeposited - uncleared_cash_expenses`
- `checking_balance` = ending balance of primary checking account
- `reserve_floor` = `abs(min(checking_balance,0)) + 0.5 * essential_monthly_outflow`
- `reserve_target` = `abs(min(checking_balance,0)) + 1.0 * essential_monthly_outflow`
- `reserve_coverage_pct` = `(real_cash_position / reserve_target) * 100`

### Debt
- `total_debt` = sum(active debt balances: cards + LOC + loans + tax liabilities)
- `debt_change_wow` = `total_debt - total_debt_last_week`
- `monthly_interest_estimate` = `sum(current_balance * (apr_percent/100) / 12)`

### Working Capital
- `ar_open_total` = sum(open invoice balances)
- `ar_over_30_pct` = `(AR_31_plus / ar_open_total) * 100`
- `ap_due_7d` = sum(open bills where due_date <= week_end + 7 days)

### Baseline Constants (from historicals)
- `revenue_month_avg` = **$27,000**
- `revenue_week_target` = `27000 * 12 / 52` = **$6,231**
- `gross_margin_baseline` = **54.5%**
- `total_debt_baseline` = **$174,000**
- `checking_baseline` = **-$14,000**

---

## 3) KPI Thresholds (Red / Yellow / Green)

| KPI | Green | Yellow | Red |
|---|---:|---:|---:|
| **Revenue (Week vs $6,231 target)** | `>= 100% target` | `85%–99%` | `<85%` |
| **Gross Margin (Week)** | `>= 54.5%` | `50.0%–54.4%` | `<50.0%` |
| **Gross Margin (4-week)** | `>= 54.5%` | `52.0%–54.4%` | `<52.0%` |
| **Floor Graphics Share (Week)** | `>= 30%` | `20%–29.9%` | `<20%` |
| **Real Cash Position** | `>= $0` | `-$9,999 to -$0.01` | `< -$10,000` |
| **Checking Balance** | `>= $0` | `-$9,999 to -$0.01` | `< -$10,000` |
| **Reserve Coverage** | `>=100%` | `75%–99%` | `<75%` |
| **Total Debt vs $174K baseline** | `<$172K` | `$172K–$176K` | `>$176K` |
| **Debt Change WoW** | `<= -$1,000` | `-$999 to +$250` | `> +$250` |
| **A/R >30 days** | `<20%` | `20%–35%` | `>35%` |
| **A/P Due in 7 days** *(as % of real cash)* | `<40%` | `40%–70%` | `>70%` |

**Status logic:**
- `overall_status = worst(KPI statuses)`
- If Cash or Reserve is Red, overall cannot be Green.

---

## 4) Data Pull Checklist (QuickBooks API + Internal Logs)

Use this checklist in order each Monday run.

### A) QuickBooks Core Pulls
- [ ] **Company timezone check** (ensure ET alignment)
- [ ] **ProfitAndLoss (weekly):**
  - `GET /v3/company/{realmId}/reports/ProfitAndLoss?start_date={{week_start}}&end_date={{week_end}}&accounting_method=Cash`
- [ ] **ProfitAndLoss (4-week rolling):**
  - `GET /v3/company/{realmId}/reports/ProfitAndLoss?start_date={{week_start_minus_27d}}&end_date={{week_end}}&accounting_method=Cash`
- [ ] **BalanceSheet (as of week_end):**
  - `GET /v3/company/{realmId}/reports/BalanceSheet?end_date={{week_end}}&accounting_method=Cash`
- [ ] **Account catalog (for account-type mapping):**
  - `GET /v3/company/{realmId}/query?query=SELECT Id,Name,AccountType,AccountSubType,CurrentBalance FROM Account`
- [ ] **Invoices (A/R + aging inputs):**
  - `GET /v3/company/{realmId}/query?query=SELECT Id,DocNumber,TxnDate,DueDate,TotalAmt,Balance,CustomerRef FROM Invoice WHERE Balance > '0'`
- [ ] **Bills (A/P due in 7 days):**
  - `GET /v3/company/{realmId}/query?query=SELECT Id,TxnDate,DueDate,TotalAmt,Balance,VendorRef FROM Bill WHERE Balance > '0'`
- [ ] **Deposits / Sales Receipts / Payments** (cash reconciliation support):
  - Pull transactions in week window for matching off-books deposits.

### B) Floor Graphics Classification Pull
- [ ] Pull line-level revenue detail (Invoice + SalesReceipt lines)
- [ ] Classify as `floor_graphics` when one of these is true:
  1. `ClassRef` = Floor Graphics (preferred)
  2. Item/Service name mapped to floor graphics SKU list
  3. Description contains floor/wrap/vinyl floor terms (fallback)

### C) Internal (Non-QB) Pulls
- [ ] `offbooks_cash_log` (undeposited cash)
- [ ] `debt_accounts` (APR, balances, minimums)
- [ ] Prior week snapshot from `finance_scoreboard_weekly` (for WoW deltas)

### D) Validation Checks (must pass before publish)
- [ ] `revenue_week >= floor_revenue_week`
- [ ] `gross_margin_week_pct` is between `-100%` and `100%`
- [ ] `total_debt >= 0`
- [ ] No nulls in headline KPIs
- [ ] If any validation fails: publish with `⚠️ DATA QUALITY WARNING` + list failed checks

---

## 5) Narrative Generation Rules (“So What” Paragraph)

Write **one paragraph (3–5 sentences, max 600 chars)** using this structure:

1. **What changed:** Mention 2–3 biggest numeric moves (cash, margin, debt, floor share).
2. **Why it matters:** Tie to business survival/growth (cash runway + profitable mix).
3. **So what now:** Give one clear priority for this week.
4. **Confidence cue:** End with one positive forward-looking line.

### Hard Rules
- Use plain language (no accounting jargon overload).
- Must include floor graphics line at least once (biggest money maker).
- If any KPI is Red, sentence 1 must acknowledge it directly.
- Never output more than 3 actions.
- Include one win even in bad weeks.

### Narrative Template
`This week {{primary_change}} while {{secondary_change}}. The key implication is {{business_impact}}. Priority this week: {{single_priority_action}}. Positive signal: {{confidence_win}}.`

---

## 6) Mobile-Friendly Telegram Format (Samsung Z Fold 7)

Use this compact send format (optimized for narrow + folded view):

```markdown
📊 Finance Scoreboard ({{week_start}}–{{week_end}})
Overall: {{overall_status_emoji}} {{overall_status}}

💵 Cash: ${{real_cash_position}} | Checking ${{checking_balance}} | Reserve {{reserve_coverage_pct}}%
📈 Rev: ${{revenue_week}} / ${{revenue_week_target}} | GM {{gross_margin_week_pct}}%
🧱 Floor: ${{floor_revenue_week}} ({{floor_share_week_pct}}%)
💳 Debt: ${{total_debt}} (WoW {{debt_change_wow}}) | Int/mo ${{monthly_interest_estimate}}
🧾 AR: ${{ar_open_total}} (30+ {{ar_over_30_pct}}%) | AP 7d: ${{ap_due_7d}}

🧠 So what: {{so_what_1_sentence}}
✅ 3 Moves: 1) {{a1}} 2) {{a2}} 3) {{a3}}
🏆 Win: {{weekly_win_short}}
```

Formatting rules:
- Keep to ~10–14 lines.
- One emoji per line max.
- Use abbreviations: `Rev`, `GM`, `Int/mo`, `AP 7d`.
- Avoid markdown tables in Telegram.

---

## 7) Integration Notes (When QuickBooks Production API Goes Live)

1. **Switch API base URL**
   - From sandbox: `https://sandbox-quickbooks.api.intuit.com`
   - To production: `https://quickbooks.api.intuit.com`

2. **Keep schema unchanged**
   - Continue writing into existing Q1 tables:
     - `cash_accounts_daily`
     - `offbooks_cash_log`
     - `debt_accounts`
     - `margin_weekly`
     - `finance_scoreboard_weekly`
   - Only change `source_system` tag from `quickbooks_sandbox` → `quickbooks_prod`.

3. **OAuth + reliability**
   - Refresh token before Monday run.
   - Retry policy: 3 attempts with backoff (2s, 5s, 10s).
   - If API fails, publish partial scoreboard with `DATA DELAY` tag rather than skipping Monday update.

4. **Idempotent weekly writes**
   - Unique key: `week_start`.
   - Re-runs overwrite same week row (no duplicates).

5. **Classification hardening (floor graphics)**
   - Add explicit product/service mapping table in QB.
   - Require line-level classing going forward to reduce fallback keyword matching.

6. **Auditability**
   - Store raw API payload snapshots per run (`/workspace/financials/raw/{{week_start}}/*.json`).
   - Log formula outputs and status colors for traceability.

---

## 8) Monday Auto-Run Sequence (Implementation Shortcut)

1. Pull QB + internal data (checklist above)  
2. Compute formulas + KPI statuses  
3. Generate narrative paragraph  
4. Render full markdown template  
5. Render compact Telegram block  
6. Save snapshot row to `finance_scoreboard_weekly`  
7. Publish

**Definition of done each Monday:** One validated markdown scoreboard + one Telegram-ready summary, both generated before first business block.
