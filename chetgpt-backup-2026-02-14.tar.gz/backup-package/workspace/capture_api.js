const puppeteer = require('puppeteer-core');
const fs = require('fs');

async function captureApiCalls() {
  const browser = await puppeteer.connect({
    browserURL: 'http://localhost:18800',
    defaultViewport: { width: 1400, height: 900 }
  });
  
  const page = await browser.newPage();
  const apiCalls = [];
  
  // Capture all network requests
  await page.setRequestInterception(true);
  page.on('request', (request) => {
    const url = request.url();
    if (url.includes('computePrice') || url.includes('calculator')) {
      apiCalls.push({
        url: url,
        method: request.method(),
        postData: request.postData(),
        headers: request.headers()
      });
      console.log('Captured API call:', url);
      console.log('Post data:', request.postData());
    }
    request.continue();
  });
  
  try {
    console.log('Loading page and capturing API calls...');
    await page.goto('https://www.nextdayflyers.com/postcard-printing/standard-postcards.php', { 
      waitUntil: 'networkidle2', 
      timeout: 60000 
    });
    
    // Wait for calculator to load
    await new Promise(r => setTimeout(r, 10000));
    
    // Click on size dropdown to trigger API call
    await page.evaluate(() => {
      const dropdowns = document.querySelectorAll('.dropdown-toggle');
      for (const dd of dropdowns) {
        if (dd.textContent.includes('4') && dd.textContent.includes('6')) {
          dd.click();
          return;
        }
      }
    });
    
    await new Promise(r => setTimeout(r, 3000));
    
    fs.writeFileSync('api_calls.json', JSON.stringify(apiCalls, null, 2));
    console.log('\n✓ API calls saved to api_calls.json');
    console.log(`Total API calls captured: ${apiCalls.length}`);
    
  } catch (e) {
    console.error('Error:', e);
  } finally {
    await page.close();
    await browser.disconnect();
  }
}

captureApiCalls();
