/**
 * NextDayFlyers Pricing Scraper
 * 
 * Run this in Antigravity IDE with a headless browser (Puppeteer)
 * 
 * Setup:
 * 1. npm install puppeteer
 * 2. node scrape-prices.js
 */

const puppeteer = require('puppeteer');
const XLSX = require('xlsx');
const fs = require('fs');

// Product categories to scrape
const PRODUCTS = [
  { name: 'Postcards', url: 'https://www.nextdayflyers.com/postcard-printing/standard-postcards.php' },
  { name: 'Flyers', url: 'https://www.nextdayflyers.com/marketing-materials/business-flyers.html' },
  { name: 'Booklets', url: 'https://www.nextdayflyers.com/catalogs-and-booklets/booklets.html' },
  { name: 'Hang Tags', url: 'https://www.nextdayflyers.com/boxes-and-packages/hang-tags.html' },
];

// Turnaround options
const TURNAROUNDS = [
  { name: '3 Business Days', value: '22518' },
  { name: 'Next Business Day', value: '22519' },
  { name: 'Same Day (by 10am)', value: '22520' },
];

async function scrapeProduct(browser, product) {
  console.log(`\n📦 Scraping: ${product.name}`);
  
  const page = await browser.newPage();
  await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
  
  try {
    await page.goto(product.url, { waitUntil: 'networkidle0', timeout: 30000 });
    
    // Wait for calculator to load
    await page.waitForSelector('#calculator_handler', { timeout: 10000 });
    
    // Wait for prices to render
    await page.waitForFunction(() => {
      const priceEl = document.querySelector('#price');
      return priceEl && priceEl.innerText.includes('$');
    }, { timeout: 15000 });
    
    // Extract base configuration
    const config = await page.evaluate(() => {
      const priceEl = document.querySelector('#price');
      const unitPriceEl = document.querySelector('[data-qaid="originalUnitPrice"]');
      
      return {
        basePrice: priceEl ? priceEl.innerText.trim() : 'N/A',
        unitPrice: unitPriceEl ? unitPriceEl.innerText.trim() : 'N/A',
        sizes: [],
        paperStocks: [],
        coatings: [],
      };
    });
    
    // Extract all available options from dropdowns
    const options = await page.evaluate(() => {
      const sizes = [];
      const paperStocks = [];
      const coatings = [];
      
      // Size options (attr 3)
      document.querySelectorAll('#attr_container_3 .attr-value').forEach(el => {
        sizes.push({
          value: el.dataset.value,
          display: el.dataset.display
        });
      });
      
      // Paper stock options (attr 338)
      document.querySelectorAll('#attr_container_338 .attr-value').forEach(el => {
        paperStocks.push({
          value: el.dataset.value,
          display: el.dataset.display
        });
      });
      
      // Coating options (attr 339)
      document.querySelectorAll('#attr_container_339 .attr-value').forEach(el => {
        coatings.push({
          value: el.dataset.value,
          display: el.dataset.display
        });
      });
      
      return { sizes, paperStocks, coatings };
    });
    
    console.log(`   Found ${options.sizes.length} sizes, ${options.paperStocks.length} papers, ${options.coatings.length} coatings`);
    
    await page.close();
    
    return {
      product: product.name,
      basePrice: config.basePrice,
      unitPrice: config.unitPrice,
      options: options,
      turnarounds: TURNAROUNDS,
      scrapedAt: new Date().toISOString()
    };
    
  } catch (error) {
    console.error(`   Error: ${error.message}`);
    await page.close();
    return { product: product.name, error: error.message };
  }
}

async function main() {
  console.log('🚀 NextDayFlyers Pricing Scraper');
  console.log('================================\n');
  
  const browser = await puppeteer.launch({ 
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });
  
  const results = [];
  
  for (const product of PRODUCTS) {
    const result = await scrapeProduct(browser, product);
    results.push(result);
  }
  
  await browser.close();
  
  // Save results
  fs.writeFileSync('nextdayflyers-prices.json', JSON.stringify(results, null, 2));
  console.log('\n💾 Saved raw data to nextdayflyers-prices.json');
  
  // Create Excel
  const workbook = XLSX.utils.book_new();
  
  // Summary sheet
  const summaryData = results.map(r => ({
    Product: r.product,
    'Base Price': r.basePrice || 'N/A',
    'Unit Price': r.unitPrice || 'N/A',
    'Sizes Available': r.options?.sizes?.length || 0,
    'Paper Stocks': r.options?.paperStocks?.length || 0,
    'Coatings': r.options?.coatings?.length || 0,
    Status: r.error ? 'Error' : 'Success',
    Error: r.error || ''
  }));
  
  const summarySheet = XLSX.utils.json_to_sheet(summaryData);
  XLSX.utils.book_append_sheet(workbook, summarySheet, 'Summary');
  
  // Options sheets for each product
  for (const result of results) {
    if (result.error) continue;
    
    const sheetName = result.product.substring(0, 31).replace(/[\/\\?*\[\]]/g, '_');
    
    // Sizes
    if (result.options?.sizes?.length) {
      const sizeSheet = XLSX.utils.json_to_sheet(result.options.sizes.map(s => ({
        Size: s.display,
        Value: s.value
      })));
      XLSX.utils.book_append_sheet(workbook, sizeSheet, `${sheetName}_Sizes`);
    }
    
    // Paper Stocks
    if (result.options?.paperStocks?.length) {
      const paperSheet = XLSX.utils.json_to_sheet(result.options.paperStocks.map(p => ({
        'Paper Stock': p.display,
        Value: p.value
      })));
      XLSX.utils.book_append_sheet(workbook, paperSheet, `${sheetName}_Paper`);
    }
    
    // Coatings
    if (result.options?.coatings?.length) {
      const coatingSheet = XLSX.utils.json_to_sheet(result.options.coatings.map(c => ({
        Coating: c.display,
        Value: c.value
      })));
      XLSX.utils.book_append_sheet(workbook, coatingSheet, `${sheetName}_Coatings`);
    }
  }
  
  XLSX.writeFile(workbook, 'nextdayflyers-prices.xlsx');
  console.log('📊 Saved Excel file to nextdayflyers-prices.xlsx');
  
  console.log('\n✅ Done!');
}

main().catch(console.error);
