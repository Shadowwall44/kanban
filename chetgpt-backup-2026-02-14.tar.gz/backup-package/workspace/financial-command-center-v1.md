# Financial Command Center v1 (Q1 Build)

**Owner:** Aviel  
**Goal:** Replace financial anxiety with one clear weekly control system  
**Design principle:** *Clarity over complexity* — one dashboard, one debt rule, one weekly scorecard, one reconciliation workflow.

---

## 0) Current Financial Baseline (from existing reports)

- Revenue: **$686,179** over ~25.5 months (**~$26.9K/mo**)
- Gross margin: **54.5%**
- Net income: **-$10,746** (debt servicing + other expenses)
- Total debt exposure: **~$174K**
- Checking: **-$13,991** overdrawn
- Known issue: meaningful cash is received but not consistently captured in QuickBooks

This Command Center is built to solve that exact gap.

---

## 1) Cash + Debt + Margin Dashboard Schema

## 1.1 Dashboard layout (single-screen)

Use a 4-block dashboard:

1. **Cash Control** (top-left)
2. **Debt Waterfall** (top-right)
3. **Margin Health** (bottom-left)
4. **Floor Graphics Revenue Share** (bottom-right)

### Top-line metrics (shown every week)

- **Real Cash Position**
- **Reserve Coverage %**
- **Total Debt**
- **Weekly Debt Change**
- **Gross Margin % (4-week rolling)**
- **Floor Graphics Share % of Revenue**

---

## 1.2 Data model (practical schema)

## A) `cash_accounts_daily`
One row per account per day (QuickBooks + bank balances).

| Field | Type | Example | Source |
|---|---|---:|---|
| snapshot_date | date | 2026-02-13 | System date |
| account_id | string | qb_1010 | QuickBooks COA |
| account_name | string | Chase Business Checking-1365 | QuickBooks |
| account_type | enum | bank\|cash\|credit\|loan | QuickBooks |
| ending_balance | decimal | -13990.79 | QuickBooks Balance Sheet |
| source_system | enum | quickbooks_sandbox\|quickbooks_prod\|manual | Integration tag |
| imported_at | datetime | ... | ETL timestamp |

## B) `offbooks_cash_log`
Cash received outside current QuickBooks flow (must be captured daily).

| Field | Type | Example | Source |
|---|---|---:|---|
| cash_txn_id | string | CASH-2026-02-14-001 | Manual form |
| txn_date | date | 2026-02-14 | Manual form |
| customer_name | string | Walk-in customer | Manual form |
| job_type | enum | floor_graphics\|small_format\|other | Manual form |
| amount_received | decimal | 450.00 | Manual form |
| invoice_id | string/null | INV-1234 | QuickBooks/Manual |
| deposited_flag | bool | false | Reconciliation process |
| deposit_batch_id | string/null | DEP-2026-02-16-A | Reconciliation process |
| notes | text | paid cash at pickup | Manual form |

## C) `debt_accounts`
Canonical debt register for waterfall logic.

| Field | Type | Example |
|---|---|---:|
| debt_id | string | DEBT-CC-2476 |
| lender | string | Chase |
| debt_type | enum | credit_card\|loc\|term_loan\|tax |
| current_balance | decimal | 18500.00 |
| apr_percent | decimal | 24.99 |
| min_payment | decimal | 550.00 |
| due_day | int | 18 |
| promo_end_date | date/null | null |
| prepayment_penalty_flag | bool | false |
| refinance_candidate_flag | bool | true |
| status | enum | active\|closed |
| updated_at | datetime | ... |

## D) `margin_weekly`
Weekly performance rows for revenue + COGS + margin.

| Field | Type | Formula |
|---|---|---|
| week_start | date | Monday date |
| revenue_total | decimal | Sum income accounts |
| cogs_total | decimal | Sum COGS accounts |
| gross_profit | decimal | `revenue_total - cogs_total` |
| gross_margin_pct | decimal | `gross_profit / revenue_total` |
| floor_graphics_revenue | decimal | Tagged floor jobs only |
| floor_graphics_share_pct | decimal | `floor_graphics_revenue / revenue_total` |

## E) `finance_scoreboard_weekly`
Auto-generated summary output table.

| Field | Type | Formula |
|---|---|---|
| week_start | date | - |
| real_cash_position | decimal | See formula section |
| reserve_target | decimal | See debt model |
| reserve_coverage_pct | decimal | `real_cash_position / reserve_target` |
| total_debt | decimal | Sum of active debt balances |
| debt_change_wow | decimal | `this_week_debt - last_week_debt` |
| gross_margin_pct | decimal | from `margin_weekly` |
| floor_graphics_share_pct | decimal | from `margin_weekly` |
| status_color | enum | green\|yellow\|red |
| top_3_actions | text[] | generated |

---

## 1.3 Formula definitions (core)

### Real Cash Position
```text
real_cash_position =
  (sum(bank and petty cash balances from QB))
+ (offbooks cash received but not yet deposited)
- (known uncleared cash expenses)
```

### Reserve Coverage
```text
reserve_coverage_pct = real_cash_position / reserve_target
```

### Gross Margin
```text
gross_margin_pct = (revenue_total - cogs_total) / revenue_total
```

### Floor Graphics Share
```text
floor_graphics_share_pct = floor_graphics_revenue / revenue_total
```

---

## 1.4 Source mapping (where each metric comes from)

- **QuickBooks Balance Sheet:** checking, credit cards, LOC, loans
- **QuickBooks P&L:** weekly/monthly revenue, COGS, margin
- **QuickBooks invoice tags/classes:** floor graphics revenue tagging
- **Manual cash log (`offbooks_cash_log`):** off-books cash capture
- **Debt register (`debt_accounts`):** APR, minimums, due dates, refinance flags

> While QuickBooks production is pending, run this from sandbox + manual CSV imports. When production connects, keep same schema and switch source tag.

---

## 2) Debt Waterfall Model (APR-ranked + safe reserve)

## 2.1 Objective

1. Stop cash emergencies (overdraft first)
2. Keep a minimum safe reserve
3. Pay minimums on all debts
4. Attack highest APR debt with all extra cash

---

## 2.2 Inputs required weekly

From `debt_accounts`:
- `current_balance`
- `apr_percent`
- `min_payment`

From cash model:
- `real_cash_position`
- `reserve_target`

From ops:
- weekly free cash after essentials

---

## 2.3 Safe cash reserve formula

Given current volatility + overdraft, use two levels:

### Reserve Floor (do not break)
```text
reserve_floor = overdraft_cure + 0.5 * essential_monthly_outflow
```

### Reserve Target (aim every month)
```text
reserve_target = overdraft_cure + 1.0 * essential_monthly_outflow
```

Where:
```text
overdraft_cure = abs(current_checking_negative_balance)
essential_monthly_outflow =
  rent + payroll + payroll_taxes + utilities + phone + insurance + software + debt_minimums
```

### Starting estimate using available data
- Overdraft cure: **$13,991**
- Essential monthly outflow (initial estimate): **~$12,000**

So:
- `reserve_floor ≈ 13,991 + 6,000 = $19,991` → **round to $20K**
- `reserve_target ≈ 13,991 + 12,000 = $25,991` → **round to $26K**

**Rule:** no aggressive extra debt payments until cash is above reserve floor.

---

## 2.4 Waterfall payoff algorithm

```text
Step 1: Pay all debt minimums.
Step 2: If real_cash_position < reserve_floor:
          send ALL surplus cash to reserve (not extra debt payoff).
Step 3: If real_cash_position >= reserve_floor:
          extra_payment_pool = real_cash_position - reserve_target (minimum 0)
          rank debts by effective APR descending
          allocate 100% of extra_payment_pool to rank #1 debt
Step 4: When debt #1 is paid off, roll its minimum payment into debt #2.
Step 5: Repeat weekly.
```

### Debt ranking rule
```text
effective_apr = apr_percent
rank by effective_apr DESC, then by balance ASC (tie-break)
```

### Initial expected ranking (based on current context)
1. **Credit cards (~$71K, typically highest APR)**
2. **Chase LOC (~$43K, ~17–18% known)**
3. **Loan payable (~$60K, likely lower APR than cards/LOC)**

---

## 2.5 Refinance trigger logic

Flag `refinance_candidate_flag = true` if:
- APR > 12% AND balance > $15K, OR
- interest paid last 90 days > 2.5% of balance

Immediate candidate: **Chase LOC (~17–18%)**.

---

## 3) Weekly Finance Scoreboard Template (auto-generatable)

Use this exact template each Monday (or Sunday close).

```markdown
# Weekly Finance Scoreboard — {{week_start}} to {{week_end}}

## 1) Cash
- Real Cash Position: **${{real_cash_position}}**
- Reserve Floor: **${{reserve_floor}}**
- Reserve Target: **${{reserve_target}}**
- Reserve Coverage: **{{reserve_coverage_pct}}%**
- Status: {{cash_status}}  (Green >=100%, Yellow 75-99%, Red <75%)

## 2) Debt
- Total Debt: **${{total_debt}}**
- WoW Debt Change: **${{debt_change_wow}}**
- Estimated Monthly Interest Burn: **${{monthly_interest_estimate}}**
- #1 Payoff Target This Week: **{{top_target_debt_name}}**
- Extra Payment Sent to Target: **${{extra_payment_amount}}**

## 3) Margin
- Revenue (Week): **${{revenue_total}}**
- COGS (Week): **${{cogs_total}}**
- Gross Profit (Week): **${{gross_profit}}**
- Gross Margin %: **{{gross_margin_pct}}%**
- 4-Week Gross Margin %: **{{gross_margin_4wk_pct}}%**

## 4) Floor Graphics
- Floor Graphics Revenue: **${{floor_graphics_revenue}}**
- Floor Graphics Share of Revenue: **{{floor_graphics_share_pct}}%**
- Target Share: **{{floor_graphics_share_target_pct}}%**

## 5) This Week’s 3 Moves
1. {{action_1}}
2. {{action_2}}
3. {{action_3}}

## 6) Risk Alerts
- {{risk_alert_1}}
- {{risk_alert_2}}

## 7) Win
- {{weekly_win}}
```

### Scoreboard generation rules
- Keep to 1 screen on mobile
- No more than 3 actions each week
- Always include one positive win line (confidence reinforcement)

---

## 4) Cash Reconciliation Workflow (off-books + QuickBooks)

## 4.1 Goal
Every dollar received is visible in one of 3 places:
1. In bank
2. In cash-on-hand log
3. In transit deposit batch

If not in one of these, it is **unreconciled** and must be resolved weekly.

---

## 4.2 Workflow cadence

### Daily (10 minutes, end of day)
1. Log every cash payment in `offbooks_cash_log`
2. Assign `cash_txn_id`
3. Mark job type (floor graphics / other)
4. Count physical cash and record closing cash count
5. Investigate same-day variance > $20

### Deposit Day (2–3x per week)
1. Group undeposited cash into `deposit_batch_id`
2. Create matching deposit in QuickBooks (Bank Deposit)
3. Mark all included `offbooks_cash_log` rows as deposited
4. Save deposit slip reference

### Weekly Reconciliation (20–30 minutes)
1. Pull QuickBooks bank activity + undeposited funds
2. Match deposit batches by amount/date
3. Generate unreconciled list:
   - cash logged but not deposited >7 days
   - deposits in bank with no cash batch
   - cash sales with no invoice/sales receipt
4. Resolve each item or mark with owner + due date

### Month-End Close (by day 5)
1. Verify `unreconciled_cash_total <= tolerance` (target: $0, temporary tolerance: $100)
2. Post any required correction entries with notes
3. Lock monthly scoreboard snapshot

---

## 4.3 Reconciliation status fields

Use these statuses in `offbooks_cash_log`:
- `logged`
- `batched_for_deposit`
- `deposited`
- `matched_to_qb`
- `exception`

Any row in `exception` for >7 days is automatically RED on scoreboard.

---

## 5) Implementation Plan (simple rollout)

## Week 1 (Build + baseline)
- Create 4 core tables/logs (`cash_accounts_daily`, `offbooks_cash_log`, `debt_accounts`, `margin_weekly`)
- Enter all current debts with APR/min payments
- Set reserve floor/target to **$20K / $26K** (initial)
- Start daily off-books cash logging

## Week 2 (Automation + first scoreboard)
- Generate first weekly scoreboard from real data
- Run first debt waterfall allocation decision
- Run first full weekly cash reconciliation
- Fix top 3 reconciliation leaks

## Week 3+ (Stabilize)
- Tune reserve target based on actual volatility
- Tag all floor graphics invoices for clean revenue-share reporting
- Add alerts (reserve breach, unreconciled cash, debt increase)

---

## 6) Immediate Action List (next 48 hours)

1. Build and populate `debt_accounts` with exact APR + minimums for each card/loan
2. Start `offbooks_cash_log` for all new cash starting now
3. Set first weekly scoreboard date and publish baseline
4. Freeze extra debt prepayments until reserve floor rule is met
5. Launch LOC refinance check (rate quotes)

---

## 7) Anti-Overwhelm Operating Rule

- **Daily:** 10-minute cash capture
- **Weekly:** 20-minute scoreboard review
- **Monthly:** close by day 5

That’s it. Consistency beats complexity.

This system is designed to make finances visible and controlled — without judgment and without overload.
