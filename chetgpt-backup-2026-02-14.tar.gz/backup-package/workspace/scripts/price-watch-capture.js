#!/usr/bin/env node

/**
 * Price Watch Capture (v1.1)
 *
 * Captures NextDayFlyers prices automatically from watchlist URLs.
 * VistaPrint rows are left unchanged for now (DOM-rendered pricing requires browser capture).
 *
 * Usage:
 *   node scripts/price-watch-capture.js
 *   node scripts/price-watch-capture.js --watchlist research/price-watch/watchlist.csv --out research/price-watch/snapshots/2026-02-14-auto.csv
 */

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

function parseArgs(argv) {
  const out = {};
  for (let i = 2; i < argv.length; i++) {
    const token = argv[i];
    if (!token.startsWith('--')) continue;
    const key = token.slice(2);
    const next = argv[i + 1];
    out[key] = next && !next.startsWith('--') ? argv[++i] : true;
  }
  return out;
}

function splitCsvLine(line) {
  const out = [];
  let cur = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === ',' && !inQuotes) {
      out.push(cur);
      cur = '';
    } else {
      cur += ch;
    }
  }

  out.push(cur);
  return out;
}

function csvEscape(value) {
  const s = String(value ?? '');
  if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

function parseCsv(text) {
  const lines = text.split(/\r?\n/).filter(Boolean);
  if (!lines.length) return [];
  const header = splitCsvLine(lines[0]);

  return lines.slice(1).map((line) => {
    const cols = splitCsvLine(line);
    const row = {};
    for (let i = 0; i < header.length; i++) row[header[i]] = (cols[i] || '').trim();
    return row;
  });
}

function rowsToCsv(header, rows) {
  const lines = [header.join(',')];
  for (const row of rows) {
    lines.push(header.map((h) => csvEscape(row[h] ?? '')).join(','));
  }
  return `${lines.join('\n')}\n`;
}

async function fetchText(url) {
  const res = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (compatible; INKredible-PriceWatch/1.1; +https://shadowwall44.github.io)',
      Accept: 'text/html,application/xhtml+xml',
    },
  });

  if (!res.ok) {
    throw new Error(`HTTP ${res.status} for ${url}`);
  }

  return res.text();
}

function extractNdfPrice(html) {
  // 1) Product calculator current displayed price
  let m = html.match(/id=["']price["'][^>]*>\s*\$?\s*([0-9][0-9,]*\.?[0-9]{0,2})/i);
  if (m) {
    return Number(m[1].replace(/,/g, ''));
  }

  // 2) Structured lowPrice for some pages (e.g., banners)
  m = html.match(/"lowPrice"\s*:\s*"?([0-9]+(?:\.[0-9]+)?)/i);
  if (m) return Number(m[1]);

  // 3) Structured price fallback
  m = html.match(/"price"\s*:\s*"?([0-9]+(?:\.[0-9]+)?)/i);
  if (m) return Number(m[1]);

  return null;
}

function money(n) {
  return Number.isFinite(n) ? n.toFixed(2) : '';
}

function isoDate() {
  return new Date().toISOString().slice(0, 10);
}

async function main() {
  const args = parseArgs(process.argv);

  const watchlistPath = path.resolve(ROOT, args.watchlist || 'research/price-watch/watchlist.csv');
  if (!fs.existsSync(watchlistPath)) {
    throw new Error(`Watchlist not found: ${watchlistPath}`);
  }

  const outPath = path.resolve(
    ROOT,
    args.out || `research/price-watch/snapshots/${isoDate()}-auto.csv`
  );
  const outDir = path.dirname(outPath);
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

  const watchRows = parseCsv(fs.readFileSync(watchlistPath, 'utf8'));
  const byUrl = new Map();

  const results = [];
  let ndfAuto = 0;
  let ndfMiss = 0;
  let vistaRows = 0;

  for (const row of watchRows) {
    const competitor = row.competitor || '';
    const url = row.url || '';

    let price = '';
    let source = '';

    if (/nextdayflyers/i.test(competitor)) {
      try {
        if (!byUrl.has(url)) {
          byUrl.set(url, fetchText(url));
        }
        const html = await byUrl.get(url);
        const extracted = extractNdfPrice(html);
        if (Number.isFinite(extracted)) {
          price = money(extracted);
          source = 'auto:ndf-page-default';
          ndfAuto++;
        } else {
          source = 'auto:ndf-missing';
          ndfMiss++;
        }
      } catch (err) {
        source = `auto:error:${String(err.message || err).slice(0, 120)}`;
        ndfMiss++;
      }
    } else {
      vistaRows++;
      source = 'pending:browser-capture';
    }

    results.push({
      date: isoDate(),
      currency: 'USD',
      competitor,
      product: row.product || '',
      url,
      spec: row.spec || '',
      quantity: row.quantity || '',
      turnaround: row.turnaround || '',
      price,
      source,
    });
  }

  const header = [
    'date',
    'currency',
    'competitor',
    'product',
    'url',
    'spec',
    'quantity',
    'turnaround',
    'price',
    'source',
  ];

  fs.writeFileSync(outPath, rowsToCsv(header, results), 'utf8');

  console.log(`✅ Snapshot written: ${outPath}`);
  console.log(`- NextDayFlyers rows auto-priced: ${ndfAuto}`);
  console.log(`- NextDayFlyers rows missing: ${ndfMiss}`);
  console.log(`- VistaPrint rows pending browser capture: ${vistaRows}`);
}

main().catch((err) => {
  console.error(`❌ ${err.message}`);
  process.exit(1);
});
