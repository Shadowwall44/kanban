#!/usr/bin/env bash
# Parallel invoice extraction — runs multiple vendors concurrently
# Uses NVIDIA NIM (Kimi K2.5), no Gemini quota concerns
set -euo pipefail

WORKDIR="/home/inkredible/.openclaw/workspace"
OUT_DIR="$WORKDIR/extraction-results"
TS="$(date +%Y-%m-%d-%H%M%S)"
LOG_DIR="$OUT_DIR/run-logs/$TS"
mkdir -p "$LOG_DIR"

echo "📊 Starting parallel extraction at $(date)"
echo "Log dir: $LOG_DIR"

# Step 1: Prepare Ddpmsc retry — build errors.json from missing files
python3 - "$WORKDIR" <<'PY'
import csv, glob, json, os, sys
workdir = sys.argv[1]
out_dir = os.path.join(workdir, 'extraction-results')
inv_dir = os.path.join(workdir, 'inkredible-invoices', 'Ddpmsc')
csv_path = os.path.join(out_dir, 'ddpmsc-extracted.csv')

extracted = set()
if os.path.exists(csv_path):
    with open(csv_path, newline='', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            sf = (row.get('source_file') or '').strip()
            if sf: extracted.add(sf)

all_pdfs = sorted(os.path.basename(p) for p in glob.glob(os.path.join(inv_dir, '*.pdf')))
missing = [p for p in all_pdfs if p not in extracted]
errors = [{'file': f'Ddpmsc/{m}', 'error': 'pending retry'} for m in missing]

with open(os.path.join(out_dir, 'errors.json'), 'w', encoding='utf-8') as f:
    json.dump(errors, f, indent=2)
print(f"Ddpmsc: {len(missing)} files queued for retry")
PY

# Step 2: Launch extractions in parallel
# Group 1: Ddpmsc retry (51 files — heaviest)
echo "▶ Launching Ddpmsc retry..."
node "$WORKDIR/extract-invoices.mjs" --retry-failed Ddpmsc > "$LOG_DIR/ddpmsc.log" 2>&1 &
PID_DDPMSC=$!

# Small delay so file handles don't clash
sleep 3

# Group 2: Piedmont (43 files — second heaviest)
echo "▶ Launching Piedmontplastics..."
node "$WORKDIR/extract-invoices.mjs" Piedmontplastics > "$LOG_DIR/piedmontplastics.log" 2>&1 &
PID_PIEDMONT=$!

sleep 3

# Group 3: Steadfast (13 files)
echo "▶ Launching Steadfast Papers..."
node "$WORKDIR/extract-invoices.mjs" "Steadfast Papers Inc" > "$LOG_DIR/steadfast.log" 2>&1 &
PID_STEADFAST=$!

sleep 3

# Group 4: Small vendors sequentially (Sfsupplies, Shardarsp, Plockmatic, TriState, Uline = 17 files total)
echo "▶ Launching small vendors batch..."
(
  node "$WORKDIR/extract-invoices.mjs" Sfsupplies > "$LOG_DIR/sfsupplies.log" 2>&1
  node "$WORKDIR/extract-invoices.mjs" Shardarsp > "$LOG_DIR/shardarsp.log" 2>&1
  node "$WORKDIR/extract-invoices.mjs" "Plockmatic Document Finishing Inc" > "$LOG_DIR/plockmatic.log" 2>&1
  node "$WORKDIR/extract-invoices.mjs" "Tri State Knife Grinding Corp" > "$LOG_DIR/tristate.log" 2>&1
  node "$WORKDIR/extract-invoices.mjs" Uline > "$LOG_DIR/uline.log" 2>&1
) &
PID_SMALL=$!

echo ""
echo "⏳ 4 parallel tracks launched:"
echo "  Track 1 (PID $PID_DDPMSC): Ddpmsc retry — 51 files"
echo "  Track 2 (PID $PID_PIEDMONT): Piedmontplastics — 43 files"
echo "  Track 3 (PID $PID_STEADFAST): Steadfast Papers — 13 files"
echo "  Track 4 (PID $PID_SMALL): Small vendors — 17 files"
echo ""

# Step 3: Wait for all tracks
FAILED=0

wait $PID_DDPMSC || { echo "❌ Ddpmsc track failed"; FAILED=$((FAILED+1)); }
echo "✅ Ddpmsc track complete"

wait $PID_PIEDMONT || { echo "❌ Piedmontplastics track failed"; FAILED=$((FAILED+1)); }
echo "✅ Piedmontplastics track complete"

wait $PID_STEADFAST || { echo "❌ Steadfast track failed"; FAILED=$((FAILED+1)); }
echo "✅ Steadfast track complete"

wait $PID_SMALL || { echo "❌ Small vendors track failed"; FAILED=$((FAILED+1)); }
echo "✅ Small vendors track complete"

echo ""
echo "============================================================"
echo "ALL TRACKS COMPLETE at $(date)"
echo "Failed tracks: $FAILED"
echo "============================================================"

# Step 4: Compile summary
python3 - "$WORKDIR" "$LOG_DIR" <<'PY'
import csv, glob, json, os, sys

workdir, log_dir = sys.argv[1:]
inv_dir = os.path.join(workdir, 'inkredible-invoices')
out_dir = os.path.join(workdir, 'extraction-results')

vendors = sorted([d for d in os.listdir(inv_dir)
                   if os.path.isdir(os.path.join(inv_dir, d)) and not d.startswith('.')],
                  key=str.lower)

total_items = 0
total_extracted = 0
total_pdfs = 0
total_remaining = 0
total_failures = 0
rows = []

for v in vendors:
    pdfs = glob.glob(os.path.join(inv_dir, v, '**', '*.pdf'), recursive=True)
    csv_path = os.path.join(out_dir, f"{v.lower()}-extracted.csv")
    extracted = set()
    items = 0
    if os.path.exists(csv_path):
        with open(csv_path, newline='') as f:
            for row in csv.DictReader(f):
                items += 1
                sf = (row.get('source_file') or '').strip()
                if sf: extracted.add(sf)
    basenames = set(os.path.basename(p) for p in pdfs)
    done = len(basenames & extracted)
    remaining = len(basenames) - done
    total_items += items
    total_extracted += done
    total_pdfs += len(pdfs)
    total_remaining += remaining
    rows.append(f"{v}: {done}/{len(pdfs)} PDFs, {items} items, {remaining} remaining")

# Count failures from log files
for log_file in glob.glob(os.path.join(log_dir, '*.log')):
    with open(log_file) as f:
        content = f.read()
        # Count "FAILED:" lines
        total_failures += content.count('❌ FAILED:')

summary = {
    'total_items': total_items,
    'total_extracted_pdfs': total_extracted,
    'total_pdfs': total_pdfs,
    'total_remaining': total_remaining,
    'total_failures': total_failures,
    'vendor_breakdown': rows,
}

with open(os.path.join(log_dir, 'summary.json'), 'w') as f:
    json.dump(summary, f, indent=2)

# Update coverage CSV
with open(os.path.join(out_dir, f"vendor-coverage-final.csv"), 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['folder', 'pdf_total', 'pdf_extracted', 'pdf_remaining', 'coverage_pct', 'items'])
    for v in vendors:
        pdfs = glob.glob(os.path.join(inv_dir, v, '**', '*.pdf'), recursive=True)
        csv_path = os.path.join(out_dir, f"{v.lower()}-extracted.csv")
        extracted = set()
        items = 0
        if os.path.exists(csv_path):
            with open(csv_path, newline='') as ff:
                for row in csv.DictReader(ff):
                    items += 1
                    sf = (row.get('source_file') or '').strip()
                    if sf: extracted.add(sf)
        basenames = set(os.path.basename(p) for p in pdfs)
        done = len(basenames & extracted)
        remaining = len(basenames) - done
        pct = round(done/len(pdfs)*100,1) if pdfs else 0
        w.writerow([v, len(pdfs), done, remaining, pct, items])

print("=== FINAL SUMMARY ===")
print(f"Total items extracted: {total_items}")
print(f"PDFs extracted: {total_extracted}/{total_pdfs}")
print(f"Remaining: {total_remaining}")
print(f"Failures: {total_failures}")
for r in rows:
    print(f"  {r}")
PY
