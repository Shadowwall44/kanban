#!/usr/bin/env node

/**
 * Compare two competitor-pricing snapshot CSVs and generate a markdown report.
 *
 * Usage:
 *   node scripts/price-watch-diff.js
 *   node scripts/price-watch-diff.js --old path/to/old.csv --new path/to/new.csv --out reports/price-watch-2026-02-14.md
 */

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const SNAPSHOT_DIR = path.join(ROOT, 'research', 'price-watch', 'snapshots');
const REPORT_DIR = path.join(ROOT, 'reports');

function parseArgs(argv) {
  const args = {};
  for (let i = 2; i < argv.length; i++) {
    const token = argv[i];
    if (token.startsWith('--')) {
      const key = token.slice(2);
      const value = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : true;
      args[key] = value;
    }
  }
  return args;
}

function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });
}

function parseCsv(text) {
  const lines = text.split(/\r?\n/).filter(Boolean);
  if (lines.length < 2) return [];
  const header = splitCsvLine(lines[0]);
  return lines.slice(1).map((line) => {
    const cols = splitCsvLine(line);
    const obj = {};
    for (let i = 0; i < header.length; i++) {
      obj[header[i]] = (cols[i] || '').trim();
    }
    return obj;
  });
}

function splitCsvLine(line) {
  const out = [];
  let cur = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === ',' && !inQuotes) {
      out.push(cur);
      cur = '';
    } else {
      cur += ch;
    }
  }
  out.push(cur);
  return out;
}

function toNumber(raw) {
  const cleaned = String(raw || '')
    .replace(/[$,\s]/g, '')
    .trim();
  if (!cleaned) return NaN;
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : NaN;
}

function keyFor(row) {
  return [
    row.competitor || '',
    row.product || '',
    row.spec || '',
    row.quantity || '',
    row.turnaround || '',
  ].join('||');
}

function pctChange(oldPrice, newPrice) {
  if (!Number.isFinite(oldPrice) || oldPrice === 0) return null;
  return ((newPrice - oldPrice) / oldPrice) * 100;
}

function formatMoney(n) {
  return `$${n.toFixed(2)}`;
}

function formatPct(n) {
  const sign = n > 0 ? '+' : '';
  return `${sign}${n.toFixed(2)}%`;
}

function getLatestSnapshots() {
  if (!fs.existsSync(SNAPSHOT_DIR)) {
    throw new Error(`Snapshot directory not found: ${SNAPSHOT_DIR}`);
  }
  const files = fs
    .readdirSync(SNAPSHOT_DIR)
    .filter((f) => f.toLowerCase().endsWith('.csv'))
    .sort();

  if (files.length < 2) {
    throw new Error('Need at least 2 snapshot CSV files in research/price-watch/snapshots');
  }

  return {
    oldPath: path.join(SNAPSHOT_DIR, files[files.length - 2]),
    newPath: path.join(SNAPSHOT_DIR, files[files.length - 1]),
  };
}

function buildReport({ oldRows, newRows, oldPath, newPath }) {
  const oldMap = new Map(oldRows.map((r) => [keyFor(r), r]));
  const newMap = new Map(newRows.map((r) => [keyFor(r), r]));

  const allKeys = new Set([...oldMap.keys(), ...newMap.keys()]);

  const changed = [];
  const added = [];
  const removed = [];
  const newlyPriced = [];
  const lostPrices = [];
  let unchangedCount = 0;

  for (const k of allKeys) {
    const oldRow = oldMap.get(k);
    const newRow = newMap.get(k);

    if (!oldRow && newRow) {
      added.push(newRow);
      continue;
    }
    if (oldRow && !newRow) {
      removed.push(oldRow);
      continue;
    }

    const oldPrice = toNumber(oldRow.price);
    const newPrice = toNumber(newRow.price);

    if (!Number.isFinite(oldPrice) && Number.isFinite(newPrice)) {
      newlyPriced.push({
        competitor: newRow.competitor,
        product: newRow.product,
        spec: newRow.spec,
        quantity: newRow.quantity,
        turnaround: newRow.turnaround,
        newPrice,
      });
      continue;
    }

    if (Number.isFinite(oldPrice) && !Number.isFinite(newPrice)) {
      lostPrices.push({
        competitor: newRow.competitor,
        product: newRow.product,
        spec: newRow.spec,
        quantity: newRow.quantity,
        turnaround: newRow.turnaround,
        oldPrice,
      });
      continue;
    }

    if (!Number.isFinite(oldPrice) && !Number.isFinite(newPrice)) {
      unchangedCount++;
      continue;
    }

    if (Math.abs(oldPrice - newPrice) < 0.0001) {
      unchangedCount++;
      continue;
    }

    const pct = pctChange(oldPrice, newPrice);
    changed.push({
      competitor: newRow.competitor,
      product: newRow.product,
      spec: newRow.spec,
      quantity: newRow.quantity,
      turnaround: newRow.turnaround,
      oldPrice,
      newPrice,
      delta: newPrice - oldPrice,
      pct,
      url: newRow.url,
    });
  }

  changed.sort((a, b) => Math.abs(b.delta) - Math.abs(a.delta));

  const up = changed.filter((c) => c.delta > 0);
  const down = changed.filter((c) => c.delta < 0);
  const volatile = changed.filter((c) => c.pct !== null && Math.abs(c.pct) >= 10);

  const dateStamp = new Date().toISOString().slice(0, 10);

  let md = `# Competitor Price Watch Report — ${dateStamp}\n\n`;
  md += `Compared:\n`;
  md += `- Old: ${path.basename(oldPath)}\n`;
  md += `- New: ${path.basename(newPath)}\n\n`;
  md += `## Summary\n`;
  md += `- Total tracked lines: ${allKeys.size}\n`;
  md += `- Price changes: ${changed.length}\n`;
  md += `- Increased: ${up.length}\n`;
  md += `- Decreased: ${down.length}\n`;
  md += `- Unchanged: ${unchangedCount}\n`;
  md += `- Added lines: ${added.length}\n`;
  md += `- Removed lines: ${removed.length}\n`;
  md += `- Newly priced (was blank -> now has price): ${newlyPriced.length}\n`;
  md += `- Lost prices (had price -> now blank): ${lostPrices.length}\n`;
  md += `- Volatile (>=10% move): ${volatile.length}\n\n`;

  if (changed.length === 0) {
    md += `## Changes\nNo price changes detected between the two snapshots.\n`;
  } else {
    md += `## Changes\n`;
    md += `| Competitor | Product | Spec | Qty | Turnaround | Old | New | Delta | % |\n`;
    md += `|---|---|---|---:|---|---:|---:|---:|---:|\n`;
    for (const c of changed) {
      md += `| ${c.competitor} | ${c.product} | ${c.spec} | ${c.quantity} | ${c.turnaround} | ${formatMoney(c.oldPrice)} | ${formatMoney(c.newPrice)} | ${formatMoney(c.delta)} | ${c.pct === null ? 'n/a' : formatPct(c.pct)} |\n`;
    }
    md += `\n`;
  }

  if (volatile.length > 0) {
    md += `## Action Alerts (>=10% move)\n`;
    for (const v of volatile) {
      const direction = v.delta > 0 ? 'UP' : 'DOWN';
      md += `- ${direction} ${v.competitor} ${v.product} (${v.spec}, qty ${v.quantity}, ${v.turnaround}): ${formatMoney(v.oldPrice)} → ${formatMoney(v.newPrice)} (${formatPct(v.pct)})\n`;
    }
    md += `\n`;
  }

  if (newlyPriced.length > 0) {
    md += `## Newly Priced Rows\n`;
    for (const r of newlyPriced) {
      md += `- ${r.competitor} | ${r.product} | ${r.spec} | qty ${r.quantity} | ${r.turnaround} | ${formatMoney(r.newPrice)}\n`;
    }
    md += `\n`;
  }

  if (lostPrices.length > 0) {
    md += `## Lost Price Rows\n`;
    for (const r of lostPrices) {
      md += `- ${r.competitor} | ${r.product} | ${r.spec} | qty ${r.quantity} | ${r.turnaround} | was ${formatMoney(r.oldPrice)}\n`;
    }
    md += `\n`;
  }

  if (added.length > 0) {
    md += `## Added Rows\n`;
    for (const r of added) {
      md += `- ${r.competitor} | ${r.product} | ${r.spec} | qty ${r.quantity} | ${r.turnaround}\n`;
    }
    md += `\n`;
  }

  if (removed.length > 0) {
    md += `## Removed Rows\n`;
    for (const r of removed) {
      md += `- ${r.competitor} | ${r.product} | ${r.spec} | qty ${r.quantity} | ${r.turnaround}\n`;
    }
    md += `\n`;
  }

  return md;
}

function main() {
  const args = parseArgs(process.argv);
  ensureDir(REPORT_DIR);

  let oldPath = args.old;
  let newPath = args.new;

  if (!oldPath || !newPath) {
    const latest = getLatestSnapshots();
    oldPath = oldPath || latest.oldPath;
    newPath = newPath || latest.newPath;
  }

  if (!fs.existsSync(oldPath)) throw new Error(`Old snapshot not found: ${oldPath}`);
  if (!fs.existsSync(newPath)) throw new Error(`New snapshot not found: ${newPath}`);

  const oldRows = parseCsv(fs.readFileSync(oldPath, 'utf8'));
  const newRows = parseCsv(fs.readFileSync(newPath, 'utf8'));

  const outPath = args.out || path.join(REPORT_DIR, `price-watch-${new Date().toISOString().slice(0, 10)}.md`);

  const report = buildReport({ oldRows, newRows, oldPath, newPath });
  fs.writeFileSync(outPath, report, 'utf8');

  console.log(`✅ Report written: ${outPath}`);
}

try {
  main();
} catch (err) {
  console.error(`❌ ${err.message}`);
  process.exit(1);
}
