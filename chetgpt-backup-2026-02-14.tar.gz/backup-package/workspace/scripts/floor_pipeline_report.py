#!/usr/bin/env python3
"""Generate weekly floor graphics pipeline KPI report from CSV."""
from __future__ import annotations
import csv
import statistics
from datetime import date, datetime, timedelta
from pathlib import Path

CSV_PATH = Path('/home/inkredible/.openclaw/workspace/templates/floor-graphics-pipeline-template.csv')
OUT_PATH = Path('/home/inkredible/.openclaw/workspace/reports/floor-pipeline-weekly.md')


def parse_date(raw: str) -> date | None:
    raw = (raw or '').strip()
    if not raw:
        return None
    try:
        return datetime.strptime(raw, '%Y-%m-%d').date()
    except ValueError:
        return None


def previous_week_window(today: date) -> tuple[date, date]:
    # Monday=0 ... Sunday=6
    this_week_monday = today - timedelta(days=today.weekday())
    prev_monday = this_week_monday - timedelta(days=7)
    prev_sunday = this_week_monday - timedelta(days=1)
    return prev_monday, prev_sunday


def in_window(d: date | None, start: date, end: date) -> bool:
    return d is not None and start <= d <= end


def pct(n: float, d: float) -> float:
    return (n / d * 100.0) if d else 0.0


def median_or_zero(values: list[float]) -> float:
    return statistics.median(values) if values else 0.0


def stage_status(value: float, green_min: float | None = None, yellow_min: float | None = None,
                 green_max: float | None = None, yellow_max: float | None = None) -> str:
    if green_min is not None:
        if value >= green_min:
            return 'Green'
        if yellow_min is not None and value >= yellow_min:
            return 'Yellow'
        return 'Red'
    if green_max is not None:
        if value <= green_max:
            return 'Green'
        if yellow_max is not None and value <= yellow_max:
            return 'Yellow'
        return 'Red'
    return 'N/A'


def main() -> None:
    today = date.today()
    week_start, week_end = previous_week_window(today)

    rows: list[dict[str, str]] = []
    if not CSV_PATH.exists():
        raise SystemExit(f'Missing CSV: {CSV_PATH}')

    with CSV_PATH.open(newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    leads_week = [r for r in rows if in_window(parse_date(r.get('lead_created_date', '')), week_start, week_end)]
    leads_count = len(leads_week)

    discovery_count = sum(1 for r in leads_week if (r.get('stage', '').strip().lower() in {
        'discovery_complete', 'quote_sent', 'deposit_received', 'production_scheduled',
        'delivered_installed', 'paid_in_full', 'follow_up'
    }))

    quote_count = sum(1 for r in leads_week if (r.get('stage', '').strip().lower() in {
        'quote_sent', 'deposit_received', 'production_scheduled', 'delivered_installed', 'paid_in_full', 'follow_up'
    }))

    deposit_count = sum(1 for r in leads_week if (r.get('stage', '').strip().lower() in {
        'deposit_received', 'production_scheduled', 'delivered_installed', 'paid_in_full', 'follow_up'
    }))

    won_rows = [r for r in leads_week if r.get('won_lost', '').strip().lower() == 'won']
    lost_rows = [r for r in leads_week if r.get('won_lost', '').strip().lower() == 'lost']

    def fnum(r: dict[str, str], key: str) -> float:
        raw = (r.get(key, '') or '').strip().replace(',', '')
        if not raw:
            return 0.0
        try:
            return float(raw)
        except ValueError:
            return 0.0

    quoted_value = sum(fnum(r, 'quoted_amount') for r in leads_week)
    booked_revenue = sum(fnum(r, 'deposit_amount') for r in leads_week)
    delivered_revenue = sum(fnum(r, 'quoted_amount') for r in leads_week if r.get('stage', '').strip().lower() in {'delivered_installed', 'paid_in_full', 'follow_up'})

    avg_won_value = (sum(fnum(r, 'quoted_amount') for r in won_rows) / len(won_rows)) if won_rows else 0.0

    repeat_won = sum(1 for r in won_rows if (r.get('is_repeat_client', '').strip().lower() in {'true', '1', 'yes'}))

    lead_to_quote = [fnum(r, 'days_to_quote') for r in leads_week if fnum(r, 'days_to_quote') > 0]
    quote_to_deposit = [fnum(r, 'days_quote_to_deposit') for r in leads_week if fnum(r, 'days_quote_to_deposit') > 0]
    deposit_to_delivery = [fnum(r, 'days_deposit_to_delivery') for r in leads_week if fnum(r, 'days_deposit_to_delivery') > 0]

    close_rate = pct(deposit_count, quote_count)
    quote_rate = pct(quote_count, leads_count)
    discovery_rate = pct(discovery_count, leads_count)
    win_rate = pct(len(won_rows), len(won_rows) + len(lost_rows))
    repeat_rate = pct(repeat_won, len(won_rows))

    close_status = stage_status(close_rate, green_min=40, yellow_min=25)
    lq_status = stage_status(median_or_zero(lead_to_quote), green_max=1, yellow_max=2)
    qd_status = stage_status(median_or_zero(quote_to_deposit), green_max=3, yellow_max=6)
    ticket_status = stage_status(avg_won_value, green_min=3500, yellow_min=2000)

    out = f"""# Floor Graphics Pipeline Weekly Report\n\nWindow: {week_start} to {week_end}\nGenerated: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n## 1) Volume + Conversion\n- New leads: **{leads_count}**\n- Discovery completion rate: **{discovery_rate:.1f}%**\n- Quote rate: **{quote_rate:.1f}%**\n- Close rate (quotes→deposits): **{close_rate:.1f}%** ({close_status})\n- Win rate: **{win_rate:.1f}%**\n\n## 2) Speed\n- Lead→Quote median days: **{median_or_zero(lead_to_quote):.1f}** ({lq_status})\n- Quote→Deposit median days: **{median_or_zero(quote_to_deposit):.1f}** ({qd_status})\n- Deposit→Delivery median days: **{median_or_zero(deposit_to_delivery):.1f}**\n\n## 3) Revenue Quality\n- Quoted value this week: **${quoted_value:,.2f}**\n- Booked revenue (deposits): **${booked_revenue:,.2f}**\n- Delivered revenue: **${delivered_revenue:,.2f}**\n- Average won job value: **${avg_won_value:,.2f}** ({ticket_status})\n- Repeat-client rate (won jobs): **{repeat_rate:.1f}%**\n\n## 4) Next 3 Moves\n1. Speed up quote turnaround to <=1 day for all fresh leads.\n2. Push quote follow-up cadence at 24h / 72h / 7d until deposit or clear loss reason.\n3. Review losses and remove top 1 recurring objection this week.\n"""

    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUT_PATH.write_text(out, encoding='utf-8')
    print(f'Wrote {OUT_PATH}')


if __name__ == '__main__':
    main()
