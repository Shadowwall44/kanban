#!/usr/bin/env bash
# Sequential invoice extraction with 2 parallel tracks max
# Track A: Small vendors (quick wins) then Steadfast
# Track B: Ddpmsc retry (51 files)
# After both complete: Piedmontplastics (43 files)
set -euo pipefail

WORKDIR="/home/inkredible/.openclaw/workspace"
OUT_DIR="$WORKDIR/extraction-results"
TS="$(date +%Y-%m-%d-%H%M%S)"
LOG_DIR="$OUT_DIR/run-logs/$TS"
mkdir -p "$LOG_DIR"

echo "📊 Starting extraction at $(date)"
echo "Log dir: $LOG_DIR"

# Prepare Ddpmsc retry errors.json
python3 - "$WORKDIR" <<'PY'
import csv, glob, json, os, sys
workdir = sys.argv[1]
out_dir = os.path.join(workdir, 'extraction-results')
inv_dir = os.path.join(workdir, 'inkredible-invoices', 'Ddpmsc')
csv_path = os.path.join(out_dir, 'ddpmsc-extracted.csv')
extracted = set()
if os.path.exists(csv_path):
    with open(csv_path, newline='', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            sf = (row.get('source_file') or '').strip()
            if sf: extracted.add(sf)
all_pdfs = sorted(os.path.basename(p) for p in glob.glob(os.path.join(inv_dir, '*.pdf')))
missing = [p for p in all_pdfs if p not in extracted]
errors = [{'file': f'Ddpmsc/{m}', 'error': 'pending retry'} for m in missing]
with open(os.path.join(out_dir, 'errors.json'), 'w', encoding='utf-8') as f:
    json.dump(errors, f, indent=2)
print(f"Ddpmsc: {len(missing)} files queued for retry")
PY

# Track A: Small vendors then Steadfast
echo "▶ Track A: Small vendors + Steadfast"
(
  echo "[A] Uline (1 file)..." && node "$WORKDIR/extract-invoices.mjs" Uline 2>&1
  echo "[A] Shardarsp (4 files)..." && node "$WORKDIR/extract-invoices.mjs" Shardarsp 2>&1
  echo "[A] Plockmatic (4 files)..." && node "$WORKDIR/extract-invoices.mjs" "Plockmatic Document Finishing Inc" 2>&1
  echo "[A] Sfsupplies (5 files)..." && node "$WORKDIR/extract-invoices.mjs" Sfsupplies 2>&1
  echo "[A] Steadfast (13 files)..." && node "$WORKDIR/extract-invoices.mjs" "Steadfast Papers Inc" 2>&1
  echo "[A] TRACK A COMPLETE at $(date)"
) > "$LOG_DIR/track-a.log" 2>&1 &
PID_A=$!

sleep 5

# Track B: Ddpmsc retry
echo "▶ Track B: Ddpmsc retry (51 files)"
node "$WORKDIR/extract-invoices.mjs" --retry-failed Ddpmsc > "$LOG_DIR/track-b-ddpmsc.log" 2>&1 &
PID_B=$!

echo "⏳ 2 tracks launched: A (PID $PID_A), B (PID $PID_B)"

# Wait for Track A
wait $PID_A && echo "✅ Track A complete" || echo "⚠️ Track A had errors"

# Wait for Track B
wait $PID_B && echo "✅ Track B complete" || echo "⚠️ Track B had errors"

echo ""
echo "▶ Track C: Piedmontplastics (43 files — solo)"
node "$WORKDIR/extract-invoices.mjs" Piedmontplastics > "$LOG_DIR/track-c-piedmont.log" 2>&1
echo "✅ Track C complete"

echo ""
echo "============================================================"
echo "ALL EXTRACTION COMPLETE at $(date)"
echo "============================================================"

# Final summary
python3 - "$WORKDIR" "$LOG_DIR" <<'PY'
import csv, glob, json, os, sys

workdir, log_dir = sys.argv[1:]
inv_dir = os.path.join(workdir, 'inkredible-invoices')
out_dir = os.path.join(workdir, 'extraction-results')

vendors = sorted([d for d in os.listdir(inv_dir)
                   if os.path.isdir(os.path.join(inv_dir, d)) and not d.startswith('.')],
                  key=str.lower)

total_items = 0
total_extracted = 0
total_pdfs = 0
total_remaining = 0
total_failures = 0
rows = []

for v in vendors:
    pdfs = glob.glob(os.path.join(inv_dir, v, '**', '*.pdf'), recursive=True)
    csv_path = os.path.join(out_dir, f"{v.lower()}-extracted.csv")
    extracted = set()
    items = 0
    if os.path.exists(csv_path):
        with open(csv_path, newline='') as f:
            for row in csv.DictReader(f):
                items += 1
                sf = (row.get('source_file') or '').strip()
                if sf: extracted.add(sf)
    basenames = set(os.path.basename(p) for p in pdfs)
    done = len(basenames & extracted)
    remaining = len(basenames) - done
    total_items += items
    total_extracted += done
    total_pdfs += len(pdfs)
    total_remaining += remaining
    rows.append(f"  {v}: {done}/{len(pdfs)} PDFs ({items} items)")

# Count failures from all logs
for log_file in glob.glob(os.path.join(log_dir, '*.log')):
    with open(log_file) as f:
        content = f.read()
        total_failures += content.count('❌ FAILED:')

summary = {
    'total_items': total_items,
    'total_extracted_pdfs': total_extracted,
    'total_pdfs': total_pdfs,
    'total_remaining': total_remaining,
    'total_failures': total_failures,
}

with open(os.path.join(log_dir, 'summary.json'), 'w') as f:
    json.dump(summary, f, indent=2)

# Coverage CSV
with open(os.path.join(out_dir, 'vendor-coverage-final.csv'), 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['folder', 'pdf_total', 'pdf_extracted', 'pdf_remaining', 'coverage_pct', 'items'])
    for v in vendors:
        pdfs = glob.glob(os.path.join(inv_dir, v, '**', '*.pdf'), recursive=True)
        csv_path = os.path.join(out_dir, f"{v.lower()}-extracted.csv")
        extracted = set()
        items = 0
        if os.path.exists(csv_path):
            with open(csv_path, newline='') as ff:
                for row in csv.DictReader(ff):
                    items += 1
                    sf = (row.get('source_file') or '').strip()
                    if sf: extracted.add(sf)
        basenames = set(os.path.basename(p) for p in pdfs)
        done = len(basenames & extracted)
        remaining = len(basenames) - done
        pct = round(done/len(pdfs)*100,1) if pdfs else 0
        w.writerow([v, len(pdfs), done, remaining, pct, items])

# Print for the calling agent to capture
new_items = total_items - 123  # baseline from last run
print(f"NEW_ITEMS={max(0, new_items)}")
print(f"FAILURES={total_failures}")
print(f"REMAINING={total_remaining}")
print(f"TOTAL_ITEMS={total_items}")
print(f"TOTAL_PDFS_DONE={total_extracted}")
print(f"TOTAL_PDFS={total_pdfs}")
for r in rows:
    print(r)
PY
