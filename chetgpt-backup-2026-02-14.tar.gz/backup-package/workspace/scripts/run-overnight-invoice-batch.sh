#!/usr/bin/env bash
set -euo pipefail

WORKDIR="/home/inkredible/.openclaw/workspace"
INVOICES_DIR="$WORKDIR/inkredible-invoices"
OUT_DIR="$WORKDIR/extraction-results"
TS="$(date +%Y-%m-%d-%H%M%S)"
RUN_DIR="$OUT_DIR/run-logs/$TS"
mkdir -p "$RUN_DIR"

stats_json() {
  local out_json="$1"
  local out_csv="$2"
  python3 - "$WORKDIR" "$out_json" "$out_csv" <<'PY'
import csv, glob, json, os, sys
workdir, out_json, out_csv = sys.argv[1:]
invoices_dir = os.path.join(workdir, 'inkredible-invoices')
out_dir = os.path.join(workdir, 'extraction-results')

vendors = [d for d in os.listdir(invoices_dir)
           if os.path.isdir(os.path.join(invoices_dir, d)) and not d.startswith('.')]
vendors.sort(key=str.lower)

coverage = []
total_items = 0
remaining_total = 0

for vendor in vendors:
    pdf_paths = sorted(glob.glob(os.path.join(invoices_dir, vendor, '**', '*.pdf'), recursive=True))
    pdf_basenames = [os.path.basename(p) for p in pdf_paths]
    pdf_total = len(pdf_basenames)

    csv_path = os.path.join(out_dir, f"{vendor.lower()}-extracted.csv")
    extracted_files = set()
    item_rows = 0

    if os.path.exists(csv_path):
        with open(csv_path, newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                item_rows += 1
                sf = (row.get('source_file') or '').strip()
                if sf:
                    extracted_files.add(sf)

    extracted_count = len(set(pdf_basenames) & extracted_files)
    remaining = max(0, pdf_total - extracted_count)
    pct = (extracted_count / pdf_total * 100) if pdf_total else 0.0

    coverage.append({
        'vendor': vendor,
        'pdf_total': pdf_total,
        'pdf_extracted': extracted_count,
        'pdf_remaining': remaining,
        'coverage_pct': round(pct, 1),
        'item_rows': item_rows
    })

    total_items += item_rows
    remaining_total += remaining

with open(out_json, 'w', encoding='utf-8') as f:
    json.dump({'total_items': total_items, 'remaining_pdfs': remaining_total, 'coverage': coverage}, f, indent=2)

with open(out_csv, 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['folder', 'pdf_total', 'pdf_extracted', 'pdf_remaining', 'coverage_pct'])
    for row in coverage:
        w.writerow([row['vendor'], row['pdf_total'], row['pdf_extracted'], row['pdf_remaining'], row['coverage_pct']])
PY
}

prepare_ddpmsc_missing_errors() {
  python3 - "$WORKDIR" <<'PY'
import csv, glob, json, os, sys
workdir = sys.argv[1]
out_dir = os.path.join(workdir, 'extraction-results')
inv_dir = os.path.join(workdir, 'inkredible-invoices', 'Ddpmsc')
csv_path = os.path.join(out_dir, 'ddpmsc-extracted.csv')

extracted = set()
if os.path.exists(csv_path):
    with open(csv_path, newline='', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            sf = (row.get('source_file') or '').strip()
            if sf:
                extracted.add(sf)

all_pdfs = sorted(os.path.basename(p) for p in glob.glob(os.path.join(inv_dir, '*.pdf')))
missing = [p for p in all_pdfs if p not in extracted]
errors = [{'file': f'Ddpmsc/{m}', 'error': 'pending retry'} for m in missing]

with open(os.path.join(out_dir, 'errors.json'), 'w', encoding='utf-8') as f:
    json.dump(errors, f, indent=2)

print(len(missing))
PY
}

failures_total=0
quota_exhausted=0

run_cmd() {
  local label="$1"
  shift
  local log="$RUN_DIR/${label}.log"
  echo "============================================================"
  echo "▶ Running: $label"
  echo "============================================================"

  set +e
  "$@" 2>&1 | tee "$log"
  local exit_code=${PIPESTATUS[0]}
  set -e

  local run_failures=0
  if [[ -f "$OUT_DIR/errors.json" ]]; then
    run_failures=$(python3 - <<'PY'
import json
try:
    with open('/home/inkredible/.openclaw/workspace/extraction-results/errors.json', 'r', encoding='utf-8') as f:
        data = json.load(f)
    print(len(data) if isinstance(data, list) else 0)
except Exception:
    print(0)
PY
)
  fi
  failures_total=$((failures_total + run_failures))

  if grep -qi "exceeded your current quota" "$log"; then
    quota_exhausted=1
    return 99
  fi
  if grep -q "API 429" "$log" && grep -q "Succeeded: 0" "$log"; then
    quota_exhausted=1
    return 99
  fi

  if [[ $exit_code -ne 0 ]]; then
    return $exit_code
  fi

  return 0
}

before_json="$RUN_DIR/stats-before.json"
before_csv="$RUN_DIR/vendor-coverage-before.csv"
stats_json "$before_json" "$before_csv"

DDPMSC_MISSING=$(prepare_ddpmsc_missing_errors)
echo "Ddpmsc missing PDFs queued for retry: $DDPMSC_MISSING"

if [[ "$DDPMSC_MISSING" -gt 0 ]]; then
  if ! run_cmd "01-ddpmsc-retry-failed" node "$WORKDIR/extract-invoices.mjs" --retry-failed Ddpmsc; then
    code=$?
    if [[ $code -eq 99 ]]; then
      echo "QUOTA_EXHAUSTED=1" > "$RUN_DIR/status.env"
    else
      echo "BATCH_FAILED_EXIT=$code" > "$RUN_DIR/status.env"
      exit $code
    fi
  fi
fi

if [[ $quota_exhausted -eq 0 ]]; then
  run_cmd "02-piedmontplastics" node "$WORKDIR/extract-invoices.mjs" Piedmontplastics || true
fi
if [[ $quota_exhausted -eq 0 ]]; then
  run_cmd "03-plockmatic" node "$WORKDIR/extract-invoices.mjs" "Plockmatic Document Finishing Inc" || true
fi
if [[ $quota_exhausted -eq 0 ]]; then
  run_cmd "04-sfsupplies" node "$WORKDIR/extract-invoices.mjs" Sfsupplies || true
fi
if [[ $quota_exhausted -eq 0 ]]; then
  run_cmd "05-shardarsp" node "$WORKDIR/extract-invoices.mjs" Shardarsp || true
fi
if [[ $quota_exhausted -eq 0 ]]; then
  run_cmd "06-steadfast" node "$WORKDIR/extract-invoices.mjs" "Steadfast Papers Inc" || true
fi
if [[ $quota_exhausted -eq 0 ]]; then
  run_cmd "07-tri-state" node "$WORKDIR/extract-invoices.mjs" "Tri State Knife Grinding Corp" || true
fi
if [[ $quota_exhausted -eq 0 ]]; then
  run_cmd "08-uline" node "$WORKDIR/extract-invoices.mjs" Uline || true
fi

after_json="$RUN_DIR/stats-after.json"
after_csv="$OUT_DIR/vendor-coverage-$(date +%Y-%m-%d).csv"
stats_json "$after_json" "$after_csv"

python3 - "$before_json" "$after_json" "$RUN_DIR" "$failures_total" "$quota_exhausted" <<'PY'
import json, os, sys
before_path, after_path, run_dir, failures_total, quota_exhausted = sys.argv[1:]
with open(before_path, 'r', encoding='utf-8') as f:
    before = json.load(f)
with open(after_path, 'r', encoding='utf-8') as f:
    after = json.load(f)

summary = {
    'new_items_extracted': max(0, int(after.get('total_items', 0)) - int(before.get('total_items', 0))),
    'failures': int(failures_total),
    'remaining_pdfs': int(after.get('remaining_pdfs', 0)),
    'quota_exhausted': bool(int(quota_exhausted)),
    'before_total_items': int(before.get('total_items', 0)),
    'after_total_items': int(after.get('total_items', 0)),
    'run_dir': run_dir,
}

out = os.path.join(run_dir, 'summary.json')
with open(out, 'w', encoding='utf-8') as f:
    json.dump(summary, f, indent=2)

print(json.dumps(summary))
PY
