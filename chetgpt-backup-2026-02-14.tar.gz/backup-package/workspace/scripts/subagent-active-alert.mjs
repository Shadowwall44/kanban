#!/usr/bin/env node
import fs from 'fs';
import path from 'path';

const WORKSPACE = '/home/inkredible/.openclaw/workspace';
const SESSION_DIR = '/home/inkredible/.openclaw/agents/main/sessions';
const REPORT_DIR = path.join(WORKSPACE, 'reports');
const STATE_DIR = path.join(WORKSPACE, '.state');
const STATE_PATH = path.join(STATE_DIR, 'subagent-active-alert-state.json');

const LOOKBACK_MIN = Number(process.env.LOOKBACK_MIN || 90);
const ALERT_THRESHOLD = Number(process.env.ALERT_THRESHOLD || 5);
const MAX_FILES = Number(process.env.MAX_FILES || 200);

function safeParse(line) {
  try {
    return JSON.parse(line);
  } catch {
    return null;
  }
}

function compact(text = '', max = 100) {
  const one = String(text || '').replace(/\s+/g, ' ').trim();
  return one.length > max ? `${one.slice(0, max - 3)}...` : one;
}

function parseToolResultDetails(message) {
  if (message?.details && typeof message.details === 'object') return message.details;
  const text = message?.content?.find?.((c) => c?.type === 'text')?.text;
  if (!text || typeof text !== 'string') return {};
  try {
    return JSON.parse(text);
  } catch {
    return {};
  }
}

function fmtET(ts) {
  return new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/New_York',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  }).format(new Date(ts));
}

function extractCompletionLines(text = '') {
  return String(text)
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line.startsWith('✅ '))
    .filter((line) => !line.endsWith(':'))
    .filter((line) => line.length >= 12)
    .map((line) => line.replace(/\*\*/g, '').trim());
}

function readState() {
  try {
    return JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
  } catch {
    return {
      lastAlertBucketStartIso: null,
      lastAlertActiveEstimate: 0,
      lastRunAt: null,
    };
  }
}

function writeState(state) {
  fs.mkdirSync(STATE_DIR, { recursive: true });
  fs.writeFileSync(STATE_PATH, JSON.stringify(state, null, 2));
}

function collectWindowEvents() {
  const nowMs = Date.now();
  const minMs = nowMs - LOOKBACK_MIN * 60 * 1000;

  const files = fs
    .readdirSync(SESSION_DIR)
    .filter((f) => f.endsWith('.jsonl') && !f.includes('.deleted.'))
    .map((f) => {
      const full = path.join(SESSION_DIR, f);
      const st = fs.statSync(full);
      return { file: f, path: full, mtimeMs: st.mtimeMs };
    })
    .filter((f) => f.mtimeMs >= minMs)
    .sort((a, b) => b.mtimeMs - a.mtimeMs)
    .slice(0, MAX_FILES);

  const spawns = [];
  const completions = [];

  for (const file of files) {
    const lines = fs.readFileSync(file.path, 'utf8').split('\n').filter(Boolean);
    const spawnMetaByToolCallId = new Map();

    for (const line of lines) {
      const obj = safeParse(line);
      if (!obj || obj.type !== 'message' || !obj.message || !obj.timestamp) continue;
      const tsMs = Date.parse(obj.timestamp);
      if (!Number.isFinite(tsMs) || tsMs < minMs) continue;

      const msg = obj.message;

      if (msg.role === 'assistant' && Array.isArray(msg.content)) {
        for (const part of msg.content) {
          if (part?.type === 'toolCall' && part?.name === 'sessions_spawn') {
            const args = part.arguments || {};
            spawnMetaByToolCallId.set(part.id, {
              label: args.label || '',
              model: args.model || args.agentId || 'codex',
              task: compact(args.task || ''),
            });
          }

          if (part?.type === 'text' && typeof part.text === 'string') {
            for (const completionText of extractCompletionLines(part.text)) {
              completions.push({
                ts: obj.timestamp,
                source: file.file,
                text: completionText,
              });
            }
          }
        }
      }

      if (msg.role === 'toolResult' && msg.toolName === 'sessions_spawn') {
        const details = parseToolResultDetails(msg);
        const meta = spawnMetaByToolCallId.get(msg.toolCallId) || {};
        spawns.push({
          ts: obj.timestamp,
          source: file.file,
          runId: details.runId || '',
          label: meta.label || 'sub-agent',
          model: meta.model || 'codex',
          task: meta.task || 'task n/a',
        });
      }
    }
  }

  spawns.sort((a, b) => Date.parse(a.ts) - Date.parse(b.ts));
  completions.sort((a, b) => Date.parse(a.ts) - Date.parse(b.ts));

  return { filesScanned: files.length, spawns, completions };
}

function makeBucketStartIso(now = new Date()) {
  const bucketMin = Math.floor(now.getUTCMinutes() / LOOKBACK_MIN) * LOOKBACK_MIN;
  const d = new Date(now);
  d.setUTCMinutes(bucketMin, 0, 0);
  return d.toISOString();
}

function main() {
  fs.mkdirSync(REPORT_DIR, { recursive: true });

  const now = new Date();
  const state = readState();
  const { filesScanned, spawns, completions } = collectWindowEvents();

  const activeEstimate = Math.max(0, spawns.length - completions.length);
  const bucketStartIso = makeBucketStartIso(now);

  const shouldAlert =
    activeEstimate >= ALERT_THRESHOLD &&
    (state.lastAlertBucketStartIso !== bucketStartIso || state.lastAlertActiveEstimate !== activeEstimate);

  const stamp = now.toISOString().replace(/[:.]/g, '-').replace('T', '_').slice(0, 19);
  const reportPath = path.join(REPORT_DIR, `subagent-active-alert-${stamp}.md`);

  const lines = [];
  lines.push('# Sub-Agent Active Alert Snapshot');
  lines.push('');
  lines.push(`Generated: ${now.toISOString()}`);
  lines.push(`Window: last ${LOOKBACK_MIN} minutes`);
  lines.push(`Files scanned: ${filesScanned}`);
  lines.push(`Alert threshold: ${ALERT_THRESHOLD}`);
  lines.push('');
  lines.push('## Counts');
  lines.push(`- Spawn events (window): **${spawns.length}**`);
  lines.push(`- Completion lines (window): **${completions.length}**`);
  lines.push(`- Active estimate: **${activeEstimate}**`);
  lines.push(`- Alert needed now: **${shouldAlert ? 'YES' : 'NO'}**`);
  lines.push('');

  lines.push('## Latest Spawns');
  if (spawns.length === 0) {
    lines.push('- None');
  } else {
    for (const s of spawns.slice(-8)) {
      lines.push(`- ${fmtET(s.ts)} | ${s.label} | 🧠 ${s.model} | ${compact(s.task, 90)}${s.runId ? ` | run=${s.runId}` : ''}`);
    }
  }
  lines.push('');

  lines.push('## Latest Completions');
  if (completions.length === 0) {
    lines.push('- None');
  } else {
    for (const c of completions.slice(-8)) {
      lines.push(`- ${fmtET(c.ts)} | ${c.text}`);
    }
  }
  lines.push('');

  lines.push('## Telegram Draft');
  lines.push('```text');
  if (shouldAlert) {
    lines.push(`⚡ Active work alert: estimated ${activeEstimate} tasks in-flight (threshold ${ALERT_THRESHOLD}+)`);
    lines.push(`Window: last ${LOOKBACK_MIN} min | Spawns: ${spawns.length} | Completions: ${completions.length}`);
    lines.push('');
    lines.push('Latest spawns:');
    for (const s of spawns.slice(-5)) {
      lines.push(`🤖 ${s.label} | 🧠 ${s.model} | ${compact(s.task, 72)}`);
    }
  } else {
    lines.push(`✅ No active-work alert. Current estimate: ${activeEstimate} (< ${ALERT_THRESHOLD}).`);
    lines.push(`Window: last ${LOOKBACK_MIN} min | Spawns: ${spawns.length} | Completions: ${completions.length}`);
  }
  lines.push('```');

  fs.writeFileSync(reportPath, lines.join('\n'));

  state.lastRunAt = now.toISOString();
  if (shouldAlert) {
    state.lastAlertBucketStartIso = bucketStartIso;
    state.lastAlertActiveEstimate = activeEstimate;
  }
  writeState(state);

  console.log(`REPORT=${reportPath}`);
  console.log(`SPAWNS=${spawns.length}`);
  console.log(`COMPLETIONS=${completions.length}`);
  console.log(`ACTIVE_ESTIMATE=${activeEstimate}`);
  console.log(`ALERT=${shouldAlert ? 'YES' : 'NO'}`);
}

main();
