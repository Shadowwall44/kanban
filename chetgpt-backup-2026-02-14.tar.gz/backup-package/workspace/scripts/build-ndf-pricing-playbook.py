#!/usr/bin/env python3
import csv
import math
import statistics
from pathlib import Path
from collections import defaultdict

BASE = Path('/home/inkredible/.openclaw/workspace')
INPUT = BASE / 'ndf-pricing-complete.csv'
SNAPSHOT = BASE / 'research/price-watch/snapshots/2026-02-14-complete.csv'
OUT_CSV = BASE / 'research/price-watch/ndf-standard-min-price-anchors-2026-02-14.csv'
OUT_MATCH = BASE / 'research/price-watch/ndf-vs-vistaprint-matchups-2026-02-14.csv'
OUT_MD = BASE / 'reports/ndf-pricing-playbook-2026-02-14.md'


def to_float(v):
    try:
        x = float(str(v).replace('$', '').replace(',', '').strip())
        if not math.isfinite(x):
            return None
        return x
    except Exception:
        return None


def to_int(v):
    try:
        return int(float(str(v).strip()))
    except Exception:
        return None


def percentile(values, pct):
    if not values:
        return None
    s = sorted(values)
    if len(s) == 1:
        return s[0]
    k = (len(s) - 1) * pct
    f = int(k)
    c = min(f + 1, len(s) - 1)
    if f == c:
        return s[int(k)]
    d0 = s[f] * (c - k)
    d1 = s[c] * (k - f)
    return d0 + d1


def normalize_product(name):
    key = (name or '').strip().lower()
    mapping = {
        'standard postcards': 'postcards',
        'postcards': 'postcards',
        'standard business cards': 'business cards',
        'business cards': 'business cards',
        'business flyers': 'flyers',
        'flyers': 'flyers',
        'brochures': 'brochures (tri-fold)',
        'brochures (tri-fold)': 'brochures (tri-fold)',
        'banners': 'banners',
        'floor decals': 'floor decals',
    }
    return mapping.get(key, key)


rows = []
with INPUT.open(newline='', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for r in reader:
        row = dict(r)
        row['Quantity_int'] = to_int(r['Quantity'])
        row['NDF Price_f'] = to_float(r['NDF Price'])
        row['Per Unit_f'] = to_float(r['Per Unit'])
        row['Floor_f'] = to_float(r['Floor (=NDF)'])
        row['Target_f'] = to_float(r['Target (+10%)'])
        row['Opening_f'] = to_float(r['Opening (+25%)'])
        rows.append(row)

products = sorted(set(r['Product'] for r in rows))
turnarounds_by_product = defaultdict(set)
for r in rows:
    turnarounds_by_product[r['Product']].add(r['Turnaround'])

baseline_priority = ['6 Business Days', '4 Business Days', '3 Business Days']
baseline_by_product = {}
for p in products:
    turns = turnarounds_by_product[p]
    baseline = None
    for t in baseline_priority:
        if t in turns:
            baseline = t
            break
    if baseline is None:
        baseline = sorted(turns)[0]
    baseline_by_product[p] = baseline

# Build turnaround lookup for rush multipliers
by_key = defaultdict(dict)
for r in rows:
    key = (
        r['Product'],
        r['Size'],
        r['Quantity_int'],
        r['Paper Stock'],
        r['Coating'],
    )
    if r['NDF Price_f'] is not None:
        by_key[key][r['Turnaround']] = r['NDF Price_f']

rush_summary = defaultdict(lambda: {'next': [], 'same': []})
for key, prices in by_key.items():
    product = key[0]
    base = prices.get('3 Business Days')
    nxt = prices.get('Next Business Day')
    same = prices.get('Ready Today (in by 10am)')
    if base and nxt:
        rush_summary[product]['next'].append(nxt / base)
    if base and same:
        rush_summary[product]['same'].append(same / base)

# Baseline rows for summaries and anchors
baseline_rows = [
    r for r in rows
    if r['Turnaround'] == baseline_by_product[r['Product']]
    and r['NDF Price_f'] is not None
]

product_stats = {}
for p in products:
    vals = [r['NDF Price_f'] for r in baseline_rows if r['Product'] == p and r['NDF Price_f'] is not None]
    if not vals:
        continue
    product_stats[p] = {
        'rows': len(vals),
        'min': min(vals),
        'median': statistics.median(vals),
        'p90': percentile(vals, 0.9),
        'max': max(vals),
    }

# Anchor table: choose cheapest row for target quantities on baseline turnaround
anchor_quantities = [100, 250, 500, 1000, 2500, 5000]
anchor_rows = []
for p in products:
    p_rows = [r for r in baseline_rows if r['Product'] == p and r['Quantity_int'] is not None]
    qmap = defaultdict(list)
    for r in p_rows:
        qmap[r['Quantity_int']].append(r)
    available = sorted(qmap.keys())
    if not available:
        continue
    for q in anchor_quantities:
        if q in qmap:
            candidates = [x for x in qmap[q] if x['Floor_f'] is not None and x['Per Unit_f'] is not None]
            if not candidates:
                continue
            best = min(candidates, key=lambda x: x['NDF Price_f'])
            anchor_rows.append(best)

OUT_CSV.parent.mkdir(parents=True, exist_ok=True)
with OUT_CSV.open('w', newline='', encoding='utf-8') as f:
    fields = [
        'Product', 'Size', 'Quantity', 'Paper Stock', 'Coating', 'Turnaround',
        'Floor (=NDF)', 'Target (+10%)', 'Opening (+25%)', 'Per Unit Floor',
        'recommended_start_tier', 'playbook_note'
    ]
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in sorted(anchor_rows, key=lambda x: (x['Product'], x['Quantity_int'])):
        floor = r['Floor_f'] if r['Floor_f'] is not None else r['NDF Price_f']
        if floor is None:
            continue
        if floor <= 60:
            tier = 'opening'
            note = 'Commodity-priced ticket; start higher and concede toward target if needed.'
        elif floor <= 180:
            tier = 'target'
            note = 'Balanced ticket; start at target and protect margin.'
        else:
            tier = 'target'
            note = 'High-ticket order; hold target and avoid dropping below floor without strategic reason.'

        w.writerow({
            'Product': r['Product'],
            'Size': r['Size'],
            'Quantity': r['Quantity'],
            'Paper Stock': r['Paper Stock'],
            'Coating': r['Coating'],
            'Turnaround': r['Turnaround'],
            'Floor (=NDF)': f"{floor:.2f}",
            'Target (+10%)': f"{(r['Target_f'] if r['Target_f'] is not None else floor * 1.1):.2f}",
            'Opening (+25%)': f"{(r['Opening_f'] if r['Opening_f'] is not None else floor * 1.25):.2f}",
            'Per Unit Floor': f"{(r['Per Unit_f'] if r['Per Unit_f'] is not None else floor / max(1, r['Quantity_int'])):.4f}",
            'recommended_start_tier': tier,
            'playbook_note': note,
        })

# Per-unit drop checkpoints (where pricing gets materially better)
checkpoint_lines = []
for p in products:
    p_rows = [
        r for r in baseline_rows
        if r['Product'] == p and r['Quantity_int'] is not None and r['Per Unit_f'] is not None
    ]
    q_best = {}
    for r in p_rows:
        q = r['Quantity_int']
        if q not in q_best or r['Per Unit_f'] < q_best[q]['Per Unit_f']:
            q_best[q] = r
    ordered = [q_best[q] for q in sorted(q_best.keys())]
    best_drop = None
    for i in range(1, len(ordered)):
        prev = ordered[i - 1]
        cur = ordered[i]
        if prev['Per Unit_f'] <= 0:
            continue
        drop = (prev['Per Unit_f'] - cur['Per Unit_f']) / prev['Per Unit_f']
        if best_drop is None or drop > best_drop[0]:
            best_drop = (drop, prev, cur)
    if best_drop:
        checkpoint_lines.append((p, best_drop[0], best_drop[1], best_drop[2]))

# Competitor matchup extraction (NDF vs VistaPrint)
ndf_market = {}
vista_market = {}
if SNAPSHOT.exists():
    with SNAPSHOT.open(newline='', encoding='utf-8') as f:
        for r in csv.DictReader(f):
            comp = (r.get('competitor') or '').strip()
            product = normalize_product(r.get('product') or '')
            qty = to_int(r.get('quantity'))
            price = to_float(r.get('price'))
            if not product or qty is None or price is None:
                continue
            key = (product, qty)
            if comp == 'NextDayFlyers':
                # Keep the lowest observed NDF price for the same product/qty
                prev = ndf_market.get(key)
                if prev is None or price < prev:
                    ndf_market[key] = price
            elif comp == 'VistaPrint':
                vista_market[key] = price

matchups = []
for key, vp in sorted(vista_market.items(), key=lambda x: (x[0][0], x[0][1])):
    ndf = ndf_market.get(key)
    product, qty = key
    if ndf is None:
        signal = 'No direct NDF benchmark in snapshot (capture needed)'
        matchups.append({
            'product': product,
            'quantity': qty,
            'ndf_price': '',
            'vistaprint_price': f"{vp:.2f}",
            'ndf_minus_vista': '',
            'ndf_vs_vista_pct': '',
            'pricing_signal': signal,
        })
        continue

    diff = ndf - vp
    pct = (diff / vp * 100) if vp > 0 else None

    if pct is not None and pct >= 250:
        signal = 'Large commodity gap; sell speed/service/local trust, avoid floor unless strategic.'
    elif pct is not None and pct >= 100:
        signal = 'Significant gap; open high, expect negotiation pressure.'
    else:
        signal = 'Tighter market gap; target tier should hold more often.'

    matchups.append({
        'product': product,
        'quantity': qty,
        'ndf_price': f"{ndf:.2f}",
        'vistaprint_price': f"{vp:.2f}",
        'ndf_minus_vista': f"{diff:.2f}",
        'ndf_vs_vista_pct': f"{pct:.1f}" if pct is not None else '',
        'pricing_signal': signal,
    })

OUT_MATCH.parent.mkdir(parents=True, exist_ok=True)
with OUT_MATCH.open('w', newline='', encoding='utf-8') as f:
    fields = [
        'product', 'quantity', 'ndf_price', 'vistaprint_price',
        'ndf_minus_vista', 'ndf_vs_vista_pct', 'pricing_signal'
    ]
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    w.writerows(matchups)

OUT_MD.parent.mkdir(parents=True, exist_ok=True)
with OUT_MD.open('w', encoding='utf-8') as f:
    f.write('# NDF Pricing Playbook — 2026-02-14\n\n')
    f.write('Built from `ndf-pricing-complete.csv` (4,086 rows) to push idea #11 (Competitor Price Watch) into an actionable quoting system.\n\n')

    f.write('## 1) Baseline price envelope by product\n\n')
    f.write('| Product | Baseline Turnaround | Rows | Min | Median | P90 | Max |\n')
    f.write('|---|---:|---:|---:|---:|---:|---:|\n')
    for p in products:
        s = product_stats.get(p)
        if not s:
            continue
        f.write(
            f"| {p} | {baseline_by_product[p]} | {s['rows']} | ${s['min']:.2f} | ${s['median']:.2f} | ${s['p90']:.2f} | ${s['max']:.2f} |\n"
        )

    f.write('\n## 2) Rush-turnaround multipliers vs 3 Business Days\n\n')
    f.write('| Product | Next Day Median Multiplier | Same Day Median Multiplier | Samples |\n')
    f.write('|---|---:|---:|---:|\n')
    for p in products:
        nxt = rush_summary[p]['next']
        same = rush_summary[p]['same']
        nxt_med = statistics.median(nxt) if nxt else None
        same_med = statistics.median(same) if same else None
        samples = max(len(nxt), len(same))
        nxt_txt = f"{nxt_med:.2f}x" if nxt_med else 'n/a'
        same_txt = f"{same_med:.2f}x" if same_med else 'n/a'
        f.write(f"| {p} | {nxt_txt} | {same_txt} | {samples} |\n")

    f.write('\n## 3) Biggest per-unit price-drop checkpoint (baseline turnaround)\n\n')
    f.write('| Product | Best Drop | From Qty/Unit | To Qty/Unit |\n')
    f.write('|---|---:|---:|---:|\n')
    for p, drop, prev, cur in sorted(checkpoint_lines, key=lambda x: x[0]):
        f.write(
            f"| {p} | {drop * 100:.1f}% | {prev['Quantity_int']} @ ${prev['Per Unit_f']:.4f} | {cur['Quantity_int']} @ ${cur['Per Unit_f']:.4f} |\n"
        )

    f.write('\n## 4) NDF vs VistaPrint direct snapshot matchups\n\n')
    f.write('| Product | Qty | NDF | VistaPrint | NDF-Vista | Gap % | Signal |\n')
    f.write('|---|---:|---:|---:|---:|---:|---|\n')
    for m in matchups:
        ndf = f"${m['ndf_price']}" if m['ndf_price'] else 'n/a'
        vp = f"${m['vistaprint_price']}" if m['vistaprint_price'] else 'n/a'
        diff = f"${m['ndf_minus_vista']}" if m['ndf_minus_vista'] else 'n/a'
        pct = f"{m['ndf_vs_vista_pct']}%" if m['ndf_vs_vista_pct'] else 'n/a'
        f.write(f"| {m['product']} | {m['quantity']} | {ndf} | {vp} | {diff} | {pct} | {m['pricing_signal']} |\n")

    f.write('\n## 5) How to use this on live calls (INKredible rule set)\n\n')
    f.write('- Start with **Opening (+25%)** when floor ticket is below ~$60 (commodity jobs where customers expect negotiation).\n')
    f.write('- Start with **Target (+10%)** on most tickets between ~$60 and ~$180.\n')
    f.write('- For high-ticket jobs (>$180 floor), hold **Target** as default and avoid dropping below floor unless strategic (volume/relationship).\n')
    f.write('- Use rush multipliers to pre-frame urgency pricing before discount talks.\n')
    f.write('- Anchor quantities at discount checkpoints (section 3) to upsell to a better per-unit tier.\n')
    f.write('- Where Vista gap is extreme (section 4), sell reliability/turnaround/service — not just price.\n\n')

    f.write('## Output files\n\n')
    f.write(f'- `{OUT_CSV.relative_to(BASE)}` — anchor quote sheet (by product + quantity)\n')
    f.write(f'- `{OUT_MATCH.relative_to(BASE)}` — direct NDF vs Vista snapshot gaps\n')
    f.write(f'- `{OUT_MD.relative_to(BASE)}` — this playbook report\n')

print(f'Wrote: {OUT_CSV}')
print(f'Wrote: {OUT_MATCH}')
print(f'Wrote: {OUT_MD}')
