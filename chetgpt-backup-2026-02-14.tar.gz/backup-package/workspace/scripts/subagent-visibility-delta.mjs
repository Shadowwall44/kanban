#!/usr/bin/env node
import fs from 'fs';
import path from 'path';

const WORKSPACE = '/home/inkredible/.openclaw/workspace';
const SESSION_DIR = '/home/inkredible/.openclaw/agents/main/sessions';
const REPORT_DIR = path.join(WORKSPACE, 'reports');
const STATE_DIR = path.join(WORKSPACE, '.state');
const STATE_PATH = path.join(STATE_DIR, 'subagent-visibility-state.json');

const LOOKBACK_HOURS = 96;
const MAX_FILES = 200;
const MAX_STATE_IDS = 5000;

function safeParse(line) {
  try {
    return JSON.parse(line);
  } catch {
    return null;
  }
}

function compact(text = '', max = 110) {
  const one = String(text).replace(/\s+/g, ' ').trim();
  return one.length > max ? `${one.slice(0, max - 3)}...` : one;
}

function parseToolResultDetails(message) {
  if (message?.details && typeof message.details === 'object') return message.details;
  const text = message?.content?.find?.((c) => c?.type === 'text')?.text;
  if (!text || typeof text !== 'string') return {};
  try {
    return JSON.parse(text);
  } catch {
    return {};
  }
}

function fmtET(ts) {
  return new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/New_York',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  }).format(new Date(ts));
}

function extractCheckLines(text = '') {
  return String(text)
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line.startsWith('✅ '))
    .filter((line) => !line.endsWith(':'))
    .filter((line) => line.length >= 20)
    .filter((line) => !/^✅\s*(done|completed)$/i.test(line))
    .map((line) => line.replace(/\*\*/g, '').trim());
}

function loadState() {
  try {
    const raw = fs.readFileSync(STATE_PATH, 'utf8');
    const parsed = JSON.parse(raw);
    return {
      seenSpawnIds: new Set(Array.isArray(parsed.seenSpawnIds) ? parsed.seenSpawnIds : []),
      seenCompletionIds: new Set(Array.isArray(parsed.seenCompletionIds) ? parsed.seenCompletionIds : []),
      lastRunAt: parsed.lastRunAt || null,
    };
  } catch {
    return {
      seenSpawnIds: new Set(),
      seenCompletionIds: new Set(),
      lastRunAt: null,
    };
  }
}

function saveState(state) {
  fs.mkdirSync(STATE_DIR, { recursive: true });
  const spawnIds = Array.from(state.seenSpawnIds).slice(-MAX_STATE_IDS);
  const completionIds = Array.from(state.seenCompletionIds).slice(-MAX_STATE_IDS);
  fs.writeFileSync(
    STATE_PATH,
    JSON.stringify(
      {
        seenSpawnIds: spawnIds,
        seenCompletionIds: completionIds,
        lastRunAt: new Date().toISOString(),
      },
      null,
      2,
    ),
  );
}

function collectEvents() {
  const minMtime = Date.now() - LOOKBACK_HOURS * 60 * 60 * 1000;
  const files = fs
    .readdirSync(SESSION_DIR)
    .filter((f) => f.endsWith('.jsonl') && !f.includes('.deleted.'))
    .map((f) => {
      const full = path.join(SESSION_DIR, f);
      const st = fs.statSync(full);
      return { file: f, path: full, mtimeMs: st.mtimeMs };
    })
    .filter((f) => f.mtimeMs >= minMtime)
    .sort((a, b) => b.mtimeMs - a.mtimeMs)
    .slice(0, MAX_FILES);

  const spawnEvents = [];
  const completionEvents = [];

  for (const file of files) {
    const lines = fs.readFileSync(file.path, 'utf8').split('\n').filter(Boolean);
    const spawnCallByToolId = new Map();

    for (const line of lines) {
      const obj = safeParse(line);
      if (!obj || obj.type !== 'message' || !obj.message) continue;
      const msg = obj.message;

      if (msg.role === 'assistant' && Array.isArray(msg.content)) {
        for (const part of msg.content) {
          if (part?.type === 'toolCall' && part?.name === 'sessions_spawn') {
            const args = part.arguments || {};
            spawnCallByToolId.set(part.id, {
              ts: obj.timestamp,
              label: args.label || '',
              model: args.model || args.agentId || '',
              task: compact(args.task || ''),
            });
          }
          if (part?.type === 'text' && typeof part.text === 'string') {
            for (const lineText of extractCheckLines(part.text)) {
              completionEvents.push({
                ts: obj.timestamp,
                text: lineText,
                source: file.file,
              });
            }
          }
        }
      }

      if (msg.role === 'toolResult' && msg.toolName === 'sessions_spawn') {
        const details = parseToolResultDetails(msg);
        const meta = spawnCallByToolId.get(msg.toolCallId) || {};
        const runId = details.runId || '';

        spawnEvents.push({
          ts: obj.timestamp,
          label: meta.label || '',
          model: meta.model || '',
          task: meta.task || '',
          runId,
          childSessionKey: details.childSessionKey || '',
          source: file.file,
        });
      }
    }
  }

  spawnEvents.sort((a, b) => new Date(a.ts) - new Date(b.ts));
  completionEvents.sort((a, b) => new Date(a.ts) - new Date(b.ts));

  return { filesScanned: files.length, spawnEvents, completionEvents };
}

function idForSpawn(s) {
  return s.runId || `${s.ts}|${s.label}|${s.task}`;
}

function idForCompletion(c) {
  return `${c.ts}|${c.text}`;
}

function main() {
  fs.mkdirSync(REPORT_DIR, { recursive: true });

  const state = loadState();
  const { filesScanned, spawnEvents, completionEvents } = collectEvents();

  const newSpawns = [];
  const newCompletions = [];

  for (const s of spawnEvents) {
    const id = idForSpawn(s);
    if (state.seenSpawnIds.has(id)) continue;
    state.seenSpawnIds.add(id);
    newSpawns.push(s);
  }

  for (const c of completionEvents) {
    const id = idForCompletion(c);
    if (state.seenCompletionIds.has(id)) continue;
    state.seenCompletionIds.add(id);
    newCompletions.push(c);
  }

  saveState(state);

  const now = new Date();
  const stamp = `${now.toISOString().replace(/[:.]/g, '-').replace('T', '_').slice(0, 19)}`;
  const reportPath = path.join(REPORT_DIR, `subagent-visibility-delta-${stamp}.md`);

  const lines = [];
  lines.push('# Sub-Agent Visibility Delta');
  lines.push('');
  lines.push(`Generated: ${now.toISOString()}`);
  lines.push(`Files scanned: ${filesScanned}`);
  lines.push(`Lookback: ${LOOKBACK_HOURS}h`);
  lines.push(`Previous run: ${state.lastRunAt || 'none'}`);
  lines.push('');
  lines.push('## New Spawn Events');
  if (newSpawns.length === 0) {
    lines.push('- None');
  } else {
    for (const s of newSpawns) {
      lines.push(`- ${fmtET(s.ts)} | ${s.label || 'sub-agent'} | ${s.model || 'model n/a'} | ${s.task || 'task n/a'} | run=${s.runId || 'n/a'}`);
    }
  }
  lines.push('');
  lines.push('## New Completion Lines');
  if (newCompletions.length === 0) {
    lines.push('- None');
  } else {
    for (const c of newCompletions) {
      lines.push(`- ${fmtET(c.ts)} | ${c.text}`);
    }
  }
  lines.push('');
  lines.push('## Telegram Draft');
  lines.push('```text');
  lines.push('⚡ Sub-agent delta update');
  lines.push(`New spawns: ${newSpawns.length}`);
  lines.push(`New completions: ${newCompletions.length}`);
  if (newSpawns.length > 0) {
    lines.push('');
    lines.push('Spawns:');
    for (const s of newSpawns.slice(-5)) {
      lines.push(`🤖 ${s.label || 'sub-agent'} | 🧠 ${s.model || 'model n/a'} | ${compact(s.task || 'task n/a', 75)}`);
    }
  }
  if (newCompletions.length > 0) {
    lines.push('');
    lines.push('Completions:');
    for (const c of newCompletions.slice(-5)) {
      lines.push(c.text);
    }
  }
  lines.push('```');

  fs.writeFileSync(reportPath, lines.join('\n'));

  const summary = [
    `REPORT=${reportPath}`,
    `NEW_SPAWNS=${newSpawns.length}`,
    `NEW_COMPLETIONS=${newCompletions.length}`,
  ].join('\n');

  console.log(summary);
}

main();
