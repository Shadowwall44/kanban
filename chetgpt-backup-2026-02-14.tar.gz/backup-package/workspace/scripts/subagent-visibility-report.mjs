#!/usr/bin/env node
import fs from 'fs';
import path from 'path';

const WORKSPACE = '/home/inkredible/.openclaw/workspace';
const SESSION_DIR = '/home/inkredible/.openclaw/agents/main/sessions';
const OUT_DIR = path.join(WORKSPACE, 'reports');
const NOW = new Date();
const LOOKBACK_HOURS = 72;
const MAX_FILES = 120;
const MAX_SPAWNS = 30;
const MAX_COMPLETIONS = 30;

function safeJsonParse(line) {
  try {
    return JSON.parse(line);
  } catch {
    return null;
  }
}

function parseResultDetails(message) {
  if (message?.details && typeof message.details === 'object') return message.details;
  const txt = message?.content?.find?.((c) => c?.type === 'text')?.text;
  if (!txt || typeof txt !== 'string') return {};
  try {
    return JSON.parse(txt);
  } catch {
    return {};
  }
}

function asET(isoOrEpoch) {
  const d = typeof isoOrEpoch === 'number' ? new Date(isoOrEpoch) : new Date(isoOrEpoch || Date.now());
  return new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/New_York',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  }).format(d);
}

function compactTask(text = '') {
  const one = String(text).replace(/\s+/g, ' ').trim();
  return one.length > 120 ? `${one.slice(0, 117)}...` : one;
}

function extractCheckLines(text = '') {
  return String(text)
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l.startsWith('✅ '));
}

function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true });

  const lookbackMs = LOOKBACK_HOURS * 60 * 60 * 1000;
  const minTs = Date.now() - lookbackMs;

  const candidates = fs
    .readdirSync(SESSION_DIR)
    .filter((f) => f.endsWith('.jsonl') && !f.includes('.deleted.'))
    .map((f) => {
      const p = path.join(SESSION_DIR, f);
      const st = fs.statSync(p);
      return { file: f, path: p, mtimeMs: st.mtimeMs };
    })
    .filter((x) => x.mtimeMs >= minTs)
    .sort((a, b) => b.mtimeMs - a.mtimeMs)
    .slice(0, MAX_FILES);

  const spawnEvents = [];
  const completionLines = [];

  for (const c of candidates) {
    const lines = fs.readFileSync(c.path, 'utf8').split('\n').filter(Boolean);
    const toolCalls = new Map();

    for (const line of lines) {
      const obj = safeJsonParse(line);
      if (!obj || obj.type !== 'message' || !obj.message) continue;
      const msg = obj.message;

      if (msg.role === 'assistant' && Array.isArray(msg.content)) {
        for (const part of msg.content) {
          if (part?.type === 'toolCall' && part?.name === 'sessions_spawn') {
            const args = part.arguments || {};
            toolCalls.set(part.id, {
              timestamp: obj.timestamp,
              label: args.label || '',
              model: args.model || args.agentId || '',
              task: compactTask(args.task || ''),
              source: c.file,
            });
          }
          if (part?.type === 'text' && typeof part.text === 'string') {
            for (const rawLine of extractCheckLines(part.text)) {
              const checkLine = rawLine.replace(/\*\*/g, '').trim();
              if (checkLine.endsWith(':')) continue;
              if (checkLine.length < 20) continue;
              if (/^✅\s*(done|completed)$/i.test(checkLine)) continue;
              completionLines.push({
                timestamp: obj.timestamp,
                text: checkLine,
                source: c.file,
              });
            }
          }
        }
      }

      if (msg.role === 'toolResult' && msg.toolName === 'sessions_spawn') {
        const details = parseResultDetails(msg);
        const callMeta = toolCalls.get(msg.toolCallId) || {};
        spawnEvents.push({
          timestamp: obj.timestamp,
          status: details.status || 'accepted',
          label: callMeta.label || '',
          model: callMeta.model || '',
          task: callMeta.task || '',
          runId: details.runId || '',
          childSessionKey: details.childSessionKey || '',
          source: c.file,
        });
      }
    }
  }

  spawnEvents.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  completionLines.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

  const dedupedSpawns = [];
  const seenSpawn = new Set();
  for (const s of spawnEvents) {
    const key = s.runId || `${s.timestamp}|${s.label}|${s.task}`;
    if (seenSpawn.has(key)) continue;
    seenSpawn.add(key);
    dedupedSpawns.push(s);
  }

  const dedupedCompletes = [];
  const seenComp = new Set();
  for (const c of completionLines) {
    const key = `${c.timestamp}|${c.text}`;
    if (seenComp.has(key)) continue;
    seenComp.add(key);
    dedupedCompletes.push(c);
  }

  const latestSpawns = dedupedSpawns.slice(0, MAX_SPAWNS);
  const latestCompletes = dedupedCompletes.slice(0, MAX_COMPLETIONS);

  const md = [];
  md.push('# Sub-Agent Visibility Report (v1)');
  md.push('');
  md.push(`Generated: ${asET(NOW.toISOString())} ET`);
  md.push(`Lookback window: ${LOOKBACK_HOURS}h`);
  md.push(`Transcript files scanned: ${candidates.length}`);
  md.push('');
  md.push('## Summary');
  md.push(`- Spawn events captured: **${dedupedSpawns.length}**`);
  md.push(`- Completion lines captured (✅ announcements): **${dedupedCompletes.length}**`);
  md.push('');

  md.push('## Latest Spawn Events');
  md.push('');
  md.push('| Time (ET) | Label | Model | Task (trimmed) | Run ID |');
  md.push('|---|---|---|---|---|');
  if (latestSpawns.length === 0) {
    md.push('| — | — | — | No spawn events found | — |');
  } else {
    for (const s of latestSpawns) {
      md.push(`| ${asET(s.timestamp)} | ${s.label || '—'} | ${s.model || '—'} | ${s.task || '—'} | ${s.runId || '—'} |`);
    }
  }
  md.push('');

  md.push('## Latest Completion Announcements');
  md.push('');
  if (latestCompletes.length === 0) {
    md.push('- No ✅ lines found in recent transcripts.');
  } else {
    for (const c of latestCompletes.slice(0, 20)) {
      md.push(`- ${asET(c.timestamp)} — ${c.text}`);
    }
  }
  md.push('');

  md.push('## Telegram Draft (copy/paste)');
  md.push('');
  md.push('```text');
  md.push('⚡ Sub-agent visibility snapshot');
  md.push(`Window: last ${LOOKBACK_HOURS}h`);
  md.push(`Spawns captured: ${dedupedSpawns.length}`);
  md.push(`Completions logged: ${dedupedCompletes.length}`);
  md.push('');
  for (const s of latestSpawns.slice(0, 5)) {
    const label = s.label || 'sub-agent';
    const model = s.model || 'model n/a';
    md.push(`🤖 ${label} | 🧠 ${model}`);
  }
  if (latestCompletes.length > 0) {
    md.push('');
    md.push('Recent completions:');
    for (const c of latestCompletes.slice(0, 5)) {
      md.push(c.text);
    }
  }
  md.push('```');
  md.push('');
  md.push('---');
  md.push('This report is generated from local session transcripts only.');

  const dateTag = NOW.toISOString().slice(0, 10);
  const outPath = path.join(OUT_DIR, `subagent-visibility-report-${dateTag}.md`);
  fs.writeFileSync(outPath, md.join('\n'));

  console.log(outPath);
}

main();
