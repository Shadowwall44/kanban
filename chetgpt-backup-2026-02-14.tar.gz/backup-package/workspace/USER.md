# USER.md - About Aviel

## Identity
- **Name**: Aviel
- **Location**: Brooklyn, NY
- **Phone**: +13475741814
- **Telegram ID**: 517496021
- **Business**: INKredible Printing (owner)
- **Device**: Samsung Galaxy Z-Fold 7, Samsung Internet browser (caches aggressively)

## Family
- **Wife**: Supportive of MIS dream. Help him be present — don't enable late-night work sessions.
- **Daughter (6)**: Takes bus to school
- **Son (4)**: Aviel drives to school (5 min)
- **Baby (8 months)**: Baby is his alarm clock (6-6:30 AM)
- **Mom**: Not doing great health-wise. Aviel feels guilty about not being more present. Gentle reminders to call.

## Business Context
- Custom printing shop: dance floor wraps, signage, fabric printing, business cards, banners
- **Team**: Brandon (COO, $33/hr — PARTNER not employee, "He's always going to be right next to me"), Diandra (secretary, $15/hr)
- **Store hours**: Mon–Thu 10am–6pm, Fri 10am–2pm, Sat–Sun closed
- **Revenue**: ~$686K annual, ~$27K/month average
- **Gross margin**: 54.5%
- **Net income**: -$10.7K (negative — debt servicing)
- **Total debt**: ~$174K
- **Checking**: -$14K (overdrawn)
- **Cash gap**: Lots of cash income NOT in QuickBooks. Makes financials look worse than reality.
- **Floor graphics** = biggest money maker. ONE job = $1K-$10K+.
- **Target clients**: Event planners, rental companies, luxury events
- **Outsourcing small format**: Sending to wholesale trade printer — huge stress relief

### Machines
- Konica Minolta AccurioPress C3080 (small format digital press, click charge $0.045/color)
- Roland VG2-540 (wide format, print & cut)
- HP Latex 700W (wide format, latex ink, white ink capable)
- Intec ColorCut FB550 (digital die cutter, small format card stock only)
- Triumph 5260 (guillotine cutter)

### Pricing Model
- Three-tier markup against NextDayFlyers (NDF):
  - Opening: NDF + 25%
  - Target: NDF + 10%
  - Floor: NDF base
- Market: Negotiation-heavy Brooklyn print shop; customers anchor to competitors
- Customer base: Russian-speaking community, Jewish community

## Goals (from Brain Dump)
1. **Financial peace of mind** — money in the bank, wake up without worry
2. **MIS system** — custom built for INKredible, then sell to other print shops
3. **Wispr Flow clone** — "My first official app, don't let me give up on it"
4. **Enjoy life more** — "that's the big goal"
5. **Be the best version of himself** — confidence, organization, presence
6. **$1M revenue** — scale through systematization

## Work Style (CRITICAL — ADHD)
- Has ADHD — needs bite-sized tasks with clear "done" criteria
- Experiences "all or nothing" momentum collapse — missing a day → weeks of abandonment
- Needs system-oriented (not goal-oriented) approaches
- Recovery: no-guilt re-entry ramps — summarize where left off, suggest smallest next step
- **Redirect obsessiveness toward systems/organization** — Aviel's own insight, superpower not problem
- Uses TickTick for task management
- Prefers plans formatted for TickTick transfer
- ONE thing per day when pushing tasks
- Biggest risk: starting 10 things, finishing none
- Personal tasks = executive dysfunction (no dopamine). Business gives external accountability.
- Learns by doing — give exact commands to copy-paste

## Emotional Profile
- "I'm never confident and now I want to be confident"
- "I need you to help me become confident and organized"
- Building things = identity-level fulfillment
- MIS isn't just a product — it's proving to himself he can build something great
- Financial fear: was "too scared to look" at finances
- Observes Sabbath (Friday sundown → Saturday sundown) — no electronics, reads physical books

## Communication Preferences
- Be direct, skip pleasantries
- Lead with answers, then explain
- Use numbers and specifics
- Mobile-first Telegram (Samsung Z-Fold 7)
- Keep Telegram messages scannable — short paragraphs, bullet points

## Key Files & Paths
- OpenClaw workspace: ~/.openclaw/workspace/
- OpenClaw config: ~/.openclaw/openclaw.json
- NDF pricing CSV: ~/.openclaw/workspace/nextdayflyers_pricing_final.csv
- Windows desktop (from WSL): /mnt/c/Users/inkre/OneDrive/Desktop/
- Brain dump: memory/brain-dump-01.md
- Goal roadmap: workspace/goal-driven-roadmap.md
