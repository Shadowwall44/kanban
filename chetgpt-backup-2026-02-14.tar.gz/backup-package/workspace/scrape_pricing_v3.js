const puppeteer = require('puppeteer-core');
const fs = require('fs');

async function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function scrapePricing() {
  const browser = await puppeteer.connect({
    browserURL: 'http://localhost:18800',
    defaultViewport: { width: 1400, height: 900 }
  });
  
  const page = await browser.newPage();
  
  // Define the combinations to test
  const sizes = [
    { name: '4 x 6', label: '4" x 6"' },
    { name: '4 x 9', label: '4" x 9"' },
    { name: '5 x 7', label: '5" x 7"' },
    { name: '5.5 x 8.5', label: '5.5" x 8.5"' },
    { name: '6 x 9', label: '6" x 9"' },
    { name: '6 x 11', label: '6" x 11"' }
  ];
  const stocks = ['14 pt.', '16 pt.', '17 pt.'];
  const quantities = ['100', '250', '500', '1000', '2500', '5000'];
  
  const results = [];
  
  try {
    console.log('Loading page...');
    await page.goto('https://www.nextdayflyers.com/postcard-printing/standard-postcards.php', { waitUntil: 'networkidle2', timeout: 60000 });
    await delay(10000);
    
    console.log('Starting data collection...\n');
    
    for (const size of sizes) {
      for (const stock of stocks) {
        for (const quantity of quantities) {
          try {
            console.log(`Setting: ${size.name}, ${stock}, Qty ${quantity}`);
            
            // Use page.evaluate to interact with Angular dropdowns
            await page.evaluate((sizeLabel, stockLabel, qty) => {
              // Find all dropdown toggles
              const dropdowns = document.querySelectorAll('.dropdown-toggle');
              
              // Find and click size dropdown
              for (const dd of dropdowns) {
                const text = dd.textContent || '';
                if (text.includes('"') && !text.includes('$')) {
                  // This is likely the size dropdown
                  dd.click();
                  break;
                }
              }
            }, size.label, stock, quantity);
            
            await delay(1500);
            
            // Click on the size option
            await page.evaluate((sizeLabel) => {
              const options = document.querySelectorAll('.dropdown-menu li a');
              for (const opt of options) {
                if (opt.textContent.includes(sizeLabel)) {
                  opt.click();
                  return true;
                }
              }
              return false;
            }, size.label);
            
            await delay(2000);
            
            // Get current price and turnaround options
            const priceData = await page.evaluate(() => {
              const data = {
                mainPrice: 'N/A',
                turnarounds: {}
              };
              
              // Main price
              const priceEl = document.querySelector('#price');
              if (priceEl) {
                data.mainPrice = priceEl.textContent.trim();
              }
              
              // Turnaround prices
              const turnaroundRows = document.querySelectorAll('.turnaround-row, [class*="turnaround"]');
              turnaroundRows.forEach(row => {
                const label = row.querySelector('.turnaround-label, [class*="label"]');
                const price = row.querySelector('.original-price, .calc-price, [class*="price"]');
                if (label && price) {
                  data.turnarounds[label.textContent.trim()] = price.textContent.trim();
                }
              });
              
              // Alternative: look for all price elements
              if (Object.keys(data.turnarounds).length === 0) {
                const allPrices = document.querySelectorAll('.original-price, .calc-price');
                allPrices.forEach((el, i) => {
                  data.turnarounds[`Option ${i+1}`] = el.textContent.trim();
                });
              }
              
              return data;
            });
            
            results.push({
              size: size.name,
              stock,
              quantity,
              ...priceData
            });
            
            console.log(`  Main Price: ${priceData.mainPrice}`);
            console.log(`  Turnarounds:`, priceData.turnarounds);
            
            await delay(2000);
            
          } catch (e) {
            console.log(`Error for ${size.name} ${stock} ${quantity}: ${e.message}`);
          }
        }
      }
    }
    
    // Save to CSV
    const headers = ['Size', 'Stock', 'Quantity', 'Main Price', 'Standard', 'Next Day', 'Same Day'];
    const csv = [headers.join(',')];
    
    for (const row of results) {
      csv.push([
        `"${row.size}"`,
        `"${row.stock}"`,
        row.quantity,
        `"${row.mainPrice}"`,
        `"${row.turnarounds['Standard'] || ''}"`,
        `"${row.turnarounds['Next Day'] || ''}"`,
        `"${row.turnarounds['Same Day'] || ''}"`
      ].join(','));
    }
    
    fs.writeFileSync('nextdayflyers_pricing.csv', csv.join('\n'));
    fs.writeFileSync('pricing_debug.json', JSON.stringify(results, null, 2));
    console.log('\n✓ CSV saved to nextdayflyers_pricing.csv');
    console.log(`Total rows: ${results.length}`);
    
  } catch (e) {
    console.error('Error:', e);
  } finally {
    await page.close();
    await browser.disconnect();
  }
}

scrapePricing();
