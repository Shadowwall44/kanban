# Claude Opus 4.6 MASSIVE upgrade for ClawdBot (full guide)
# URL: https://youtube.com/watch?v=iGkhfUvRV6o
# Segments: 507

Claude Opus 4.6 just dropped and it is a
historic leap for AI. It gives new
capabilities to both Claudebot and
Claude Code that will completely change
how you use these tools. I figured out a
way to use Opus 4.6 with these tools
that will not only give you way better
results, but also save you money. In
this video, I'll go through all the new
differences with Opus 4.6, six, show you
how to get it set up in both Claudebot
and Claude Code, even though it's not
officially supported in Cloudbot yet,
and show you all the new workflows you
can start doing now to get way better
results and have cheaper API bills. If
you stick with me to the end of this
video, you'll be an Opus 4.6
master and have the smartest AI employee
in the world working for you. Let's lock
in and get into it. So, I'm not going to
go into all these benchmarks because I
think they're fake and stupid. So we are
just going to go directly into all the
improvements you're going to get out of
Claude Opus 4.6. So over on the left
hand side here are all the biggest new
features I think you will get the most
benefit out of. So you got context
window. You now have a 1 million token
context window. That is absolutely
massive and the best in the entire
industry. But what does that mean for
your tools? How does that improve both
Claudebot/openclaw?
I'm actually starting to use the new
name now and Claude Code. Well, one
thing, this gives Claudebot
significantly better memory. The fact
that it can remember 1 million tokens of
context at a time means when you're
having a super long conversation, it
won't need to compact as much and it'll
be able to remember way more details.
The more you use Clawbot, the more it
stores in memory. But the issue a lot of
people are having is is that when it
compacts, it forgets a lot of things cuz
it can't store that much. This one
million context window is going to make
it so much better at remembering things
so that it can give you way better
results in the work it does for you. As
for claw code, this means you're going
to be able to explore way bigger
databases. So all those apps you're
building with tons of code in it and a
huge database, it can now explore and
remember it so much better. This also
means if you have your Claudebot use
cloud code to actually build apps, it's
going to be able to do a way better job
of producing results. which is why I
might be recommending a switch from
Codeex to Claude Code for the coding
abilities, but we'll get into that
later. By the way, just as a side note,
as I go through these features, this
video split up after we go through these
improvements, I have a full demo of
Claudebot and a full demo of Claude Code
using Opus 46 going through all those
workflows. It's all labeled in the
chapters down below, so feel free to
skip around if you want to go see those
demos of the different tools. Not only
does it have a bigger context window, it
also has bigger token output. 128,000
token output. What does that mean for
you? That means it can do more tasks in
one go. Claudebot can do more for you
with a single prompt. It's already the
greatest agentic tool in the world. Is
able to do so many things based on what
you tell it to do. Now, it can do even
more. So, for instance, for this video,
check this out. I literally had it write
the script for this video you're reading
right here. I said, "Go research Claude
Opus 4.6." It not only was able in one
go to research it, find all the big
upgrades, it then gave me a whole bunch
of amazing use cases. I'll be going
through the future potential, walk
through all the amazing benchmarks. It
is able to do so much more in one go
because that larger token output.
basically at the end of the day is means
you can give more complex tasks, have it
do bigger tasks, and have it run longer
autonomously. As for clawed code, it
means it can write more code in a single
prompt. It can just do more and that is
really helpful. It means you're doing a
whole lot more oneshotting with claude
code. It has agent teams aka agent
swarms built in. Now, this means Claude
Opus is way better at spinning up its
own sub agents to go and do work for
you. So, that means it can do bigger
tasks quicker. So if you're using
Claudebot and you say, "Hey, research
Opus 4.6 and give me a h 100red
different use cases." It'll be able to
do that faster because it's going to
spin up a swarm of agents to do that
research. As for Claude Code, that means
it can touch more parts of your codebase
all at once. This is something you need
to enable in Claude Code. So I will also
show you how to enable that manually in
the demo portion of Claude Code. But
this means you can have multiple agents
going and writing code on your codebase,
which is pretty incredible. That means
you're going to get better results much
faster. I remember back in the old days,
Opus was by far the slowest model of
them all. But Anthropic has pulled off a
miracle of having a model that's
significantly smarter and faster, which
is incredible. And on top of all this,
with all these amazing benefits, it's
the same price. So for Claudebot, that's
a big FY. And for Clawed Code, that
means an FY. So we walked through the
benefits that Opus 46 brings to both
Claudebot and Claude Code. Now, let me
show you how to take advantage of all
these benefits. So, we are in Claudebot.
At the moment, Opus 46 isn't
automatically supported by Claudebot. It
needs a config upgrade in the code to
make it work. But I figured out a
workaround. After talking with Claudebot
a ton, we have figured out a workaround
to get Opus 46 officially implemented
into the tool so you can start taking
advantage of all this incredible
functionality we talked about. I put it
all in this prompt. Unfortunately, the
UI of this stinks. So, here is the full
prompt. You can see it right here. I put
this down in the description below. You
can just copy and paste it into your
Clawbot to get it to do these things.
But basically, what it's going to do is
research the model and figure out how to
edit its own config so that it can
support this new model. When OpenClaw
eventually supports this new model and
you upgrade to that version that
supports it, it will automatically
overwrite these changes so you get the
official support. But it for the moment
right now, you need to do it this way to
work around to get Opus 4.6 six working
and trust me in my opinion is very much
worth it. So you run this prompt it will
automatically get 4 six working for you.
From there you can start taking
advantage of the magic. The first thing
I would do once you get upgraded is do a
little reverse prompting. If you haven't
seen any of my videos or live streams
before, by the way, Monday, Wednesday,
Friday, 11:00 a.m. Pacific, I talk a lot
about reverse prompting. What reverse
prompting is is when instead of telling
the AI what to do, you instead ask the
AI questions to figure out what to do
next. So instead of me explicitly
saying, "Hey AI, do this." I say, "Hey,
what's the best thing for us to do
here?" So here's a good example of a
reverse prompt we want to use for Claude
Opus 46. Now that we are on Claude Opus
46, based on what you know about me and
the workflows we've done in the past,
how can you take advantage of its new
functionality to perform new workflows?
I put that prompt down below. Feel free
as you're watching this video to paste
that prompt into your own Clawbot as we
go here. So, you can see what Claude
wants to do based on this new
technology. What this is going to do is
actually have Claudebot go and figure
out the best workflows you can do with
46. So, instead of you having to sit
there and brainstorm it, a much smarter
super intelligence will do the
brainstorming for you. So, here we go.
This is what we got. All right. So, we
got a whole bunch of use cases here.
Again, this is the beauty of the 128K
token output. We are getting a lot of
really good information just based on
one prompt. So, here's a bunch of use
cases Claude Opus 46 can now do for me,
taking advantage of all the new
functionality. Here's probably the
biggest upgrade for everyone. It can do
true second brain queries. Meaning, if
you ask it a question about something
you've talked about in the past,
something that requires a lot of context
on your past memories, you probably do a
lot inside Claudebot, it can now hold
way more context about things you've
discussed in the past in its context
because of those million tokens. So now
when it answers questions for you, it
can base it off of conversations from
yesterday, the week before, the month
before, the week before that. Maybe it
bases it off 20 different conversations
you've had in the past. It wasn't able
to do that before. Now, it can do that,
meaning you get way better answers, more
deeper research because it can use more
sources and give you more information.
And here's the big one. Here's the one I
love. Overnight autonomous projects. So
now, the longunning overnight tasks for
me, I have it do longunning overnight
tasks. I have it building a whole bunch
of new features for Creator Buddy, my
SAS. I have it doing research for me. I
have it doing investing for me. It can
do a lot more longunning tasks. So,
here's my recommendation for you. I'll
just give you a starter. After you run
this prompt and see all your own custom
workflows, make sure to say, "Hey, when
you do your overnight tasks now, your
proactive overnight tasks, make sure you
take advantage of that 1 million token
context window and you'll start getting
a lot cooler results when you wake up.
Take advantage of all these new
improvements and run that prompt I gave
you down below that will show you all
the custom workflows that Claudebot can
do for you now based on this upgraded
functionality." Which brings us to
Claude Code. Let's get right into that.
So Claude Code, you open it up, you make
sure you're upgrading. You'll see Opus
46 there, which is amazing. A few ways
to take advantage of these new upgrades
for Claude Code. First thing you want to
do is do slash model. You hit enter on
that. And one thing you can do now is
when you have Opus selected, which is
the default, you can use the left and
right arrow keys and change the effort
level. Right? So you have low effort,
medium effort, high effort. If you are
on the $200 plan, I'd recommend having
high effort on at all times by default.
You'll still get tremendous amounts of
usage out of it. If you are on the $100
plan, I would go with medium effort. If
you're on the $20 plan, you can go with
low effort. There you go. Even if you're
on the $100 plan, honestly, you can
probably get away with high effort
unless you are using it 24/7, 365. So,
there you go. You want to take advantage
of the effort levels. That'll save you
money in the long run, right? If you
have shorter tasks, maybe you switch to
low effort. If you're just changing
colors of buttons, things like that,
switch to low effort. I hear so many
complaints about people running up
against limitations on Claude Max.
Taking advantage of the right effort
levels will save you tokens and money in
the long run. So, the biggest change in
Claude code with Opus 46 will be agent
teams. Agent teams by default are turned
off. What are agent teams? This is what
I hinted at earlier with agent swarms I
called it. But basically what it allows
it to do is spin up multiple claw code
instances to tackle a problem. This is
very different than sub agents. Before
with sub aents, claude code would spin
up smaller agents to do tasks, but they
were all in the same session. And what
that basically means is it was just like
your one cla code agent doing multiple
things at one time. But with agent
teams, this is different. It actually
spins up multiple sessions at one time.
It's literally like opening up 10 clawed
code sessions on your computer and them
all attacking a problem together. What's
amazing is is they can communicate with
each other and they can talk to each
other. With sub agents, you weren't able
to directly communicate with each sub
agent. But with agent teams, you
literally can talk to the different
agents working on the different problems
you spun up. So it makes it more
flexible, more powerful, and faster. You
need to enable it cuz again, it's
disabled by default. The way you do that
is you just use a simple prompt. You
say, "Hey, Claude Code, can you enable
this for us?" So I said, "I'm looking to
enable agent teams, which just became
available in Claude Opus 46. By the way,
prompt down below for this. Can you read
the docs and help me figure out how to
enable it?" I gave the link. It said,
"Yep, here's how you do it." And now all
we need to do is say, "Yes, enable that
for us." All right, so that enabled it
for us. It actually edited our settings
file for us to get that enabled. Now
we're good to go. All right, so you just
reset your cloud code. Now we can start
taking advantage of these agent swarms.
So, we're going to say this. Please use
an agent team to create a new project
management app for us using NextJS. Make
it a beautiful featurerrich
project management app with to-do list
and calendar functionality and other
features. And I'm going to hit enter.
The key here is saying please use an
agent team. That is going to indicate to
claude code. It should be spinning up
multiple sessions and multiple agents
and use that swarm functionality. And
here we go. I'll create a team of agents
to build this project management app in
parallel. Let me set everything up. So
I'm going to hit yes. And it is going to
start using this swarm. So it's
installing all the dependencies. And
then once the dependencies are
installed, it's going to figure out the
task list to get this done. Once the
task list is done, you'll see it here.
Let me create all the tasks and then
spin up a team. So it'll figure out the
tasks. And the way it's going to think
is, okay, I'm going to spin up team
members for each one of these tasks so
they can tackle it all at the same time.
And here you can see it is spinning up
the tasks, which is amazing. We had that
week a few weeks ago. Remember that? We
were all talking about Ralph loops. That
was the hot thing at the moment. Ralph
loops. Now look at this. We have the
Ralph loops built right into Claude
Code. No one's talking about Ralph
anymore. That was a funny week. I think
sometimes we just look for narratives to
talk about in the AI world, but here we
go. You have all your tasks that it'll
be able to keep just chugging through
and spinning up agents for to tackle for
you. All right, here we go. Now, let me
assign tasks and spawn the agents. Task
one and two have no dependencies, so
they can start immediately. I'll assign
them first. Now, let me spawn the first
two agents in parallel to start on the
independent task. Two agents launched.
Here we go. Control O to expand. We have
a store builder and a layout builder.
This is amazing. So, one's working
already. You can see the task being
tackled. You can see the store builder
on one. the layout builder on the other.
I'm just going to say yes. Do whatever
the hell you need. Uh they both need
their own permissions. This is amazing.
You can choose who you want to talk to
by doing shift up and down. You hold
shift, you go up and down. So you can
talk to the team lead agent, give them
commands who then they'll talk to each
individual agent. Or I can switch to
individual agents on the team. If I want
to talk to the layout builder, if I want
to talk to the store builder, I can do
that and give them direct commands. That
is a huge upgrade over sub agents cuz
with sub aents you could not talk to the
individual agents. It really feels like
for the first time it's not like we have
just an agent working for us. We have an
agent working for us who has agents
working for them. This is now a
hierarchy company. We no longer have a
flat company. It's us agents and then
agents working for them. That is
amazing. 15 16 tool uses for layout
builder. Nine tool uses for store
builder. this it's incredible the
efficiency we're getting now out of
this. Not only that is it more
efficient, but it's also smarter because
they have their own context built in.
It's not context shared between all the
agents. It's context just for the
individual agents and they're able to
communicate upwards to the team lead.
Now you can see a third agent, a third
team member has been spawned. The
dashboard bu This is fun to watch. I'll
just say this. This is much more fun to
watch than what it was doing before. Oh
my god. We have the calendar builder,
the task builder, and they're all
tackling different tasks at the same
time. Look at that. They're all There's
four different tasks being tackled at
the same time. The pages builder just
got spun up. We're about to get an
entire complex app in like 2 minutes
because we have like eight different
Claude Code instances working for us.
This is a massive upgrade. This is
awesome. All right, looks like we're
done here. It worked for six minutes. We
had this entire team of Claude Code
sessions working for us here. Uh let's
see what this looks like. All right, it
just ran the server. Now it is cleaning
up the team. I hope that doesn't mean
they're getting fired. I want them to
keep working for the company. So, let's
see what happens here. Store Builder
refuses to leave. All the other members
got fired. Store Builder said, "I'm not
leaving." And here we go. Let's test
this out. Wow, look at this. This is
unbelievable.
So, a full project management tool with
an entire dashboard. Your task, what's
completed in progress, overdue, the task
distribution. So, it has the entire
dashboard. Let's go to my task. An
entire canband board, which for the
record, this UI is great. You can move
the cards around easily. It has a
calendar view. Let's check out the
settings here. Wow. You can put in your
name, your email, change the appearance,
turn on notifications. I mean, that is
as fullfeatured as it gets. If you were
using Claude Code for this before, you
probably get one or two of these built
out with one singular prompt. We got it.
Basically, monday.com. Congratulations,
monday.com. Uh, your entire company is
pretty much worthless at this point. I
just built your entire product in one
prompt. I'm probably shorting Monday.com
stock come Monday. How how ironic.
Anyway, that is Claude Code. Turn on the
agent swarms. I put a link down below
for that. Opus46 is actively blowing my
mind. Claude Code, Claudebot, both
massively upgraded with this new model.
Stop what you're doing. Drop what you're
doing. Quit your job. Get rid of your
friends and family. is sit down at your
computer, get this up and running now,
use it. It will change your life. If you
learned anything at all, leave a like
down below. Let me know in the comments
if you want me to do a deep dive on this
for either Claudebot or Claude Code.
Which would you prefer a deep dive on
more, Claudebot or Claude Code? Let me
know down in the comments. Subscribe,
turn on notifications. All I do is make
amazing videos about AI. I'm doing an
entire boot camp about Claudebot in the
Vibe Coding Academy this Friday. Link
down below for that. I do every Friday a
live boot camp on Claudebot. You can
interact with me, ask me questions, all
that. Link for that's down below as
well. I hope you learned a ton. I so
enjoy making these videos for you and
I'll see you in the next