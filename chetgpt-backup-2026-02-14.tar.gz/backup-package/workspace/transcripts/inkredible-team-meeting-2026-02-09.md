# INKredible Printing Team Meeting
# Date: February 9, 2026
# Participants: Aviel Samucha (Owner), Brandon Lewis (COO)
# Duration: ~34 minutes
# Priority: HIGH

## Full Transcript
[Saved from Aviel's message — see original for full text]

## Key Themes

### 1. Aviel's ADHD & Self-Awareness
- Therapist confirmed extreme ADHD symptoms
- Hyperfocus on AI/tools instead of business operations
- Recognizes pattern: can't stop, blocks out family/people, guilt cycle
- Considering psychiatrist + low-dose medication
- "If I don't fix this, it's a me problem"

### 2. Brandon's Anxiety & Concerns
- Fears his hard work is "fueling instability"
- Worried about cash management: $13K in owner withdrawals (Dec-Jan)
- Doesn't want to overstep but needs to speak honestly
- Feels business operations are strong but financial management isn't matching

### 3. Cash Flow Issues
- Unpaid invoices: Hadad, two Messy Laws
- Celia's check — possibly lost (left in car)
- Cash not being funneled into business account (tax avoidance concern)
- One credit card getting overloaded instead of spreading across 2-3
- $6K in expenses (graphics event + dry cat) couldn't be offset because cash wasn't deposited
- Brandon's point: if everyone paid and withdrawals were lower, account could be at $33-50K

### 4. Business Health (Positive)
- Revenue growing since Aug 2025 restructuring (after Shai left)
- More stable operations — orders on time, fewer mistakes
- Better job mix: more floor graphics, fabric (higher margin, less labor)
- Now Graphics partnership — lower margin but fills capacity
- Claude analysis: business at 1.5x metric (sales/expenses), needs 2.0x
- Brandon feels company is in "100 times better place" than before

### 5. Brandon's Relationship to the Company
- "I love the company almost as if it's my company"
- Aviel: "You're not a worker. You're family."
- Brandon doesn't want to leave
- Needs to feel his hard work translates to stability

### 6. Action Items Discussed
- Daily 15-min morning meetings (recorded for AI processing)
- Connect ClickUp → Claude for task management
- Use ADHD planning skill for organizing meeting action items
- Track personal spending (possibly reconnect Origin)
- Better cash flow management: funnel cash into business account
- Follow up on outstanding invoices (Hadad, Messy Law)
- Find Celia's check
- Lynn's job: 100x 5x7 perf sheets (60-degree blade, test new blade)
- Send tax returns (2 years / Schedule C) for loan application

### 7. Aviel's Fear of Numbers
- Avoids looking at personal finances out of fear/anxiety
- Therapist helping work through this
- Claude conversation helped identify this pattern
- Connected to feeling like a failure
