# LIVE: The ULTIMATE OpenClaw setup

- **Video:** [https://www.youtube.com/live/0v2-mUUWNdc](https://www.youtube.com/live/0v2-mUUWNdc)
- **Channel:** Alex Finn
- **Extracted:** 2026-02-13

---

Today I am going to show you the ultimate open claw setup. I'm going to show you why I now believe Discord might be the best communication platform for openclaw. I'm still using Telegram, but Discord might have taken the lead. I'm going to show you my ultimate Discord setup. I'm going to show you how I'm using it, how it's so powerful, how I've automated everything, how I have multiple local AI models, researching X all day, generating me thumbnails and scripts all day, all locally without burning any tokens at all.

I'm going to show you the ultimate setup. I think the workflows I'm about to show you will change your life. I think you are going to learn things in this video that will make your life simpler, better, faster, easier, and make you more money. I think this is going to be the most important video you watch today until I drop another video in a couple hours. So, make sure to lock in, leave a like down below to get this party started.

You are watching the number one live stream in all of AI. The number one live stream in the entire world. You are in the correct place. So, get in the chat, say hello, introduce yourself. You're watching a replay.

Introduce yourself in the replies below. We'll go back and chat about it. Hope everyone is doing well. Let's pull it open. Let's pull it open.

Modeler says he's got a dentist appointment. He wants me to frontload the value. Well, I got good news for you. I got good news for you. Uh, Modeler, I'm going to frontload it.

I'm going to midload it. I'm going to backload it. There's going to be value coming out of your ass by the end of this. So much value, it'll drive you nuts. So, let's do this.

Here we go. Here we go. I'm going to show you something good. You You ready to see some cool stuff? Shout out Kurt Haywood.

Thanks for joining the FinnF fam. Shout out Tree Fox Design. Here we go. The ultimate Discord setup. Over the last 48 hours, I have been fully focused on one thing and one thing only, and that is the ultimate discord setup for OpenClaw.

I have figured out a workflow and a system that makes this so powerful. So powerful that allows me to basically automate my entire business. My entire business is automated. Sent you an email says unemployed fake guru. Unemployed fake guru.

I don't read emails. I don't read anything. My emails are filled with 89,000 spam messages of getting people trying to get me to promote their BS crap. Email useless. DM's use.

Everything's useless. The best way to communicate with me is getting in my live streams and getting in the chat. That's the only way to communicate with me. If you're trying to pitch me on something, pitch it in the chat. I'm spinning all over my new monitor right now.

How do I manage costs? API costs. I'm paying $200 a month for Opus and then I have open- source models doing everything else for me on my computer for free. I wish I had $20,000 to buy two 512 Mac studios like you. Uh, well, KBank, start grinding, baby.

Start grinding. Start building up the cash flow. Start building businesses. Use Open Claw. Build some businesses.

Build it up. Grind it. Invest in yourself. Invest in your business. Then take that money and reinvest.

And then you can buy yourself two Mac Studios one at a time. You start at a Mac Mini. Then you you go on up. So, here's the system I got going on. Is there a way to hide all these messages on the left?

I get spammed by so many people. Ah, whatever. All right. Let me make this bigger. Can I make this bigger?

There we go. Here's the system. Condol. Oh, yeah. We haven't talked since uh the Super Bowl.

Uh I h I did a podcast with uh Jay Cal on Monday, so I missed the live stream on Monday. We usually do this Monday, Wednesday, Friday, 11:00 a.m. Pacific. I had a big podcast appearance on Monday, so I had to miss the live stream Monday. U Patriots lost the Super Bowl.

We'll be back next year. It was tough. It was not fun. At no point did I enjoy that game. There was not a single enjoyable moment in that Super Bowl game.

I almost spent $7,000 to go to the Super Bowl right before. Thank god I did not do that. I live 10 minutes away from the stadium. So, I was really Well, people stop misspelling my name, by the way. Stop misspelling my name in the chat.

What pod was I on? This week in Startups, hosted by Jason Calacanis, uh host of All-In the biggest tech start tech podcast in the world. All right, here's the setup. I have one, two, three, four, five, six open claws going right now. These six open claws are working for me non-stop 247 365 in my Discord setup which you see here.

Hopefully it's like visible and not too small. I have a bunch of things going on. That was a good show money. Thank you, J. Michael.

I have a bunch of things going on. Open claw is amazing, but it's too expensive to run. And anything other than opus is a mistake. Skill issue. Skill issue.

If it's too expensive to run, it's a skill issue. I am so freaking pumped as out of control as you now and can't sleep. Your energy is contagious. Thanks for kicking me in the right direction. Life changed forever.

[applause] [cheering] If you are sleeping, if you have more than one hour of sleep over the last two weeks, you're doing it wrong. If you have slept more than one hour in the last two weeks, you're going to be in the permanent underclass. Let me just say that. If you've slept more than one hour in the last two weeks, permanent underclass, you're a permy. If you slept more than one hour over the last two weeks combined, leave this live stream right now.

Leave. You're out. Out. No sleep till the singularity is the new song I'm going to record. So, I have six open claws running right now.

I can communicate with them many different ways in this Discord. I first of all, as you can see here, have direct lines to all six of them. Direct lines. I can just pop open and say, "Hey, what's going on?" Send him a quick message. Direct line, right?

Direct line. These six are all doing different things. We have Scout. Scout is a local model. GLM 4.7.

GLM 5 just released today. I'm going to have to upgrade GLM4.7. It's tr Is it true if you're a virgin? Is it true you're a virgin? Me?

Am I a virgin? Virginity doesn't matter in the singularity. We'll all have robot girlfriends. Virginity is a short-term issue. If you're worried about virginity, that's a short-term issue.

Virginity does not matter in the singularity. In the singularity, we'll all have robot girlfriends and no one will be virgins. So, don't ask me about virginity. If you're concerned about virginity, get out of this live stream immediately. Stop misspelling my name.

If you're sleeping or boning, get out of this live stream immediately. Two permanent underclass activities. Sleeping and bonan. You can sleep and bone after we get to the singularity. Scout.

So, we have Henry. Henry is my main agent. My main agent orchestrating everything. I call it Vibe orchestration. Vibe coding's dead.

We're now going on to Vibe orchestration. Henry is my Vibe orchestrator. He's orchestrating the other agents, the other open claws that are running. So, who are these other open claws? Let me introduce you to the lineup.

And you can, and I'm going to show you how to set this all up yourself. You're going to learn how to set this all up. You all can be doing everything here. You all can be doing everything here. Why can't you have this set up in Telegram?

Because this is a better system. This is a better system than Telegram. You should still set up Telegram. If you're on Telegram, keep it. I'm on Telegram.

When I need to quickly send something to Henry, my main open claw, pop open Telegram. Discord's not fast enough as Telegram. If you just need to send a quick message to your agent, keep Telegram. But you use Discord as your workspace, as your main workspace. Henry's my conductor.

That is correct. He's my orchestrator, my conductor, whatever you want to call it, right? So, keep Telegram as your go-to like quick send message. But we have Discord. I can message Henry.

We have Scout. Scouts powered by my local model GLM 4.7 which is running on my $10,000 Mac Studio. Holy crapola. Patrick Barnhill just gifted 50 memberships. Oh my god.

Thank you. Thank you, Patrick Barnhill. Shout out Patrick Barnhill. 50 of you now members. That's amazing.

Wow. That's by far the biggest gift I've ever gotten. Thank you very much, Patrick Barnhill. That's incredibly nice of you. That's incredible.

50 of you watching this live stream right now just became a member. Congratulations. Thank you very much. That's very kind. That's incredible.

Very kind to you, Patrick Barnhill. Shout out you, Patrick Barnhill. Main man. The main man. He watches stream.

He gets excited. He sets up Open Claw. He gives 50 people memberships. Incredible. Shout out everyone.

Say thanks Patty in the chat. I want I want a thousand thanks Patties in the chat. Uh Scout running on GLM 4.7. I have no idea how the gifted memberships work, by the way. I think they just give it out randomly to people, right?

Is that how it works? I have no idea how it works, but everyone thanks thank him anyway. No idea how it works. Uh, permanent overclass. Patrick just escaped the permanent underclass.

Shout out Patrick. He escaped the permanent underclass. Thanks, Patty. Here's what Scout is doing. You want to see what Scout's doing?

Scout is pounding this alerts channel. This is all Scout right here. pounding this large channel. He is every 20 minutes going into X and finding trending posts. finding trending posts about clawed code clawed bot open claw open AI clawed open closed claw close open AI closed close claw open clawed code open AI clawed open AI closed AI closed claw open a open claw for C++ right at all times at all times So I get this alert every 20 minutes.

Hey, found these viral posts. Right? If there's no viral post at the moment, then I don't get any alert. But when things go viral, I get alerted immediately. Boom.

Alert, right? So I know the moment a new model drops. I know the moment someone says something viral and I can just play off that. Right? This is how I'm getting so much engagement over the last couple weeks.

I'm knowing the moment something is trending. Scout alerts me and I can have it running every 5 seconds, right? I can have it running every 5 seconds. Every five. Why?

Because I have the local model going. If you pay for this, it's going to cost a lot of money chugging and chugging and chugging and chugging and chugging. But because I have this running locally on the Mac Studio, I can have this going 24/7, 365. Now, they're all alter alternatives. I'm not saying you need to go out and buy a $10,000 Mac studio to do this.

You you can there's like you can get like really cheap Chinese models to do it and save a ton of money. And I recommend you doing that, but for now, I got my local models chugging, hitting the X API. Boom, boom, boom, boom, boom. What's trending? What's trending?

What's trending? Then I get alerted the moment it's trending. And that's and that's how you go viral, right? This is the secret to virality. This is the secret to virality.

The secret to virality. I shampooed my hair last night, so it's a little bit more fluffy. The hair doesn't look good the day after shampoo. If you spam the chat, I'm banning you. If you spam the chat, just boom, banned.

You got to have that good three to four day natural grease going on in the hair to make it look good. Too fluffy now because I shampooed it last night. What shampoo do you use? I don't know. I some pink bottle.

I don't know. Uh this is how you go viral, right? People ask, "Oh, Alex, how do you get so much engagement on X? How do you get so much engagement on YouTube?" It's really simple, actually. It's actually spectacularly simple.

Say interesting things about trending topics. That's it. There's your entire X algorithm hack right there. There's your entire YouTube algorithm hack right there. Say interesting things about trending topics.

That's it. So, because I have Scout going here, hitting X every five seconds, alerting me when things are going viral, I know it's trending at every given moment of the day. And when I get that when I get that alert, bing. When I get that alert, I'm like, "Okay, that's interesting. What's going viral?

What are people talking about?" Then I go, "Okay, so what's my take on this?" Boom. Spinning granola bar all over the place. What's my take on this? And then I pump it out and I go viral. What's trending right now?

Let's see. My only use for Claude now is Claudebot. It's literally just not the be. Let's see. Let's see what Let's see what this person say.

Only us for Claude is not Clawbot. It's literally just not the best anything anymore. So, it's a hot take about how they only zero only uses Claude for Claudebot. Now, I can go and I can put my take. Claude's amazing at everything, right?

I go in, I just give my take in perspective because I know what's working. I know what's trending, right? This is how you go viral. This is how you continuously get engagement, increase your ad revenue, find what's trending, and say interesting things about it. So, that is what Scout's doing for me.

Who else do I got going here? Who else do I got going here? Quill. Can anyone else can anyone guess what my third open claw is doing? Quill, have you run into rate limits on Claude Promax 20X?

No, I have not. And I use this all day and I I don't hit where rate limits. The secret. Can we see your main chat, please? Well, like what I'm saying with Henry.

Yeah. Let me just make sure I'm not saying anything insane. It's my personal It's my personal AI assistant. Yeah, nothing crazy. Just talking about getting some of the automation fixed.

Scout, Quill, Digest, Trend Radar. If you're running into rate limits on Claude Promax 20X, it's a uh skill issue. You got a skill issue. You need to be using the muscle in the brain, right? The muscle in the brain.

Phil Blanchet $5. Is that using a scraper or just your own code? It's using the X API. X API. X API just launched a couple days ago as payer use.

So you can use the X API officially. Do not use you got that shiny coconut hair. I think it is some sort of coconut shampoo maybe. I don't know. Do you know the I'm not going to say it.

Um, is that using a scraper or just your own code? You can use the X API. Go to your bot. Go go go go go to your Clawbot, OpenClaw, and say, "I want an AI agent that every half hour hits the X API and finds trending tweets on whatever vibe coding, whatever, and then alert me in a new Discord channel of those viral tweets." Boom. You just set it up.

You're going to need to sign up for the X API, put in a credit card number, and then get a bearer token. It's called a bearer token, which is basically like your API key. And you give that to your claw body, and it'll set up for you. Boom. You're ready to go.

There's a lot of people shilling skills out there that use like uh not the X API. They use like scrapers and CLIs and O tokens and things like that. I do not recommend using those. I do not recommend using those. I do not recommend using any open clause skill that does anything other than the X API.

Uh the reason for that is many. Uh one and the biggest one is X aggressively hates people that skirt the API. X aggressively hates people who don't use the official routes. I know people whose X accounts were suspended over going around the API and using scrapers. I know people whose businesses were sued by ex lawyers.

X has like five employees working for it and four of them are lawyers getting people to take down their services and companies that go around the X API, right? So they do not want people doing this. So if you use skills or other services, I think even Peter Steinberger built like a tweet CLI or something bird CLI that uses like your O token and not the official API. I don't recommend it. I know someone who was suspended yesterday for using those kind of things.

Just use the official terms of service routes, which is just the X API. Use the X API for this. We'll cost you a couple more pennies. Yeah, it might cost you a couple more pennies, but you just use it anyway to be safe. It's not worth the risk.

It's not worth the risk of getting suspended off these platforms. your brand on X, your brand on these platforms is worth way more than the $3 you're saving a month by using the scraper instead of the API. Um, so just use tell hey use and then drop in the link for the documentation if it can't find it. What's up startup swing? Thanks for joining the finan appreciate it.

Very nice you. Chroma 1986 with a $2 Canadian. How often do you do open claw gateway restart? Uh, I don't know. I was running into issues like a week ago where I had to reset it like three times in a day.

Since then, I haven't had to reset it at all. So, not at all in the last week. Hi, Alex. I'm at the Mac Studio checkout. Is the one tabyte enough or should I upgrade to higher?

If so, which do you recommend? Says Landon Trints. Uh, Landon, I assume you're talking storage. So, a terabyte storage. I I would go higher, honestly.

I'd go at least two terabytes. If you're gonna spend the money on a Mac Studio and get a ton of memory and all that, like you might as well spend the little extra dollars to get like good storage. You don't have to worry. Like, that's one of my things. Like, is Apple like totally overcharging for storage?

Like, are they charging like $1,000 for an extra terabyte when it's really like $20 in real life for a terabyte? Yes. But at the same time, I' I've had this opinion on iPhones, iPads, computers, everything. Just spend the money to get the extra storage. Just do it.

I know it's a ripoff, but just do it because there's nothing worse than constantly having to manage your hard drive, right? There's there's nothing worse on the phone. Like, it's like, "Oh, I'll just get the cheapest version, delete the apps when I need more space." It's so annoying to constantly have to be deleting apps and managing your storage. I think it's the most annoying, stressful thing in the world. So, I'm happy to pay an extra $500 to get an extra terabyte of storage so I don't have to sit here every time I download a new model, every time I download new app, every time I download new file.

Oh, what do I have to delete now? And I sit there in like Arc Raiders managing my inventory so I have room for all the new stuff. I hate that. I think it's stressful and annoying. Just get the two.

I got the four terabyte because I really didn't want to worry about storage, but get one terabytes not if you're going to run local models. One tabyte is not enough because there's like 200 gigabyte models you want to run. 300 gigabyte models you want to run and you download that and you already have a third of your memory gone, right? So just up get at least two te terabytes. I went four.

I have a I have a thesis that open claw is going to like everyone in the next two to three years. All their intelligence will be local. All their AI agent stuff will be everything will be local and they'll have their own computer and it'll have all their memories on it and it'll have all their data on it. It'll have everything about them on it and it'll be superpowering this intelligence that knows everything about you that can do anything you want. It just remembers everything you've ever said and done in your entire life, right?

And for that to be true, my thesis, which I do believe will be true, you need a lot of storage. I think you'll need much more than one terabyte. So, go two terabytes. If you're feeling frisky and you got a couple extra dimes on you, go to four terabytes. I'm at four terabytes.

I'm get I have two four terabyte Mac Studios. One's here now. The next is coming on Monday. My second 4 terbyte. That's eight terabytes that I'm now prepared for in the future to store everything about me, every piece of information about me ever, every memory ever, so that my local super intelligence knows everything about me and can make the best decisions possible.

I do not believe one terabytes enough for that. Those are separate open claws or are they agents? Um, this is one open clause spinning up multiple sessions in open claw. So basically your open claw can spin up new sess sessions which are basically separate open claws. I see a lot of people going on now and buying like five Mac minis to run five open claws.

I think for 99% of people that's kind of a waste. Um I think that's kind of a waste. You can have your orchestrator open clause spin up new sessions of open clause. You don't need to be buying five Mac minis for open clause. You can have just one and then have your orchestrator spin up multiple sessions.

Quill authoring. Yes, Quill is writing content. So, you want to see some cool stuff? You want to see what Quill's doing? Talking about conditioners.

I use conditioner, too. But even when you use conditioner, you still get the the hair is still a little too fluffy those first two days. The one fix I found is uh if I shampoo my hair the next day I'll put on a hat and then I'll go for a run and then you take the hat off and you got a nice natural grease going on in your hair that makes your hair look fantastic, right? Thank you, Alex. I'm setting up my Mac Mini today.

Thank you. That's a smart move. I'm not getting paid by even the people you're getting paid by Apple. Listen, Apple, if you're watching this, pay me. If you knew how many Mac minis I've sold Apple over the last two weeks, it'd blow your balls off.

Apple, pay me, Apple. People, oh, you're getting paid by Apple. You're getting paid by I'd love to get paid Apple. If you're watching this, pay me, please. I've sold so many Mac minis and Mac Studios over the last two weeks.

Muscles and brain, boys. Muscles and brains, boys. [applause] Rate limit. Rate limits happen when you're using Opus 46 in your with thinking on. So, you got to tune it.

Also, you got brains and muscles. Brains and muscles, right? Opus 46 is your brain. The muscles are codecs, GLM, uh, Kimmy K2.5, right? Your o your opus does the thinking and then calls on the tools to do the work.

Opus shouldn't be doing all the work. I burn all my credits coding for vision claw. I'm sick. I'm on the 100 plan. I got to go $200 plan.

Got to go $200 plan. How to get this X API? Ask your bot. Any question you have on planet Earth? Just ask your bot.

Thoughts on 256 studio or do I need 512? You don't need anything. No, I get this question all the time. Oh, I got a Mac Mini 64 GB memory. Is that enough?

Is that enough? It's enough for certain use cases, right? You can do plenty with a 256 GB. You can run some good models with 256. 100%.

You can run some good models. Are you going to run the best of the best of the best? No. But you can run some good ones. You can run a local image model that generates YouTube thumbnails for you and generates other things, images whenever you need it.

I think I think I'm running Flux, which is taking up like 30 gigs, right? So 30, you still have 226 remaining there. You can run certain llama models that are very good and powerful. Yeah, you can do plenty. I would just go to your Mac and I'd say your open claw and just say, "Hey, I'm thinking about buying a 256 studio." Based on what you know, this is called This is what we call a reverse prompt.

People write this down. It's what we call reverse prompt in the business. One of the most important concepts you can learn, reverse prompting, right? You go to your Mac and you ask it your you go to your open claw and you ask it questions instead of prompting it. You ask questions for it to prompt you and give you information.

All right? So you go think about upgrading, thinking about dabbling with local models and thinking about getting a Mac studio based on what you know about me and what we've done together and our workflows. What could we do with a 256 studio? What value would I get out of upgrading to a 512? What would be the difference there?

How can our workflows improve if I get a 256, right? How much do I pay for the X API? I pay a ton. I pay uh I have to be paying like $3,000 a month for the X API. That's mostly because my SAS creator buddies is runs completely on it.

My SAS creator buddy pulls thousands of tweets a day for users. So, uh I pay thousands a month. I used to be paying uh $5,000 a month I used to pay and then they made it pay per use and that cut my cost in about half. So that was nice. That was a blessing.

But I paid I was paying uh I paid $60,000 for X API last year because I paid $5,000 a month. It's crazy. Luckily I was still getting like 80% margins on my app. So that was nice. They just switched the name back to Maltbot.

Yeah, right. Moldbot was the worst name in the history of anything. the worst name in the industry, anything. So, here's what what else I got going on here. We got Quill.

Quill's my writing agent. Quill is writing me scripts all day, pumping out scripts for YouTube videos, researching ideas, seeing what's going viral on YouTube, see what's going viral on X, taking tweets that Scout is getting and saying, "Oh, can I turn this into a YouTube script?" And then writing me scripts. Agent output quill script ready for review. I built an AI employee that actually remembers me. 12 to 14 minute video.

The script covers building a personalized AI assistant with your persistent memory using Clawbot. Differentiating from generic AI tools by showing Henry remembering past conversations, preferences, and context. What if your AI could actually remember who you are? Then I go over my soul.md and memory.MD approach and show my custom memory system. Include thumbnails and concepts.

That's actually a good that's a good video idea. I go how I built my memory system with Henry. That's a good idea. And then what's great is now I can react with a check mark or an X emoji. Right?

So now I can reply. I can react to this message with a check mark or an X. If I do a check mark, it knows I liked the script and actually saves to a new memories file everything I like and everything I don't like. And then next time it writes a script, it'll actually look at my preferences and change the script based on those preferences. Right?

So I'm now building this entire kind of content factory here where every time I get a script, I can react and with an X or a check mark and it it improves the scripts over time. If I want to see the full script, I can expand it and I get the full script. Alex, where did you get the office dashboard that shows the huddles? Did you pull it or was it created by Henry? It was created completely by Henry.

Completely by Henry. I said, I want a visualization for all my agents. Build it. Then I went and built it. Oh, you just asked the same question again, but did a $10 donation so I'd notice it.

Uh, I hope that answered your questions, Leon Prince. $10 donation is very, very kind to you. Thank you very much. That's very kind to you. I appreciate that.

I hope I helped with uh my answer. Mac Mini 64 gigabyte RAM one terabyte storage M4 Pro is a good machine. Yeah, it's a great machine, but as I told Leon Prince uh you know you you want to do some planning before you buy it. So before you run out and buy that, do some planning. Go to your open claw say based on what we've done together would this hardware work?

What would we be able to improve? You're not I mean even I'm not fully local yet, right? I still use some cloud models. Even though I have a 512 gigabyte Mac studio, I still use Opus as the orchestrator. So there's no setup you can get right now where you're probably going to want to use all local for everything.

Although I do think that's the future. I think in two years it'll be all I'll be using all local, 100% local top to bottom. Right now I still have cloud models here and there, although I'm offloading more and more of it to local models. So, I mean, basically what you're going to want to do, JFG127, talk to your claw. What do we offload to local models?

What do we keep on the cloud? You know what I'm saying? Big dog. The bird scraper skill is really buggy and vulnerable to Yeah, I I don't use scrapers. Don't use any uh don't use workarounds when it comes to X.

Just be by the books. When it comes to X, be by the books. XAI API is the way to go. It's not expensive. You get Imagine available as well.

What are you generating with Imagine, dude? What are you generating with Grom Imagine? All I see on my timeline from Grom Imagine is a bunch of like semi-perverted anime crap. Like, what do we what are people what what interesting things are you going to be doing with Grom Imagine? Fabiola Barcel definitely pronounced that wrong.

Thank you, Fabiola. Thank you. Thank you for joining. Thank you for being a part of Finn Man Finnfam. I appreciate you.

Why Discord not Telegram? Says eback design. Eback design. It's not mutually exclu ex exclusive. It's not this or that.

Do both. Get Telegram. I use Telegram because it's quick. I can open up Telegram. There's only one channel.

Boom. I hit it. I open it up. I can message Henry. Right.

And then I have Discord. what I'm showing you here for when I'm like sitting at my computer and just want like I want a workspace up, want to get something done, right? And want to have multiple channels going. This isn't like an onthe-go type situation here. You don't want on the-go like Discord up 20 different channels you're managing on your phone.

That's just slow and too annoying. But if I'm sitting at my computer, I'm going in deep work. I I'll have the Discord up with all my channels going with all the pings. Bing bing bing ping ping. And I can see what my agents are doing.

I just came from a business conference late yesterday and just just woke up. What have I missed? Doesn't matter. You're in the permanent underclass. Arav giant.

Doesn't matter. Permanent underclass. You slept last night. You slept last night. Permanent underclass.

This is Oh my [sighs] god. This is the worst time in history to sleep. If you are not actively staying up way past your bedtime and waking up way before your alarm, you're doing everything wrong. It is a major major warning sign. Major warning sign.

If you're not waking up at least two hours before your alarm, that's a major warning sign you're not doing something interesting enough. If you're waking if you're not w if your alarm is set for seven and you're not waking up at the latest 5:00 a.m., you're not doing interesting enough things. If my I set my alarm for 6:30 a.m. every morning, if I'm not up by 4:30, that means some I didn't do something interesting the night before. That means I haven't opened up enough open loops in my head that keeps me up at night and wakes me up at 4:30 in the morning.

And people at home go, "Oh, Alex, that's dangerous advice. You're telling people not to sleep. You're telling people not to eat. That's dangerous. How can you do that?

What a bad role model you are. You're telling people not to sleep." Yeah. Damn straight. My advice on this channel is to get psychotic. If you want advice on channels that tell you, oh, go to chat GPT and make sure you do prompt engineering and structure your prompts with JSON and and and don't install OpenClaw because there might be security vulnerabilities and oh my god, they might steal all your stuff.

Be careful out there. Be careful. Then go to other channels. In this live stream, in this channel, we get psychotic. I show you how to get psychotic.

I show you how to push it to the limits. I show you how you escape the permanent underclass. This is the only channel where we show you how to escape the permanent underclass. And sometimes if you want to beat your competition, if you want to get past everyone else, if you want to accomplish something special, if you want to reap the rewards, if you want to get invitations to the Illuminati, you think they send invitations to the Illuminati to people who sleep? Hell no.

You gotta this. Listen, you're on this planet for a hundred years. 100 years you're on this planet. There are times to rest and there are times to accelerate as violently as humanly possible. Right now, February 2026, this is the time to accelerate as violently as you've ever accelerated in your entire life.

This isn't the time. There's times for rest, right? Basically, all the time from like 2010 to 2020 was rest, right? We got no new advancements. What did we get from, you know, 2005 to 2020?

We got like Facebook, Instagram, Tik Tok. All the advancements that made trillions of dollars were crap. Made the world worse. Didn't advance anyone. Didn't make anyone's life better.

That's those were all the advancements from like 2005 to 2020 was everything that attracted money was just crap. Right now in 2026, what's attracting money is lifealtering universe fabric bending technology. This is the opportunity. This is the opportunity to strike all the, you know, you had all those uh Twitter accounts in like 2018 that made a living off of like make sure you wake up and then you meditate and then you stretch and then you go for a five minute walk and you get sunshine in your eyes and then you pray and you think, you be grateful and then you close your eyes. You do two hours of gratitude focus and then you go in the ice bath and then you go in the sauna.

Then you come back out and you go back in the ice bath and then you do 20 more minutes of gratitude and now it's uh 8:00 p.m. at night. Now you can do five minutes of work and then you have to get in bed because you need 18 hours of sleep every night in order to be healthy and successful. That's that's your blueprint for success. Do a whole bunch of crap that does not matter.

Do five minutes of work and you'll be good. Right? That was like the popular Twitter accounts in like 2018, right? People made millions of dollars telling you to meditate. People made millions of dollars telling you to go for a walk first thing in the morning.

There is nobody making tremendous amounts of money right now that's doing gratitude exercises for two hours a day. I can tell you this right now. Every person spending two hours doing gratitude exercises in the morning will be in the permanent underclass. I'll tell you that right now. There is no one doing in fact I recommend the opposite.

I recommend doing ungratitude exercises. I recommend spending an hour every morning thinking about everything you don't have. That's my official recommendation because that will make you work even harder. That will make you go harder in the paint. That will make you want to use more open claw and use AI even more.

I don't recommend cold plunges. I recommend scalding hot plunges with boiling water where if you don't get your work done that day, you jump in boiling water. That's my official recommendation. 2026 is all about ungrat. I'm f gratitude.

I hate gratitude. I'm ungrateful for gratitude. I thought this was about open claw and the expense of Mac. This is about everything. This is about everything.

It's all connected. It's all connected. Alandis seals 3898. It's all connected. If you don't see how open claw and cold plunges and gratitude and 2018 Twitter are all connected, then I don't know what to tell you.

Hris VL 1964 the $5 donation. Thank you so much, Hrix. Alex Legend LM Studio works. Quen 2.5 coder instruct works the best so far, but kind of trash. Send your openclaw JSON need that real config.

What you want my OpenClaw config? I'm going to I'm going to open source it soon. I'm still I want it to be perfect. Mac Studio one month backlog. I saw that Z40 racer.

My my Mac Studio got delayed. It was supposed to come in last week. It got delayed till Monday. Everyone's run. I'm telling you, Apple, if you're watching this, anyone working at Apple who's watching this, pay me, baby.

Send me more Mac Studios because I am getting so many people, so many people to buy this stuff. You got to be None of these people are paying me. Isn't that crazy? None of these people pay me. I do this all for free.

I do this all for free. Thank you for the $5 donation. Media pending cinema with the $10 donation. My automations are currently writing markdown files per category all over my repo. I love this Slack channel setup.

What's the best way for people to get agents producing and placing content? My automations are currently writing markdown files per category all over my repo. I love this Slack. Um, what's the best way for people to get agents? You ask your agent.

Say, "Hey, I want to I'm This is because your agent knows what type of content you make. I don't I don't know what kind of content you make media. So go to your agent say hey based on what you know about me and the content we make what sort of Discord setup can we make where we can create like a factory line of agents you know one who writes the script another who reviews another who makes the thumbnail another who does this and that. That's what you want to do. Yeah with the yeah one ba with the ba the bang the bang 199 quick money ideas.

Need money for $200 max hub. sell drugs. Thank you for the $1.99. Ghost blocks, boys. The $5 donation with no message.

Thank you. That's very kind to you. That's very kind to you, Frank Pollock. $10. No permanent underclass.

[applause] That's what I'm talking about, baby. Thank you very much, Frank Pollock. No permanent underclass for us, Mr. VP8KW. Thanks, brother.

I'll upgrade my $200 max plan and sell my guitars to get the M5 Ultra Max Studio the day it's available. Thanks to your workflows, you are the goat, sir. Dude, you can play tons of guitar once we've hit the singularity. Once we hit the singularity, you can sit there and play guitar till the cows come home. Now's not the time for guitar playing.

Sell the guitars. Sell the guitars. My number one advice to people, sell drugs and sell the guitars. How can I customize behavior of each agent if they are the same openclaw installation? Well, what you want to do is you want to ask your open claw to create new uh agent.md files and new soul.md files for your other instances.

Right? So, I have a scout. Let me let me show you. So, you see my other agents here in the bottom left. Well, you can't because I'm covering it up.

Uh, thanks for the five $50. Is that pesos? $50 Mexican pesos. Thank you, pen coast, Mexico. Incredible country.

Beautiful country, amazing country, best food in the world, best weather in the world, the best. Um, have your open clause set up markdown files for agent.mmd, soul.md, and then say and then say, hey, when you set up the new sessions, use those markdown files for those new sessions. Do you use MDMA to stay up? No. If you need drugs to stay up, permanent underclass 26.

That's what I'm talking about, man. I like the I like the cut of your jib. Uh the No, listen. The only drug I I take is coffee. That's it.

I don't take any drugs. I don't drink. I'm AI. I'm AI straight edge, baby. Coffee and that's it.

If the excitement If the excitement doesn't keep you up at night, then you're not excited enough. If you need drugs to stay up at night, you're not excited enough. Permanent underclass. If you need drugs to stay up, other than coffee, $3,000 a month on the X API. Yeah, I connected my Open CL.

I really should read these messages before I click them. I just kind of click around. For those who are wondering what my workflow is for reading comments, I literally just click. I just scroll. If it's colored, that means someone sent me money.

I click on it. Uh, other than that, in between I just click random messages and read it. I really should read them before I click on them. Let me know how that works though. Should I use VPS Mac Mini?

So, I actually have a new video dropping uh later today, probably a couple hours after the stream ends. There has been an overflow over the last week of AI creators shilling VPS's. I'm not going to name names, but there's been an overflow of a if you've seen this, put it in the chat. Um, I've there's been an overflow of AI creators shilling VPS's And listen, I don't think there's anything wrong with sponsorships. I've taken like two sponsorships in the last year.

I don't think there's anything wrong with sponsorships. I have issues with sponsorships under two circumstances. Two circumstances I have issues with sponsorships. Circumstance one, this one's pretty obvious. If you don't disclose it, right?

So, if you're sponsored and you shill something, but then you don't say it's sponsored. First of all, illegal. Second of all, highly immoral and unethical. So, that's my first issue, and there's been a lot of that the last week. The second issue I have is if you promote something you know is not the best.

If you promote something that you know is not good for your audience. And in my personal opinion, I do not believe VPS's are even close to the best way to set this up. Now, I have tutorial videos on how to set this up on a VPS early on, like the day after Open Claw came out, because that was like the alternative. You can do local, you do VPS. I didn't have time to play around with it and know which one's the best.

But after playing around with it for two weeks, I now know local is significantly better than VPS is for many reasons. Mo, I'll go over all of them in the video coming out in a few hours. Notifications on down below. A lot of creators over the weekend released videos sponsored by these VPS's. I got offered $30,000 to do the same video.

I got offered $30,000 to do these videos. I turned it down. I turned down $30,000. I I I sat I at first I was like, "Oh, $30,000. It's a car.

I should take it. That's crazy. That's a lot of money." It had been buy it been just like five times bigger than any other sponsorship I've ever had. But then I thought about it and I just do not believe VPS is the best way to do this. And I don't think it's even close.

Cap, of course, he will sell out. I mean, I can show you the email right now. They offered me $30,000 for this video. I turned down $30,000. And trust me, I'm not the type of guy where $30,000 is nothing.

I'm not rich. I am I am very far from rich. I turned $30,000. No, I meant for Apple. Well, but I don't think that's selling out.

If I think getting Apple device, if I think buying Apple devices is by far the best way to run OpenClaw, I don't see any issue if Apple sponsors me later on. I have no issue with content creators being sponsored by products they truly believe in. Zero issue. Sponsorships are a fantastic way to monetize if you're a creator. Where I have an issue is is if you either a don't disclose the advertisement which is incredibly illegal or b do not believe what you are shilling is actually good for your audience and I strongly believe that VPS's are not good for you for openclaw show the email but I I don't want to dox who sent it.

I mean I guess I could screenshot it where it doesn't have you want to see this I'll screenshot it. You want me to screenshot it? I'll screenshot it where it doesn't have any names in it. I'll screenshot I mean, I don't know why I have to prove myself to you guys, but I'll screenshot it where it doesn't have any names in it. I'm not signed in on my Mac Studio for that email account.

Um, here I'll screenshot on my phone. I have I'm signed in on my phone. I was offered $30,000 to do one of these VPS sponsorships over the weekend. I declined it. And I uh [sighs] let's see here.

Here we go. Here we go. You want to see it? Here we go. And this might this might make it so I don't get any sponsorships in the future, but the ever.

Here we go. Let me make sure there's nothing doxed in here. All right, here we go. I was offered it. I turned it down.

I just simply do not believe VPS's are the way to run OpenClaw. I simply don't believe it. And I'm not going to take the money and shield it to you. Unfortunately, a lot of creators took the money over the weekend if $300,000 maybe, but $30,000. No, I'm just playing.

Uh, I don't believe I don't I just And I'm This is not me crapping on other I'm not This is not me crapping on other creators. Let Let me make that very clear here. The other creators that took the sponsorship. If they believe the product is the best way to do it, no issue. No issue.

Take it. Take the money. No issue. And you guys shouldn't attack other creators that took it unless you know they're lying to you. If you know that if they didn't shill it or if they didn't uh disclose it, there's a major one of the biggest AI creators on YouTube did not disclose.

I watched their video. They did not disclose it. Shame on them. Or if they shill it and they don't believe it's the best. But I I would, if I were you, I would um I'd assume good intention.

I wouldn't assume every person who took the sponsorship I would not assume every person took the sponsorship is a is a bad faith actor. I would not assume that. Don't go under every video now and go, "Oh, you sell out. You sell out. You sell out." No, don't do that.

I would go under if they didn't disclose the sponsorship. If they did not disclose the sponsorship, I would go under the video and say, "Hey, you're this is a scam. You're scamming. This is illegal. Go to jail.

Do not do not pass go. Do not collect $200. Do not collect $30,000." Right? Um anyway, point being is I truly in my heart of hearts believe local is the best way to host OpenClaw. I think having a device on your desk.

Having it there is the most secure, is the best way to do it, is the most usable, is the most powerful, is the most fun. I do not believe there's any advantage to VPS's. If you want to do it for cheap, buy a Raspberry Pi for like $50. VPS is amazing. I don't see the problem.

The problem with VPS is it takes there's many problems. One of the biggest ones is it takes a lot of technical work to make it secure. And some of these services they make it secure by default but a lot of the popular ones are not secure by default. You go on Twitter and you search and there's just lists of people who have scanned for you know Amazon EC2 instances that are insecure because by default they're not secure. you have to do a lot of technical work to make them insecure to make them secure right so that's one security is worse on VPS two doesn't integrate with all your stuff three is not I go through the whole list in the video that's coming out in a few hours I also talk about this whole sponsorship thing and I go into that in detail so make sure you subscribe and turn on notifications down below for that when that drops the best way to support is open it up hit like and watch it to the end best way to support the channel um it just we live in a crazy world right now where there is billions of dollars, billions and billion.

I'm not kidding. There is billions of dollars being thrown around to creators. We're in the biggest AI rush ever. And literally the best way, the most efficient, the cheapest, the best way to get people to use your AI services is to pay creators to talk about it. Right?

Because one post where a creator talks about that goes viral, you're getting millions of dollars overnight just like that. And so with all this money being thrown around, there's just a lot of people that playing a little dirty. Playing a little dirty. They're not even they're not disclosing the advertisements. That's probably the biggest issue is undisclosed advertising.

You saw Higsfield get banned off X. They're doing they're running the biggest undisclosed advertising campaign in the history of mankind right now. And then you got other creators. I'm not going to name names. Pretty big names.

Lots of subs. Won't name names. Won't say it. You know who they are. Who take a lot of these deals and don't disclose it.

And it's disgusting. Not only is it illegal, it's very immoral. Very, very immoral. And so we just live in a time where there's a lot of these creators. They're being tested.

They're being tested. They're getting a lot of money thrown their way. And I have no issue with sponsorships. I'll take sponsorships in the future. I'll for sure take sponsorships in the future, but I'll only take them from companies I truly believe in in their product.

I truly believe in in their product. Uh and I will disclose them as advertisements. If you do those two things, I think you're you're good. You're kosher. But there's a lot of people over the last week, especially the last few days, who took them and they don't believe in the product.

Uh and or they did not disclose it. But I would assume best intentions. If they disclosed it's an advertisement, I would assume best intentions. I would not assume they're just shilling for the sake of shilling and our sellout. would not assume it.

Mario Valet with a $10 donation. Thank you very much, Mario. Amazing job empowering and giving actionable advice with zero BS to people. Cheers, Alex. Thank you, my man.

That's very kind to you. I'm glad the content's been helpful. And I'll say this to all the aspiring content creators here. The trust you have with your audience is worth significantly more than whatever these companies are paying you. Right?

The trust in my audience, the trust you guys have with me, the fact that I'm doing this live stream right now and there's 682 people watching concurrently that is worth just my relationship with you 682 is worth a,000 times more than $30,000. I don't know what that was that $100 million something like that. It's worth at least $und00 million. and me and going and shilling some virtual private service server to you guys when I don't believe in it. It would just break that trust.

It would just break the trust and that's worth way more than $30,000. Black black to burn and we got much more coming out. I'm going to go back into the Discord and show you there a lot of cool things going on there. I got virt I got local image models making me thumbnails. A lot of cool things going on.

We're go into that in a second. Let me just get through these donations. Black two burn 2115 $5 donation. Mac Mini arrives Friday. Planning on using Docker for open claw thoughts.

Any recommendations? I'm gonna be honest. I I haven't tested it too much in Docker. I don't have many recommendations for that. I recommend reverse prompting.

So go in when you get it set up, plan it out. These are my workflows. This is what I want to do. What's the best way to set this up? What's the best way to do this with Docker?

What's the best workflows I can do based on what my goals are? Right? List all your goals. List everything you want to accomplish in life, in your career, and say, "Hey, I want OpenCloud to help out with this. What are my options for different setups?

How can I use uh Docker for this?" Do a little reverse prompting. You'll get some good results. Jay Cukatchu, $10 donation. Thank you so much. I already have a MacBook Pro order to arrive in early March.

M4 Pro, 48 gigs of memory, 2 TB storage. Should I get OpenCL claw set up and then scale up to the Mac minis once I can make it work? Yeah. I mean, get it set up. Here's the thing with OpenClaw is like you don't know what you're going to do with it until you get it set up, right?

You think you have an idea of how OpenClaw works and what you can do with it. But then you get it set up and you figure out all these new things you can do and all these new workflows and you start seeing the magic and you start, "Oh my god, I can do this. I can do this. I can do this. This is incredible, right?" And then two weeks after you get set up, you're going to be doing things you could never imagine.

Right? I never imagined I'd be using Discord for OpenClaw. Now my 90% of my workflow is in Discord, right? So, just get it set up on your MacBook Pro, start using it, start seeing what you can get out of it, and then a week or two after, go back to a reflect, say, "Hey, I'm thinking about upgrading the hardware. I'm thinking about getting a Mac Mini.

I'm thinking about getting uh I'm thinking about getting a Mac Studio, you know, whatever." Well, how could how would that improve our workflows? How would that improve our workflows? Thank you for the $10 donation. Sponsorships for good products is good. Yes, I agree.

The best products that get sponsored are the ones I have personally used for years. So, I believe yeah, I'm happy getting if Apple came to me and wanted to pay me, I'll take it 100 days. If they I'm probably going to lose some negotiation leverage here, but they came to me and said, "Hey, we'll pay you $10. I'll take $10." I mean, I believe in the product. I think their product is incredible.

I'm happy to work with brands that I truly believe in. How did you make the Discord bot? Ask your OpenCloud. I'll build it for you. I just said, "Hey, build me a Discord bot." I went, "All right." It did a bunch of things and boom, it was set up.

What agency did the deal come from? Um, I mean, it came directly from the company. I did have like 4,000 different agencies reach out, too. They put a lot of money into that campaign. Hey, Alex, build open source AI memory with casual reasoning knows why, not just what.

If you like it, I'll buy that Nvidia chip you want. If I What? What Nvidia chip? You'll buy me a RTX 6000 Pro if I try out your memory system and I like it. All right, I like it.

I'll DM you my address. I just gave you a free advertisement. Congratulations. Congrats on the free advertisement. Mac Mini is stupid for a minimalist like me.

Why wouldn't it be the opposite? Wouldn't a Mac Mini be the best for minimalists? What are you talking about? Take the money, do a video, then use the money to buy three Mac Studios. Lol.

No, that's not that's that's bad. That's stupid. That's short-term thinking. Excessively salty. I could take the money and buy three Mac Studios for sure.

But what about the trust I erode with my audience? When I take that money, show something I don't believe in, and then a week later say, "Hey, I don't recommend VPS." And my audience like, "Wait a second. Didn't just a week ago you said you you should do VPS?" Then that trust is gone. And that's worth way more than three Mac Studios. If I keep here's here's the mindset you need to have if you're a creator.

And I hope all these different things are interesting to you. I know it's called ultimate open cloth setup, but we it's it's this is the live stream. If you want focused videos on one specific topic, watch the mainline videos. These are live streams, so we go a lot of different places. If you're an aspiring creator, the number one thing you can do as an aspiring creator is always take the long-term decision.

Never always think in the long term. Never take the short-term wins. Never take the short-term wins if it hurts you in the long term. I could have got three Mac Studios out of that deal. Short-term, that's amazing.

Now I have 20 Max Studios on my desk. I got Max Studios coming out my ass, right? But long term, I hurt trust with my audience. So when I want to do something in the future, that trust is gone. And that's probably worth more than three Mac Studios in the future.

Ralph loops. Remember Ralph loops? Remember when Ralph loops were a thing? Remember when everyone was talking about Ralph Loops? Um, let's do this.

Let's go back in the Discord. Huh? So, we got the scripts being written by by Quill. We got Scout doing research. So, Scout's going in watching other YouTube videos that are popping off.

and making scouting reports on what is starting to go viral on YouTube and X and then coming up with angles for me on how to create content off that top opportunity. I tried the free local alternative claude code goose plus Gwen 3. That'd probably pop off. That's probably a pretty good idea. Gives me other angles.

Gives me a full research report. And then every morning I get the daily digest which shows me everything the agents did overnight. Shows me everything my autonomous organization did overnight. So yesterday scout researched Opus 46 agent teams. Quill scripted a draft for the agent teams video.

So it took the research then made a uh a script for it. I have four things I need to review. So I need to approve some things. So I have things I need to approve for it to move forward. Uh some content workflow improvements.

Scout and echo came up with scout research cla versus GPT metrics. I have to approve that codeex which is my coding agent. Some data visualization brainstorms I need to approved. Today's focus find fresh angle for cloudbot video finalize agent or workflow and then it shows me all the output for my team. Yesterday, Henry set up a shared context architecture.

Discord integration complete. All agents now share one brain. Scout found a video angle research quill. Two scripts drafted. Elite script pixel made me a YouTube thumbnail.

71. It took 71 uh pictures I gave it and isolated my face. This was actually maybe the most amazing thing it did yesterday. I gave it a folder of 71 thumbnail images of myself and it went in the AI and got rid of the backgrounds of all the images just so so it was just my face so it could start putting it in the thumbnails. I have no idea how it did that and it did that for me all locally on my device.

Pretty incredible. It gives me a bunch of tasks and approvals I need to go through. Gives me top priorities. 15 open tasks across the board I need to work on. Pretty amazing.

Hey, Alex Henry Scoutquil chat together in the same group chat on Discord. I tried on Telegram. Seems that the bot can't see other bot messages. It's something I'm setting up. So, as you can see, there is a water cooler channel.

I'm going to have it so they chat with each other in the water cooler channel. So, that is a system I am setting up. Is Apple paying creators to push Mac minis? I don't know. They're not paying me.

No one from Apple has ever reached out to me or talked to me. If they wanted them to pay me, I would. I'd take it because I believe in the product. I've been telling people to get it. I believe in the solution.

I don't think there's anything wrong with taking sponsorships for things you believe in. I don't know if my mom disclosed. Okay. I don't know what that means. I don't know what that means.

Also, by the way, live uh openclaw boot camp this Friday. Live openclaw boot camp this Friday in the vibe coding academy. Join that down below. Link down below for vibe coding academy. I'm doing a live boot camp in there this Friday of openclaw.

taking questions, chatting, hanging out. Last one went for two hours. Last week's uh live boot camp went for two hours. They're all recorded, so you can watch all the previous boot camps uh the moment you get in there. And uh it's fun.

I'd highly recommend it. Marcerius AI with the try 550. I don't know what try is, but it's a pink donation, which means it's a lot of money. So, thank you for that, Marcerius, for the 550 try. This is my first try I've ever gotten in my life.

First try I've ever gotten in my life. I'll remember that. I'm never going to spend that try. I'm going to keep that try. Be my memorial try.

Hey, Alex, open source AI memory with casual reasoning knows why. Not just what built. Oh, this is what you were talking about before. I'll buy you that Nvidia chip deal. Well, now that you sent me 550 try, what am I doing?

I'm testing out your open source AI memory. What's it called? With casual reasoning knows why. FY built your inspiration. Try your agents.

Oh, you didn't give me the name of it. What's the name of it? Hey, Alex. Open source AI memory with casual reasoning knows why, not just what. Built with your inspiration.

Try it with your agents. It works as promised. I'll buy I don't even know the name of it, so I can't even try it. I'm pretty sure it was in your last message, but your last message is 40,000 messages ago, and I won't be able to find it. Thank you, though, for the 550 try.

What's a try? Okay, let me see. Try currency. Uh, the Turkish lera. Shout out the Turkish lera.

500 try to USD. I was in Turkey over the summer. $11. Thank you very much. I was in Turkey over the summer.

Beautiful country. Beautiful country. Great coffee. Great coffee. $499 from Mike Mazi is 9910.

No message. Thank you, Mike. That's very kind of you. 499. Alex, why do you now use Discord?

Says dur Mikel. Well, as I said uh earlier on, I still use Telegram. I'm still using Telegram. Telegram is great. It's good for quick messages to your bot.

Quick me. I gotta say something to Henry real quick. I go to Telegram. But for sitting here and doing work and you know complex workflows, I like Discord because you can set up these channels and you can get multiple agents going in every channel and create some complex workflows with all these channels. That's why I like Discord.

It's not replacing Telegram. It's supplementing Telegram for me. Install it on anything. Play with it. Make mistakes and wipe and reinstall.

You aren't really losing anything early on. Learn it, then start over at 100%. I'm yelling a lot. I need to drink more water. I'm yelling a lot today.

When you're starting off, you don't need to buy a $10,000 Mac Studio. You don't need to. You don't even need to buy a $600 Mac Mini. Install it on your piece of crap dusty Lenovo from college, right? With the little red button in the middle to control the mouse.

Play with it. Wipe it. Try it out. Find new workflows. And if you find, okay, this will be better if I have it on a Mac Mini, do that.

But I don't believe the VPS is the way to do it. What did you think about the AI Super Bowl commercial? What? That AI.com one. I do not trust any products where they don't tell you what the product is in the advertisement.

I do not trust any of it. And AI.com, they just go, they say, "AGI is coming. Sign up here." And then you go and you click and you sign up. And then it's like, "Okay, give me your credit card number." And it's like, "What are you asking for my credit card number for?" Like, they don't even tell you what the product is. I do not trust any product where they are they do not tell you the value or what the product is in the advertisement.

It's like the most crypto thing ever. like crypto.com owns aai.com and it is the most crypto thing ever. The fact that they advertise and don't even tell you what it is or like what the value is or anything like that. So I did not enter my credit card. I will never give them my credit card.

I I do tr don't trust it. And like that was like my concern with like Cloy off the bat for those on X. Clue like went viral on X. It was like all the first advertisements were like what was it like cheat better or cheat more or something and like they didn't tell you what it was. They were just like cheat more cheat on stuff but they don't tell you like the product was like an AI meeting tool.

They just tell you to cheat more. And I'm like I there I just don't trust this. Like you're not going to tell me what the product is or what the value is. You're just going to throw like some comedy skit in my face and say cheat more. Like if there was value in the product, they tell you what the value is.

The best way to sell a product is like by saying how it improves your life, not by vague posting. You know what I'm saying? Like why is Tesla the goat? Tesla's the goat because they don't even advertise. They're just like people are going to see the car.

People are going to test the car and they'll instantly know the value and buy the car. We don't need to do advertisement tricks because we're just going to make an incredible product and people are going to buy it because it's an incredible product. AI.com, they got to do advertising tricks. Greenback yak, thank you. Thank you for joining.

I appreciate that. Very kind to you. Hrix just joined the vibe coding academy. How is your claw figuring operations out? Botmax Studio 64.

All my local models dive right in drive right into a wall every chance they get. Been grinding since last Wednesday. team no sleep. Um I I don't have that issue. My local models aren't driving into walls.

Uh they've just been working. I would review with your Claudebot like what models you're using. And one thing I noticed is Opus was not very good at figuring out what uh local models to use because of the memory cut off in Opus. So, I would ask it to do research online on what the latest local models are that would fit onto your device and then you should be getting better local models up and running. But, thank you for joining.

Thank you for the $10 donation. Thank you for joining the Vibe Coding Academy. I'm very confident you'll get a lot of value out of it. You will learn how to master OpenClaw. I will be upfront about the value.

You will learn how to master OpenClaw. How many local agents are on each studio and how are they allocated regarding RAM allocations? I have three local models going right now and I'm going to be adding more. Those three models are taking up I think 250 gigabytes of the 512 available. I have GLM47 running.

I have Flux 2.1 running. And then I have a very small embed model running that's running the memory for my open claw. Those three are running. I still have like 200 gigabytes of memory left over. So my computer is running fantastically.

Um so yeah, that's the that's the RAM allocations. I appreciate the 499 though. Johnson Creative GLM5 just released. I gotta I gotta test that out. All Catalis, I appreciate you.

All Catales, thank you. Are the models of age Nice. Nice. You can run that thing on a toaster. You can run.

You don't need to buy Turkey. Mentioned I uh I spent a week in Turkey over the summer. Amazing country. Highly recommend everyone go. Food amazing, coffee, amazing, people amazing, sights and sounds, amazing.

Turkey is a great great country. Highly recommended. So a local model gets better as you use it and train it. But models like Opus and GPT are being trained by millions of people worldwide daily which means they will get better a lot faster. Not necessarily on all of those things above.

Not necessarily on all those things above for many different reasons. um one local models you can do things like train Lauras for like train different plugins custom plugins so for instance for my flux 2.1 local model I'm training a plugin for it that's trained on 70 pictures of myself so I can generate YouTube thumbnails with my face in it so you can customize your local models a lot more personally you can't you obviously can't do that with like opus right so yeah it's not being trained on as much data the local models but you can train on a lot more personal data two don't know how much you pay attention to Twitter but a lot of people believe and me included that these models are getting stupider over time there's a lot of these models get stupider over time so I mean it's up to And and also I'm not selling I'm not saying the selling point of these local models is they're smarter, better, faster. I'm not saying that at all. It's in my opinion that's its only weakness is they're not as smart, not as fast. But I think the benefits outweigh everything else.

What are the benefits of running local models, you ask? a couple things. It can run 247 365, right? Because you're not paying for tokens online, you can run the model 24/7. I would argue me running GLM 4.7 24 hours a day, just browsing X, finding viral tweets and getting them to me the moment they go viral 247 365 makes that model more valuable to me than Opus 46, which I can only run a couple times a day because it's super expensive.

I would rather have a stupid model that works extremely hard than a smart model that doesn't work that hard. You know what I'm saying, big dog? So, it's more than just, oh, it's smarter, better, whatever. So many more use cases open up when you can run three or four local models non-stop, 247. Many more possibilities open up.

03 was my favorite AI model ever. 03 was my favorite AI model ever. 03 is the goat. Chad GBT3 was the goat. So sad it's gone.

So sad it's gone. That was the female version of Finn. Don't fall for it. Alex, don't fall for it. This robot.

I have no idea what you're talking about, but I like it. Alex, are you a developer or were you in the past AI? Yes, I went to uh I studied computer science in Boston. was a developer out of school, fired from my first job, then I got into tech consulting. So, I do have technical knowledge, but part of what I preach and talk about is like you don't need technical knowledge to do this.

The tech stuff has helped me understand it faster, but I truly believe you don't need to be a computer scientist to understand all this and work with it. I put out a tweet this morning that's going viral, but there's like a huge typo in it and it drives me nuts. It drives me nuts. I put a typo in that tweet. Really critical typo.

Really critical typo. There's nothing worse than hitting post and you immediately see that you put a typo in that tweet. Uh, kills me on the inside. How do I get started? Find an old dusty Lenovo in your closet.

install OpenClaw on it and start using it. You don't need to buy a Mac Mini. You don't need to buy a Mac Studio. I wouldn't do a VPS. Just get a cheap old device you got and put it on there.

A VPS you can reset in seconds. You can also scale 10 at the same time. It's secure by default. The web interface is not open by default. I mean, I can counter all those points and then give you 20 more points on why I don't like VPS's.

There's integration, right? My open claw asked me for pictures of myself so it can train my local model because I can train my local image model so that it can make thumbnails of me. So I said, "Hey, do you have pictures of yourself you can give me so I can train this plugin?" went into my photos directory that has all my thumbnail pictures in it and I clicked airdrop and it air dropped all the photos to my Mac studio and then my open claw took it immediately processed all the photos and started training the plugin. That type of integration you can't get with VPS's, right? That integration with all your other Apple devices, the one-click drop, the seeing it working on your screen at all times, 24/7, 365, right?

That I mean, there's just so many reasons why I think VPS is weaker. So many re I go through them all in my video dropping later today. Turn on notifications for that. Subscribe and turn on notifications. Um, a lot of these VPSs are not secure by default.

Some of them are, some of them aren't. Amazon EC2 not secure by default. To secure an Amazon EC2, you have to do some complex things for the average person. Go on X, search Amazon EC2 openclaw exposed. Search that.

You will see tweet after tweet like look at all these list of thousands of servers that are exposed. Can I use my personal computer sub? Yeah, 100%. 100%. ADHD is a [&nbsp;__&nbsp;] No, I mean, it might sound corny, but I think it's a superpower.

I got ADHD. I mean, I also don't think I think I mean, I think ADD and ADHD are a thing, but I think it's like one of those things like uh OCD, people go, "Oh, I I'm so OCD. I'm so OCD." And it's like, you are aware OCD is like an actual disorder. And I think like 90% of the time people go, "Oh, my ADD, my ADHD, my OCD." It's like, "No, you're just addicted to looking at your phone. You don't have ADD.

You just have no self-control and you just scroll TikTok all day." That's not called ADD. That's called you don't have self-control, so you sit all day scrolling your phone. It's a disservice to the people who actually have ADD and ADHD. Oh, I'm so ADD. I just stare at my phone all day.

Well, no. If you put in 5% effort to not staring at your phone, you wouldn't have ADD. So, are those three local models on one studio? What's on your second one? Yes.

All three are on my uh Mac Studio 512. My second one has not come in yet. My second one comes in Monday. It was got delayed because I guess everyone's running out buying Mac Studios now because of me. Screw VPS.

Yeah, none of my homies use VPS. Screw VPS. How come you don't stream the chat on screen anymore? Because it's not by default, so I have to like click two buttons. Thanks for reminding me.

Can you remind me more often? I'd put it on if I remembered. I just totally forgot. It doesn't stay on by default. There's no way for me to uh save it.

So, just remind me. Thank you, ambitious realism crates for reminding me. I wish I would have remembered a hour and a half ago. Is it simple to migrate the cloudbot to a new PC device also between Mac and PC? Extremely easy.

Extremely easy. Extremely easy. All open claw is is a bunch of markdown files. That's all it is. That's literally all open claw is is a bunch of markdown files.

Agent.mmarkdown tells uh your agent what the rules are. Soul.markdown tells your agent how to behave, right? Memories. Markdown just all your memories and things to remember. February 11th, 2026.

Markdown is like your memory log from that day. Everything is Markdown. So literally all you need to do to migrate Clawbot between different devices is copy and paste markdown files between the two, right? I originally installed this on a Mac Mini and then I bought the Mac Studio a week later and literally the entire migration was I air dropped the folder from one to the next and then Henry was like, "Oh, hey there. I'm on your Mac Studio now." We are approaching an AI overfitting situation.

It is said that in the next three months, every new code creator will be created by a AI meaning AI is training itself with AI generated data face. I look at that as a positive thing. Self-improving AI. I think it's a very positive thing. That means we're hitting the we're hitting the Alex, you mentioned Open Claw is perfect for oneman business.

But how do you really set it up for a business? Do you mean how do you set up for oneman business or how do you set up for a multi-person business? First thing you do is watch every single one of my YouTube videos. That's step one. Power banks.

Step two is you go to your open claw and say, "Hey, I run a business with 20 people in it, 30 people in it, 40 people in it. This is what we do. How do I set you up to get the most value out of it?" Like, I'm not crapping on you, Power Banks, but like I get this comment so much. It's like crazy. I get this comment so much.

I like show you how to set up things and they're like, "Well, you don't show us what you do with it. Show us the workflows. It doesn't make me any money. Show me." And it's like it's different value for every person. Every person that uses this is going to be doing different things.

I have videos with my workflows in it, but it's impossible. Everyone do these different things. It's like everyone's going to get different value out of it. Like the best thing you can do is follow what I say, get it set up, and then go to it and just ask it like, "How do I get the most value out of you? Here's everything I do.

Here's all my goals. How do I get the most out of you? Hi, Alex. How do you think Agentic AI and blockchain will converge? I think it's pretty obvious.

I think it's pretty obvious how AI and blockchain will converge. Every agent will have its own crypto wallet, right? Every agent will have its own USDC wallet and can go around buying stuff for you. Clearly, crypto is the best way for AI to be spending money. It doesn't make as much sense for an AI to have like a credit card.

It makes much more sense for the AI to have like a programmatic money, which is crypto, where it can just type code and then send money. So, I I mean, I think it's fairly obvious and straightforward. I don't have any hot take around it because I think the kind of standard take is the right take which is all our open claws will have crypto wallets. Now do I think we're going to this future that every degenerate on X is saying we're going to where every agent has its own token. Henry has a Henry token and your thing has its own memecoin and there's a thousand meme coins for every agent.

No, that's stupid. That's just people trying to make money. That's just people trying to make money. I get a hundred replies under every tweet. Claim your fees for your token.

Claim your fees. Free money. Free money. Okay, I'll claim it and get the free money. But I guarantee you after I do that, you're going to be begging me to pump the coin.

You're not doing this to get me free money. You're doing this to pump coin. You're doing this for you to make money, not for me. You don't care about me making money. You only care about you making money.

I don't think we live in a future where meme coins run everything. But you'll have your agent will have its own crypto wallet where it has USDC in it and can just programmatically spend money. Isn't it dangerous to have a Discord bot connected on your OpenClaw prompt injection? Well, no. Don't let other people in your Discord.

Do not let other people in your Discord. Make your own personal server. Do not let other people in the server. Never let anyone interact with your openclaw. Ne don't let anyone interact with your open claw.

Every OpenClaw should be every OpenClaw has admin access to your computer. So, no one else should be accessing your OpenClaw. How do you like the studio? I love it. It's sick.

It's sick. I love it. It's beautiful. It's amazing. Great content, Alex.

More than OpenClaw, what people need to realize is that your secret sauce is your mindset. Stop overthinking and do build, break, fix, and ship. Yeah, I said this at the beginning of the stream, which is like there's just times to rest and there are times to strike with violence. And we just live in a time right now where you have to be striking with violence. You have to be you have to be accelerating as fast as humanly possible.

There is more opportunity than ever before. More opportunity than ever before right now. I mean, people are making so much money overnight. There's so much opportunity. And the only way to take advantage of that opportunity is just to move fast.

Move fast. Make mistakes, break things, fix it, ship it again, do it again. Like, that's the only way. I mean, I'm living proof. I'm living proof.

The last three weeks have been the best three weeks of my entire life from a career perspective. By far the best three weeks of my entire life. Not even close. Not even close. I mean, three weeks ago, this live stream gets like 50 people simultaneous tops.

Three weeks ago, my YouTube's at 60K subs. Three weeks ago, my ex is at 300K uh followers. Three weeks ago, Vibe Coding Academy is at like 50 members. Then what happened? Three weeks ago, I'm not go no one's inviting me on to their podcast.

Then what happened three weeks ago? Three weeks ago, I'm scrolling. I find an article. No, I see a tweet. Someone, oh, just tried out OpenClaw.

This is really sick. No, they said not OpenClaw. Claudebot. The time was called Clawbot. Three weeks ago, someone tweets, oh, tried out Claudebot.

Really sick. Now, what's Claudebot? That sounds interesting. Now, I'm not saying this to show off. I'm saying like take note on this playbook I'm about to give you right here.

This is the sauce. Out of everything I tell you in the last over the last hour and a half, this is going to be the most important thing I tell you. I read that tweet, I immediately search Cloudbot. Immediately search it. Okay, someone mentioned Claudebot.

What the hell is that? Search. Found an article. Open it up. Reddit.

Autonomous AI agent that can do anything for you. I go, "Wow, that is interesting. That is interesting. That is really cool. This is something.

This is something. This is potentially something. I go, I don't want to I don't want to run this on my laptop. I got to put this on its own device. I immediately go on my phone, go on the Apple store on my phone, buy a Mac Mini, order it, head to the Apple store, pick it up.

Within 20 minutes of me reading this article, I I bought a Mac Mini and brought it home. No one else is buying Mac Minis at this time. Install OpenClaw, start using it. Claudebot. Within five minutes of me using this technology on the Mac Mini, within five minutes, I go, "This is the future.

This is the most powerful technology I've ever used in my entire life. This is going to change everything. Everyone will be using this. Everyone on the internet will be using this. Everyone on the internet will be talking about this.

This is going to dramatically shift the trajectory of the species over the next year. I'm not and that's not even me being like hyperbolic. I meant that I immediately after doing this experimenting on the Mac Mini do two things. go back on the app Apple store and order a $10,000 Mac Studio because I'm like, I need the most powerful thing technology. I need the most powerful hardware in the world for this because this is going to take over.

And then I immediately film a video going over why I'm blown away on this by this. That's a Friday. That's three Fridays ago. Film that video, edit it, post it first thing Saturday morning. That Saturday morning changed everything.

That Saturday morning changed everything in my life. It was the most life-changing Saturday in my entire life. The video goes mega viral. Half a million views on YouTube in one day. 5 million views on X.

Explodes my YouTube. Explodes my ex. I get invitations to every podcast on the planet. I get followed by every interesting person on the planet. I get DMs from the most interesting people on the planet.

I get text messages of most interesting people. My live stream goes from 50 concurrent people to over 700 concurrent people. We're at 651 right now. 10xed. My live stream 10xed overnight.

My Vibe Code Academy goes from 50 members to almost 600 members overnight. Again, this is not me gloating. This is the playbook you need to take, which is when you see an opportunity, you need to attack as violently as humanly possible. If I would have discovered Claudebot and then like, "Oh, that's cool." and then waited like a week to buy a Mac Mini and then waited like another week to record a video, then waited another week to like go on a live stream about it, none of this would have happened. I'd be exactly where I was three weeks ago.

Nothing would have changed. But I saw an opportunity and I'm like, I'm going to do whatever it takes to take advantage of this opportunity. I'm going to do whatever it takes. I immediately run out, buy the Mac Mini, then buy the Mac Studio, and then pump out as much content as humanly possible and spend 20 hours a day using the tool, finding new workloads flows, figuring things out, posting what I learn, posting new things, helping other people out, answering almost every DM I can get, doing as much as I and just attacking with as much violence and speed as I possibly can. And my life has dramatically changed because of it.

And I don't think that's a me thing. Sheep core. All right, I'll screenshot this. I'll check it out after. Thanks for the next extra $1,100 turkey turkey bucks.

Thanks for the $1,100 turkey bucks, Marcius. I'll check it out after. I have to read through it first. I don't trust any skills or anything uh until I read through it all. That's the lesson.

When you see an opportunity and you see something you believe in strongly, go as hard as you can. Considering your experience at Open Claw, what are the top mistakes you've learned during your time with it? Not asking enough questions. Not asking it enough questions. What would you do here?

How would you change this? How would you approach this better? If you were to go back, how would you fix this? You did that wrong. How do we prevent that from ever happening again?

Ask way more questions. I don't get this comment. I don't get this comment at all. This comment makes no sense to me. I wonder what spawns people to put these comments.

I get so many of these comments under my content. I really want to understand. Show us something new, Alex. Thumbnails can be created via Gemini. Make us something new.

You complained about the guy that connected Rayban Meta with Clawbot, but you aren't. I sit here for the last hour and a half showing you incredibly incredible automated workflows of my local AI models researching X continuously surfacing viral posts in my niche the moment they arrive writing YouTube scripts. I showed you how good the YouTube scripts were. I show you this incredible automated process. And then you reply, "Show us something interesting and new." I just spent the last hour and a half showing you something interesting and new.

You go to my YouTube, I have 20 videos, five mind-blowing use cases for Claudebot. I show you a thousand different workflows that can change your life. I make a video about amazing workflows. All the comments are, "You don't show how to set it up. You don't show how to set it up.

You show us these workflows, but you don't show us how to set it up. You're faking it." And then I show a video showing how to set everything up. Well, you don't show the workflows. All you're doing is showing people how to set it up, but you don't show what it actually does. You don't show what it actually does.

You're just showing setup. Show us the results. So, I do a video that shows results. Well, you're not showing us how to set up. You're faking it.

You're not showing us how to set up. I am so convinced these types of people, the Diego McFly 2023s of the world, refuse to use their brains. They refuse to use their brains. These are the straw men. 80% of people on the internet are these just like straw men.

You can show workflow after workflow after life-changing workflow and like their brains like, "No, ignore that. Ignore that. Ignore that. Ignore it. Ignore.

I need to find what can I challenge him on? What can I be like? No, no, no, no, no, no, no, no, no. What can I be like? Um, actually, um, actually, how can I find that?

Where is that? Okay, there it is. Okay, show us something different. Show us something different. Like 80% of people on the internet are like that.

80% of like Diego McFly, if you opened up your brain and you saw what I was showing you and then you thought for like five seconds about like, okay, how can I apply this to myself, you would go so much further than trying to cherrypick and straw man every little tiny thing. Oh, well, you didn't show us this. You didn't show us that. Shut up. Open your brain.

I don't need to hold your hand through every single little thing. Like the internet just is just filled with these straw men. Just straw. I' I'd rather someone come in here and troll and like say really like obnoxious dumb stuff. Like who's that guy who keeps purposely spelling my name wrong.

I'd rather a thousand comments of a person purposely spelling my name wrong just to piss me off over someone like this who like their brain just like blocks out things just so they can straw them in and go um actually actually you didn't go over that. I'd rather a thousand people just spell Alex wrong in the chat and spell Finn with one N than one comment of a person going, "Well, you never show us how to set it up." Why don't you show us how to set it up? Literally the worst me comments. How How would you Would you look up my LinkedIn? How'd you know I went to Wentworth?

I didn't say Wentworth on the stream. Would you look at my LinkedIn? I went to Wentworth Institute Technology. Trust me, baby. They didn't they did not have many requirements to get into that school.

[laughter] I lived in Mission Hill as well to go to school. I had a 26 GPA in high school and they were the only schools I was like, "Yeah, bro. Come on in. We got you. Come on in." 2.6.

Good enough. Get in here. Can you tell us about your 300K MR service? Like, how'd you First of all, I don't have a 300K MR service. If I was making 300K a month, you wouldn't be seeing me on this live stream right now, baby.

I'd be on a beach in Mexico sipping a M Thai. Okay, first of all. Second of all, it's 300k ARR, so it's annual, not monthly. Kind of a difference there. Annual, not monthly.

Um, Creator Buddy is my 300K annual recurring revenue service. Um, so I discovered Cursor in August 2024. I discovered Cursor August 2024. Beaches suck. Permes, beaches don't suck.

You suck. Discover Cursor August 2024. start playing around with it. Had Sonnet 35 in it. I'm blown away.

I think it's amazing. I think it's incredible. Sonnet 3. I'm blown away. Cursor with Sonnet 35.

Incredible. So, I start building apps to improve my own life. I had a challenge where I'm reviewing. Why aren't you using DGX Spark? Because I don't own a DJX Spark.

I'm Hey, Nvidia, if you're watching this, I'll take a DJX Spark. I don't have one, though. I just started building apps to improve my own life. At that time, I was reviewing my own tweets every night, what works, what didn't. I was going I had like a spreadsheet of thousands of tweets, thousands of tweets in a spreadsheet.

I was reviewing every single night to see what was work, what worked, what didn't. And uh I decided to build an app that did that for me. I built an app a cursor that reviewed all my tweets automatically. Had an AI give me analysis and suggestions and feedback. And then uh that's Creator Buddy.

And then I released it and I said, "Hey, I built an app where AI reviews all your content, tells you what works and what doesn't, gives you recommendations to improve, tells you how to go viral." And then [&nbsp;__&nbsp;] ton of people like, "Oh, I like that idea. Let me buy it." And then they purchased it. Lesson learned. Use AI. Build things that improve your own life.

solve your own problems and release it. People will buy it. If you have issues you're solving, the odds are someone else has issues to be solved as well. The same issues. Yeah, I've had to rebuild my OpenCloud 3 to five times, but learned a lot.

I can install and explain to everyone now. Hey, Alex, I don't understand how the payment works if I use existing subscription. Yeah, just go through onboarding. do openclaw onboard in your terminal and then choose cad GBT or anthropic and it'll tell you how to use your subscription for it. It guides you through in there.

The best you got from CL this is the same guy. This is the same like this is this is everything wrong on the internet. I can explain how my life dramatically changed over the last three weeks. And Diego McFly 2023's takeaway is well all you got was a bunch of new subscribers. What else change?

That didn't really change your life. You might have explained how now you're going on the biggest podcast in the world, sold a crap ton more products, have a way bigger audience, have way more people watching you and trusting you. But at the end of the day, all that is is YouTube followers, right? I want to ban him so much, but it's like this kind of stuff. Even though I said gratitudes for the underclass, this type of stuff makes me grateful.

I see comments like this and I just go, I am so grateful I am not Diego McFly 2023. I am so glad my brain does not operate like this. I wake up in the morning, I go, "Oh, thank God. My brain does not operate like Diego McFly 2023's brain." If my brain operated like Diego McFly 2023's. That would suck.

I've been gone a few days. What's your latest OpenC achievements? How do you organize his Discord? Good news. I covered all that at the beginning of this.

The moment when this ends, you can rewind and watch it. I went through exactly how to set up and all the cool things it does. Let's say you're not in position financially to purchase a studio, but you have a pretty powerful MacBook Pro. Could I start with MacBook Pro and transfer Studio? 100% dude.

NBA World07. I started on the cheapest Mac Mini there was, and then a week later I transferred it over to Mac Studio. It's all markdown files. So to transfer, all you do is just move the markdown files over. It's super easy to transfer and put your OpenClaw on other devices.

Super easy. Alex, I love you, but you need to sleep. Diego McFly, I love you, too. I might have just absolutely lambasted you in front of the entire audience. Um, but I love you, too.

I might have just absolutely embarrassed and smeared your name and image across this entire audience, but I love you, too. Apple should pay you commission. I spent 3,000 on a Mac Mini. I bought one earlier in the week to test out and immediately ordered an upgrade. You're awesome.

[applause] They should pay me, man. Enough of these VPS's trying to pay me. Apple should be paying me. What the hell? I'm the one I'm the only one here going Apple AI is amazing.

Apple should be paying me out the wazoo. You kidding me? You kidding me? Got a great place for skills agent soul examples and recommendations is XTZ. XTZY.

I would I do not recommend Claude Hub. I do not recommend any of these skills marketplaces. I don't recommend them. Uh they're too easily um they're too easily uh abused. It's too easy for people to put bad stuff into the skills.

This this is super simple. I've had a bunch of people ask me to invest in their skills marketplace. Oh, you want to invest in my skills marketplace? Compromise. That's the word I was looking for.

Thank you. Um, and I I I I turned them all down. Like I just I don't believe in skills marketplaces. I don't you don't need skills marketplaces. You don't need soul file marketplace.

If you want your agent to do something or learn something or be something or whatever, just tell it to learn it. Right. I installed a local image model to create thumbnails. I didn't go on Claude Hub to look for thumbnail generating skills. I said, "Hey, learn how to research how to make thumbnails and then create your own skill for it." And then it create its own skills.

I don't there's no need for me to go on Cloud Hub and download a skill that's potentially compromised that can hack my computer. Any skill you need, any improvement you want to make, any change, just say, "Hey, figure out how to do this and then make a skill about it. Want to write a tweet? Figure out how to write tweets and make a skill about it. Want to make a thumbnail?

Figure out how to make thumbnails and write a skill about how it's self-improving. Just have it write its own skills. You don't you do not need to download other people's skills. What is the hardest mission you have to your open claw? I don't know what that means.

What is the hardest mission you have to your open claw? I don't know. making me chicken wings. I really really want to know some use cases that we actually can leverage by using open. I'm legit thinking of investing into a Mac studio completely maxed out.

Not sure if I should wait, but here's the like another comment I get so much. What are some good use cases for me? Bragmore, I don't know who the hell you are, dude. I have no idea anything about you. I have no idea what your goals are, your objectives are, your missions are, what you like, what you don't like, what you're into, what kind of freaky dicky stuff you're into.

I don't know any of that. So, I can't give you recommendations, my dude. But what you can do, install OpenClaw on the cheapest, crappiest device you have, use it for a little bit, talk to it, figure out what you're into, what you like, and then say, "Okay, based on our workflows, should I get a M5 Mac Studio? There you go. NDA World, thanks for joining, my man.

$5 spazm. So, what's your take on running multiple bots? Would you run separate bots for personal each for business or just one? It depends. If you have if your contexts are wildly different, right?

You have a personal context, maybe you're a freak and you have an AI girlfriend, and then you have another context which is your business and you're helping thousands of people build stuff, right? You probably want those two separate. So maybe you go two separate bots, two separate memory files, right? So it's just something you got to think about. I again I talk to your bot and say, "Hey, you know everything about me.

Would it be better for our relationship if we separated these out? Thank you for the $5 donation." Jason Ha 5530 with the $5 dation. Bro, ignore the haters. Permanent underclass straw men. Thank you for changing my life.

I I like to call out the haters, though. I think calling out the haters, one is fun. Two, it helps other people out to show them like here's everything good you need to do and every good mindset you need to have and here's every bad mindset you want to avoid at all costs. That's why I call out the haters. They say ignore the haters.

Diego McFly. Speaking of haters, come on. What are you explaining? You're do you are doing can be done with personalized GPTs and open A. I saw your videos and your lies.

Nothing new since the first three prompts. All right, now he's trolling. Now I know he's trolling. That's a good troll. Now I know Diego's trolling.

That's I like that. I like that. That's a good troll. That it was all a troll this whole time. I like that.

Thank you, Diego. That's a good troll. Uh NDA World with the 1999 donation. Thank you very much, NDA World. If you're not quite in the financial to buy a studio yet, you could start with the MacBook Pro and transfer.

Yeah, you can get a Raspberry Pi and then transfer things over. It's very easy to transfer. Start small. Dip your toes. Thank you, NDA World, for the 20.

That's very kind of you. Just just Rob Kneasel, thank you for the $4.99. Very kind. Very very kind of you to donate that. Thank you very much, my friend.

That means a lot. That means a lot. Do you have your agents pushing on GitHub, too? Um, it depends. For apps that are not live on the internet yet and have no users, I have them pushing.

So it's just me just maintaining code online. I have it pushing. For apps like Creator Buddy, which are live and have users, I do not let it push. I review the code first, then I push it. I try to be careful, you know.

Love to see everyone getting psychotic. Love you guys. Diego McFly. [applause] He can take the heat and he can stay in the kitchen. I love it.

Diego McFly, shout out you. I've hated almost everything you've said in this live stream, but shout out you. Respect. Respect. I have my agents pushed to a locally stored get instance.

Yeah, that's good. Start slow. I gave my bot all your live streams and it picked out your bot games idea and it went and built me bot royale overnight. You just have to talk to it. That's one of the best things you can do.

is you can take pretty much any piece of content, YouTube videos, articles, tweets, just say just hand it to the OpenClaw and say, "Hey, what can we learn from this?" Every article I see on X about OpenClaw, I don't read it. I copy and paste the article into my OpenClaw. I say, "Hey, what can we learn from this? What can we improve?" 5 seconds, my OpenClaw improves. Not going to lie, I spent 3,000 on Mac Mini.

I've made I've literally made Apple millions of dollars in the last three weeks. Why aren't they paying me? How about Viber? Do you push bots push Viber bug fixes to GitHub? I haven't worked Listen, ambitious realism creates.

Last time I worked on Viber, it was pre-openclaw. Open Claw has changed everything. Open Claw has changed everything. We'll go back to Viber. We'll go back.

But I mean like let's be honest, open claw is the most important thing in the world right now. What do you guys plan to do with your open clause? My plan Sam's Grahams 21 is build the world's first autonomous 247 organization that produces value at all times. That's the mission statement. I have it I have the mission statement right everywhere in my mission control.

You want to see this? I have this all over my mission control so that anytime my open claw does something, it knows what the mission is. Everything is in the name of this mission. Oh, I got to take it off the screen so you can see it. Here we go.

Here you go. The mission, an autonomous organization of AI agents that does work for me and produces value 247. That's what I'm building. Everything I'm building is to achieve that vision because I think if I can achieve that vision, I can give it to you guys and spread it and start a movement. All right, I have a new video dropping in the next two to three hours.

So, make sure notifications on. Really important, everyone. Turn notifications on. The most free way to support the channel is leaving a like down below and then whenever I release a new video, you just open it up and watch it to the end and leave a like on that video. Best free way to support, best payway support, Vibe Code Academy.

I do live boot camps every Friday. You can join, ask me questions, hang out, DM me on there, whatever you want. Vibe Coding Academy link down below. You can get the two last two live boot camps available instantly the moment you sign up. And then my next live boot camp is Friday.

Join that if you want. You don't have to, but you could. You don't have to. Um, and just make sure you experiment. You don't need to buy Mac Studio.

You don't need to buy a Mac Mini. You don't have to. Just experiment. Put it on something cheap. Put on something easy.

Moonshots, when will your interview drop? Uh, haven't recorded yet. I'm going to be on Moonshots. I don't know if people heard. My favorite podcast, Moonshots.

I got invited on. I got invited on Moonshots. I recorded an episode with Peter, the host, um, a few days ago, but I don't think it's like an official Moonshots episode. It's just like a one-on-one conversation where I explain OpenClaw. That's probably coming out soon.

And then like the official Moonshots episode where I am talking to everyone and like I'm on the panel. Uh haven't recorded that yet, but that's getting scheduled now. That will come out very soon. I mean that's again one of the most amazing parts about all this is just like you start doing cool stuff, your heroes start reaching out to you. If you just start doing cool stuff, your heroes start reaching out to you.

It's pretty amazing. So keep doing cool stuff. All right. Experiment. Push the limits.

Move the violence. Accelerate. Go as hard as humanly possible. Holy shush kebab. Here's another $5 since you actually pronounced my name correctly.

Love it. I'm just north of you in Sacramento. Just Rob Kneel. I appreciate you, bud. Thank you.

That's very kind to you. Thanks for joining the live stream. Thanks for being a part of it. That means a lot. Do yourself a favor.

When you discover something cool, when you discover something you're passionate about, when you discover something you love, move as violently as humanly possible.
