# How I use Claude Code to automate my entire life (5 tricks)
# URL: https://youtube.com/watch?v=wfiv67NixCY
# Segments: 402

Everyone knows Claude Code is the best
coding tool in the world. But what if I
told you it has a million use cases
outside of coding that will make your
life significantly better? I use Claude
Code to track my business metrics, to
track my personal goals, to plan content
for me, to analyze all my notes and
thoughts, and so much more. In this
video, I'm going to show you how to do
the exact same thing. By the end of this
video, you'll have every prompt you need
to launch an army of AI agents from
Claude Code that will be running your
entire life. I'm Alex Finn and I use AI
every single day to build and launch
businesses, including Creator Buddy,
which is now a $300,000 a year AI
content tool. Let's get into it.
So, I'm going to show you five use cases
of how I use Claude Code to run my
day-to-day life. But first, I'm going to
show you how to set this up yourself. In
order for Claude Code to effectively do
work for you, it needs to know context
on who you are. So, open up Claude Code
inside a cursor. Create a new folder in
there. I call mine clawed life. You can
call it life OS or whatever you want.
And then create a new markdown file in
there called background on yourself. In
this markdown file, include as much
information about yourself as you
possibly can. Who you are, what your
interests are, links to your content,
links to your side hustles, anything
that's relevant to who you are. This
will be the data that's sent to Claude
when you run any of the use cases I'm
about to show you. For instance, when
you run your weekly check-ins, your
daily journal, your content researcher
and planner, all of this data you put in
this file will be sent to claude to make
it so much more powerful. Once you've
created that file inside of claude code
and cursor, all you need to do is is run
/init in claude code. And what that'll
do is take that information and create a
cla rules file that will set cla code up
for these use cases. So, let's get into
the first use case that is my weekly
check-in. Claude Code automatically runs
a weekly check-in for me where it will
track all my metrics on my business, my
personal life, my career, my side
hustles, everything. And it creates this
incredible personal dashboard that shows
my growth in all my metrics and
everything I'm doing in my life. And
it's all done through Claude Code. So,
what I do is every single Sunday night,
I run slashweekly
check-in. And I'll show you how to set
this up right after. I hit enter. And
now a sub agent is spawned that I built
that will now collect a bunch of metrics
from me and update that dashboard with
all my latest information and metrics.
So what you can see here is it asks me
for all my latest metrics. I just type
it in. It knows dynamically which
metrics are important to me based on the
information I put in that file in that
last step. So I quickly filled in those
metrics it asked for. I hit enter. And
now what it's going to do is take those
metrics and update my personal weekly
dashboard so I can track my growth over
time. So now sub agents are being spun
up and they're going taking my data and
creating that really nice custom
dashboard. And this was all done really
intelligently, right? It went in, saw
all the information about myself, saw
that I had a YouTube, a business, a
Twitter, all of that. Figured out what
metrics would be important for me and
then built that dashboard. And just like
that, it's done. And this was all set up
with a single prompt, which I put down
below in the description. So feel free
to pause, take this if you want, or wait
till after. You grab that prompt, you
put it into claw code after you did the
setup I showed you earlier, and it will
actually build out the slash command
that launches the sub aents as well as
build the sub aents itself that actually
went in and performed this task. What's
amazing is it actually gives you a lot
of other recommendations as well. It
tells you what content ideas you can
build out based on what it knows about
you. It gives you wins of the week, the
fact I hit 30,000 on YouTube, it
celebrates those wins. So, it gives you
a lot of other cool things in here and
tells you when you can even run the next
check-in. It's like having a personal AI
agent that works for me. Again, prompt
to set up this AI agent down below. You
can just feed that into Cloud Code and
you're good to go.
[Music]
The next use case I do is really good
for my mental health. It is basically a
daily journaling AI agent that Claude
Code runs. So, every morning I go into
Claude Code and I'll do SL daily
check-in. This is basically a daily
journaling habit I do every single
night. And what this is going to do is
it it's going to ask me for a bunch of
information. It's going to put into a
personal dashboard. But this dashboard's
different. This dashboard's for habits.
This dashboard's for mental health. This
dashboards for how I'm feeling and what
I accomplish. It's basically an
automated journaling AI agent. So I'm
going to run /aily check-in. This is
basically my journaling agent. I'm going
to hit enter. And now it's going to ask
me a few questions about my day-to-day
life. It will now store in my daily
journaling dashboard. So, as you can
see, good evening, Alex. What did I
accomplish today? How are you feeling
right now? What are your biggest wins
today? I answer these questions. I hit
enter. It sends it to my AI agent and
Claude Code, and that creates my daily
journal entry. So, this is a great way
to have Claude Code work with you, track
the things you're accomplishing in your
life, help you practice a little bit of
gratitude, and just stay on top of your
day-to-day progress. Again, all done
with a single prompt. I set that up and
now all I do every day is just type in
slash daily check-in and I'm good to go.
I put that prompt down below as well.
Feel free to wait till the end if you
want to just copy and paste those
prompts. You can do the step and just
paste each one of those in individually
and you're good to go.
[Music]
So, as you obviously know, I am a
content creator and I actually use
Claude Code to help build all my
content. I have a popular newsletter. It
has 40,000 subs. I actually use Claude
code to do research and all my competing
newsletters and also look at my recent
newsletters to see what does well based
on all that information. It actually
writes me my weekly draft for my
newsletters with one single command.
With one command, it's researching a ton
of other newsletters. It's reading all
my newsletters and based on what's
trending, writes me a newsletter draft
in my own voice. It doesn't have to just
be newsletters. If you do any sort of
content creation at all, you can use
Clawed Code to research all your
competitors and draft content in your
own voice. The setup for this is simple.
Inside of Clawude Code, I just have a
markdown file where I list my newsletter
as well as other newsletters that are in
my niche. And then when I run the
commands I'm about to show you in a
second, it does the research through all
those newsletters and writes me that
draft. So, all I do is type
slashnewsletter
researcher,
hit enter, and now the AI agent's not
only going to read all my competitors
newsletters, it's going to read my own
newsletters and then write a newsletter
draft in my own voice. So, I ran the
command. It then read the newsletters
from all my competitors, went through
their entire content history to see what
trends were going on at the moment. It
saw what they were talking about. It
talked about AI tool adoption, rapid
skill acquisition, pricing, and business
growth. And then it found unique angles
for me based on the newsletters in my
own newsletter, which is incredible. And
the way this can work for you is if
you're a YouTube creator, it can do
similar things or researches competitor
YouTubes. Or if you're a Twitter
creator, it'll look at other Twitter
accounts. And so for me, this helps me
with my newsletter. I write my
newsletter every single Thursday. And I
just quickly run that command every
Thursday. A few minutes later, I have a
draft I can go with. I edit the draft,
hit send, and it's good to go. Claude
Code has been the best content
researcher I've ever had in my life.
With one command, I will never run out
of newsletter ideas again. Again, if you
want to set up your own content
researcher prompt down below, you can
just copy and paste this. Those are
really cool use cases. My next one might
be the most powerful one yet.
[Music]
This next use case I call a brain dump
analyzer, but basically what it is is a
note analyzing tool. I have a folder in
my clawed folder here that has a bunch
of brain dumps I that I do as often as I
possibly can. In these brain dumps, I
just talk about anything going on in my
life, any observations I have, any
interests I have, just things that are
going on in my head. Then what I do on
about a weekly basis is I run this brain
dump analyzer which will go through my
brain dumps and do a basically a mindm
map visualization. You can see here that
takes all my thoughts from that week and
maps it out. Maps out my philosophy, my
identity, my strategies. I can then take
this and just either understand myself
better, pick out different ideas I have
to build other businesses or just create
more content on it. And this is the same
thing you can do. You don't even
necessarily need to do brain dumps. You
can just add all your own notes in here.
So if you're taking notes right now in
notion or in Obsidian, take those notes,
copy them in, and then put them in a
notes or brain dumps folder in your
Claude code OS folder. Then you can run
/brain dump analysis, which again prompt
down below to get that slash command set
up inside of Claude and it will take an
AI agent and analyze your brain dumps or
your notes and build out the same sort
of mind map based on all your notes. And
this is fully customizable too, right?
If you wanted to analyze your notes and
tell you next steps in meetings or
people you have to reach out to, you can
customize the prompt I have down below
to do those exact same things. Claude
Code analyzes all my notes so I get the
best insights out of them. And then I
can come in here and I have in my brain
dumps folder an analysis folder where
Claude automatically puts in all my
analyses so I can see what it thinks
about all my notes. I recommend doing
this based on brain dumps because then
you can get insight really into how your
brain works. But you can use this for
meeting analysis, notes analysis,
whatever you want. Prompt down below.
You just put the prompt in the cloud
code and you're good to go. And you have
that slash command set up. And here's
the one that just ran just now. It goes
through, tells me what type of morning
routine I should do based on my brain
dumps. It tells me what my content
strategy should be based on my brain
dumps. It gives me a weekend challenge.
There's so many cool things that come
out of running this agent.
[Music]
The next one is a super powerful agent I
spin up every single morning that gives
me the rundown on all of my interests.
You're going to like this one. So, the
fifth use case I spin up every single
morning is my daily brief agent. Here's
an example of what the daily brief agent
spins up for me. It goes through all my
interests from that original file I
showed you that you set up inside of
Claude Code and goes on the internet and
does research based on all my interests
for the latest story. So, for instance,
it found the latest tech news. It found
the latest news on YouTube and a whole
bunch of other things going on in the
industries I care about. And now I can
use this and a just know what's going on
in the industry. So, I'm up to date with
everything going on in AI and tech, but
also b this helps me come up with
content, right? I see a news break
overnight from my daily brief agent. I
take that, I do a YouTube video or I
make a tweet or I make a newsletter.
This helps me stay on top of everything
going on with my interest. So, so
instead of having me go online and do
research and have to Google everything
I'm interested in, I just go inside a
clawed code. I do slash daily brief.
Again, prompt for this down below in the
description. So, you can set this up as
well. You hit enter and it goes and
starts running the agent to get your
daily brief. As you can see, it's doing
research online for AI coding tools from
the last 7 days. It's searching for
creator economy updates. It's compiling
and saving my daily brief. So, it's
going online doing a whole bunch of
research for me and saving me a
tremendous amount of time so I don't
have to do this Googling myself. Then it
creates that daily brief for me so I can
quickly understand what's going on, what
happened in the world overnight and stay
on top of all the latest trends. You can
do the exact same thing. You just make
sure your original files have all your
interests in it that we talked about.
Then you run the prompt from down below
that sets up that daily brief agent and
then every morning you go in and you hit
slash daily brief and you're good to go.
Those use cases I just showed you save
me hours every single week. It saves me
hours from having to write content. It
saves me hours from having to do
research on all the topics I'm
interested in. Claude Code just takes
care of all that for me. And as you can
see, none of that involved coding.
Everyone uses Claude Code for coding.
Obviously, I use it to build my app.
Most of the time, I'm using it for
things outside of coding. That's how
powerful Claude Code is. So, if you can
build your own claw code life operating
system like I just showed you here, go
in, you set up your folders with your
notes, you set up your folders with
information about your businesses and
your interests. Then, you take the
prompts from down below to set up all
those different processes like your
daily and weekly check-ins, your daily
brief, and you're good to go. This setup
shouldn't take any more than 10 minutes.
And all of a sudden, you have an entire
AI agent ready to go to work for you to
get you information. And there's so much
more you can do on top of this. You're
not limited just to the use cases I
showed you. If you want to ask questions
to Claude Code about your notes, if you
want to ask anything you want, you can
do it because now Claude Code has all
the context about your life. Really,
really powerful stuff. And all you would
need to do to set up your own agents is
say, "Hey, I want to do a sub agent that
does this task for me. Can you set it
up, Claude Code?" And Claude Code will
build that agent for you. It's really
amazing. All the prompts are down below
to set up all these agents I showed you.
Feel free to take that. I also have a
template that you can fill out for all
your own personal information you could
put inside Claude Code. If you're brand
new to Claude Code, linked somewhere
beside me is a video to my Claude Code
beginners guide. So, make sure to check
that out as well. If you learned
anything, make sure to leave a like.
Make sure to subscribe. All I do is
create incredible videos on AI. Turn on
notifications and I'll see you in the
next