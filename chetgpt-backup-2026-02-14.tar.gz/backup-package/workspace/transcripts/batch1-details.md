# Batch 1 — transcript-specific actionable takeaways (OpenClaw / “ClawdBot”)

> Source transcripts:
> - Qkqe-uRhQJE • Setup guide
> - UTCi_q6iuCM • “10x better” (5 steps)
> - lxfakTpdz1Y • Run for dirt cheap
> - 04wh2Hlgbds • Cheapest/easiest setup (EC2)
> - iGkhfUvRV6o • Opus 4.6 upgrade guide
> - ev4iiGXlnh0 • Major warning: don’t use a VPS

---

## Video: Qkqe-uRhQJE — “ClawdBot is the most powerful AI tool - Setup guide”
URL: https://youtube.com/watch?v=Qkqe-uRhQJE

### Install / environment setup (specific steps mentioned)
- **Install is “one line”**: go to **`claw.bot`** (spelled in transcript as “cl a w.bot”), scroll to **Quick Start**, **copy the one-line command**, paste into Terminal, press **Enter**.
- During onboarding you must acknowledge risk: click/confirm **“Yes, I understand this is very powerful and very risky.”**
- **Choose where to run it (with explicit $ comparisons):**
  - **Mac mini**: speaker bought **base $600** model; says you don’t need more storage/RAM unless you’ll (a) do storage-heavy tasks like video editing, or (b) run **5–6 vibe-coded apps at the same time**.
  - **VPS**: can run on a **virtual private server** (speaker mentions **AWS**; says you can “spin up like a free plan”).
  - **High-end local**: mentions a **Mac Studio** with **512 GB memory** costing **~$10K** to run **local models** (privacy + “unlimited” usage aside from power).

### Security / safety warnings (what NOT to do)
- **Do NOT run on your main computer while you’re still learning**: transcript repeatedly emphasizes **“zero guardrails”**.
  - Concrete examples of what can go wrong: it could send emails from the wrong account, or open iMessage and message friends.
- **Use a separate environment + separate accounts**:
  - Create a **dedicated Gmail** for the bot.
  - Give the bot **its own accounts for everything** (avoid personal accounts) because it can “do anything.”

### Provider/model choices + cost notes (as stated)
- You must pick a **model/provider** during onboarding.
- Cost tiers mentioned:
  - **Claude API**: “most expensive” (speaker says you can spend **thousands of dollars/month**).
  - **Claude Max plan**: **$200/month**.
  - **MiniMax**: speaker claims you can spend **~$10/month**.
  - Mentions using existing **ChatGPT subscription** (no extra cost beyond that subscription).
- Model recommendation logic in this video: choose by **(1) intelligence** and **(2) personality**.
  - “Best overall” (intelligence + personality): **Claude Opus 45**.
  - “Intelligent but robotic personality”: **GPT 5.2** (speaker calls it “Chad GPT 5.2”).
  - “Best cheap option”: **MiniMax** (good enough intelligence + “pretty good” personality).

### Messaging interfaces (specific apps)
- Claudebot/OpenClaw can be interfaced via messaging apps; examples explicitly mentioned:
  - **Telegram** (speaker’s primary)
  - **iMessage**
  - **WhatsApp**
  - **Discord**

### Tools / skills / plugins explicitly named
- Mentions a **skills marketplace** and skills to control:
  - **Apple Notes**
  - **Notion**
  - **Claude Code** (CLI)
  - **Codex** (CLI)
  - **PowerPoint creation**
  - **Things 3** (to-do list)
- Image editing tool named: **“Nano Banana Pro”** (used to edit a YouTube thumbnail).

### Concrete workflows to copy
- **Brain dump to seed memory** (specific interaction detail):
  - In the gateway UI, use **Shift + Enter** to insert new lines.
  - Suggested starter prompt (paraphrased from transcript):
    - “Let’s get to know each other… I’m going to tell you about myself, then ask me any questions you want.”
- **Morning brief (proactive)**:
  - Ask it to set up a **daily morning brief** and include **“ideas for today / tasks you can do for me”** (explicitly called out as critical to make it proactive).
- **Coding automation pipeline (exact workflow described):**
  - Install **Claude Code** or **Codex** on the bot machine.
  - Ask the bot to build features; it can:
    - **write code via Claude Code**,
    - **push to GitHub**,
    - **create a Pull Request**,
    - **send you the PR link** for review.
  - Concrete instruction pattern given:
    - “I logged into GitHub on your computer. Go check my repos… clean up code… build this feature… tackle bugs…”
- **Build a Kanban/task board to manage the bot**:
  - Prompt pattern: “Build a Kanban board that tracks our tasks so I can assign you work and monitor progress.”
- **Dedicated email workflow**:
  - Create a dedicated Gmail; then **forward/CC** emails to the bot with instructions like “respond/schedule/remind/do the tasks mentioned.”
- **“Second brain” file system**:
  - Ask it to create folders/categories (examples used): **ideas**, **inbox**, **research**.
  - Goal stated: replace Notion to avoid paying for it.
- **Overnight build habit**:
  - Nightly prompt the speaker uses: **“Build something cool for me tonight.”**

---

## Video: UTCi_q6iuCM — “How to make ClawdBot 10x better (5 easy steps)”
URL: https://youtube.com/watch?v=UTCi_q6iuCM

### 1) Memory upgrades: two settings OFF by default
- Two memory features named as **off by default**:
  - **Memory flush**
  - **Session memory search**
- Problem described: after automatic **memory compactions**, it may “forget what it said 5 seconds ago.”
- Action to implement (as stated): paste the creator’s **prompt** (provided “down below” in the video description) to enable both.
  - **What Memory flush does (per transcript):** right *before* compaction it records the most important parts so they survive the compaction.
  - **What Session memory search does (per transcript):** lets the bot **search conversation history** when it doesn’t remember something.

### 2) Model routing: “brain” vs “muscles” (explicit model-to-task mapping)
- Core concept: use **Opus 45 as the brain** (conversation + orchestration) but route specialized tasks to better “muscles.”
- Specific recommendations:
  - **Coding muscle:** **Codex (CLI)**
  - **Web search muscle:** **Gemini (API)**
  - **Social/X search muscle:** **Grok (API)**
- Exact instruction pattern to give your bot (quoted structure from transcript):
  - “Moving forward, use **Codex CLI** for all coding. Use the **Gemini API** for all web search. Use the **Grok API** for all social search.”
- Setup flow described: it will ask for **API keys**; you provide them; it configures and remembers.

### 3) “Brain dump” + expectation setting (to trigger proactive behavior)
- Action:
  - Spend ~**10 minutes** telling it your goals, workflow, ambitions, relationships, hobbies.
- Expectation setting (explicit):
  - Tell it you want it to be **proactive** and do work **overnight while you sleep**, so you wake up “surprised” by progress.

### 4) Reverse prompting (exact technique + example prompts)
- Reverse prompting definition: instead of telling it tasks, ask it what it needs / what it should do.
- Example prompts given:
  - “Based on what you know about me and my goals, what tasks can you do to get us closer to our missions?”
  - “What other information can I provide you to improve our productivity?”

### 5) Have it build internal tooling (examples explicitly shown)
- Ask it: “What tooling can we build to improve our productivity?”
- Concrete tools it built (as described):
  - A **task board** with columns: **backlog / working on / reviewed** plus activity history.
  - A **document viewer** to browse “memories and tasks.”
  - Mentions layering more: **project board, memory board, captures, people, CRM**.
- Implementation instruction:
  - After installing **Codex** as coding muscle, ask: “What tools could you build so we can be more productive together?”

---

## Video: lxfakTpdz1Y — “How to run ClawdBot for DIRT CHEAP”
URL: https://youtube.com/watch?v=lxfakTpdz1Y

### Key cost trap + fix: the heartbeat
- Fact in transcript: OpenClaw has a **heartbeat every 10 minutes** that checks for tasks.
- Default behavior: it uses your **brain model** for that heartbeat.
- Cost estimate the speaker claims:
  - If heartbeat uses **Opus 45**: **~$2/day** ⇒ **~$54/month** wasted.
- Actionable fixes:
  1) **Switch heartbeat model to Claude Haiku** (speaker says it’s enough compute for monitoring).
     - Claimed new cost: **~$0.10/day**.
  2) **Increase heartbeat interval** from **every 10 minutes → every hour**.
     - Claimed cost at hourly: **~$0.01/day**.

### Model routing recommendations by use-case (brain + muscles)
- **Brain model**
  - “Best regardless of cost”: **Opus 45**.
  - “Cheapest brain with near-Opus vibe”: **Kimmy K2.5**.
    - Notes: “specials” where you can get **~a month basically free**.
- **Coding**
  - Best (no cost concern): **Codex GPT 5.2 “extra high”** via **CLI**.
    - Instruction pattern: “Use Codex GPT 5.2 extra high whenever you code (via CLI).”
  - Cheapest: **MiniMax 2.1**.
    - Claimed pricing: **~$1/week** (mentions “coding specific plan”).
    - Claimed savings: avoids **~$250/month** “Codex Pro plan on ChatGPT.”
- **Web crawling / browser automation**
  - Best: **Opus 45**.
  - Cheap alternative: **DeepSeek V3** (specifically for “controlling the browser / crawling the web”).
- **Writing content**
  - Best: **Opus 45** (warm personality).
  - Cheap: **Kimmy K2.5** (closest personality among cheaper models).
- **Voice**
  - Recommended voice model: **“Chat GBT40 real time”** (OpenAI **Realtime API**).
  - Action: ask the bot to set it up; you need an **OpenAI platform API key**.
  - Use-case: send/receive **voice notes via Telegram**, and bot can also set up phone-number calling workflow (mentioned).
- **Image understanding (vision)**
  - Best: **Opus 45**.
  - Cheap: **Gemini 2.5 Flash**.

### “Local models = free tokens” hack (hardware mentioned)
- Speaker claims Kimmy K2.5 / MiniMax / DeepSeek can be run as “local models,” and if you have a powerful machine you can run them “completely for free.”
- Hardware purchase mentioned: speaker bought **two Mac Studios** to run **Kimmy K2.5 locally**.

---

## Video: 04wh2Hlgbds — “CHEAPEST and EASIEST way to set up ClawdBot” (Amazon EC2)
URL: https://youtube.com/watch?v=04wh2Hlgbds

### EC2 setup: exact click-path + settings
- AWS Console → search **EC2** → **Launch instance**.
- Name: e.g., **“Claudebot”**.
- AMI: **Ubuntu**.
- Instance type (explicit): **“C7i Flex large”**.
  - Cost guidance given: could be free with minimal use; otherwise **~$15–$25/mo**, “around **$20/mo**” for fair usage.
- Storage: **30 GB**.
- Key pair:
  - Create new key pair (example name: **“claudebot key”**).
  - Type: **RSA**.
  - Format: **PEM** for **Mac/Linux**, **PPK** for **Windows**.
  - Warning in transcript: **do not lose** the downloaded key file (“your password”).
- Network settings:
  - Ensure **Create security group** is checked.
  - Ensure **Allow SSH traffic** is checked.
  - Add inbound rule:
    - Type: **Custom TCP**
    - Port: **18789**
    - Source: **Anywhere**

### Installing OpenClaw on EC2 (as described)
- After launch: EC2 instance → **Connect** → open the **browser console**.
- Go to Claudebot docs, **copy install command**, paste into the EC2 console, hit **Enter**.

### Choosing provider + getting keys (explicit steps)
- If you already pay for **Claude Max** or **ChatGPT subscription**, the creator says using that is the “cheapest” (via **OAuth** flow).
- If you need an API key:
  - Go to **platform.openai.com** → **Dashboard** → **API keys** → **Create new key**.
  - Paste into onboarding when prompted.
  - Model choice recommended here: **GPT 5.2** (“best balance of cost to intelligence”).
  - Reminder: add a **credit card** to your OpenAI API account so usage can be billed.
- Mentions **MiniAX**:
  - Calls it “absolute cheapest” and “recommended by Peter Steinberger,” but also claims it’s **unreliable** and “personality meh.”
  - For “reliability + cost,” he recommends **ChatGPT API** over MiniAX.

### Channel setup recommendations
- Choose a messaging channel; creator recommends **Telegram** or **WhatsApp** as easiest.

### First workflows to run (prompts / schedules)
- **Brain dump** (repeat): provide as much personal/work context as possible.
- **Morning brief prompt (given explicitly in transcript):**
  - “I want to create a morning brief that you text me every day. Please let me know any news going on in the world that is relevant to me, the weather in Mountain View (or wherever you are), and tasks you can do today that will be helpful… and tasks I should do that will advance my career.”
- **Connector-driven automations** (important caveat for EC2):
  - Because it’s in the cloud, it needs **connectors/plugins** for things like Gmail/Twitter/LinkedIn.
  - Example request: “Monitor my email and send me a summary at the end of every day.”
  - Flow: it will ask what service (e.g., Gmail) and walk you through providing credentials/API keys.
- **Interview prompt to discover “unknown unknowns” (given explicitly):**
  - “Based on what you know about me, what are five workflows and tasks you can do for me every day (including connectors/skills we don’t have yet)?”
- **Scheduling (explicit capability):**
  - After selecting a workflow, tell it: “Do this task every day at [time], then text me about it.”

---

## Video: iGkhfUvRV6o — “Claude Opus 4.6 MASSIVE upgrade for ClawdBot (full guide)”
URL: https://youtube.com/watch?v=iGkhfUvRV6o

### Claimed Opus 4.6 feature deltas that directly change workflows
- **Context window:** **1,000,000 tokens** (speaker claims: fewer compactions → better memory inside OpenClaw sessions).
- **Max output:** **128,000 tokens** (bigger one-shot tasks).
- **Agent teams / agent swarms:** model better at spinning up multiple agents.
- Speaker claims: **same price** as prior Opus (no increase).

### OpenClaw/Claudebot: workaround to use Opus 4.6 when not officially supported
- Transcript claim: Opus 4.6 “isn’t automatically supported… needs a config upgrade.”
- Workaround approach described:
  - Paste a provided **prompt** (in the video description) that makes the bot **research the model** and **edit its own config** to add Opus 4.6.
  - Warning: when OpenClaw releases official support and you upgrade, it may **overwrite** these changes.

### Reverse prompt specifically for Opus 4.6 (given explicitly)
- “Now that we are on Claude Opus 46, based on what you know about me and the workflows we’ve done in the past, how can you take advantage of its new functionality to perform new workflows?”

### Claude Code: concrete commands/settings (effort levels)
- In Claude Code:
  - Run **`/model`**.
  - With Opus selected, use **left/right arrow keys** to change **effort**:
    - **low / medium / high**.
- Plan-based recommendations given:
  - **$200 plan:** keep **High effort** by default.
  - **$100 plan:** use **Medium effort**.
  - **$20 plan:** use **Low effort**.
- Cost-control hack: switch to **low effort** for trivial changes (“changing colors of buttons”).

### Claude Code: enable “agent teams” (disabled by default)
- Transcript says agent teams must be enabled and Claude Code can do it by editing settings.
- The speaker’s enablement flow:
  - Prompt Claude Code to **read docs** and enable agent teams; then confirm **“Yes, enable that for us.”**
  - Claude Code edits a **settings file**.
  - **Restart Claude Code** to apply.

### How to actually invoke agent teams (exact phrasing)
- Include: **“Please use an agent team…”** at the start of your task.
- Example from transcript:
  - “Please use an agent team to create a new project management app for us using NextJS…”

### Operating the agent-team UI (specific keybindings)
- **Ctrl + O**: expand to see agents.
- **Shift + Up/Down**: switch which agent you’re chatting with (team lead vs individual agents).
- Each agent requests its own permissions; you must approve.

---

## Video: ev4iiGXlnh0 — “DO NOT use a VPS for OpenClaw (major warning)”
URL: https://youtube.com/watch?v=ev4iiGXlnh0

### Major warnings: why NOT to run OpenClaw on a VPS (specific claims)
- The creator claims most VPS-recommendation videos are **sponsored**; says creators are being paid **“high five figures”** (mentions **~$30,000** sponsorship).
- VPS downsides called out:
  - **Harder to set up than local** (even “one-click” installs).
  - **Insecure by default**: claims people are scanning the internet and finding “thousands” of exposed EC2/VPS instances; risk of credential/token theft.
  - Requires “highly technical” security work: **firewalls, SSH, etc.**
  - Worse integration and visibility: can’t easily use **AirDrop**, can’t easily watch the agent locally.

### Recommended alternatives (specific hardware + costs)
- Use a **local device**:
  - **Mac mini** (repeats **$600** value claim)
  - **Mac Studio** (he mentions buying **two $10,000 Mac Studios** to run local models)
  - **Old laptop/PC** (“dusty old Lenovo”)
  - **Raspberry Pi (~$75)**

### Local security best practice (explicit “do this”)
- If using an old device: **wipe it first** so there’s no insecure software/accounts.

### Local install: one-command setup (specific source)
- Go to **openclaw.ai** → copy the install command → paste into Terminal (Mac) / Command line (Windows) → Enter.

### Anthropic $200 plan token workflow (concrete steps)
- Provider selection: choose **Anthropic** and then **Anthropic token**.
- In the menu select: **“Run Claude setup token elsewhere.”**
- Then:
  1) copy the **Claude setup token** command,
  2) run it in **another terminal**,
  3) log into the Anthropic subscription,
  4) it outputs a long token string.
- Important formatting trick (explicit):
  - Copy token into **Notepad** first to remove **line breaks**, then paste the single-line token back into onboarding.

### Cheaper provider option mentioned
- Recommends **Kimmy K2.5** via **Moonshot**.
  - Claims plans as low as **~$5/month**.
  - Mentions a possible **NVIDIA** promotion: search “**Nvidia Kimmy K2.5**” for potential free subscription period.

### Messaging recommendation (and why)
- Strong recommendation: **Telegram**.
- Reason given: more customization features like **threading** and **chunking**.
- Setup detail: create a **Telegram bot** during the onboarding walkthrough.
