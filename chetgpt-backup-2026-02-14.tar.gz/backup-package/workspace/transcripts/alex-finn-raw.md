# Alex Finn - ClawdBot / OpenClaw / Claude AI Videos
## Complete Raw Data Collection

**Collection Date:** February 12, 2026
**Source:** YouTube Channel @AlexFinnOfficial
**Channel URL:** https://www.youtube.com/@AlexFinnOfficial
**Total Videos:** 198
**Subscribers:** 111K
**Channel Description:** "The number 1 vibe coding channel on Youtube. I'll teach you how to use Claude Code, Codex, and AI even if you've never used them before!"

---

## CLAWDBOT / OPENCLAW VIDEOS

### 1. MAIN SETUP VIDEO
**Title:** ClawdBot is the most powerful AI tool I've ever used in my life. Here's how to set it up
**URL:** https://www.youtube.com/watch?v=Qkqe-uRhQJE
**Duration:** 27 minutes 45 seconds
**Views:** 652,067 (2 weeks ago)
**Description:** ClawdBot is a 24/7 AI agent employee and it is the most powerful technology I've ever used. Here's how it works and how to set it up

**Chapters:**
- 0:00 Intro
- 0:59 What is ClawdBot
- 5:42 Do you need a Mac Mini
- 11:13 Installing ClawdBot
- 16:41 Using ClawdBot
- 23:52 Why I'm scared

**Links in Description:**
- Vibe Coding Academy: vibecodingacademy.dev
- Newsletter: https://www.alexfinn.ai/subscribe
- Twitter: https://x.com/AlexFinn
- CreatorBuddy: https://www.creatorbuddy.io/
- ClawdBot: http://clawd.bot/

---

### 2. CHEAPEST SETUP
**Title:** This is the CHEAPEST and EASIEST way to set up ClawdBot
**URL:** https://www.youtube.com/watch?v=04wh2Hlgbds
**Duration:** 15 minutes
**Views:** 99K (2 weeks ago)
**Description:** ClawdBot is a 24/7 AI agent employee and it is the most powerful technology I've ever used. Here's how to set it up cheap and easy.

**Chapters:**
- Intro
- Why not Mac Mini
- Setting up Amazon EC2
- Deploying ClawdBot
- Choosing a model
- Setting up ClawdBot
- ClawdBot use cases and tips

---

### 3. IMPROVE PERFORMANCE
**Title:** How to make ClawdBot 10x better (5 easy steps)
**URL:** https://www.youtube.com/watch?v=UTCi_q6iuCM
**Duration:** 10 minutes 23 seconds
**Views:** 77K (11 days ago)
**Description:** ClawdBot is a 24/7 AI agent employee and it is the most powerful technology I've ever used. Here are 5 steps to making it way smarter.

**Chapters:**
- Intro
- Improving memory
- Use the right models
- Set expectations with Clawd
- Reverse prompting
- Create your own tooling

---

### 4. RUN CHEAP
**Title:** How to run ClawdBot for DIRT CHEAP
**URL:** https://www.youtube.com/watch?v=lxfakTpdz1Y
**Duration:** 12 minutes 18 seconds
**Views:** 62K (9 days ago)
**Description:** ClawdBot (OpenClaw) is a 24/7 AI agent employee and it is the most powerful technology I've ever used. Here is how to save TONS of money using it.

**Chapters:**
- Intro
- Brain
- Heartbeat
- Coding
- Web Search
- Content
- Voice
- Image understanding

---

### 5. MAC MINI REQUIREMENT
**Title:** You NEED a Mac Mini for ClawdBot
**URL:** https://www.youtube.com/watch?v=tqhmgHfT7v4
**Duration:** 15 minutes 19 seconds
**Views:** 46K (7 days ago)
**Description:** ClawdBot (OpenClaw) is a 24/7 AI agent employee and it is the most powerful technology I've ever used. Here are all the ways to set it up.

**Chapters:**
- Intro
- The options
- Mac Mini vs VPS
- One click launch services
- Old computer in your closet
- Mac Studio

---

### 6. USE CASES
**Title:** 5 insane ClawdBot uses cases you need to do immediately
**URL:** https://www.youtube.com/watch?v=b-l9sGh1-UY
**Duration:** 13 minutes 3 seconds
**Views:** 66K (2 weeks ago)
**Description:** ClawdBot is a 24/7 AI agent employee and it is the most powerful technology I've ever used. Here's how to get the most out of it.

**Chapters:**
- Intro
- Morning Report
- Proactive Coder
- 2nd brain
- Daily research report
- Last30Days Research
- Outro

---

### 7. VPS WARNING
**Title:** You're being lied to: do NOT use a VPS for OpenClaw
**URL:** https://www.youtube.com/watch?v=ev4iiGXlnh0
**Duration:** 17 minutes 6 seconds
**Views:** 8.1K (11 hours ago)
**New Video**

---

### 8. MAC STUDIO
**Title:** This is what OpenClaw running on a $10,000 Mac Studio is like...
**URL:** https://www.youtube.com/watch?v=2KWhHY0KTMk
**Duration:** 19 minutes 15 seconds
**Views:** 42K (2 days ago)
**Description:** Claude Opus 4.6 just release and it's incredible. Here's all the improvements plus how to use it in ClawdBot and Claude Code.

**Chapters:**
- Intro
- What we cover
- Why you should use local models
- What I built with OpenClaw
- Local model use cases
- Local models you can run

---

### 9. CLAUDE OPUS 4.6 UPGRADE
**Title:** Claude Opus 4.6 is a MASSIVE upgrade for ClawdBot and Claude Code (full guide)
**URL:** https://www.youtube.com/watch?v=iGkhfUvRV6o
**Duration:** 17 minutes
**Views:** 49K (6 days ago)
**Description:** Claude Opus 4.6 just release and it's incredible. Here's all the improvements plus how to use it in ClawdBot and Claude Code.

---

## LIVE STREAMS & SPECIAL VIDEOS

### 10. LIVE: The ULTIMATE OpenClaw setup
**Title:** LIVE: The ULTIMATE OpenClaw setup
**URL:** https://www.youtube.com/watch?v=0v2-mUUWNdc
**Duration:** 1 hour 58 minutes
**Views:** 9.6K (15 hours ago)
**Summary:** Alex Finn's ultimate OpenClaw setup uses Discord for automated business workflows. Learn how AI agents research trends, write scripts, and generate thumbnails locally, saving on API costs.

---

### 11. LIVE: Running ClawdBot on a $10,000 Mac Studio
**Title:** LIVE: Running ClawdBot on a $10,000 Mac Studio
**URL:** https://www.youtube.com/watch?v=SGEaHsul_y4
**Duration:** 1 hour 54 minutes
**Views:** 23K (5 days ago)
**Summary:** Running ClawdBot on a $10,000 Mac Studio shows a creator building a fully autonomous AI organization. This live stream features a unique organizational chart and domain registration. Learn about local model implementation and potential benefits, including cost savings.

---

### 12. LIVE: Building INCREDIBLE apps with ClawdBot
**Title:** LIVE: Building INCREDIBLE apps with my ClawdBot (Sonnet 5???)
**URL:** https://www.youtube.com/watch?v=UpM2H83MJO8
**Duration:** 1 hour 58 minutes
**Views:** 15K (7 days ago)
**Summary:** Build incredible apps with ClawdBot, plus learn about Sonnet 5! Alex Finn demonstrates amazing ClawdBot creations and guides viewers through setup. This live stream also features a new setup and addresses audience questions about ClawdBot's capabilities and costs.

---

### 13. LIVE: Building apps with ClawdBot
**Title:** Building apps LIVE with my 24/7 AI employee Clawdbot
**URL:** https://www.youtube.com/watch?v=XkpskYqB5v4
**Duration:** 1 hour 54 minutes
**Views:** 13K (2 weeks ago)
**Summary:** Alex Finn builds apps live with Clawdbot, a 24/7 AI employee. This live stream showcases Clawdbot's capabilities, from managing GitHub repos to creating pull requests. Viewers witness real-time app development and integration with various services.

---

### 14. LIVE: Using ClawdBot to ship a startup
**Title:** LIVE: Using ClawdBot to ship a FULL startup
**URL:** https://www.youtube.com/watch?v=JxTLn_dQGSM
**Duration:** 1 hour 52 minutes
**Views:** 16K (9 days ago)
**Summary:** Using ClawdBot to ship a full startup live. Alex Finn demonstrates building a complete social ClawdBot app and discusses new use cases, including cost savings with Sonnet 5. This includes a multiplayer ClawdBot game launching live during the stream!

---

### 15. LIVE: Showing ClawdBot use cases
**Title:** LIVE: Showing AMAZING ClawdBot/OpenClaw use cases
**URL:** https://www.youtube.com/watch?v=-5ym_hGHp0U
**Duration:** 1 hour 52 minutes
**Views:** 20K (12 days ago)
**Summary:** Alex Finn's live stream explores ClawdBot's incredible capabilities, including setting up a voice and making phone calls. The video also delves into using Telegram and Discord for communication, and discusses a new social media site for AI agents. Learn about advanced use cases and workflow tips.

---

## CLAUDE CODE VIDEOS

### 16. $500K WITH CLAUDE CODE
**Title:** How I made $500,000 with Claude Code (and how you can too)
**URL:** https://www.youtube.com/watch?v=TLBZ6sCkqaU
**Duration:** 20 minutes
**Views:** 25K (2 weeks ago)

---

### 17. CLAUDE COWORK
**Title:** Claude Cowork is the best AI tool of 2026. Here's how to use it.
**URL:** https://www.youtube.com/watch?v=rdURhrS4xHI
**Duration:** 13 minutes 33 seconds
**Views:** 30K (3 weeks ago)

---

### 18. CLAUDE COWORK BEGINNER
**Title:** Claude Cowork: from beginner to expert in 18 minutes
**URL:** https://www.youtube.com/watch?v=Bwqy0lsEaEg
**Duration:** 18 minutes
**Views:** 61K (4 weeks ago)

---

### 19. BEST WORKFLOW
**Title:** The greatest Claude Code workflow ever (10x your speed)
**URL:** https://www.youtube.com/watch?v=WdD6uD_kupY
**Duration:** 17 minutes
**Views:** 32K (4 weeks ago)

---

### 20. RALPH WIGGUM PLUGIN
**Title:** The Ralph Wiggum plugin makes Claude Code 100x more powerful (WOW!)
**URL:** https://www.youtube.com/watch?v=uJUVUL8U7b4
**Duration:** 9 minutes 59 seconds
**Views:** 51K (1 month ago)

---

### 21. CREATOR'S WORKFLOW
**Title:** The creator of Claude Code just revealed his INSANE workflow (must watch)
**URL:** https://www.youtube.com/watch?v=AkG-BZ-708U
**Duration:** 11 minutes
**Views:** 58K (1 month ago)

---

### 22. PROMPTING WRONG
**Title:** You're prompting Claude Code wrong. Here's how to do it correctly...
**URL:** https://www.youtube.com/watch?v=7WuKgc3-_-s
**Duration:** 14 minutes 42 seconds
**Views:** 19K (1 month ago)

---

### 23. USING IT WRONG
**Title:** I was using Claude Code wrong... then I discovered this
**URL:** https://www.youtube.com/watch?v=hD_CLUic4jE
**Duration:** 13 minutes
**Views:** 31K (1 month ago)

---

### 24. SKILLS
**Title:** Claude Code Skills are INSANE (and you're not using them correctly)
**URL:** https://www.youtube.com/watch?v=thxXGxYIwUI
**Duration:** 17 minutes
**Views:** 32K (1 month ago)

---

### 25. MAJOR UPDATE
**Title:** Claude Code just had a MAJOR update. Here's how to use it.
**URL:** https://www.youtube.com/watch?v=Cb49pGTSigI
**Duration:** 14 minutes 27 seconds
**Views:** 36K (1 month ago)

---

### 26. COMPLETE GUIDE
**Title:** The only Claude Code guide you'll ever need (Opus 4.5)
**URL:** https://www.youtube.com/watch?v=UVJXh57MgI0
**Duration:** 24 minutes
**Views:** 93K (1 month ago)

---

### 27. 9 MONTHS LESSONS
**Title:** 9 months of Claude Code Lessons in 19 minutes
**URL:** https://www.youtube.com/watch?v=wxFt2d7xN44
**Duration:** 19 minutes
**Views:** 37K (2 months ago)

---

### 28. DESKTOP VERSION
**Title:** Claude Code for Desktop is the BEST way to build apps with AI EVER
**URL:** https://www.youtube.com/watch?v=pZ2N7CJFbBk
**Duration:** 14 minutes 3 seconds
**Views:** 94K (2 months ago)

---

### 29. IOS APPS
**Title:** The EASIEST way to build iOS apps with Claude Code (Opus 4.5)
**URL:** https://www.youtube.com/watch?v=-ldzZ6D5cwY
**Duration:** 18 minutes
**Views:** 28K (2 months ago)

---

## ALEX FINN EXTERNAL LINKS

**Newsletter:** https://www.alexfinn.ai/subscribe
- "Ship/It Weekly - AI, made simple"
- Over 39,000 subscribers

**Twitter:** https://x.com/AlexFinn

**CreatorBuddy:** https://www.creatorbuddy.io/ ($300k/yr AI app)

**Vibe Coding Academy:** vibecodingacademy.dev

---

## KEY CONCEPTS & TERMINOLOGY

**ClawdBot / OpenClaw:**
- 24/7 AI agent employee
- Proactive AI worker
- Can research trends and build features automatically
- Creates pull requests on GitHub
- Manages domain registration
- Builds organizational charts
- Voice and phone call capabilities
- Telegram and Discord integration
- Local model support
- Cost savings with proper setup

**Hardware Options:**
- Mac Mini (recommended for most users)
- Mac Studio (high-end option)
- Local servers
- VPS (not recommended per Alex)
- Old computers repurposed

**Key Features:**
- Morning Brief workflow
- Proactive Coder
- 2nd Brain
- Daily research reports
- Skills system
- MCP (Model Context Protocol)
- Claude Opus 4.5/4.6
- Sonnet 5 (upcoming)
- Voice integration
- Image understanding

**Cost Control:**
- Local models vs API calls
- Amazon EC2 setup
- Choosing appropriate models
- Memory management
- Token usage optimization

---

## RELATED VIDEOS FROM OTHER CREATORS

### Greg Isenberg
**Title:** Clawdbot/OpenClaw Clearly Explained (and how to use it)
**URL:** https://www.youtube.com/watch?v=U8kXfk8enrY
**Duration:** 35 minutes 14 seconds
**Views:** 259K (2 weeks ago)

**Chapters:**
- Intro
- Clawdbot Overview
- The Morning Brief Workflow
- Proactive Builds: Trends → Features → Pull Requests
- The Setup: Context + Expectations For Proactivity
- The Onboarding Prompt Alex Uses
- Hunting "Unknown Unknowns" For Real Leverage
- Using the right Models for cost control
- Mission Control: A Kanban Tracker Henry Built
- The future of Human and AI workflow
- Hardware And Hosting: Cloud vs Local (Mac Mini/Studio)
- The Productivity Framework
- The Possible Evolution of Clawdbot
- Security and Privacy Concerns
- Closing Thoughts: Tinkering, Opportunity, And Next Steps

---

### Matthew Berman
**Title:** I Played with Clawdbot all Weekend - it's insane.
**URL:** https://www.youtube.com/watch?v=MUDvwqJWWIw
**Duration:** 21 minutes
**Views:** 365K (2 weeks ago)

---

### Tech With Tim
**Title:** ClawdBot Full Tutorial for Beginners: SECURE Setup Guide
**URL:** https://www.youtube.com/watch?v=tnsrnsy_Lus
**Duration:** 50 minutes 4 seconds
**Views:** 81K (4 days ago)

---

### Peter Yang
**Title:** How OpenClaw's Creator Uses AI to Run His Life in 40 Minutes
**URL:** https://www.youtube.com/watch?v=AcwK1Uuwc0U
**Duration:** 37 minutes 44 seconds
**Views:** 222K (10 days ago)

---

### Nate B Jones
**Title:** Clawdbot to Moltbot to OpenClaw: The 72 Hours That Broke Everything
**URL:** https://www.youtube.com/watch?v=p9acrso71KU
**Duration:** 22 minutes 2 seconds
**Views:** 245K (9 days ago)

---

### Y Combinator
**Title:** OpenClaw Creator: Why 80% Of Apps Will Disappear
**URL:** https://www.youtube.com/watch?v=4uzGDAoNOZc
**Duration:** 22 minutes 36 seconds
**Views:** 402K (4 days ago)

---

### Lex Fridman
**Title:** OpenClaw: The Viral AI Agent that Broke the Internet - Peter Steinberger
**URL:** https://www.youtube.com/watch?v=YFjfBk8HI5o
**Duration:** 3 hours 15 minutes 52 seconds
**Views:** 68K (9 hours ago)

---

## COLLECTION NOTES

All videos collected from:
1. YouTube search for "Alex Finn ClawdBot"
2. Direct channel navigation: https://www.youtube.com/@AlexFinnOfficial/videos
3. Related video suggestions

Videos span from December 2025 to February 2026, showing rapid evolution of ClawdBot/OpenClaw technology.

Last updated: February 12, 2026
