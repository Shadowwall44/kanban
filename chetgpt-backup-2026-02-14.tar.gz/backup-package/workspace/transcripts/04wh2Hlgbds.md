# CHEAPEST and EASIEST way to set up ClawdBot
# URL: https://youtube.com/watch?v=04wh2Hlgbds
# Segments: 452

bot is the most important technology you
should be using in 2026. It's literally
an AI employee that works for you 24/7,
365, and it is changing many people's
lives, including my own. The issue is it
is incredibly difficult and expensive to
set up if you do not know what you're
doing. In this video, I'll go through a
way of setting up CloudBot that's so
simple and so cheap, it'll save you a
ton of money and time, and anyone will
be able to do it. I'll also go over the
first few workflows you should use with
Claudebot. Whether you've never used
Claudebot before or you're Claudebot
pro, you have a ton to learn from this
video. Let's lock in and get into it.
So, everyone is going out and buying Mac
minis to use for Cloudbot. It's what I
did. I actually just returned my Mac
Mini to buy a Mac Studio. But that's not
the only way to run Claudebot. There are
significantly cheaper ways, especially
if you want to a save money or b just
dip your toes and see if Claudebot is
for you because this is a brand new
radical technology. If you are one of
those people where you're just trying to
save time, you don't want to buy a new
computer or you just want to save a
little money, this is the right way to
do it. We are going to be able to host
our Cloudbot on the internet. So, we do
not need to buy any hardware. I'm going
to put the link down for this below. You
can do this alongside with me if you
want to, or you can watch this, then go
out and do it right after. So, we are
going to get Claudebot up and running on
Amazon EC2. Amazon EC2 is a virtual
server where we'll be able to install
Claudebot, then have it run 247 for us,
doing work, being our employee. This
might look a little technical, but I
promise if you stick with me, I'll make
this as easy as possible for you. Anyone
should be able to set this up. So, go to
the link I have down below for Amazon
EC2. Create an account here. Once you
signed in or created your account,
search for EC2 at the top, virtual
servers in the cloud. We're going to
click on that. We're going to go down
here. We're going to click launch
instance. Once we do that, we're going
to name our server. We can name it
Claudebot. Let's choose Ubuntu for this.
This is a Linux server we'll be
creating. So, click on Ubuntu. Next,
we're going to want to choose our tier.
So, click the drop down here. Choose
Flex Large. If we use little enough
memory here, this could end up being
free, but if you use this enough, this
could go up to 15, 20, $25 a month.
Obviously, it's flexible. So, if you're
just pounding this, it could be more,
but this should cost you around $20 a
month if you use this a fair amount. So
that's C7i Flex large. Make sure that is
selected. And then we are going to click
on launch instance. Scroll down a little
bit more. We're going to do 30 gigabytes
of storage. This is going to allow us to
store a good amount on this server. And
then we're going to go over here and
click launch instance. Scrolling down a
little bit more. We want to go to key
pair. Let's create a new key pair here.
Give your key pair a name. You can name
this whatever you want. I named it
claudebot key. Make sure RSA is
selected. Use PM if you are using Mac or
Linux. Use PPK if you're on Windows. And
then you're going to click create key
pair. That is going to download a file.
That's basically your security file. So
do not lose that. Keep that safe on your
computer. That's going to basically have
your password for connecting to this
server. Let's go down to network
settings. You want to make sure create
security group is checked here. You want
to make sure allow SSH traffic is
checked as well. You're going to want to
click edit up here at the top right.
From here, you want to scroll down,
click add security group RO here. Make
sure it is custom TCP. Port range, we're
going to put in 18789 right there.
Source type is going to be anywhere.
Once you do all of that, you are ready
to go. You can click launch instance
from here. Boom. It has launched. Just
like that, we are good to go. Now, we
can install Clawbot on here. From here,
we're going to go to view all instances.
There's our instance. From here, all
you're going to want to do is click on
this instance ID. You're going to want
to click on connect right here and then
click connect in the bottom right. right
here. This is going to open up our
console inside Amazon EC2 where we are
going to actually deploy CloudBot. From
here, we're going to go to Claudebot
docs. We're going to copy this command
right here. We're going to paste that in
right here. And we're going to hit
enter. And it is going to start
installing Claudebot on the web. In just
a second, you're going to have a 247
employee working for you. This is so
sick. And I know those last couple steps
might have got a little confusing at
times, but I hope I got you through it
clearly. If you messed anything up, feel
free to go back and watch that step by
step again. But this is the simplest way
to do it without having to buy a brand
new Mac. All right, so that is good to
go. Let's start set up. I'll walk you
through setup here. Then I'll give you a
few awesome workflows we can use here.
Got to make sure we understand the risk.
We're going to go with the quick start
onboarding mode. Now, we're going to
choose our model off provider. There are
a few ways to do this. The point of this
video is showing you the absolute
cheapest way to use Claudebot. If you're
already paying for either Claude Max or
a Chat GBT subscription, the cheapest
way to do this will be to use those
already existing subscriptions. So, what
you would do is you would choose one of
those two here and then it will give you
the option for OOTH, which will
basically give you a command. This
command will reveal a key that you're
going to want to put in here. So, take
that command and put it into your
terminal if you're doing the OOTH. when
you put in your own terminal on your own
computer, it will give you that OOTH key
that you can put in. Now, let's say
you're not already on an anthropic or
open AI subscription plan. You're going
to need your own subscription plan. You
have a few options here. So, the
absolute cheapest way to do this will be
using a model called Miniax. MiniAX is a
cheap AI model. It is very inexpensive
to use. It's actually one that's
recommended by the creator of Claudebot,
Peter Steinberger. The issue is it is
just not nearly as intelligent or
personable as Claude Opus. It is still
very intelligent. The personality is
kind of meh, but Opus is the greatest AI
model created of all time. So, you have
that option, right? You can sign up for
Claude Max, which is going to cost you
$200 a month. You can sign up for chat
GPT, which is going to cost you $20 a
month and it's still going to be very
intelligent. The personality is just
going to stink. But if you want the
absolute cheapest way to do this, you
want to sign up for Miniax. From a cost
to results basis, I actually think going
with a chat GPT API is going to be
better here. Miniax, from what I'm
hearing, is very unreliable. So for
reliability and cost, I think the best
balance you're going to get is Chat GPT.
If you want the absolute best
performance on planet Earth and you're
willing to spend more, you go with
Claude Opus. But the point of this video
is doing this the cheapest way possible.
So, let's get the chat GPT API key if
you haven't already logged in with chat
GPT or anthropic already. So, if you go
to platform.opai.com
and feel free to skip to the next
chapter if you've already done this. You
can go to dashboard then you can go API
keys and then you can create a new key.
I name it Claude. I'm going to click
create. Then you can come in here and
you can say OpenAI. We're going to do
OpenAI API key. From here, we can choose
a model. I'm going to go with GPT 5.2. I
think that'll give us the best balance
of cost to intelligence. So, I'm going
to hit enter on that. Next, you can set
up your channel. I use Telegram, but you
can use WhatsApp, Discord. You can use
any of these you want. I'd probably
recommend WhatsApp or Telegram. Those
are two are probably the easiest to set
up out of this, but this is where you're
going to be interfacing with your bot.
So, feel free to choose one of those.
This will allow you to text message your
247 agent anytime you want. You can
configure the skills if you want. I'm
not going to configure them right now.
As for hooks, I'm going to skip that as
well for now. And you are good to go.
Let us hatch our friend. So, I'm going
to hatch in the TUI, which is your
terminal user interface here. Also, by
the way, side note, make sure you have
your credit card into the chat GBT API
section just so it can charge you as you
use tokens if you haven't done that
already. All right, so here's the
onboarding. I'm here. It looks like this
is my first moment online in this
workspace. So, we should do a quick who
are we setup. What should you call me?
So, now you can name your Clawbot. I'm
going to name ours Jones for this
example. Two, what kind of thing am I to
you? I'd make it an assistant, but you
can make the role whatever you want. I
think I made mine chief of staff for
Henry, my Claudebot. Three, what's the
vibe you want? Very blunt, efficient,
warm, chatty. Somewhere in between.
Somewhere in between. I think it's good
to have a balance. It feels human but
still gets straight to the point. And
number four, signature emoji, yes or no.
If yes, which one? Lion emoji. So,
choose an animal for yours. I chose an
owl for Henry, my personal Clawbot, but
you can choose any you want. I'm going
to hit enter. Once this is good to go,
by the way, I'm going to show you a few
workflows that would be super helpful to
set up with your Clawbot. One more
thing, so I can be useful without
guessing, what's your name and time
zone. I'm Alex and I'm in PST. Hit enter
on that and you are good to go. All
right, so we're locked in. You're good
to go. The entire world is ahead of you.
You got 247 AI employee. Let's go
through a few use cases I think everyone
should do when they set up their
Claudebot. The first thing I think
everyone should do when they first set
up their Claudebot is do a massive brain
dump on who you are. What's so powerful
about Claudebot is it's self-improving
and has an incredible memory system. So
everything you tell it, it will
remember. So, I like to start this off
and tell as much about myself as I
possibly can. So, do yourself a favor,
go in right now, brain dump as much
about you, your business, your family,
relationships, everything you can, put
it in there, and Claudebot will remember
that about you. So, when it does task
for you moving forward, it will have
relevant context. Again, one of the
biggest strengths about Clawbot that
makes it amazing is it's constantly
learning, constantly improving.
Everything you say, it takes out the
details and remembers it for you. So
brain dump in here. Tell it about what
you like, what you enjoy, your hobbies,
what you do for work, how you want to
make money, your dreams, aspirations.
Put that all in here. The more the
better. The next thing you should do
with it is have it set up a morning
brief. This is one of the most helpful
things a personal AI assistant can do is
right when you wake up in the morning,
you have a morning brief. And so here's
how you want to do it. Here's the prompt
I use to set up my morning brief. I want
to create a I'll put this down below,
too. I want to create a morning brief
that you text me every day. So, this is
going to be great. It'll text whatever
channel you set up. Please let me know
any news going on in the world that is
relevant to me. That's why you do the
brain dump a second ago. The weather in
Mountain View or wherever you are and
task you can do today that will be
helpful. I love this part here because
this helps your agent be proactive.
Right? One of our problems as humans is
it's very hard for us to creatively
think of what other people should do.
What this helps is let the AI decide
what it should be doing to help us. So
you want that part in there too. And
then I say and tasks I should do that
will advance my career. And this is
going to give us recommendations for
what we can do to improve our life. And
we're going to wake up every single day
to these recommendations. So put that
in. Hit enter on that. If you want a
little example about a real life morning
brief I get every single morning. My
Claudebot actually goes researches
competitors on YouTube for me on what
they're creating content on. tells me
some trending news and stories and gives
me ideas for content I can create. So
you can get really interesting and
creative with this morning brief that
and make it really helpful for you when
you wake up. So here's another super
powerful thing about Cloudbot is it
pretty much can do anything a human
being can do, right? So if you wanted to
monitor your email, you can do that.
Now, since this is running in the cloud
and not on your local computer, it's
going to need connectors and plugins in
order to use other tools like looking at
your email or looking at Twitter, but
you can still do it. And what's great is
you can just ask it to do things and
your Clawbot will figure out how to do
it. So, for instance, if I say, "Please
monitor my email for me and send me a
summary of my emails at the end of every
day." When I hit enter on this, it is
going to go through a setup where it'll
say, "Okay, let's connect to your Gmail
or what email service are you using?"
Okay, perfect. You're going to need to
give me the API key for this. So, do
this step by step. And it will walk you
through it. And if at any point you get
confused, you can say, "Hey, I don't
know what I'm doing here. Can you help
me out to figure this out?" Anything you
want your Claudebot to do, it doesn't
matter if you don't know how to do it,
just tell your Claude. If you want it to
post for you on LinkedIn every day, you
can do that. Just say, "Hey, please post
on LinkedIn for me every day." It
doesn't matter if you don't know how to
set this up to LinkedIn. Just say it
anyway. And Claudebot will walk you
through setting it up. Not knowing how
to do things is not an excuse anymore.
If you don't know how to do something,
you go to your super intelligence. You
say, "I want to do this. Tell me how to
do it." And it will walk you through it.
So, brain dumping so knows everything
about you. Setting up the morning brief,
monitoring your emails, those are three
solid ones. The last one I'll say is
based on what you know about me, what
are five workflows and tasks you can do
for me every day. These can include
connectors or skills we don't have yet.
This is a great one because again it
uncovers the unknown unknowns you have.
Right? The claude will go look at all
the memories it has about you,
everything you told it, right? This is
again the advantage of that brain dump
at the beginning and find helpful tasks
it can do for you regularly. Once it
gives you a list of those tasks, you can
even come back in here, choose one of
the tasks and say, "Hey, do that task
for me every day at a certain time."
Right? And then you give it a time.
What's really powerful about Claudebot
is it can schedule tasks. So if you find
a task you wanted to do daily, just say,
"Hey, do this task every day at this
time. Then text me about it." And it
will text you directly on your phone.
So, the fourth thing you want to do is
you want to interview Claudebot on tasks
that will be helpful for you. The
downside of this system and using AWS
and hosting this on the web is you're
going to have to set up connectors for
every single thing you do that needs
other tools. Right? If you have a Mac
Mini, you pay $600. You just set it up
on your computer and everything that's
on your computer it can use. But you're
able to set this up much faster. You
don't need to buy another computer and
you can save money upfront. dip your
toes, see if it's right for you, and
then if you want to go and then buy a
computer for this, you can do that as
well. I dipped my toes. I bought a Mac
Mini and I loved it so much I'm buying a
Mac Studio now for this. So, this is the
quickest, easiest, cheapest way to get
Claudebot set up. No matter what kind of
device you have, you have the worst
computer on planet Earth, this will
still work for you. Again, you want to
choose the model that works for you. If
you already are paying for Claude or
Chat GPT, you might as well use that
subscription and just plug it in. But if
you don't have those yet and you're
newer to AI, just sign up for the chat
GPT API and choose the cheaper models
and you'll be good to go. This AWS
instance should only cost you $15$20 a
month depending on your usage, much
cheaper than $600 upfront. So dip your
toe, see how you like it. Interview the
Clawbot. That's my biggest
recommendation. Interview it. Say, "Hey,
what can you do for me?" Schedule those
tasks and you will have an AI employee
working for you at all times. Leave a
like down below if you learned anything
at all. Let me know in the comments what
you're doing with your Claudebot, what
you want to get out of it. Subscribe and
turn on notifications. I'm about to make
more Clawbot content than you can shake
a stick at. I hope this was helpful.
I'll see you in the next video.