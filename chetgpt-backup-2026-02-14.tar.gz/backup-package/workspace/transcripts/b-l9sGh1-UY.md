# 5 insane ClawdBot use cases
# URL: https://youtube.com/watch?v=b-l9sGh1-UY
# Segments: 398

Claudebot is taking the entire internet
by storm right now and for good reason.
It is what I believe to be the most
powerful amazing AI tool of 2026. The
issue is most people are just
experiencing 1% of its power. Most
people just install it and ask it what
the weather is. That's a huge mistake.
In this video, I'll go over five Clawbot
use cases that you can implement right
now that will save you time, make you
money, and change your life. Let's get
into it. So, here is the first thing I
wake up to every morning that has been
incredibly helpful for me that I will
show you how to set up. I'm going to
give you the prompt for each one of
these use cases I'm going through. This
is a morning brief that I'm going to
show you how to set up that's going to
give you some really important
information. The most important thing
here is probably this mission control.
What this mission control does is it
takes a look at my to-do list every
single day. It tells me what I need to
work on today, what my Claudebot Henry
is going to work on today, and what my
Claudebot Henry actually worked on last
night while I was sleeping. If you
haven't yet, you need to connect your
Clawbot to one of your to-do list
systems. I connected mine to a to-do
list called Things 3, which is an
amazing Mac to-do list app, but even if
you're on PC, you can connect it to many
other to-do list. Just talk to your
Cloudbot about which to-do list you use.
And so this morning brief first lets me
know what I need to work on today.
Updates me what my CloudBot's going to
work on because again, Claudebot is one
of the most amazing proactive AI tools
out there. And it lets me know what it
got done while I was sleeping. It also
looks up trending news. So it looks
online based on what it knows about me.
I didn't tell it what to look up. It
just knows based on our conversations
what to look up and finds trending news
based on my interests and then gives me
things I can execute on today. So, I
came up with the idea to react to one of
Matthew Berman's Claudebot videos. Shout
out Matthew Burman. Amazing AI creator.
My Claudebot saw that Matthew Berman
made a video that was similar to one of
my own videos. So, wants me to put out a
response. My Claudebot is petty. It also
came up with an idea. So, it looked at
my calendar. It's seeing that I I have a
Mac studio coming in in two weeks and
it's like, okay, maybe you should create
content around it. That's actually a
really good proactive idea I came up
with. And then it saw that we have a
newsletter draft in our shared folder
and it says, "Okay, we came up with
this. I think it's time for you to send
it." This is amazing. So, this is all in
my morning brief. And this is just
incredible proactive information that I
wake up to every single morning. So, how
do you set this up? Here is the prompt,
and I'll put this down below. So, feel
free to pause right here, copy and paste
into your Clawbot if you want, or just
wait till the end, then come back after
the video. I want you to send me a
morning brief every morning at 8 a.m. my
time. I want this morning brief to
include the local weather for the day. A
list of a few trending YouTube videos
about my interest. So, it's important
your Claudebot knows all about you. Make
sure it knows all your interests. If it
doesn't, tell it all your interests. A
list of tasks I need to get done today
based on my to-do list. Connect it to
your to-do list. If you don't know how
to do that, just go to your CloudBot,
say, "Hey, connect to my to-do list.
Tasks that you think you can do for me
today that will be helpful based on what
you know about me." Super critical.
Encourages your Claudebot to be more
proactive. a list of trending stories
based on my interests and
recommendations you can make for me that
will make today super productive. For
the list of trending stories one, I'd
recommend connecting to the Brave search
API. That will allow Claude to be a
little bit more efficient when it comes
to web search. And then the last parts,
the recommendations you can make for me
today that will make today super
productive. Again, a little bit of
reverse prompting. Basically, what that
means is you're having Claude prompt
you, which is tell you what to do that
day. Really, really helpful. Take that
prompt from down below, put in your
Clawbot, you are all set up. The next
use case I'm going to show you is an
amazing one. And again, I'll give you
the prompt right after so you can copy
paste and get this implemented really
quick. But this prompt turns your
Claudebot into a proactive vibe coding
machine without me even asking. My
Claudebot Henry built this entire
document viewer that automatically takes
our conversations and puts them into
really nice documents. It built out this
entire project management system. So I
can see Henry, my Cloudbot, complete
tasks as he goes. All without me asking,
which is really amazing. So what this
prompt does, and I wish I could include
more of this on the screen, but the UI,
maybe I'll improve the UI for Clawbot in
a little bit. The UI doesn't expand
here, but this prompt turns your Clawbot
into a proactive coder that builds
things without you asking. And this
might be my favorite use case of
Claudebot overall. What this prompt will
do is basically give your Claudebot
permission to build things without you
having to tell it. So I said, "I am a
one-man business. I work from the moment
I wake up to the moment I go to sleep. I
need an employee taking as much off my
plate and being as proactive as
possible. Please take everything you
know about me and just do work you think
would make my life easier or improve my
business and make me money. I want to
wake up every morning and be like, "Wow,
you got a lot done while I was
sleeping." Don't be afraid to monitor my
business and build things that would
help improve our workflow. Just create
PRs for me to review. Don't push
anything live. I'll test and commit.
Every night when I go to bed, build
something cool I can test. Schedule time
to work every night at 11:00 p.m. Take
this prompt, put it in. What this is
going to do is schedule your Clawbot to
think every night what it can build for
you and vibe code it out. After I gave
it this prompt, it started building out
so many helpful features to improve our
working relationship. It's been
unbelievable. Couple tips I'll give you
though. One is I would highly recommend
especially if you're using Opus as your
main model here to install Codeex CLI if
you're on a chat GPT subscription. This
will allow it so that Opus is kind of
your brain that organizes all of this
and Codeex is actually the tool it uses
to vibe code. This will save you a lot
of tokens on Opus which is a very
expensive model. So get codeex CLI
installed then go to your Claudebot and
say hey make sure to use the codec CLI
anytime you vibe code. that will save
you a ton of tokens. Prompt for this
down below as well. The next thing you
should do with your Clawbot that will
make it so much more powerful is have it
vibe code you a second brain. So, it
actually vibe coded this for me
proactively, but it's been so helpful
that I recommend everyone explicitly go
out of their way and have their Clawbot
build it. What this does is amazing. It
basically builds an interface where I
can go back and I can either view
memories it created. So I can like
review what we've talked about in prior
days or view documents that record
important information we discussed. So
this entire interface was built by my
claudebot and it shows all these
documents it's creating in real time as
we chat. And then it gives me this
really nice markdown viewer where
everything is formatted nicely. It also
automatically tags each one of the
documents with journal content,
newsletters, notes, YouTube scripts so I
can very quickly organize them. But what
you can see here is a few things. one,
every day it creates a journal entry.
And in this journal entry, it shows
exactly what we talked about. I love at
the end of the week going back and just
rereading everything we discussed every
day of the week just to remind myself of
when I had quick ideas. If any, if
you're anything like me, you're
constantly using Telegram just to text
your Clawbot random ideas that come to
your head. This is a great place to go
back and review all those random
thoughts that came to your head. It also
takes important concepts you discussed
and fleshes them out in their own
documents. So for instance, in two weeks
I have a Mac studio coming in where I'm
going to run a whole bunch of local
models. So much more content on that
coming very soon by the way. But because
we were discussing this, I was
discussing my Claudebot Henry how to
migrate from this Mac Mini I'm on to the
Mac Studio. It actually built me out an
entire migration dock automatically that
I can now go back and review later on
when I'm ready to migrate. So, this
second brain, mission control, it calls
it, is so so helpful because it allows
me to go back and review really
important conversations we had and go
into the details on a lot of the
important aspects of them. So, here's
your prompt for the second brain that
I'll put down below. I want you to build
a second brain. This should be a next.js
app that shows a list of documents you
create as you work together in a nice
document viewer that feels like a mix of
obsidian and linear. For for me, those
are my two favorite UIs for apps. I want
you to create a folder where all the
documents in that folder are viewable in
the second brain. Update your memory
skills so that we when we talk every
day, you create documents in that second
brain that explore some of the more
important concepts we discuss. You
should also create daily journal entries
that record from a high level all our
daily discussions. Copy paste that into
your Cloudbot and ensure before you hit
enter on that that you've told your
Claudebot you want to use Codeex as your
coding tool just so you can save tokens
on Opus if you're using Opus. I've loved
having the second brain. It's made using
Claudebot so much more pleasant. So, our
fourth use case ties in very nicely with
our second brain here, and that is a
daily research report that Claudebot
will build for you based on what it
knows about you, your interests, and
your business. So, I have it scheduled
every afternoon, which is basically my
afternoon brief instead of a morning
brief. I want a research report that I
can read every single afternoon that
goes into depth on one of my interests
or a way to improve my business. So,
I'll get a text every day on my Telegram
from my Clawbot out of the blue that
says, "Hey, I built this entire research
report that will either a teach you
something about a concept you're
interested in, like machine learning or
AI, or B, a concept I think will improve
the way you do work, improve your
business, or improve the way we work
together." So, here's an example, one I
got yesterday, which is just workflow
improvement ideas between me, my Claudeb
Henry. It just did research based on
everything I've told it, based on all my
interest, based on what we've done in
the past, based on all our past journal
entries, what would be some interesting
ways it could improve our working
relationship. So, just systems we can
implement where it watches my GitHub or
a self-reflection routine where it comes
up with self-improvement for itself or
even weekend build projects. This just
keeps your Claudebot thinking about how
it can improve everything it does and it
keeps itself improving. This has been a
massive use case you should implement.
So, here's the prompt you want to use.
I'll include it down below. I want a
daily research report sent to me every
afternoon. Based on what you know about
me, I want you to research and give me a
report about a concept that would
improve me, processes that would improve
our working relationship, or anything
else that would be helpful for me.
Examples would be deep dives on concepts
I'm interested in in like machine
learning or new workflow we can
implement together that will improve our
productivity. Again, all these prompts
are basically around making your
cloudbot more proactive for you, more
productive, and just improving your
working relationship. Copy and paste
that prompt in. Your Clawbot's instantly
smarter. The last use case I want to go
over with you is a Claudebot skill that
has absolutely blown me away. It's from
Matt Van Horn. I'll link down to Matt
Van Horn's profile down below. Make sure
to follow him on X. It is a skill that
teaches Claudebot how to research X and
Reddit in parallel for big trends that
are coming. So, this has been massive
for me. This has helped me come up with
so many concepts or videos, content, or
just seeing what people on the internet
have to say. This teaches Claudebot how
to research Reddit and X and find things
people are talking about and topics that
are trending based on what you want it
to research. So, for instance, I wanted
it to research Claudebot use cases. It
went in and it researched over the last
30 days all the top Claudebot use cases
by engagement on Reddit and on X. So, it
can show me all the top Reddit threads,
all the top exposts about Claudebot use
cases, and then it even gave me a bunch
of content ideas from the research. This
is incredible. Anytime you have to
research something, you need to be using
this skill because it will get you the
latest topics off Reddit and X. All
that's required from this is to install
the skill, which I'll show you how to do
in a second, as well as an XAI API, so
the Grock API as well as an OpenAI API
key so they can check out Reddit. So,
all you want to do, and I'll link to
this down below, is take the link to
this skill, give it to Claudebot, and
say, "Please install this skill." Once
it does that, you're good to go. And you
can just say, "Hey, use the last 30 days
skill to find me information on whatever
topic you want, and you'll get a
research report just like I showed you."
It has been incredible for me for
finding information and seeing what
people are talking about. And you can
even implement it in interesting ways.
If you want it to be a part of your
morning brief to see what other people
are saying on Reddit about specific
topics or your afternoon research
report, whatever you want, get this
skill installed. It's my favorite skill
by far. After implementing these five
use cases, my workflow has 10xed. All
the people saying Claudebot's not
capable of anything important, I dare
you to show me how your normal LLM can
do everything I just showed you. I
promise you it can. If you learned
anything at all, make sure to leave a
like down below. I do weekly boot camps
on Claudebot inside the Vibe Coding
Academy. Link for the Vibe Coding
Academy down below. You can join the
boot camps and ask me questions live.
Also, make sure to subscribe and turn on
notifications. All I do is make
incredible videos about AI. And there's
so many more videos about Claudebot
coming very soon. And they'll only
ratchet up a notch once my Mac Studio
comes in and I start running local
models on it. Hope this was helpful. See
you in the next video.