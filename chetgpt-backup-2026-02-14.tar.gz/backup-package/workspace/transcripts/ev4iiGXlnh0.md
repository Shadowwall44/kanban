# DO NOT use a VPS for OpenClaw (major warning)
# URL: https://youtube.com/watch?v=ev4iiGXlnh0
# Segments: 514

Yeah, so you're getting lied to. There
have been a lot of videos over the last
couple days of AI creators recommending
for you to set up your open claw through
VPSes like Hostinger and all these other
online services. Basically, every single
one of these videos was sponsored. Some
of the creators mentioned the videos
were sponsored. A lot of other ones
didn't mention they were sponsored,
which is very illegal and unethical.
Moral issues aside, the advice they're
giving you is at best wrong and at worst
very dangerous. In this video, I'm going
to go through why Open Claw hosted on
virtual private servers is wrong for
basically 99% of people and in some
situations very dangerous. Then I'll go
through the best way to set it up which
is more secure, more powerful, in a lot
of situations much cheaper even than the
$6 plans and a lot of these other
services. I'll walk through it all step
by step. So even if you are brand new to
OpenClaw, you'll learn how to set this
up. And if you're using OpenClaw right
now, you'll see why a lot of the advice
you're getting online right now is
extremely dangerous. Now, let's lock in
and get into it. So, in no particular
order, here's what we're going to cover
in this video. Why VPS's are bad for 99%
of people, and you shouldn't be
listening to other people's advice. The
better way to set up OpenClaus. I'll
walk through step by step setting this
up locally, whether it's on a Mac, Mini,
Mac Studio, or a really crappy old
laptop. And we'll also go through real
quick why you shouldn't trust most
people. But before we begin, I just want
to shout out our sponsors, Logic and
Good Faith. There are quite literally
billions of dollars being thrown around
by AI companies right now at creators.
The best way to get people onto your
services, spending tons of money, is to
pay creators with lots of eyes to have
them shill your service. Most creators
are taking this money. And there is
nothing wrong with that. There is
nothing wrong with doing sponsored
content. It is one of the best ways to
monetize if you are a creator. The issue
is when you start to promote things out
of bad faith knowing they're not the
best product or service or if you take
that sponsorship and then you don't
disclose it, which is quite literally
illegal, not to mention immoral,
unethical, and a whole bunch of other
bad things. Over the past few days,
almost every big AI creator on YouTube
has taken one of these sponsorships. I
get all the emails. I know how much
they're getting paid. They're getting
paid high five figures for this. And
listen, if they truly believe a VPS is
the best way to install OpenClaw and
they're disclosing it's an
advertisement, I have no issue with
these people taking their bag. My
problem is when some of these creators
know this isn't the best way to set up
OpenClaw or they just don't mention that
they took the sponsorship. I think these
creators are sacrificing the trust
they've built with their audience just
for a small $30,000 bag, which is crazy
because the earning potential in this
space is so much more if you just keep
the trust with your audience. So, I'm
just going to give it to you straight. I
think hosting OpenClaw on a virtual
private server is the wrong way to host
it. So, first thing I'll do in this
video is go through why VPS is the wrong
way to do this, why it is potentially
more unsafe, why it is worse for 99% of
people. I'll go through why local setup
is better. And then right after this,
I'll show you exactly how to set this up
locally in the easiest, cheapest, most
secure way humanly possible. No matter
what device you have, you don't even
need a Mac Mini. So, here's what the
people recommending VPS's are signing
you up for. Number one, it is just
significantly harder to set up than
local. I've tried it. I've tried them
all. I've tried even the one-click
solutions. They are not nearly as easy
to set up. Local setups are literally
one command. You just put one command in
your terminal. I understand the terminal
is scary and is it makes you feel like
you're Neo in the matrix and you want
nothing to do with it. I get it. But
trust me, it is so easy. You literally
just copy, paste it, hit enter, and
you're set up. The VPS is not secure by
default. It is incredibly dangerous by
default. There are a tremendous amount
of tweets just like this going up on X
at the moment where people are running
scans of these online services, these
EC2 instances, all these VPS's and
they're finding thousands of these are
not secure and anyone can go right now
access these online servers and take all
your credentials and tokens and
everything private to you on them. By
default, a majority of these VPS's
require highly technical work to make
them secure. You need to set up
firewalls and SSH and a whole bunch of
other services that for the average
person is incredibly technical and
complex. They might just be one-click
setups, but you're still exposing your
OpenClaw to the entire internet unless
you know how to set up really complex
security. On the other hand, by default,
when you set up Open Claw locally on a
Mac Mini or a dusty old Lenovo in your
closet, it is secure with some caveats,
which I'll explain. By default, so if
you install this on a fresh new device,
a Mac Mini, a whatever, you can buy a
Raspberry Pi for like $75 and you set it
up and there's no other apps or
programs, then this will be secure by
default because your Open Claw is only
going to have access to what's on this
computer. And if there's nothing else on
this computer, then it's not going to be
able to touch things that will make it
insecure. Also, by default, a lot of
these devices, especially Apple's, but
also a lot of the Windows devices, they
have good firewalls and security set up
right out of the box. No one's going to
hack your fresh out of the box Mac Mini.
So, by default, when you install it
locally on fresh devices, it's secure.
Now, the exception is if you're
installing it on a device that you've
already been using before, you have a
whole bunch of accounts on it already.
And maybe you've been downloading and
doing things that allow people to access
that device externally. Then you are not
going to be secure by default. But at
its core, for most people who install
this on local fresh devices, this is
going to be secure by default and won't
require a whole bunch of technical work
for you to go in and make it secure,
which is super important because if
you're new to this, which a lot of
people using OpenClaw are not very
technical in nature, you are putting
your entire digital livelihood at risk
by putting this on Amazon EC2 or these
other hosted services. Many other
reasons why VPS's stink in my opinion.
poor integration, right? I have this
running right now on a Mac studio. If I
have a video I want my Open Claw to
edit, or if I have a photo I wanted to
use for a thumbnail, or if I wanted to
read some sort of article I have
downloaded on my phone, I can hit
Airdrop and in literally 2 seconds, my
Open Clog can be using that file or
whatever I needed to do. That is
unbelievably helpful. And especially
when you're treating this like an AI
employee, the ability to go on your
iPhone, on your iPad, on your MacBook
Pro, hit a button, drop it any file you
want is so, so convenient. That's just
not possible with the VPS. From a
usability perspective, it stinks. One of
the most amazing parts about OpenClaw, I
can give it commands from my phone, then
I can sit here and watch it on my
computer do the work I asked it to do. I
can see it open browsers. I can see it
open different files. It's just on this
computer working 24/7 for me. And that
is great usability. If you work in a
corporate environment, you know why this
is important. You build much better
relationships and work much better with
employees that are inside your office
working right next to you. The employees
that are outsourced halfway across the
world. They're much harder to build
relationships with and work with and
stay on top of what they're doing and
track what they're doing. That's the
difference between a VPS and having the
device local. When the device is local,
you can sit there and communicate with
it and see every single thing it does.
when it's on a VPS, you don't have great
visibility into what's going on. So, the
usability perspective is just so much
better on a local device. All of this
combined makes the VPS not very powerful
and the local environment very powerful.
This technology is so good, you want to
take full advantage of it. You don't
want the labbotomized dumb version of
it. You want the full power. And the
only way, in my opinion, to get the full
power is using it on a local setup. Now,
does that mean you have to go out right
now and spend $600 on a Mac Mini? No,
that's not what this means at all. I I
am not recommending that. Although, you
could and it's a lot of fun and Mac
minis are amazing devices and probably
the best value for their dollar. You
don't have to. You could go in your
closet right now and pick out that old
Lenovo PC from college that has that
rubber red dot in the middle that makes
the mouse move around that's really fun
to play with. You can pick that out for
free right now and put your open claw on
and not spend a dime on this. Now,
there's a couple of reasons why I think
people are going out and shilling VPS's
and telling you Mac minis are the devil.
One, they're either getting paid like we
went over at the beginning of this
video, right? They're just shilling the
opinion of whatever company paid them
the most money last, which again is fine
if you truly truly believe it, but I'm
not sure most people believe it. Or two,
they're just contrarians who absolutely
hate when you spend money on
corporations. I'm seeing this a ton. I
say, "Hey, go out and buy a computer for
open client. Oh, what are you getting
paid by Apple? you you popping Apple
stock. First of all, no, I'm not getting
paid by Apple. Second of all, Apple, if
you want to pay me, that's great because
I 100% believe you're the best way to be
doing this. First of all, I am not
getting paid by Apple. Second of all, I
just think there's a lot of people in
this world who hate when you recommend
you spend money with companies. They
hate when other people are consumers.
They hate they for some reason just want
to tear down every big company out
there. And so when other people say,
"Hey, go buy an iPhone." They go, "Oh
no, buy a $10 Android." Or they say,
"Hey, go buy a Mac. Oh, no. Spend $5 on
the most complex Amazon EC2 setup
anyone's ever seen in their lives. They
don't care what's best for you. They
just don't like to see big corporations
win, which is whatever. But I just do I
just think at the moment the best route
for people are these local devices. Now,
if you're going with a local device like
an old dusty Lenovo laptop, I would
highly recommend wiping it first, right?
So, you make it secure so there's
nothing else that can access your Open
Claw. I wouldn't just take an old device
and put it on that has a whole bunch of
other insecure software on there cuz
again that could be dangerous. So if
you're using an old device that you've
had for a while, make sure to wipe it
first. Make sure it doesn't have access
to any other accounts and that will make
it more secure. If you want to go Mac
Mini, I think it's a great choice. I
think it's an incredible device. I think
the value you get for $600 is unmatched.
I went even a level higher. I spent I
bought two $10,000 Mac Studios. The
reason why I did that is I'm running a
bunch of local models which unlocked a
whole bunch of use cases for me. If
you're interested in seeing those use
cases, feel free to subscribe and turn
on notifications. Also, if you learned
anything so far, make sure to leave a
like down below as well. But you don't
have to do that. You don't have to go
out and buy Mac Studios. I'm just a
power user who is trying to find the
limits of this technology. But you can
easily get away with much cheaper
devices or the old dusty devices in your
closet. And the last pitch I'll give you
on why local is so much better than
virtual private servers is it is just
straight up more fun. It is more fun
looking down at your desk, seeing a
device there, knowing there's an AI
agent working there 24/7, building you
cool stuff, doing cool things for you.
That is just tremendously more fun than
having a little command line interface
in a virtual private server in a browser
that's just going there moving real
slow. That's not fun. That's not
interesting. I truly believe people
should be enjoying their tech
experiences. I truly believe you should
be having fun with AI. That's why I use
AI models that are more fun to talk to
than the ones that are robotic and not
as fun to talk to. I think it's
important to be having fun as you use
this technology. And having local
devices is just significantly more fun.
And that's not even covering privacy
concerns, right? Having your data local
on your computer rather than having it
in a cloud that anyone can access and
giving it to Amazon. You should have
your data local as well. It's just
better privacy and security, but that's
up to you. So, hopefully by this point I
have you convinced to be running this
locally. So, how do you set this up
locally? Well, after you've chosen your
device, whether it's a Mac Mini, whether
it's the dusty Lenovo, whether it's a
$75 Raspberry Pi, plug it in, get it set
up, and now let's get OpenClaw installed
on it. You go to openclaw.ai.
You scroll down. You see this command
right here. You hit copy on that
command. By the way, this is so much
easier than setting up a VPS. I don't
know who started the rumor that setting
up VPS's is easier than this, but this
is literally just copy and paste and hit
enter. From there, you just open up a
terminal if you're on Mac. If you're on
Windows, you open up the command line.
It's going to look something like this.
You're going to feel like Neo in the
Matrix. You're going to feel like you're
hacking the future. It's totally cool.
Do not be intimidated. This is super
easy. You paste in that command you just
copied and you hit enter on here. Once
you do that, it's going to install. You
just sit there. It installs everything.
Then it's going to take you through
onboarding. Onboarding, again, it's
going to feel intimidating, but I
promise you this is so simple. All you
do is you hit yes, and I understand this
is powerful and risky. You choose quick
start, and then it's going to take you
to this menu where you're going to
choose your AI provider. There's cheap
ways to do this. There's expensive ways
to do this. If you want the best, most
expensive way to do it, which is what I
recommend if you have the money, it'll
cost you $200 a month. You go to
Anthropic and then you choose Anthropic
token. So, subscribe to Anthropic. I
recommend the $200 a month plan. You go
to this option right here, and it's
going to say, "Run Claude setup token
elsewhere." Then paste the token here.
So, you copy Claude setup token. You
paste it in another terminal or command
line window. You hit enter. That's going
to ask you to log into your subscription
you just set up. It's then going to give
you a token, which is a really long
string of numbers and letters. What I'd
recommend doing is copying and pasting
that token into a notepad file. This is
going to allow you to make sure the
formatting is correct. So, get rid of
all the line breaks and everything so
it's just all in one line straight. Then
you copy and paste that into here after
you hit enter on this and it's going to
connect to your Anthropic subscription
and boom, you're set up. If you want a
cheaper way to do this, less than $200 a
month, you have many different options.
The cheapest way is going to be with a
subscription through one of these
cheaper open-source models. I recommend
Kimmy K 2.5. They have plans you can set
up where you're spending like $5 a
month. You can get in there. There's
even, from what I'm hearing, people are
getting free subscriptions to Kimmy K2.5
through Nvidia. So, if you Google Nvidia
Kimmy K2.5, you might find a deal that
they're running where you can get a
subscription for free for a while. So,
you can do that as well. So, you can
sign up for Moonshot there. Go through
the same subscription setup through this
menu. Hit enter on there and you are
good to go. And you have a much cheaper
version. might not be as smart or
efficient, but it's still going to be
good and you get a lot of bang for your
buck. After you choose the AI model,
you'll have one more menu to choose, and
that is which messaging service you want
to use. I highly, highly, highly
recommend using Telegram as your
messaging service. This is where you're
going to be interfacing with your bot.
You can choose iMessage, Telegram,
Discord, 100 different options for
messaging services. Telegram is the best
because it has the most customization
options. You can do threading, chunking,
whole bunch of other cool things. I'd
recommend Telegram. It's also incredibly
easy to set up. It'll walk you through
step by step how to do it. You just
create a bot in Telegram, which is very
easy to do. Once you do that, you have
your messaging set up and then you can
hatch your Open Claw and you are good to
go. You don't need to choose insecure
online VPS's in order to skip the setup
I just went through here. Have a little
faith in yourself. This doesn't take
Albert Einstein to set up. You can
literally set it up in under 45 seconds.
I just showed you exactly how to do it.
No programming or technical skills
necessary and you have it all set up.
And I just want to leave you off on one
more note before we go here. I have zero
issue with creators monetizing. I have
zero issue with creators taking
sponsorships. I think it is maybe the
best way for creators to get their bag
is through sponsorships. I just think
the creator is doing their fans a
disservice when they either a shield
something they don't actually believe in
or b do undisclosed shilling which is
highly illegal, immoral and unethical. I
fully plan on taking sponsorships at
some point in the future. I've been
doing this for a year and a half. I
think I've only taken two sponsorships
in the last year and a half. The reason
why I do that is I only want to talk
about products I truly believe in and
will truly make life better for my
audience. More valuable than a couple
thousand sponsorship is the trust I've
built with you and the amount of trust
you have in me. If I destroy that trust
by taking a $20,000 sponsorship from
some VPS and recommend something I know
will make your life worse, that trust is
gone and that trust is worth way more
than whatever money they're paying me.
This is not me virtue signaling. This is
me just saying it's all right to take
sponsorships. I just if you're a
creator, you're coming up, maybe you're
making AI content. A lot of people are
going out there and making more AI
content. Just make sure when you take
sponsorships, you disclose it first of
all. And if you want to conserve the
trust in your audience, make sure you're
shilling something that actually makes
their life better. Let me know down in
the comments below what OpenClaw
subjects you want me to cover next. I
think for the next video, I'm going to
go over my top five use cases for
OpenClaw that I've set up that have
improved my life. Also, leave a like
down below if you've learned anything.
Make sure to subscribe and turn on
notifications. All I do is make amazing
videos about AI. I so appreciate you
guys trusting me, spending your time
with me, watching my content.