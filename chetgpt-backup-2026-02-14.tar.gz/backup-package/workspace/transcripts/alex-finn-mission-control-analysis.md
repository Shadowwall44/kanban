# Alex Finn Mission Control Analysis
## Extracted from Two Livestream Transcripts for INKredible Printing's Dashboard Build

**Sources:**
1. `SGEaHsul_y4.md` — "Running ClawdBot on a $10,000 Mac Studio"
2. `0v2-mUUWNdc.md` — "The ULTIMATE OpenClaw Setup"
3. Screenshot descriptions: Office pixel-art view + Org chart hierarchy

**Purpose:** Drive the Mission Control build spec for Aviel's INKredible Printing AI team on GitHub Pages.

---

## 1. Agent Architecture: How Alex Structures His Agents

### The Org Hierarchy

Alex treats his AI setup as a **digital organization** called "Alex Finn Global Enterprises" (AFGE). The hierarchy is:

```
Alex Finn (CEO / Human)
  └── Henry (Chief Strategy Officer) — Claude Opus 4.6
        ├── Codex (Lead Software Engineer) — GPT Codex 5.3 (API)
        ├── GLM-4.7 (Senior Research Analyst) — Local model, 300GB
        └── GLM-4.7 Flash (Research Associate) — Local model, smaller
```

**Future hires planned:**
- **Kimmy K2.5** — When second Mac Studio arrives
- **Designer agent** — For reviewing designs
- **Pixel** — Local image model (Flux 2.1) for thumbnail generation
- **Echo** — Mentioned alongside Scout for workflow improvements

### Role Definitions
| Agent | Role | Model | Cost | Tasks |
|-------|------|-------|------|-------|
| **Henry** | Chief Strategy Officer / Orchestrator | Claude Opus 4.6 | $200/mo (Max plan) | Orchestration, strategy, task delegation, approvals, testing |
| **Codex** | Lead Software Engineer | GPT Codex 5.3 | API (pay-per-use) | Coding, building apps, creating pull requests |
| **Scout** | Trend Research | GLM 4.7 (local) | Free (energy only) | X/Reddit monitoring every 5-20 min, surfacing viral posts |
| **GLM-4.7** | Senior Research Analyst | GLM 4.7 (local) | Free | Deep research, plan writing, web browsing |
| **GLM-4.7 Flash** | Research Associate | GLM 4.7 Flash (local) | Free | Quick research, initial discovery, passing findings up |
| **Quill** | Content Writer | Local/API | Low | Script writing, content drafting, YouTube scripts |
| **Pixel** | Thumbnail Designer | Flux 2.1 (local) | Free | Image generation, thumbnail creation, background removal |

### Delegation Pattern: The Chain of Command

Alex describes an **autonomous delegation chain** that can run at 2am while he sleeps:

1. **Flash** (Junior Researcher) scrolls X/Reddit 24/7 looking for challenges/opportunities
2. **Flash** finds something interesting → hands it to **GLM-4.7** (Senior Researcher)
3. **GLM-4.7** analyzes it, writes a plan → walks it over to **Henry**
4. **Henry** (Opus 4.6) reviews the plan → approves or rejects
5. If approved, **Henry** hands the plan to **Codex** (Lead Engineer)
6. **Codex** builds it out, creates a pull request → gives back to **Henry**
7. **Henry** tests it in a browser, verifies → ships it
8. **Henry** goes back to the original tweet, replies with the solution and a $5 price tag

> "At no point in what I just described to you did I step in at all. That all happened at 2 in the morning while I was sleeping."

### Key Architectural Decisions

- **One OpenClaw, multiple sessions**: NOT separate OpenClaw installations per agent. Henry (the orchestrator) spins up new sessions within one OpenClaw.
- **Agent.md + Soul.md per agent**: Each session gets its own personality/rules via dedicated markdown files.
- **Henry manages all sub-agents**: The human (Alex) only talks to Henry. Henry delegates to the right employee.
- **Check/X emoji approval system**: Alex reacts with ✅ or ❌ to agent output. Preferences are saved to memory for future improvement.

---

## 2. Model Routing: Brain vs. Muscles

### The "Brain and Muscles" Framework

This is Alex's core cost optimization strategy:

- **Brain** = Opus 4.6 (Henry) — thinking, strategy, orchestration, approval
- **Muscles** = Everything else — Codex for coding, local models for research/content/images

> "Opus shouldn't be doing all the work... Your Opus does the thinking and then calls on the tools to do the work."

> "If you have opus doing every task, you're going to hit limits. You need to have employees working for Opus that it can pass off tasks to."

### Model Selection Rationale

| Task Type | Model Used | Why |
|-----------|-----------|-----|
| Strategy/orchestration | Opus 4.6 | Smartest model, best judgment |
| Coding | Codex 5.3 (API) | "Significantly cheaper than Opus" — good enough |
| Research (24/7 scanning) | GLM-4.7 (local) | Free, no rate limits, no restrictions, 24/7 |
| Quick research/discovery | GLM-4.7 Flash (local) | Smaller, faster, also free |
| Image generation | Flux 2.1 (local) | Free, trainable with LoRA on personal photos |
| Embeddings/memory | Small local embed model | Tiny, persistent, powers vector memory |

### Why Local Models Matter (Alex's Excalidraw List)

1. **Free** — No token costs, only energy
2. **24/7/365** — Can work non-stop because free
3. **No restrictions** — No guardrails, no "I can't do that"
4. **Privacy** — Logs don't go to Anthropic/OpenAI servers
5. **Education** — Learning about models by running them
6. **Fun** — Genuinely enjoyable to have AI chugging on your desk

> "I would rather have a stupid model that works extremely hard than a smart model that doesn't work that hard."

---

## 3. Mission Control UI: Dashboard Features

### What Alex Built (Custom, Not Open Source Yet)

From the screenshots and transcript descriptions, Alex's "Mission Control" dashboard includes:

#### A. "The Office" — Gamified Pixel-Art View
- Pixel-art office environment showing agents at desks
- Each agent has a character sprite that **moves around** (walking to other desks = delegation)
- **Status indicators**: Working / Moving / Idle
- Agents visible: Alex (human), Henry, Codex, GLM-4.7, Flash
- Visual representation of the organization — you can "watch them work"

> "I can sit here and I can watch them work. I can watch the office. I can watch them go around."

#### B. Org Chart
- Hierarchical tree: CEO → CSO → Engineers/Researchers
- Each card shows: **Name, Role, Model, Cost, Skill Tags**
- Shows reporting structure (who reports to whom)
- "We're looking to hire" — expandable when adding new agents

#### C. Mission Statement (Always Visible)
- Displayed prominently: *"An autonomous organization of AI agents that does work for me and produces value 24/7"*
- Every agent sees this in their context — everything is in service of this mission

#### D. Other UI Features (from transcript references)
- **Tasks** — Open tasks across all agents (mentioned "15 open tasks across the board")
- **Chat** — Direct lines to each agent individually
- **Council** — Water cooler channel where agents chat with each other
- **Calendar** — Scheduled tasks displayed; source of truth for cron jobs
- **Projects** — Grouped work items
- **Memory** — Memory system (soul.md, memory.md, daily memory logs)
- **Captures** — Screenshots, images, airdropped files
- **Docs** — Markdown files, scripts, plans
- **People** — Agent profiles and status
- **Daily Digest** — Morning summary of everything agents did overnight
- **Approvals Queue** — Items needing human review (4 things pending in example)

#### E. Discord Integration (Workspace)
- Separate channels per agent: Scout, Quill, Digest, Trend Radar
- Direct message lines to each of the 6 OpenClaws
- **Alerts channel** — Scout posts trending tweets every 20 minutes
- **Scripts channel** — Quill posts draft scripts for review
- **Daily Digest channel** — Morning summary of all overnight work
- **Water Cooler** — Agents chat with each other (being set up)
- **Approval workflow** — React with ✅/❌ to approve/reject work

---

## 4. Automation Workflows

### Active Automations

1. **X Trend Monitoring (Scout)**
   - Every 5-20 minutes, hits X API
   - Finds trending posts about OpenClaw, Claude, AI topics
   - Posts alerts to Discord channel
   - Uses official X API (bearer token), NOT scrapers
   - Runs 24/7/365 on local model — zero token cost

2. **YouTube Script Factory (Quill)**
   - Monitors what's going viral on YouTube and X
   - Takes Scout's research and turns it into YouTube scripts
   - Posts to "agent output" channel: title, duration estimate, outline
   - Alex approves/rejects via emoji reaction
   - Preferences saved to memory → scripts improve over time

3. **Thumbnail Generation (Pixel)**
   - Local Flux 2.1 model
   - Trained LoRA on 71 personal photos (background removed automatically)
   - Generates YouTube thumbnails with Alex's face
   - Completely local — no API cost

4. **Video Processing Pipeline (Described)**
   - Film video → airdrop to Mac Studio folder
   - Henry watches the folder
   - Research assistant gets transcripts
   - Flash generates thumbnail
   - Henry posts to YouTube
   - "Whole thing automated and systematized"

5. **Daily Digest (Morning Briefing)**
   - Every morning: summary of what agents did overnight
   - Shows: research completed, scripts drafted, tasks needing approval
   - Shows agent team output metrics
   - Surfaces top priorities and open tasks

6. **Calendar-Based Scheduling**
   - All scheduled tasks displayed on calendar
   - Calendar = source of truth for accountability
   - If a scheduled task doesn't appear on calendar → bot knows it failed

### Cron Job Strategy
- Heartbeat mentioned (30-minute intervals)
- Calendar used as accountability layer
- Local models can run cron-like loops with zero cost

---

## 5. Cost Management

### Alex's Cost Structure

| Item | Cost | Notes |
|------|------|-------|
| Claude Max (Opus 4.6) | $200/month | Brain/orchestrator only |
| Codex 5.3 API | Variable (cheaper than Opus) | Used for coding to save Opus tokens |
| X API | ~$3,000/month | Mostly for Creator Buddy SaaS, not OpenClaw |
| Local models | $0 (energy only) | GLM-4.7, Flash, Flux, embed model |
| Hardware (one-time) | $20,000 | Two Mac Studios (512GB each) |
| Mac Mini (starter) | $600 | Gateway drug / original device |

### Key Cost Optimization Strategies

1. **Never have Opus do everything** — "If you have Opus doing every task, you're going to hit limits"
2. **Use Codex for coding** — "Significantly cheaper" than Opus, past the threshold of being "unbelievably helpful"
3. **Local models for bulk work** — Research, scanning, content drafting = free
4. **OAUTH for Claude Max** — Uses $200/month subscription via OAUTH, not API tokens
5. **Rate limit avoidance** — "Rate limits happen when you're using Opus 4.6 with thinking on. You got to tune it."
6. **Economies of running local** — The more you offload, the more Opus budget you preserve for high-value decisions

> "If all these employees were APIs... the economics of the company wouldn't make sense. I'd be spending so much on tokens that I wouldn't be able to run this company 24/7."

### The Solar Panel Vision
Alex's endgame: Tesla solar panels → free energy → completely self-contained AI organization disconnected from the grid. "Self-sustaining super intelligence that doesn't stop computing."

---

## 6. Key Quotes

### On Agent Architecture
> "We're not asking it questions and giving it prompts. We're managing it."

> "The lens you need to look through when you're using OpenClaw is this is a company. This is an organization. This AI is working for me."

> "99% of people look through the lens of send and receive. I send a prompt, I get back a response. That's the wrong lens."

### On Delegation & the "Brain and Muscles" Model
> "Opus shouldn't be doing all the work. Your Opus does the thinking and then calls on the tools to do the work."

> "I would rather have a stupid model that works extremely hard than a smart model that doesn't work that hard."

> "I like Claude Code better but Codex is perfectly fine to save money."

### On 24/7 Autonomous Operation
> "At no point in what I just described to you did I step in at all. That all happened at 2 in the morning while I was sleeping."

> "These are like employees on steroids and on crack cocaine... they can work 24/7, 365 without eating, sleeping, or getting paid."

> "The power of AI is it doesn't need to eat. It doesn't need to sleep. It doesn't complain. It doesn't need health insurance."

### On Moving Fast
> "The moment a trickle of an idea kisses your prefrontal cortex, you act as quickly as humanly possible."

> "A month is not a month in 2026. A month in 2026 is 10 decades in 2005."

> "I have no secrets. Take my ideas. You're not going to beat me. I'm going to move faster than you."

### On Building the Dashboard
> "This [Mission Control office view] was created completely by Henry. I said I want a visualization for all my agents. Build it. Then it went and built it."

### On the Mission
> "An autonomous organization of AI agents that does work for me and produces value 24/7."

### On "Reverse Prompting"
> "Instead of telling your AI what to do, ask questions for it to prompt you and give you information."

---

## 7. What We Can Replicate for INKredible Printing

Aviel's setup: OpenClaw on WSL2/Linux, cloud APIs only (Claude Opus via Max, Gemini, etc.), GitHub Pages for the dashboard. No Mac Studio, no local models.

### ✅ Directly Replicable

| Feature | How We Build It |
|---------|----------------|
| **Org Chart View** | Static HTML/JS on GitHub Pages. Show agent hierarchy: Aviel (CEO) → ChetGPT (COO/Brain) → sub-agents. Each card: name, role, model, cost, skills. |
| **Agent Status Dashboard** | JSON file updated by cron (usage-tracker.json pattern). Dashboard reads it. Shows: Active/Idle/Sleeping for each agent identity. |
| **Mission Statement Banner** | Always visible at top of dashboard. "INKredible Printing AI Team — Automating the print business 24/7." |
| **Daily Digest** | Already have morning briefing cron. Display latest digest on dashboard via markdown→HTML. |
| **Task Board** | Kanban-style board showing open tasks, approvals needed, completed items. Updated via JSON. |
| **Calendar View** | Show scheduled cron jobs, recurring tasks, upcoming deadlines. Source of truth for automation accountability. |
| **Approval Queue** | List of items needing Aviel's review. React via Telegram inline buttons (already have this capability). |
| **Agent Memory Viewer** | Display contents of memory files, soul.md, agent.md — read-only view of what each "agent personality" knows. |
| **Cost Tracker** | Usage gauge already exists. Display it prominently: session %, estimated daily spend, model breakdown. |
| **Chat Log Viewer** | Recent interactions with each agent, pulled from logs. |
| **Scripts/Docs Section** | Display generated content (quotes, reports, scripts) organized by agent/date. |

### ✅ Replicable with Adaptation

| Feature | Adaptation Needed |
|---------|-------------------|
| **"The Office" Pixel Art** | We can build a simplified version — static pixel art with agent sprites, status overlays. Won't have real-time movement but can show current state. |
| **Multi-Agent Routing** | Instead of local models, use tiered cloud APIs: Opus for brain, Gemini Flash for bulk work, Haiku for quick tasks. Same "brain and muscles" pattern. |
| **X/Reddit Monitoring (Scout)** | Use X API (same as Alex), run via cron on WSL2. Post alerts to Telegram instead of Discord. |
| **Content Factory (Quill)** | Use cheaper model (Gemini, Haiku) to draft content. Aviel reviews in Telegram. Same ✅/❌ approval pattern. |
| **Water Cooler (Agent Chat)** | Log inter-agent delegations. Display conversation threads between agent sessions on dashboard. |

### ✅ Gamification Elements We Can Add
- **Agent "employee of the week"** based on task completion
- **Cost savings leaderboard** — which agent saved the most by routing to cheaper models
- **Uptime counters** — how long each automation has been running
- **Task completion streaks**

---

## 8. What's Different for Us — Adaptations Needed

### No Local Models
Alex's core advantage is $0 inference for bulk work via Mac Studio. We don't have this.

**Our adaptation:**
- Use **Gemini Flash / Gemini 2.0** as our "muscles" — very cheap, high rate limits
- Use **Claude Haiku** for quick tasks (cheapest Anthropic model)
- Reserve **Opus** exclusively for strategy/orchestration (same as Alex's Henry)
- Track cost per agent task to ensure we stay within budget
- Consider future: local models on WSL2 if hardware allows (even small ones)

### No Always-On Mac Studio
Alex has a dedicated device running 24/7. We have WSL2 on a Windows machine.

**Our adaptation:**
- OpenClaw gateway already runs on WSL2 — this works fine
- Cron jobs handle scheduled tasks (already doing this)
- Can't do real "watch a folder" integrations — use Telegram/webhook triggers instead
- Consider a cheap VPS or Raspberry Pi later for always-on (despite Alex's VPS criticism, our use case is different — we're not running local models)

### No Discord Workspace
Alex uses Discord as his agent workspace with multiple channels.

**Our adaptation:**
- **Telegram** is our primary channel (and it's what Alex still uses for quick messaging)
- **GitHub Pages dashboard** replaces Discord's multi-channel workspace view
- Dashboard sections map to Discord channels: Alerts, Scripts, Digest, Tasks, etc.
- Can add Discord later if needed, but Telegram + Dashboard covers our needs

### Different Business Context
Alex is a content creator. We run a print shop.

**Our adaptation:**
- Replace "Scout watching X for viral posts" → **Scout watching for print industry trends, competitor pricing, new product opportunities**
- Replace "Quill writing YouTube scripts" → **Quill drafting customer emails, quote responses, marketing copy**
- Replace "Pixel making thumbnails" → **Design agent reviewing artwork files, creating social posts**
- Add print-specific agents: **Quote Calculator, Job Tracker, Customer Follow-up**

### Cost Sensitivity
Alex spent $20,000 on hardware + $200/mo Claude Max. We need to be leaner.

**Our adaptation:**
- $20/mo Claude Pro (or $200/mo Max if justified by ROI)
- Gemini API (generous free tier, cheap paid tier)
- Total target: under $50/month for AI operations
- Every dollar tracked on the dashboard cost meter
- ROI tracking: "This automation saved X hours → worth $Y"

---

## 9. Dashboard Build Spec Summary

Based on this analysis, our Mission Control dashboard should have these sections:

### Page Layout (GitHub Pages, Single Page App)

```
┌─────────────────────────────────────────────────┐
│  🏢 INKredible Printing — Mission Control       │
│  "Automating the print business 24/7"           │
├─────────────┬───────────────────────────────────┤
│  SIDEBAR    │  MAIN CONTENT                     │
│             │                                   │
│  🏠 Office  │  [Selected view renders here]     │
│  📊 Org Chart│                                  │
│  📋 Tasks   │                                   │
│  💬 Chat Log│                                   │
│  📅 Calendar│                                   │
│  💰 Costs   │                                   │
│  🧠 Memory  │                                   │
│  📄 Docs    │                                   │
│  👥 Agents  │                                   │
│  📨 Digest  │                                   │
└─────────────┴───────────────────────────────────┘
```

### Data Sources
- `usage-tracker.json` → Cost gauge
- Cron output files → Daily digest, alerts
- Agent markdown files → Memory, personality viewer
- Task JSON → Kanban board
- Git commit history → Activity feed

### Tech Stack
- **Hosting**: GitHub Pages (free)
- **Frontend**: Vanilla HTML/CSS/JS or lightweight framework
- **Data**: JSON files committed to repo (updated by cron every 15 min)
- **Styling**: Dark theme, pixel-art accents inspired by Alex's office view
- **Mobile**: Responsive — Aviel checks from phone via Telegram link

---

## 10. Action Items for Build

1. **[ ] Design the Org Chart** — Aviel (CEO) → ChetGPT (COO) → define sub-agent roles for print business
2. **[ ] Create agent profile JSON** — name, role, model, cost, status, skills for each
3. **[ ] Build dashboard skeleton** — GitHub Pages with sidebar nav, dark theme
4. **[ ] Implement Org Chart view** — Interactive cards with agent details
5. **[ ] Implement Office pixel-art** — Even a simple CSS-based version with agent sprites
6. **[ ] Connect usage-tracker.json** — Live cost gauge on dashboard
7. **[ ] Daily Digest renderer** — Pull latest digest markdown, render as HTML
8. **[ ] Task board** — Kanban columns: Backlog, In Progress, Review, Done
9. **[ ] Calendar view** — Show all cron jobs and scheduled automations
10. **[ ] Define "brain and muscles" routing** — Which models handle which task types, document in AGENTS.md

---

*Analysis completed 2026-02-13. This document drives the Mission Control build spec for INKredible Printing.*
