# Batch 2 — Specific actionable tips extracted from transcripts

> Source: YouTube transcript files listed by the user. This doc only includes concrete, implementable items explicitly mentioned in the transcripts (tools by name, settings, prompts/commands, costs, warnings, model routing, and demonstrated use cases).

---

## 1) 0v2-mUUWNdc — **LIVE: The ULTIMATE OpenClaw setup**
URL: https://youtube.com/watch?v=0v2-mUUWNdc

### Communication/workspace setup (Discord + Telegram)
- **Use Telegram for “quick send”**: keep Telegram as the fastest way to send a quick message to your main agent (Henry).
- **Use Discord as the main workspace**: set up multiple channels so multiple agents can run in parallel and post outputs in dedicated channels (alerts, scripts, digest, etc.).
- **Direct lines (DMs) to each agent/session**: he shows **six OpenClaw sessions** running at once in Discord, each with a different role.

### Run multiple agents without buying multiple machines
- Instead of buying multiple Mac minis to run multiple bots, use **one OpenClaw install** and have it **spin up multiple sessions** (“separate OpenClaws”).
- **Custom behavior per session**: create separate markdown config files (he names them explicitly):
  - `agent.md` (rules)
  - `soul.md` (behavior/persona)
  - `memories.md` (memory store)
  - daily memory logs like `February 11th, 2026.md`
  Then tell OpenClaw: when creating new sessions, **use those specific markdown files**.

### Model routing: “brain” vs “muscles”
- Routing recommendation he repeats:
  - **Opus 4.6 (“Opus 46”) = brain** (planning/deciding)
  - **“Muscles” = cheaper/faster tools/models** for execution (he names): **Codex**, **GLM**, **Kimmy K2.5**.
- Practical reason: **rate limits happen when you use Opus 46 with “thinking” on**; mitigate by letting Opus orchestrate and offloading work.

### Local-model stack he’s actively running (with RAM footprints)
- On a **512GB Mac Studio**, he says he’s running **three local models** totaling **~250GB RAM**:
  - **GLM 4.7** (his “Scout” research agent; he notes **GLM 5 just released** and he plans to upgrade)
  - **Flux 2.1** (local image generation for thumbnails)
  - **a very small embedding (“embed”) model** for his OpenClaw memory system
- He says he still has **~200GB RAM free** with those three running.

### Hardware sizing + storage warnings (for local models)
- Storage: he explicitly recommends **at least 2TB** if you plan to run local models; says **1TB “is not enough”** because there are “**200GB**” and “**300GB**” models you’ll want to download.
- He personally bought **4TB** storage and says he has **two 4TB Mac Studios** (one present, another arriving).
- Memory: he says **256GB** “can do plenty” (e.g., run **Flux** at ~“30 gigs” and some Llama models) but won’t run “best of the best.”
- Reverse-prompting hardware decisions: ask your bot to compare value of hardware tiers (e.g., “what could we do with a 256 studio vs 512?”) based on *your* workflows.

### Costs & explicit dollar amounts
- He says: **“I’m paying $200 a month for Opus”** (and offloading everything else to local/open-source models “for free”).
- X API costs (his real usage):
  - currently: “**like $3,000 a month for the X API**”
  - previously: “**$5,000 a month**” (before pay-per-use change) and says the switch “cut my cost about half”
  - total: says he paid “**$60,000 for X API last year**”
- Sponsorship offer he declined (re VPS): **$30,000**.

### Demonstrated autonomous agent roles (his Discord “org chart”)
- **Henry** = “main agent / conductor / vibe orchestrator” coordinating other sessions.
- **Scout** = local model agent (GLM 4.7) doing always-on research.
- **Quill** = writing agent producing YouTube scripts.
- **Digest/Daily digest** = summary report of what agents did overnight + what needs approval.
- **Pixel** = thumbnail agent (local image model workflow).
- He also mentions **Codex** as his coding agent and references **Echo** alongside Scout in one section.

### Concrete workflow: X trend radar → alerts channel
- Scout is configured to:
  - hit the **official X API**
  - run on a schedule (he mentions **every 20 minutes** for alerts, and says you can run it “every 5 seconds” if local)
  - find **trending/viral posts** for keywords (he describes OpenClaw-related keywords)
  - post results into a dedicated Discord channel (“alerts channel”)
- Setup instruction he gives:
  1. Tell your bot: “create an AI agent that every half hour hits the X API and finds trending tweets on <topic> and alerts me in a new Discord channel.”
  2. **Sign up for X API**, add a **credit card**, obtain a **bearer token** (he calls it the API key), and give that to the bot.

### Strong warning: don’t use X scrapers / unofficial tooling
- He explicitly warns **NOT** to use skills/services that:
  - scrape X instead of using the official API
  - rely on “**scrapers and CLIs and O tokens**” instead of official X API
- Reasons he gives:
  - X “aggressively hates” bypassing the API
  - he knows people who got accounts suspended
  - he knows businesses “sued by X lawyers”
  - saving “$3 a month” isn’t worth risking your account/brand

### Strong warning: don’t use (most) skill marketplaces
- He says he **does not recommend “Claude Hub”** / skills marketplaces, claiming they’re easily compromised.
- His recommended alternative: **have your OpenClaw learn and write the skill itself** (e.g., “learn how to make thumbnails… then create your own skill for it”).

### VPS warning + local-first recommendation (security + integration)
- He says after testing, **local is significantly better than VPS** and that VPS is often not secure-by-default.
- Specific security example he cites:
  - **Amazon EC2 not secure by default**
  - claims there are “lists of thousands of servers that are exposed” and suggests searching X for: **“Amazon EC2 openclaw exposed”**.
- Local integration example he uses:
  - OpenClaw asked for pictures to train a local image model; he **AirDropped** a folder of photos to the Mac Studio; OpenClaw immediately processed them and trained.

### Prompt-injection/permissions warning (Discord)
- When asked about Discord bot risk: he says **don’t let other people in your Discord**.
- Recommendation: **personal Discord server only**; don’t let anyone else interact with your OpenClaw because it has admin access to your computer.

### Migration between devices (Mac ↔ PC)
- He states migration is **“extremely easy”** because OpenClaw is “a bunch of markdown files.”
- Concrete migration method he used:
  - moved from Mac Mini → Mac Studio by **AirDropping the folder**; agent “shows up” on the new machine after copy.

### Script factory improvement loop (explicit feedback mechanism)
- Quill posts scripts; he **reacts with ✅ or ❌**.
- He claims the reaction triggers saving to memory files:
  - ✅ means “liked” → saves what he liked
  - ❌ means “didn’t like” → saves what he didn’t like
- Goal: subsequent scripts automatically adjust to preferences.

### Local thumbnail pipeline details
- Pixel thumbnail agent:
  - he gave it a folder of **71 thumbnail images** of himself
  - it **isolated/cut out his face** from all images locally (background removal)
  - he uses that to place his face into new thumbnails.
- Flux customization:
  - he says you can train **a plugin (LoRA-style)** on “**70 pictures**” of yourself so Flux 2.1 can generate thumbnails with your face.

### Onboarding / payments command
- To understand payment/subscription setup, he tells a user to run:
  - `openclaw onboard` in terminal
  - then choose **ChatGPT** or **Anthropic** during onboarding for subscription usage.

---

## 2) b-l9sGh1-UY — **5 insane ClawdBot use cases**
URL: https://youtube.com/watch?v=b-l9sGh1-UY

### Use case 1 — Morning brief (scheduled) with concrete prompt
- Schedule: **“every morning at 8 a.m. my time.”**
- Prompt elements he explicitly lists:
  - local weather
  - a few **trending YouTube videos** about your interests
  - tasks you need to get done today based on your to-do list
  - tasks your bot can do today (explicitly asks it to be proactive)
  - trending stories based on your interests
  - recommendations to make today productive
- Tool integration:
  - Connect to a to-do list app (he uses **Things 3** on Mac).
  - For trending stories: he recommends connecting to the **Brave Search API** for more efficient web search.

### Use case 2 — “Proactive coder” that builds while you sleep (scheduled)
- Key instruction: give permission to build without being asked.
- His explicit constraints:
  - “**Just create PRs for me to review. Don’t push anything live. I’ll test and commit.**”
  - Schedule work time: **“Every night… schedule time to work every night at 11:00 p.m.”**

### Token/cost saving routing: Opus as orchestrator + Codex CLI for coding
- He recommends installing **Codex CLI** (requires a **ChatGPT subscription**) and then instructing your bot:
  - **“Use the Codex CLI anytime you vibe code.”**
- Rationale: Opus is expensive; have Opus do planning and use Codex CLI as the coding tool to **save Opus tokens**.

### Use case 3 — Build a “second brain” app (specific tech and prompt)
- He recommends a **Next.js app** that acts like a mix of **Obsidian + Linear**.
- Concrete behavior:
  - create a folder of documents viewable in the app
  - as you work together, auto-create:
    - daily **journal entries** summarizing discussions
    - deeper documents exploring important concepts
  - auto-tag documents (he lists examples: journal content, newsletters, notes, YouTube scripts).

### Use case 4 — Daily afternoon research report (scheduled)
- Schedule: “every afternoon” (his “afternoon brief”).
- Prompt goals:
  - deep dive on an interest (e.g., machine learning/AI)
  - workflows/process improvements for working relationship
  - self-improvement ideas for the bot itself
  - weekend build project suggestions

### Use case 5 — External skill: parallel trend research (X + Reddit)
- Skill author named: **Matt Van Horn** (he says he’ll link the profile).
- What the skill does:
  - researches **X + Reddit in parallel** for trends over the last **30 days**
  - outputs top threads/posts by engagement + content ideas
- Required keys he explicitly calls out:
  - **xAI API (Grok API)**
  - **OpenAI API key** (he says “so they can check out Reddit”)
- Install method:
  - give the skill link to Claudebot and say: **“Please install this skill.”**

---

## 3) lFGK0IvPaNc — **Claude Skills explained: most POWERFUL tool you're not using**
URL: https://youtube.com/watch?v=lFGK0IvPaNc

### Skills are packaged as a downloadable folder of markdown files
- He repeatedly frames a Claude Skill as essentially:
  - a `skill.md` (he says “skill.mmarkdown”) file inside a downloaded skill folder

### Building skills inside Claude (UI clicks + flow)
- He demonstrates:
  1. Ask Claude: **“Create a skill called <name> …”** (with criteria/output format)
  2. Claude generates a downloadable package
  3. Install via Claude UI:
     - **Settings → Capabilities → Skills → Upload skill**
     - select downloaded skill package
     - skill appears enabled

### Skill #1 prompt details — “Idea validator” (brutally honest)
- Evaluation criteria he explicitly includes:
  - market crowdedness + competitors
  - differentiation
  - demand (do people *actually* want it?)
  - feasibility for a solo builder: “**ship in 2–4 weeks**”
  - monetization
  - “interest factor”
- Explicit instruction: make it “**brutally honest**” (avoid generic affirmation).

### Skill #2 — “Launch planner” with explicit tech stack + deliverables
- Tech stack he specifies:
  - **Next.js + Supabase + Vercel**
- What the skill must produce:
  - MVP scoping to avoid overbuilding
  - PRD (product requirements doc)
  - starter prompts for Claude Code
  - keep you focused on shipping
  - he shows it can output DB schema

### Skill #3 — “Design guide” to eliminate ugly UI defaults
- Explicit goal: avoid “blue and purple gradients” and generate better UI by default.

### Installing skills into Claude Code (specific file operations)
- Editor environment he demonstrates:
  - **VS Code** with **Claude Code extension** (says Cursor also works)
- File/folder steps he shows:
  1. Create a **Claude** folder (his working directory)
  2. Create a **`skills/`** folder inside it
  3. Take a downloaded `design_guide.skill` file and **rename it to `design.zip`**
  4. **Unzip** it
  5. Drag the contained **`skill.md`** into your project’s **`skills/`** folder
- When prompting Claude Code, he adds: **“use the design guide skill”** and Claude Code asks permission to use it; he approves.

### Skill #4 — “Marketing writer”
- Deliverables he lists:
  - landing pages
  - tweet threads
  - Product Hunt descriptions
  - launch emails
  - brand voice guidelines + examples
- Installation into Claude Code: same **rename `.skill` → `.zip` → unzip → drag skill folder/file into `skills/`** workflow.

### Skill #5 — “Roadmap builder” (product manager)
- What it outputs:
  - MVP features worth including
  - features to exclude
  - high-impact features categorized by impact/effort

---

## 4) wfiv67NixCY — **How I use Claude Code to automate my entire life (5 tricks)**
URL: https://youtube.com/watch?v=wfiv67NixCY

### Setup: make Claude Code context-aware (concrete files + command)
- In Cursor, create a folder (he names examples): `claude-life` / `life-os`.
- Create a markdown file: **“background on yourself”** (his file name).
  - Include: who you are, interests, links to your content, links to side hustles, anything relevant.
- Then run in Claude Code: **`/init`**
  - he says it creates a “cla rules” file using that context.

### Use case 1 — Weekly check-in dashboard (slash command)
- Run every Sunday night: **`/weekly check-in`**
- Behavior:
  - spawns a **sub-agent**
  - asks you for your current metrics
  - updates a “personal weekly dashboard” tracking business/personal/career metrics over time
  - also generates content ideas + “wins of the week”

### Use case 2 — Daily journal check-in (slash command)
- Run: **`/daily check-in`** (he uses it for journaling/mental health)
- Questions it asks (examples he shows):
  - what did I accomplish today?
  - how are you feeling right now?
  - biggest wins today?
- Output: stored in a daily journaling dashboard.

### Use case 3 — Newsletter/content researcher + draft writer
- Create a markdown file listing:
  - your newsletter
  - competitors’ newsletters in your niche
- Run: **`/newsletter researcher`**
- Behavior:
  - reads competitor newsletters and your own archive
  - identifies current trends/angles
  - writes a newsletter draft in your voice

### Use case 4 — Brain dump / notes analyzer with mind-map output
- Keep a folder of “brain dumps” (or import notes from Notion/Obsidian).
- Run: **`/brain dump analysis`**
- Outputs:
  - a “mind map visualization” structure of thoughts (philosophy/identity/strategies)
  - saves analyses to an `analysis` folder inside the brain dumps folder
  - he notes you can customize the prompt to produce meeting next steps, outreach lists, etc.

### Use case 5 — Daily brief agent (trend/news research)
- Run: **`/daily brief`**
- Behavior:
  - uses the interests from your “background on yourself” file
  - researches latest stories (he mentions searching over last **7 days** for topics)
  - compiles and saves a daily brief you can use for content ideas.

---

## 5) thxXGxYIwUI — **Claude Code Skills are INSANE**
URL: https://youtube.com/watch?v=thxXGxYIwUI

### Why skills (vs claw rules): concrete efficiency claim
- He says **claw rules are inefficient** because they load on every prompt.
- Skills are “memory efficient” because they’re **only loaded when relevant** (example: a Stripe skill loads only when prompting about Stripe).

### How he structures skills in a repo
- In VS Code: create a `skills/` folder in the project.
- Install method he repeats:
  - download the skill folder and place it into the project skills folder (he also refers to a hidden “dot” skills folder).
- Runtime behavior:
  - when you ask to use a skill, Claude Code prompts for permission; he clicks **“yes”** and often **“don’t ask again.”**

### Skill 1 — Front-end design skill (UI/landing pages)
- Purpose: eliminate default “blue/purple gradient AI slop” and generate “beautiful UIs” in one shot.
- Usage instruction: while building UI-related work, explicitly prompt: **“use the frontend design skill”**; also use it to **redesign existing frontends**.
- Install: he says it’s “straight from a product manager at Claude Code” and involves running **two commands**, but the transcript does **not** include the literal commands.

### Skill 2 — Domain name brainstormer (saves hours)
- Demonstrated prompt pattern:
  - “Find me available domain names using the domain name brainstormer skill.”
- Behavior:
  - brainstorms names
  - checks availability across TLDs including: **.ai, .com, .dev, .io**
  - returns a shortlist of available domains.

### Skill 3 — Stripe integration skill (payments/webhooks)
- Purpose: consistent Stripe setup the “right way” across:
  - payment flows
  - subscriptions/products
  - customer management
  - **webhooks** (he calls this the most technically challenging part)

### Skill 4 — Content research writer (blog/newsletter in your voice + citations)
- Demonstrated setup:
  - create a markdown file for output (he names `blog.md`)
  - reference a prior writing sample for voice (he names `newsletter.md`)
- Demonstrated prompt pattern includes:
  - “Add research and citations”
  - “refined and polished in my voice”
  - “Use newsletter.md as reference”
- Output includes citations (he shows “16 different citations”).

### Skill 5 — Lead research assistant (finds customers + outreach copy)
- Demonstrated prompt:
  - “Find me 10 companies in the United States that would benefit from this product. Use the lead research assistant skill.”
- Output fields he shows:
  - priority score
  - location, employee count, funding
  - why they’re a fit
  - **target decision maker + LinkedIn profile**
  - suggested outreach/conversation starters

### Skill 6 — Skill creator (meta-skill)
- Purpose: teaches how to create your own skills from repeatable workflows.
- Homework he assigns:
  - use the skill creator to build yourself a **Supabase skill** to improve Supabase setup/migrations.

---
