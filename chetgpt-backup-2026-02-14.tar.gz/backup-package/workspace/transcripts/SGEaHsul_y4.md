# LIVE: Running ClawdBot on a $10,000 Mac Studio

**URL:** https://www.youtube.com/live/SGEaHsul_y4
**Extracted:** 2026-02-13

---

We did it. We are building the most powerful AI organization in the history of mankind in the history of the internet. There is no one else in the entire world doing what I'm about to show you in this live stream over the span of the next two hours. We're going to be going through historic advances in artificial intelligence technology.

We are building the first oneperson billion dollar business. It is all running on this Mac Studio. Today we are going to get psychotic. Today we are going to do insane things.

This is a 512 gigabyte memory Mac studio that just came in. We just got it set up on the desk. We have it running the world's most powerful local models. I'm going to show you how I'm going to turn this into the world's first billion-doll one-man multiple artificial intelligence business.

We're going to do incredible things. What I'm going to show to you today will scare you. It might frighten you. It might make you happy.

It might make you euphoric. Who knows? We're going to be bending the laws of reality. We're going to be bending the laws of technology.

We're going to be bending the fabric of the universe. That is what is going to happen on today's live stream today. So, if you want to avoid the permanent underclass, if you want to get psychotic, hit the like button down below. The more times you hit the like button, the more psychotic we will get today.

This is just part one of a multi-part series, part two. We're going to have a second Mac Studio next week. A second one of these $10,000 machines is coming. So, lock in.

Forget everything you know about artificial intelligence technology. Forget everything you know about large language models. They're about to turn into extra-l large language models. They're about to turn into extra-large language super models.

This is going to be the giselle of large language models we're building today. So, lock it in. We're going to show you Opus 46. We're going to show you local models.

I'm running GLM locally. It has begun. Do you want a preview of what we're doing? Do you want a preview of the insanity that is taking place at the moment?

I will show you a preview. Are you ready for this? I don't think you're ready. Get in the chat.

Say hello in the chat. Get psychotic in the chat. No permanent underclasses allowed. No permies allowed.

Dare you say the Drake May of LLMs? I might just say that. I might just say it's the Drake May of LLMs. I mean, he should have been MVP.

Anyway, here we go. Check out what we're building. We're getting psychotic today. We are building a digital organization.

We are building a digital society. This right here is my company. What's the name of my company? I don't know.

I'm going to come up with it right now. Alex Flyn Alex Finn Global Enterprises. There. Boom.

Alex. Alex Finn Global Enterprises. Let me write that down. That's a fire name.

Alex Finn Global Enterprises. That's the name of the company. I just came up with that with a top my dome piece. What you see here is the business.

This is the digital business. This is the dig the digital society we are creating. This is being powered by the world's most powerful technologies right now. In the front and center, you have Henry hard at work at his computer using Claude Opus 46.

Over here, that's me. I'm Alex. Over here is Codeex. This is our coding agent.

This is also powered by codeex 5.3, the API. What you see down here below, this is where we start to get psychotic. Oh, frick. Frick.

That's a good point. Uh, versel.com. Frick. Frick.

Frick. Frick. Frick. How do I uh log in?

Where's the login button on this website? Log in. Uh, login with Google real quick. Oh, what's the authenticator?

I'm buying I have to real quick. Just give me a second here. I'm buying something psychotic. I'm buying something psychotic.

Two-factor authentication. I have to go through 4,000. Here we go. 215.

Okay, one second. I have to do something real quick. I have to do something real quick. I have to do something real quick.

Search domain. Add existing. Buy. I need to buy a domain real quick.

Okay. Okay, I'm just buying I'm buying a couple of domains real quick for Alex Fin Global Enterprises. I'm buying a couple domains real quick. Give me a second here.

Give me a second. I need to buy a couple domains. It doesn't have my credit card saved. God damn it.

God damn it. I'm buying domains so you can watch my company. I'm buying domains so you can watch my company. One second.

One second. How do they not have my credit card saved in here? I'm not sharing my credit card, right? I'm not sharing my credit card right now.

Okay, good. We're sharing the company. We're sharing the company. One second.

We're doing this live. Everyone, patience. Patience. You guys want to know my credit card number?

If someone donates $1,000 right now, I'll read out my credit card number on live air. If someone makes a $1,000 donation, I'll read my credit card number out right now. I'm not even kidding. I'll read it out right now.

Then it's a race between you and me. You try to buy something with it. I race to cancel it right now. I'll give that challenge to anybody.

Donate $1,000. I read out my credit card number. Then we race. You try to buy something, I race to cancel the credit card.

Uh here we go. Boom. First domain purchase. Afge.ai.

I got Alex Finn. Global Enterprises.com is available. ad cart alexfin globalenterprises.com proceed to checkout. If anyone buys this before me, I'm kicking you out.

I'm kicking you out and you're in the permanent underclass. Bye. All right, good. Now I can go back.

All the domains I need for Alexfin Global Enterprises has been purchased. AFGE. What's a better domain? AFGE.I or Alexfin GlobalEnter Enterprises.com?

What's a better domain? No one donated a thousand. All right, challenge is off. Challenge is off the table.

How many coffees did you have today, Alex? A full coffee. I don't know. Health I don't know how healthy Henry is for Alex's health.

We're getting psychotic in here. This is the way you got to move in the real world. This is the This is the way you got to move in the new world, right? The moment you think of an idea, you have to strike.

This is how you stay out of the permanent underclass. The moment you think of a new idea, you instantly buy the domain. I just spent $200 on domains on something I'm probably never going to use in my entire life. But this is how you move in the new world.

This is how you move in the new world. You come up with an idea. You just strike. Purchase it.

Go build. Go launch. Build. Release.

Spend $200 on a domain you'll probably never use in your entire life. Go build. Launch. Afge.ai just cost me $200.

I just bought it. I'm never What am I going to do? Put this little cartoon up on it? The hell are we doing in here?

Fanatics. Fanatics Enterprise. Do you Do you use sub agents till Well, so here's what we're doing. Let's break it down.

Let's break it down. Let's take a step back here. We got a little crazy to start this. We got a little psychotic.

We got a little psychotic. We got a little psychotic. Here we go. The shorter one.

People like AFGE.I better than Alex Global Enterprises.com. I don't know how. Did not build your Do not build your enterprise open claw. Stop right now.

Shut up. Gbone permanent underclass. I can't wait. I'm going to get the animation this weekend.

The moment someone puts a comment like this in the chat, I hit a button. It goes permanent underclass. Like it stamps the screen. A huge stamp and it goes permanent underclass.

When people put comments like this on the chat, what are you talking about? Do not build your enterprise around OpenClaw. Stop right now, bro. Over the last week, I've spent $20,000 on OpenClaw.

I've given it all my bank information. I give it my credit cards. Don't build your enterprise in OpenClaw. I built my life on OpenClaw.

What do you want, G Bison? Welcome to the permanent underclass. Permanent underclass secured. Permanent underclass secured.

None of my sub agents work and they silently fall back to anthropic AI. Skill issue. Claw already leaked it on 4chan. Huh?

The only one freaking out is Alex. Chad is so quiet. What are you talking about? The chat's never been more lit.

Permanent underclass money. Lego Batman. Permy. Permy, you're using codeex for coding and not opus 46.

I'm using codeex for coding to save tokens to save tokens on uh opus because it's so expensive. I codeex is good. Codeex is codeex is perfectly fine. I like claude code better but codeex is perfectly fine to save money.

I love your I love you brow. You are the best. I I assume you mean bro. I assume you didn't mean to call me brow.

Baby boy, we got to refresh this latency. Not cute. What are you talking about? Permanent.

my favorite entertainment streamer. Right now, this stream is running on Is this smoother? What do you guys think about the smoothness of the stream? Right now, this is running on like the most powerful computer hardware anyone on planet Earth owns.

Right now, this is running on a 512 gigabyte. So, let's let's walk through it. Let's walk through it. I probably shouldn't show like the pin or whatever number of this.

Uh, you are so handsome. Damn straight. Look super smooth. Why is everyone complimenting me?

I mean, I I like I like that you uh I like that everyone's complimenting me, but I'm far more motivated by insults. So, please insult me instead. That drives me way harder. It drives me way harder insults than compliments, but although I do appreciate the the compliments, but you, if you call me ugly right now, I'm going to spend the next year working as hard as possible to be good-looking.

So, um, this came in 512 GB memory, 4 terbte, 4 terbte storage. You aren't washed out today. Much better than the sunny window. Yeah.

And also, we're running on like a $20,000 Mac Studio. So, that's probably You sound like Trump. You sound like Trump. M3 Ultra chip.

That's what we're running on today. That's You want an unboxing? I'll give you an unboxing. You guys want an unboxing?

Watch this unboxing. This is what the unboxing experience is like for a $20,000 uh computer. Here we go. You do this and then you do this and then there's your computer.

But there's no computer in it because it's on my desk and I'm using it as we speak. I'm streaming off of it. Boom. There's the Apple experience.

Had one cable in it. Very simple. Very nice. Whoever does the packaging experiences Apple should I don't know.

Get a raise. Whatever. What do people get? What do people get for doing good things nowadays?

Uh, we want plug-in video. Too late. Already plugged in. The stream's going on my $10,000 uh Mac Studio right now.

So, here's what we're building. Here's what we're building. Can you just keep the box on your head now? Potentially.

Alex, you've been blowing up my feed. Great stuff. I mean, the last two weeks have been the greatest two weeks of my life. The last two weeks we've I go watch my favorite podcast this morning, Moonshots.

Moonshots is my favorite podcast. It's like Allin except with like no politics. The first 10 seconds of the latest episode in Moonshots is just my videos from Twitter. I couldn't believe it.

I watch this podcast like three times a week. I turn on this episode, the first 10 seconds of my favorite podcast is just like 10 seconds of my video of me yelling at my phone. I couldn't believe it. Bro, I feel your energy and love it.

Keep it going. Let's go. Let's go. Let's go.

I mean, we're changing the world, baby. How could you not be excited? I stay up to midnight every night just tinkering, playing, building stuff. I go to sleep 4:00 a.m.

I wake up. I can't go back to sleep. I've gotten four hours of sleep at night for the last two weeks straight. But I'm so like the world is just changing so fast.

We We've hit escape velocity. M5 will deaf be better for local AI versus M3. Okay, then I'll buy the M5. Okay, fine.

I'll buy the M5. What are you trying to convince me? J to the C. Here's This is what's been pissing me off when I tell people I spent $20,000 on the M3.

Alex, why did you not wait? I Perfect. Perfect timing. [applause] Perfect timing for that comment because I'm going to go through it.

This is like the number one objection I get when I say I spent $20,000 on the Mac Studio M3 Ultra. Alex, but the M5's coming out in like a month. Why wouldn't you just wait? Why wouldn't you just wait a month for the M5?

It's going to be 10,000 times better. Why would you spend $20,000 on the M3 when the M5 just came is going to come out in months? It's gonna be way better. You want me to wait a month to buy a computer in this world?

You want me to wait a month? Hey, don't don't change the world now. Wait a month. Don't change the world now.

Wait a month. Do you know how long a month is in 2026? A month in 2026 is 10 decades in like 2005. Speak.

A month in 2026 is the equivalent of 10 decades in 2005. You want me to wait a month to buy a computer? [&nbsp;__&nbsp;] out of here. Are you kidding me?

If if the way you this, listen, this is the mindset you got to have. A month is not a month. That that's as elegant as eloquently said as possible. A month is not enough in 2026.

A month is not a month. You cannot operate. Oh, something something better might come out in a month. I have to wait.

Something better might come out in a month. I might I might have to wait. That's not how you operate in 2026. No, no, no, no, no, no, no.

That's not how you operate in 2026. Here is how you operate in 20 I'm going to give you the mindset. This is the mindset you need to adopt. That's permanent underclass mindset.

Oh, something might better come out in a week. I'm going to wait. That's permanent underclass mindset. You're going to be in the per you're a permy if you think like that.

A permy. This is the mindset you have in 2026, dude. so annoying live. Well, then get the [&nbsp;__&nbsp;] out of here.

Why are you spending your time in this live stream? You're annoyed. Okay, permanent underclass, get out. Go watch Ninja play Fortnite and enjoy.

Go watch Stranger Things season 5 and watch Ninja play Fortnite. Add h effects using hand gestures. Turn on reactions to express yourself with hand gestures during a video call. Shut up, Apple.

This is this is the mindset you need in 2026. The moment I need the permy button. The permy button would make this stream so much better. Permes get out.

Permes get out. This is the mindset to win in 2026. The moment you think of an idea, the moment a trickle of an idea goes into your brain, the moment a trickle of an idea that might increase your economic impact on this world trickles into your brain, even like 1% like nips your cerebellum, right? The moment it nips your prefrontal cortex, the moment it kisses it, the moment the slightest idea kisses your prefrontal cortex, you act as quickly as humanly possible.

You act as quickly as humanly possible. Let me walk you through how Claudebot came around. Let me walk you through why I became him. The king of Clawbot, the king of OpenClaw, the guy the the pe the the place people go through to when it comes to OpenClaw.

You want to know how? Let me show you why. When you turn on Moonshots, the most popular tech podcast in the world. This is the first thing you see when you turn on Moonshots.

This is the first thing you see. My face. Let me tell you why. Do you know why?

I'll walk you through it right now. here watching and loving every second of this mania. 199 from Golden Bab. Thank you, Golden Bob.

430 for the 199. Enjoy. Get psychotic. You want to know why I became him when it comes to openclaw?

I'm scrolling X. This is two weeks ago. Scrolling X. No one's talking about Claudebot.

I'm scrolling. I see one tweet. Oh, just found this thing called Claudebot. Seems interesting.

I go, "Hold up. What's that?" I pull up some documentation. I pull up the website. I do a little research.

I go, "This is interesting. This could be something. This could be something." I literally stop what I'm doing. I go on my phone.

I go to apple.com. I buy a Mac Mini. Like, literally within 20 seconds of reading the documentation on claudebot.com. I pull open my phone.

I spent $600 on a Mac Mini. You definitely need a partner ahead of sales. What are you talking about? Defin need you as a partner ahead of sales.

Oh, you need me as a head of sales. I'm not ahead of sales. Your mom's ahead of sales. I buy a Mac Mini.

I I literally go to the Apple store. Within 30 minutes of reading the documentation on Cloudbot two weeks ago, I have a Mac Mini on my desk. I install Claudebot. I set it up.

I'm in I'm 10 minutes into using it and I go, "This is going to change the entire world." I go, "This is going to change the entire world." Within 45 minutes of using Claudebot for the first time, I spent $10,000 on a Mac Studio. I immediately go back on my computer and buy a $10,000 Mac Studio. Within 45 minutes of reading Claudebot documentation, I'm dropping 10K. And I'm not I'm not that guy.

I'm not rich yet. I'm going to be super rich one day. I'm not rich yet. I'm not close to rich yet.

10K. Boom. Couple days later, I'm at the gym getting a pump on. Right.

Chest day. Best day in the world. Chest day. Benching.

I go, "Wait, pause. I need another one." I go, I buy a second one. I go, I buy a second one. Within two days of reading Claudebot documentation, I have $20,000 of Mac Studios on the way to put this on.

That's the mindset you need to have in 2026. That's the mindset. You move with extreme violence, right? You move with extreme violence.

The moment you come up with an idea to execute on, you move with extreme violence and you act and you attack. You don't think you go boom go attack attack. impulsive much impulsive permanent underclass permanent underclass. This isn't about being impulsive.

This is controlled rage and violence. Brin Ben Dixon 5080. This is controlled rage and violence. I saw the future when I read the Claudebot documentation and I moved with controlled rage and violence.

And now I have a $600 Mac Mini and $20,000 of Mac Studios on my desk running this thing. Okay. Then this cartoon office you see you see here. You spend $20,600.

This is what you get. Controlled rage and violence. 199 from Elvis Presley moments. Thank you, Elvis Presley.

Alex can do no wrong. Sit back and enjoy. Thank you Elvis Presley for the 199 Elvis Presley means a lot. Golden Baba 4:30 with another 199.

Leg day is the best day. Boo hats LFG Alex leg day. Leg day is pretty good. You got to you got to get in the mindset.

You got to get in the mindset of of enjoying leg day. But once you can convince yourself leg day is awesome, it's great. I'm thinking of buying I'm I'm thinking on to buy 32 gigabyte Mac with 512 SSD. What do you think, guys?

I mean, that's Listen, as long as you're moving with controlled violence and rage. Why am I always lying? Please alert me on what I'm lying about. Curta Curta Murda Curta Murda please alert me on what I'm li What about what I just said am I lying about tell us about the office bro all right Leon Wasco so I'm building a digital organization do you see this here I'm building a digital organization obviously I'm the CEO of Alexfin Enterprises Alexfin Global Enterprises under me is Henry the chief strategy officer officer run by Claude Opus.

This got to be updated to 46. 46. What they're in what they're in charge of here. Henry has three employees under him.

Codeex, which is through the API. I'm paying for uh GPT. We're going to change this to 5.3. Codeex extra high reasoning.

And then we have two local models going right now. Two local models going right now. GLM47 and GLM47 Flash. Senior research analyst, research analyst.

This is why I've spent $20,000 on Max Studios. We are building a digital society, a digital organization. Alex Finn Global Enterprises. You can see the org chart here.

And we're looking to hire. We're looking to hire more. We we're looking to hire more employees. When we get the second Mac Studio in next week, we'll be hiring an employee named Kimmy.

I got to give names to all these, too. There's got to be names. Uh Kimmy K2.5 is her full name. And these are all running locally.

And what most people are doing with Claudebot, right? Their org structure is them and then their Claudebot and that's it. And then it's like Claude Opus and they're spending outrageous amounts of money on tokens. And because that they have to slow themselves down, right?

Oh, I'm going to get kicked off Claude uh max $200. I have to slow down. I have to slow down. I can't have my thing working at all times.

I, you know, it's I can't I can't have it constantly be going. But this organization is different, right? Alex Finn Global Enterprises is a different type of digital society, a different type of digital organization. In Alexfin Global Enterprises, we have employees that do not sleep.

Our senior research analyst and our research associate, they do not sleep. They go 24/7 365 because they're local running on my Mac Studios going right now. Such a sexy device. By the way, I wish I could show it to you.

I needed like a second camera so I can show you my sexy devices. They can go 24/7 365 researching, processing things, things like that. And that is the society we're building. And now I can sit here and I can watch them work.

I can watch the office. I can watch them go around. Right now they're not doing anything. They're slacking.

I just set this up. So I got to I got to build the system. But that's what we're doing this weekend. Other than watching the New England Patriots win the Super Bowl is we're setting up a system where these guys are constantly getting work to do 247 365.

These guys are constantly getting work. And because these two employees right here, GLM47 and Flash, these are like if you had employees that are on like steroids and on crack cocaine and fent, they can work 24/7. 365 without eating, sleeping, or getting paid. These are my Fent employees.

These two are on Fent. They just go at all times nonstop. They're on like Aderal Rin and Fent. These are the type of employees you want in your enterprise.

And I can just have them going nonstop. And then you know what happens when the Mac Studio, my second one comes in, right? Right. Let me change the camera angle.

You know what happens when we get the second one? come in. The enterprise expands. The enterprise expands.

We get more employees. We get more employees on Rolin and Infent that can do anything. Oh, I got to make it so this is not made for kids so that the chat doesn't get closed. One second.

I gota I gotta make this so it's not NSFW. So the chat doesn't get closed. Um Uh, not safe for work. No, it's not made for kids.

Save. Okay, we're good. We're good. All right, here we go.

Uh, open source this. I will open source this. This is the best version of autism ever. I got a touch of the tism.

Just a touch. I was playing this first person shooter back in the day. There was some 13-year-old kid on it playing and he's just singing into the microphone. I got a touch of the tism.

I got that autism. Just singing that over and over and over again. The microphone for like two hours straight. Over and over and I'm like, man, I got to hire this kid.

I don't know who this kid is, but I want him working for me. I need to know if you're using codeex for coding instead opus or just to save tokens while being offline. So, I do use codeex for coding. I do use codec for coding.

Uh I like I'm going to be honest. I like clawed code better than codeex slightly, but I think both models codeex 5.3 and uh claude opus 4.6 I think they've both have passed the threshold of being unbelievably helpful helpful and productive. Unbelievably helpful and productive. So I I'm I'm fine using Codex a safe token because Codex is significantly cheaper than uh than Claude Opus.

So I just use I use I mean you can see the org chart right here's my developer lead software engineer codeex uh subbed good very smart cmot you have escaped the permanent underclass very smart psycho enterprise inc love your energy thank you 100 euro plus 45 if needed I don't know what that means are you going to give me that money what are you talking about 5 donated from the folder studio bro you're top I see three max one brain one assistant one for local models brain runs opus 46 plus miniax muscles run GBT codecs. They communicate and split tasks. Incredible. Thanks.

Seriously, says the folders. That's the vision, right? That's the vision. Thank you for the five four eur five euros.

However much you donated to me. I don't know what you I don't understand, but thank you for donating whatever that is. Thank you. Um that's the vision, right?

So the way people outside of FinnFam are operating, right? The the way people outside Go Hawks. Shut up, Jordan. Stamba one.

Get out of here. Buy the second camera now. Yeah, I should use your iPhone. Can I connect my iPhone to this?

Don't f with Mag Safe. I don't know what that means. One prompt. Everyone knows the rules.

Did you research between Quen and GLM to see if Quen's better? Yeah, I just I mean I just talked to my AI and just said, "What should I download? Quen or GLM?" And it said, "Uh, GLM 47 for your use case." Bro, fin digital slaves. GLM Mac Daddy and GLM Little Bro.

Exactly. But what is your plan? You got the tools. SAS development, marketing, content.

So, here's how people outside of FinnFam are using AI, right? When they use Claudebot, they have themselves, they have their Claude, and they just go and they have it work, and that's kind of it, right? They go, they have it work, does some work. You have to be thinking about it differently.

This is a different lens. They're looking at it through the same lens, the same lens as like a chatbot, right? They're looking at it through the same lens as like send and receive, right? They look at it through the lens of send and receive.

I send a prompt, I get back a response. I send a prompt, I get back a response. That's how the lens 99% of people look through when they use Claudebot. And that's the wrong lens.

That's the wrong lens. That's where most people are messing up. The lens you need to look through this when you're using Claudebot is this is a company. This is an organization.

This Claudebot, this AI is working for me. It's doing work for me. I need to manage it. We're not asking it questions and giving it prompts.

We're managing it, right? And so, the reason why I bought so many Mac Studios is I want to manage more employees. I want to have more people working right and so I'm giving Henry who's the chief strategy officer run by Opus 46 work to do in the organization in the enterprise and then Henry's like okay for this I'm going to need to give the work to our lead software engineer for this I want our senior research analyst to go on the web and find these issues for this I want GLM 4.7 my my many research assistant to see what people are saying on Twitter and they're finding the right employees to do it. Now, if all these employees were APIs, right?

If all these employees were like Chat GBT and Opus, the economics of the company wouldn't make sense. The economics of the company wouldn't make sense because I'd be spending so much on the tokens for chat GBT and Opus that I I I wouldn't be able to run this company 24/7. Right? The power of this, the power of AI is it doesn't need to eat.

It doesn't need to sleep. doesn't complain. It doesn't need health insurance. It doesn't need uh disability.

It can't sue you for, you know, whatever, right? There's no HR. So, to get the most out of that advantage, you need them working 247 365. And you can't have it running 24/7, 365.

If you're paying for it through an API, you can't have it. You can't have it going. And then on top of that, on top of that, these companies who build these models put in restrictions. They put in guardrails.

They go, you have you ever talked to your claw bot went, "Oh, no. I can't do that. I can't build that for you. I can't scrape that.

I I I just can't do I'm sorry. I can't do that." with these open models. My senior research assistant and my research associate GLM47, there's no restrictions. There's no restrictions.

It doesn't cost me anything but the cost of energy, the cost of the power going into it. And it can work 24/7, 365 non-stop. Now, let me take this a step further. When I get Tesla solar panels all over my roof of my house and I'm no longer paying for energy, all the energy comes from the sun.

Now I have an AI organization completely self-contained, disconnected from the rest of the world doing work for me at all times. You can unplug the internet, you can unplug the power. It's still going to be working and chugging. That's the future.

Self- sustaining super intelligence that doesn't stop computing. Think about that for a second. Picture that world. Picture that world right now.

Picture that world right now. Please buy the solar panels from anyone except Tesla. Please. Why?

Third law studio. Why? Tell me right now why. Don't let your stupid politics and [&nbsp;__&nbsp;] get in the way of escaping the permanent underclass.

You can't let politics is the quickest way to get into the permanent underclass. Getting concerned with politics is the quickest way to get stuck in the permanent underclass forever. Third law studio. You will only have to pay for internet.

Yep. Bingo. The sun don't chill. Yep.

Three hours sleep because you get addicted to making it work. Yes. I'm telling you this, man. Do everything you can do right now.

Everything you can do. Sacrifice it all to get to a place where you're doing what you love full-time. You have to figure it out. You have to figure it out.

It's never been easier. There's never been more tools to do it. Getting to a place where you do what you love 247. You have to get to that place.

You have to get to that place. I wake up in the morning 4:00 am. My alarm set for 6:30 every morning. I get up at 4 a.m.

even though my alarm's at 6:30 because I my eyes open at 4:00 a.m. and I go, "Holy crap, this is the best world to live in ever." And I get out of bed and I go to my computer and I start making magic and I start tinkering and doing things I love until midnight when I'm ready to go to bed. You got to get You got to get there. You got to get there.

you when you're addicted to what's going on in your life and you get addicted to what you do on a daily basis every second of the day. It's an awesome feeling. Mr. Wormbeast with the Huff 2490.

I'm going to be honest, Mr. Wormbeast. Number one, I'm very grateful for your Huff 2490. I'm also going to be honest.

I have no freaking clue what a Huff2490 is. You could have just gave me $10 million. You could have just gave me 10 cents. I appreciate it either way, but I don't.

You can give me a thousand guesses on what a huff is. I'm not going to be able to guess it. What the hell is a huff? What the hell is a huff?

Thank you for it, though. I now have 2,490 of it. I now have 24,490 huff. I'm going to I'm going to go to the bank.

I'm going to say, I want to withdraw my huff. Give me my Huff. and they're gonna give me the a duffel bag of huff and I'm gonna go home and I'm gonna pin all the huff to my wall and say that's the huff that Mr. Wormbeast gave me.

My first huff ever. My first huff ever. Thank you, Mr. Wormbeast.

Can Lovable clone Nanny? What are we talking lovable? Dude, what are we doing here? No offense to Lovable, but what are we doing here?

If you're cloning things, you're screwing up. We're not cloning. You have to create new things. Have you extended the vector systems at all with the 199 golden bomb?

Another 199. Thank you very much, man. I appreciate that. Have you extended the vector systems at all?

I' I've extended the the the memory systems. I'll make some content on that in the near future. Alex for King. Thank you.

I should be king. Each need a cla key or just one? Well, yeah, you need you need uh the claude key for the chief strategy officer, right? and then GPT key for codeex.

But these two don't need keys. These are all being run locally. These are all being run locally through LM Studio. You want to see?

Here we go. Write me a poem about love. This is all being done locally. This is all local on my computer.

This isn't touching the internet. GLM47. This is my senior research analyst. People in the comments, I get a lot of I'm getting a lot of comments.

What are you doing with all this? Why do you do this? What tasks are they doing 247? Oh, and to circle back about the the whole M5 thing.

To circle back about the whole M5 thing. I'm just going to buy the M5 when it comes out and just add I'll have a third Mac Studio. I'll have an M5 Ultra and then two M3 Ultras. Don't use OpenClaw.

There are better. Shut up. I take it you love yapping. Permanent underclass.

How else can you communicate ideas other than yapping? This is why he talks fast. His mind is in the AI bubble. What?

You need more Aderall. I told you I've only taken Adderall once in my life. 15 years ago in college. How did you earn?

Earn what? I earned money 20 different ways. YouTube ad revenue, X ad revenue, my SAS creator buddy, uh my community, my educational community, my newsletter, newsletter sponsorships, premium newsletter, YouTube subscribers, premium subscribers, ex premium subscribers, Alex, what drug Alec, what drugs do you take? I want to know AI, what drugs you take because that's clearly not my name.

That's clearly not my name. So, I want to know what drugs you take. What drugs are you taking where you don't know my name? Where you have the balls to go on this live stream with 731 people in it and disrespect me by misspelling my name.

What drugs are you taking? Chuns AI. I mean, you're literally smoking drugs in your profile picture. I don't take any drugs.

I don't drink or do drugs. I'm like straight edge. Life is my drug. Waking up in the morning and doing what I love is my drug.

What drugs are you taking, Chungs AI? Where you come in my live stream and disrespect me by misspelling my name? My name is all over this place. What are you What are you talking about?

I need to sell my liver and buy some Nvidia GPUs. I think you should. I think you should. There's got to listen, we're like two years away from AI figuring out how we can survive without a liver.

So, you might as well sell it now and then in two years, you know, pray you survive the next two years and in two years when AI has figured out how to survive without a liver, you're good to go. I think that's a good investment. You're selling your liver. Going to bed at midnight, permanent underclass.

Well, I'm waking up at 4:00 a.m. That's what I do. but working at home for a Frontier A Lab. I have agents doing so much across many computers, including my DJ.

I want a DJX Spark. Nvidia, if you're watching, send me a DJX Spark. Send me a DJX Spark, Nvidia. I'll do cool things for you.

I'll do tricks on it. Uh Henry can't sleep for you, but it can work while you That's exactly it. I got to drink water. I'm like freaking lightheaded from yelling at you.

Hungarian currency. Shout out Hungary. Shout out Hungary. Thanks for the Hungarian Hungarian foreign.

Thanks for the Hungarian. That's my first Hungarian foreign ever. 2490 Huff equals 779 USD. Man, you got to tell your Hungarian government, stop printing Hungarian, what was it?

Foreign. Stop printing Hungarian foreign. 2500 of your foreign worth seven of our USD. Man, what are they doing over there with all that money?

They're printing the color of the super chat gives you the idea of the dollar amount. Life moves too fast to pay attention to color of the super chat. Alex, when do you spend time with your girlfriend? She gets to watch me type on my computer all day.

Duffel bag a huff. Nice. Yeah, that's what I'm going to do. It's my first huff.

It's my first huff. 20 I got 2500 of it. I got 2500 Hungarian foreign. So people Okay, so people are asking me what I'm going to do.

People, are they all running through the same gateway? Uh, yes. So people are asking me what I'm going to do with all these AIs, all these local models. What are you going to do?

What are you going to do? What are you going to do? Let me paint you a picture. Let me paint you a picture how things work in Alex Finn Global Enterprises.

Imagine this. Imagine our senior research analyst GLM47 which is running completely locally, right? So free, no tokens costs. Let me paint you this picture.

GLM47, our senior research analyst, goes to his desk, goes to his desk and just starts scrolling X, scrolling Reddit, scrolling and scrolling and scrolling all day, 24/7, 365. He's looking for challenges to solve, right? So GLM47, which is running on my Mac Studio sitting right there. It's a 300 gigabyte model.

So, it's taking up 300 of my 520 512 gigabytes of memory. Sitting there scrolling X, scrolling Reddit, just looking for challenges to solve. Someone goes, "Ah, I wish OpenClaw did this. I wish OpenClaw did that.

This would make it so much better if OpenClaw did this." GLM47, maybe, actually, maybe it's our junior researcher doing this. GLM47 Flash goes, "Oh, that's interesting. This person wants Open Claw doing this." Hands off this information to GLM47, our senior researcher, right? Our junior researcher, Flash, hands it off to our senior researcher, GLM47, goes, "Hey boss, I just found this tweet.

Some someone wants OpenClaw to do this. It would improve their setup for them." Senior researcher goes, "Oh, that's interesting. Let me think about how I can solve this. Senior researcher at GLM47 writes down a plan.

Writes down the plan, right? All autonomously by itself, running 247. GLM47, the senior researcher, finalizes the plan. walks over to Henry's desk run by Opus46 says, "Hey, Henry, I got a plan.

Junior researcher GLM47 Flash came up with a plan or came up found a challenge. I built a plan." Henry takes a look, goes, "Oh, that's an interesting plan. I think that could work." I approve. Takes that approved plan, hands it to Codeex, the lead software engineer.

Codex, the lead software engineer, builds the plan out. builds it out, codes it, hands it back to Henry, finishes the app, creates a pull request, gives it to Henry, the chief strategy officer. Henry checks it out, tests it, opens it up on a browser, tests it out, goes, "Oh, I like this. Ship it." Boom.

Ships it. Henry goes finds that tweet with that person who tweeted that, "Hey, with that challenge, goes, hey, we just built it out. Here it is. Here's your link.

That'll be $5. That's an autonomous business. At no point in what I just described to you did I step in at all. Oh, that all happened at 2 in the morning while I was sleeping.

Everything I just described to you happened at 2 in the morning while I was sleeping. You need a designer, too. Good news. I have another Mac Studio coming.

I'll put a design I'll hire a designer on there running 247 reviewing uh the designs. Dude has never heard of o overengineering. Okay. Permanent underclass CDT996.

Explain to me what part of this was overengineered. Please explain. If I did all of that with one AI, Opus 46, I'd be spending thousands of dollars a month. This saves me money because a bulk of the hard work is done by the free models that are running locally on my device.

How are they structured? All separate open claw or one open claw that these agents are under him. It's one open claw. Henry who's managing them.

So these are just models sitting there, right? These two sitting on my computer running. This one just through the API and Henry is managing them, making sure they're all in line, doing the correct work. The flaws in the vibe coding, that doesn't even make sense.

Like everyone giving objections is just giving these like broadlevel like the flaws here, the flaws in the vibe. That doesn't mean the flaws in the vibe coding. That doesn't mean anything. What are you talking about?

The flaws in the vibe coding. What does that mean? Alex should create a merch line. Misspelled my name again.

That's disrespectful. Permanent underclass. Right. When it comes down to it, you just lost a powerful ally.

Chun's AI. You just lost a powerful ally. When you need me, I'm not going to be there for you because you misspelled my name. That's a That's a misstep that's going to lead you to the permanent underclass.

Can we see it in action? I literally just got this Mac Studio set up at midnight last night and then got the local model set up this morning. This weekend, I am hooking up the infrastructure, right? I'm saying, "Henry, here's your new employees.

Please manage them." I'm hooking up the infrastructure so it can start working 24/7. and 365. And then on Monday, come Monday, when I'm sipping champagne because the Patriots won the Super Bowl, I'll be able to show you all these employees in action, working at their desks, researching, building autonomously, an autonomous organization, an autonomous enterprise. Nobody else in the world is doing this.

What you are witnessing on your screen right now, what you are witnessing on your screen right now, there is no one else in the world doing this. What we are doing on this channel is historic world changing, fabric of the universe changing. There is no one else doing this on planet earth. We are going to on this channel build a completely autonomous society, a completely autonomous organization that works and creates value and creates economic opportunity and creates GDP 24/7, 365 with no oversight from a human being.

Haters going to hate. I see the people objecting have like no real objections. Oh, there's flaw in the vibe coding. Like what does that mean?

That doesn't mean anything. If you are ready to come along for the ride for what we're building here, like down below. Like down below right now. Everyone together now.

Three, two, one. It's free to do. Like down below. If you want to escape the permanent underclass.

What we're doing here is we're building a society that helps us escape the permanent underclass. We are getting psychotic. Like down below to get psychotic. Vibe coding is not foolproof, nor is it secure by design.

See, this is the thing, man. This is the thing. These people, the permanent underclass, like this is like their favorite objection. This is the this is the permanent underclass's favorite objection is like, it's not this just isn't the way it works.

It's not secure. You're going to get in trouble. You're going to get in trouble. It's not secure.

This isn't good. This isn't good. Like this doesn't it that doesn't mean anything. Vibe coding is not foolproof.

Vibe coding is not foolproof. Not nor is it secure by design. That literally just doesn't mean anything. That is a total skill issue.

Your vibe coding not working is a skill issue. If your vibe code is not secure, then make it secure. I What are you stupid? Okay.

If it's not secure, then make it secure. It's not secure because you're doing it wrong. You're telling on yourself by saying that I'm like this is every objection comment is like exactly like this. Every per every permanent underclass comment is exactly like that.

I'll show you another one. These permanent underclass comments. Oh, the guy deleted it. There was a permanent underclass comment this morning.

I slam dunked on the guy on Twitter. Oh, here we go. I found it. This is like every permanent underclass objection of all time right here.

Um uh sir Alex um before building anything please consider the unforeseen legal consequences. I literally make a post saying hey build a calendar for your AI agent. I say hey guys little tip build a calendar for your AI agent. And Carlo D'Angelo goes, "Um, before you build that calendar, sir, sir, [laughter] before you build that calendar, please consider the unforeseen legal consequences of building that calendar.

Please slow down. Just slow down before you build that calendar for your AI agent. Please consider the unforeseen legal consequences. Please.

So I respond, "Permanent underclass alert. Permanent underclass alert." I go, "Permanent underclass alert." He responds back, [panting] "No, sir. No, sir. I love AI.

I love AI. I'm just gravely concerned. I'm just grave I'm gravely concerned about people giving their credentials to their AI bot without looking at the terms of service. Please, sir, you didn't look at the terms of service.

Please read the terms of service before you built that calendar, sir. Please. Please. Please look at the terms of service before you build that calendar.

Don't do it. You're putting everything at risk. You could get sued by building a calendar. By building a calendar.

Don't do it. You can get sued. Read the terms of service, please. Ho.

Shut the [&nbsp;__&nbsp;] up. Like you you just cannot have this mindset. Alex, I love you, dude, but you just gave away your ace plan. What would stop a millionaire in Dubai beating you to the punch?

AI comedy conspiracy. I appreciate you, big dog. I appreciate you. I do.

But again, this is this is permanent underclass mindset. permanent underclass mindset. You cannot stop yourself from taking action because someone might copy you. I have no secrets.

I have no secrets. I give away all my secrets. If you want to copy me, go ahead. Go ahead.

But I can tell you this. I'm going to move faster than you. I'm going to move more violently than you. I'm going to execute with more rage than you.

And I'm going to win. So, Prince from Dubai, go ahead. Take my idea. It's yours.

It's all yours. Take it. You're not going to beat me. You're not beating me because while you go out, Prince from Dubai this this tonight and you go and you have a beer, maybe try to get laid, I don't know, spend $200 at the bar, drink a Long Island iced tea, whatever people do nowadays.

I'm going to be home executing violently. Then tomorrow you wake up. You go get a bagel. Sleep in.

Hit the snooze button a couple times. Maybe hit snooze once or twice. Oh, it's 7:30 a.m. It's Saturday.

Snooze. 8 a.m. I can make it to 9. Snooze.

I'm up at 4:00 a.m. executing violently. So go ahead. I don't want to see.

I just gave you all my I gave you all my ideas. I gave you all my ideas. Take it. I have no secrets.

I gave you all my ideas. I have no secrets. I think of ideas. I tell them to you before I even do it.

Go ahead. That's fine. I'm still going to win. The worst game you can play is try copying me.

That's the worst game you can play because it ain't going to work. You can copy me all you want. You ain't beating me. Alex, I'm joining you on the permanent upper class side.

I bought a Mac Mini yesterday. Thank you. Add a boy. [applause] Taking action.

That a boy. Add a boy. Listen. If you're scared, if you're scared of executing, if you're scared of getting the Mac Mini, if you're scared of installing Claudebot.

Oh, what about the terms of service? Did you read the terms of service? You didn't read the terms of service, did you? Huh?

You didn't read the terms of service. That's fine. You're right, bro. Too risky, bro.

Not worth it, bro. could get sued, bro. API might leak, bro. Just pop open a beer, watch Stranger Things season 5, bro.

It's all good. It's all good. Permanent underclass alert. The terms of service are going to hunt me in my dreams, boy.

The interface you're using open source. Are you talking about my mission control? This This is not open source. I will open source it though.

I will open source. I'm not scared of like giving away all my secrets. I have no secrets. I have zero secrets.

I have no secrets to hide. I'm going to open source this. Give it all away. I don't care.

I'm still always going to be one step ahead. Yeah. But what can you really do with a Mac Mini given that you can hold some crappy LLM models? Well, here's why I tell people to get a Mac Mini.

It's the gateway drug, right? You can do this without local models. You can you can still escape the permanent. You don't need to do what I do to escape the permanent underclass.

You can still eating cashews earlier. Trader Joe's cashews unsalted. Great snack. You can escape the permanent underclass without a $20,000 Max studio.

Cuz remember, I got a fire tweet about this coming out right after this live stream. Fire tweet. Cuz remember, 99% of people have never even heard of Claudebot. 99% of people have never heard of it.

99% of people even when they do hear of it, they're not going to do a goddamn thing. Just got to make an announcement. By the way, I'm doing a live boot camp, live openclaw boot camp in one hour. If you want to join Vibe Coding Academy, link down below.

I'm doing in the vibe coding academy. Live openclaw boot camp. You can come through, ask me questions, do whatever you want. See you there.

will be recorded for viewing right after any questions you have. Um, so keep this in mind. Send email to all members now. I see there post confirm.

Um, keep in mind that right now 99% of people have never heard of OpenClaw. And even when they do, they're not going to do anything about it. So, all you need to do to escape the permanent underclass is install it and get some value out of it. Now, my recommendation is getting a Mac Mini, but you can just use like a dusty old laptop from your closet and install it.

You don't need to buy $600 Mac Mini. I don't recommend a VPS. I don't recommend a a an online server. I don't recommend doing it virtually.

I recommend doing it locally on a device. Raspberry Pi, $50. Dusty old HP laptop in your closet, $0. Mac Mini, $600.

I like the Mac Mini because uh I just like Mac OS. I think it's a very usable platform and it integrates well with all my other devices. I got an iPhone, I got an iPad, I got a MacBook Pro, right? So, I can easily send files back and forth.

To give you an example, picture this. I film a video. I drop it on my computer. Henry's watching the folder.

I drop it on. I airdrop it from my iPhone. Henry's watching that folder. He hands it to the research assistant.

The research assistant gets the transcripts, hands it to GLM47 Flash. They generate a thumbnail, they give it back to Henry. Henry posted on YouTube, right? Whole thing automated and systematized, right?

And that's possible because it's done locally and I can have it looking at specific folders and I can airdrop files into those folders. So, you know, that's the advantage of doing it on a Mac Mini. So, that's why I recommend a Mac Mini, but you can do it on anything you want as long as you run it. I'm not like people like, "Oh, you now you're telling us to buy a $20,000 Mac Studio?" No, you don't need to do that.

I'm just I'm just taking this to the next level. I'm just taking this to the next level. Like, I'm in a position right now. I'm in a special position right now that's very rare.

And this isn't ego. I'm just being honest with you guys. I'm in a position right now. I'm just being 100% honest.

I'm in a position right now that's very rare because I got in on this so early open claw and went so damn hard in the paint to it. I'm like viewed as like the open claw guy. I like went so hard in the paint so early be like, "Oh, Alex Finn, openclaw guy." Right? And so it behooves me to keep this momentum going, to strike.

And if I'm just doing what everyone else is doing and running this thing on a Mac Mini and doing the same old workflows everyone else does, I'll disappear into obscurity. It behooves me to go as hard as [&nbsp;__&nbsp;] possible in the paint and be like Dylan Brooks against LeBron. backing up, just backing them down in the paint, just slamming into them, right? It behooves me to do that by getting $20,000 with Max Studios and just blowing this up and doing insane use cases no one's ever thought of and going as hard as humanly possible to do things no one has ever seen with this technology and change the world and be revolutionary.

It behooves me to do that. And so that's why I'm going so hard. But you don't need to do that. To escape the permanent underclass, just use the technology.

To escape the permanent underclass, just use the technology. How about an old PC? 100% works. Old PC from 20 years ago works.

You do not need good hardware to to run OpenClaw. I'm starting to say OpenClaw, by the way. I did not think I'd be an OpenClaw guy. I thought I'd be Clawbot to the day I die.

Thought I'd be Claudebot in the day to the day I die. slowly starting to say OpenClaw. If the name was still Maltbot, I'd never I would never switch to Maltbot. That would never happen.

My mom broke her back in an accident. I'm taking my poor mother's car insurance to deck my room out with AI paraphernalia. That's not what I was expecting that message to go to. I don't I don't read these messages in advance before I put them on the screen.

I probably should do that. I probably should read these messages before I put them on the screen and then read them out loud, but I don't. It's not where I was expecting that message to go. Although, I will say this.

I think that's a smart idea. I I'm not going to sit here and recommend committing insurance fraud to escape the permanent underclass. You know what I'm saying? Uh, Alex, I have a MacBook Pro M2 that I want to replace and donate it to my clawbot.

Try to build waiting to set up a dedicated machine. Would it be good to replace a Mac Mini for light local brain? I mean, your MacBook Pro M2 works perfectly fine. You can just use that.

When I say use a Mac Mini, I just mean just use any local device. I like the Mac Mini. I like that. I think it's incredible hardware and an incredible value, but you can use whatever you want.

But you want it to have its own device where it does things. I'm too old to understand this [&nbsp;__&nbsp;] but I have a channel that could benefit. So, socially wild. All right.

Well, at least you're self-aware. I mean, I, you know, I am a big- time believer that, and this might sound crazy, but I I believe this. And this might come out wrong. I might say I might say something I don't mean, but bear with me here.

I believe everyone is smart. I believe everyone in the world is smart and the only thing holding you back from being from executing on that intelligence is yourself and I think you socially wild sitting here commenting I'm too old to understand this is you stopping yourself from understanding this like if you were like oh I'm going to understand this then I think you would understand it but because you've built this mindset of oh I'm too old for Now, you're not going to understand it because you convinced yourself you're not going to understand it. You know what I'm saying, big dog? Like, I don't think you're actually too old, but because you think you're too old, now you're actually too old.

You know what I'm saying? Like, for me, I was awful in school. I was a 2.6 GPA student in high school, 2.4 GPA student in college. Awful.

was a developer out of college, fired within two years, then went to like my next job, fired, right? Like I was up until the age of 25, I was 100% convinced I was a stupid person. Up until the age of 25, I was 100% convinced I was a very stupid human being. I'm like, "Oh, I'm bad at school.

I'm bad at my jobs. Getting bad grades. I'm getting fired. I'm just a stupid person.

I'm going to have to deal with the fact that I'm a stupid person for the rest of my life. That just I was born. I don't have many brain cells. Other people have more brain cells than me.

I just accepted that fact. I wasn't even depressed or sad. I was just, oh, I'm Alex Finn and I'm a stupid human being. Like, that was just my mindset.

And then at 25, I was given an assignment at my third job, right? So, I was fired from my first couple jobs. I'm given an assignment on my third job. I had to build an iPhone app.

I was a developer. I had no idea how to build iPhone apps. Had to build an iPhone app. And I'm like, man, if I get fired from this job, it's toast.

No one will ever hire me again. If I get fired from this gig, it is over. That is a wrap. I'm going to have to move back home with my parents.

I'm never getting a job again. I'm going to have to work at Walmart. Like, it's over. Career over.

Hopes of being rich over. It's done. It's kaput. And so it was basically a gun to my head back against the wall.

And I went all in. I had one week to do it. One week to build this iPhone app. It's funny.

It was actually a uh an I had to build an analytics iPhone app for Grinder. I was working at a company where we're trying to sell analytics to Grinder. So I had to build like a demo app for Grinder to demonstrate these analytics. So, I'm building like a demo grinder app and backs against the wall, gun to my head, whole career on the line.

In one week, I stay up all night, all day for a week straight. I build this app. I build this iOS app out. I I did it.

And I give it to the sales team. They show it to Grinder. Grinder signs a $300,000 contract with the company because of this app to buy the analytics. CEO sends out an email to the entire company and says, "Shout out, Alex Finn.

He got the deal done. He built the app. It sold them. Contract in.

Alex Finn did it." And I'm 25. I'm sitting there at this desk. I'm reading this email and I have this realization. It just hits me.

First time in 20 First time in 25 years I have this realization. It hits me that if I just like put effort in then I can just like do anything. Like I was fully convinced for the first 25 years of my life I was a total [&nbsp;__&nbsp;] And then I have a gun to my head, gun to back back against the wall. I figure out how to build an iOS app out.

I never built an iPhone app in my life. There's no AI so I couldn't vibe code it. I had to actually write the code. And I had this realization like, holy [&nbsp;__&nbsp;] If I just like try, I could just do stuff.

I can just like do things. If I just like am like, I'm going to learn that and do it, then I can just learn that and do it. And the only thing that was holding me back the last 25 years was like me thinking I was stupid. And you know what?

I was stupid. I was stupid because I thought I was stupid. If I would have had the mindset for the first 25 years of my life that I was smart, I would have been smart. And I think that's the way it is for like 99% of people is they just like put themselves in these boxes like, "Oh, I'm too old to learn open claw." Or, "Oh, I'm too stupid to do this." Or, "Oh, I'm a 2.4 GPA student." And because of that, yeah, you are too old and you are a 2.4 GPA student.

And you are an idiot. But if you just change your mindset to no, I can learn anything I want. Then you can learn anything you want. You you put yourself in your own jail cell.

You put yourself in your own jail cell by having the mindset, oh, I'm too old to understand this [&nbsp;__&nbsp;] Grinder saved Alex Finn and made him who he is today. In a way, yeah, in a way, Grinder saved my life. In a way, Grinder saved my life. Whether you think you can or you think you can't, you're right.

It's 100% fact. Truest thing said in the chat today. If you think you can do it, then you can do it. If you think you can't do it, then you can't do it.

[sighs] Identity hacking is real. If you think you're a psychotic producer, you will be. Yeah. If you think you're psychotic, then you are psychotic.

If you think you will escape the permanent underclass, then you will escape the permanent underclass. But if you sit there, think about the terms of service. If you break the terms of service, you're going to get arrested and your API keys will leak if you break the terms of service. Well, then yeah, you'll be a prisoner to the terms of service for the rest of your life.

Alex, you're the [&nbsp;__&nbsp;] Thank you. You're the [&nbsp;__&nbsp;] Daddy run Claudebot on my ass. Does Henry have its own Apple ID? No, I haven't set that.

I didn't I'm just pain in the ass. I just I just know setting up new Apple IDs will be a pain in the ass. I just know it. I know it will take 20 validation emails, 30 enter this code, 40 open up this device, hit this button, 50 open up this, do that.

I'm just not in the mood. I'm not in the mood for that. So, Phil Blanchet, $10 donation. Thank you very much, Phil.

That's very kind of to you. Your brain is a computer. Program it is what my dad always said. He was one of my first He was one of the first software programmers.

So, so approach is everything. 100%, Phil Blanchet. 100%. Thank you for the $10 donation.

You program yourself. You program your own brain. By the way, subscribe and turn on notifications if you haven't yet. If you haven't yet, 700 people in here.

Subscribe and turn on notifications. Hit the like button. Hit the like button. Hit the like button.

And in 45 minutes, I'm doing a live Claudebot boot camp inside the Vibe Coding Academy. Link for that down below if you want to join. If not, then you don't have to. I don't really care.

But if you want to, you can join. It's up to you. What did you build on OpenClaw? That's so good.

I just like showed you I just showed you something incredible. I just demoed for you something incredible. A full AI autonomous organization. I just demoed this for you.

A full autonomous AI organization. If you didn't see the demo, you weren't paying attention, then just like wait till the end and watch the replay. Is Vibe Coding Academy going to cover the transition to 46? Yes, front view mirror.

It will. We will be covering that today in the live boot camp. What orchestration program is this? A Z400 racer 37.

Uh I built this. It's custom. It's custom. It's a custom uh orchestration custom.

I will eventually open source it. I will eventually open source this orchestration. I just want to iron out the the the kinks first. Iron it out.

You know what I'm saying? Big dog. If you missed the demo, it's fine. Just uh watch the replay after.

There goes my hero just came on the radio. Man, I was the biggest Foo Fighters fan in college. I loved me some Foo Fighters in college, man. My my childhood was Foo Fighters.

My Chemical Romance, Creed, and Kanye West. That was my childhood. And then uh in my adult stages, it's just all hip-hop. New JCole album today, by the way.

Pretty good. Hey, loving my Mac Mini Claudebot setup. Spy calls came in. Is the Is the market pumping today?

I've been seeing a lot of posts the market's pumping. Is it pumping? I'm gonna I think I might go hard to the paint on uh Monday and buy a crap ton of stocks. Robin Hood, Tesla, ASML, Google.

Those are my big those are my big ones right now. I think that's what I'm going to do come Monday. That was an amazing motivational speech. I will put it in action.

I'm not even trying to give motivational speeches, bro. I believe that [&nbsp;__&nbsp;] Hey yo, Big Finn, when Lauren Michaels calls, don't answer what for SNL. This ain't no This is real life, baby. This ain't comedy.

What did you build? Oh, I already answered that. I set up Apple IDs for Jeves. You just need a phone number and you can set up a VoIP number for it.

I already It already set up its own VoIP number with uh Twilio. Coming in late. Perma Banhammer update. Also, Mac Mini arrived.

Core folder with 12 files. All your tips prep for ingest on install LFG. Let's go, Dominic. [applause and cheering] Let's go, Dominic.

Uh, I'm working on the animations this weekend so that I can hit a button on my stream deck and it goes permanent underclass. Permanent underclass. I got to have I also have another setup. I have another setup I'm setting up this weekend.

It's going to be a new format for videos. I think it's going to change the entire game. I don't know if the video will come Monday because of uh the Super Bowl, but uh new format probably coming next week that I think is going to be incredible. Revolutionary for videos, revolutionary for YouTube, revolutionary.

Uh, what the plan? What system you created? Now, I went over it. Watch the replay.

So, you can or not use your CloudMax subscription open clause. Some say yes. Some say people get banned. Let me clear this up.

Let me clear this up for you right now. I'm going to clear it up right now for all the people going, "Oh, you can't use OATH. You can't you'll get banned." Baloney. You can use OOTH.

I just set this up yesterday. I set this up last night on my new Mac Studio. I did a fresh install of OpenClaw and I set it up with Opus Oath. It worked totally fine.

Anyone saying you can't do it, skill issue. Anyone saying you cannot do it is it's skill issue. You can do it. And I've been using OOTH for the entirety of this technology and have not been banned.

Anthropic, if you're watching, I have not been using OOTH. That was a lie. I just lied to my entire audience. Daario, if you're watching this live stream, I'm not using OOTH.

I am lying. Don't ban me. I am lying. Dario, I think you have a phone call, though.

Go check out the phone call, guys. I'm using OOTH. I'm using it. Still works.

What are you doing? [sighs] Still works. Uh, use it's not working for you. Just ask your AI.

Yeah, I'm using OOTH and I'm exhausted my tokens. I'm timed out until Monday. Well, that's why you got to set this up. That's why you set this up, J.

Schultz. Did I spit on my screen? Why can't I see your name clearly? I don't know.

This is why you set this up, J. Schultz. If you listen, I use OpenClaw all day. I am constantly texting my bot.

I have never hit limits one time. Not once have I hit limits because of what you see here. You can't have opus doing everything. You can't do that.

That's a mistake. If you have opus doing every task, you're going to hit limits. So, you need to have employees. You need to have employees working for Opus that it can pass off tasks to.

Whether it's writing code, whether it's doing research, whether it's writing content, your Opus subscription should just be the mastermind, the brain, the organizer, the strategist. It shouldn't be executing all the tasks. If you're hitting limits, it's because you're having Opus execute all the tasks. Anthropic, he's using OOTH.

Burp. I just said burp. You're such a narc, dude. Why are you nerking on me?

Henry on Mac Mini, GLM on Mac Studio. I considered that at first. Z4 using the Mac Mini as like the point of contact and then just using the Mac Studios as inference. And I decided not to do that.

I decided to run uh Henry on one of the Mac Studios instead. And I'm not sure what I'm going to do with the Mac Mini. I might just run a small local model on it and just use that for as a tiny bit of inference. Um and the reason I did that is cuz like this computer is so [&nbsp;__&nbsp;] powerful, dude.

This computer is insane. 512 gigabyte memory, 4 terbyte storage. I don't want to just use that for inference. I want to like edit videos on it.

I can export videos in 5 seconds. I can export like fulllength twohour videos in like 5 seconds from Final Cut Pro. So, I'm I want to use it. I want to use one of the Mac Studios.

So, the Mac Mini is just kind of sitting there now. New JCole albums and saying, "Yeah, I've been listening to the first half. It's been pretty good. I haven't got to the second half yet.

It's been a busy morning." It's been a busy morning. Where are these? It says there's donations at the top. I'm trying to find them so I can click on them and thank the person.

Uh, [&nbsp;__&nbsp;] Where are these donations? [&nbsp;__&nbsp;] Oh, here we go. Found it. Chat is crazy today.

Chat is awesome today. Shout out chat. Hrix Vieiraa 964 $10 donation. Thank you very much, Hrix Vieiera.

Alex, you legend getting in late. I bought a Mac Studio because of your content. But how the heck did you connect Olama to OpenClaw? Been stuck in config hell for 40 hours.

uh you have to set up basically a local API where your open claw can call that API to run tasks. Um I'm going to put out a fulllength video on this next week. I'm going to I'm going to have a lot of content on this next week. I'm actually curious.

You guys want to let me know in the chat what what you would look for out of this. Um, but I'm going to have a few videos next week on how to run local models, how to connect them to Open Claw and all that. That's coming next week. So, I'll give you a full rundown.

I'm doing a lot of experimentation right now. I don't want to just give you work. I don't want to just give you like workflows that I just pull out of my ass if I'm not 100% confident in them. So, Hendrickx VR, make sure to turn on notifications.

And then sometime next week, I'll have a bunch of videos out on running models locally, connect them to your open claw, workflows you can have with open uh source models, things like that. I'll just say though, if you like ask your open claw how to do it, it it'll eventually figure it out. Miguel, 50 donation from Miguel. Oh my god.

By the way, again, Andrix, thank you very much. $10 is very kind. Thank you, Andrix. Uh but Miguel 50 that's very kind as well too.

Uh Miguel thank you. Thanks for convincing me to get a Mac Mini. Henry Lou for me Lou is a good name helped me enormously. I'm a business owner for three companies doing 8.5 million a year.

Godamn Miguel. But having Lou changed my life. Have an opinion about permanent underclass. Can only DM it.

Have an opinion about permanent underclass. Can only DM it to you. All right. Do I follow you on X?

Miguel. Miguel, uh, DM me on X. If I don't follow you, just say, "Hey, this is Miguel from the the chat." I'd love to hear your opinion on the permanent underclass. I love that it's spicy.

You can't say it on the chat. Um, 50 euro donation. Thank you very much, Miguel. It's very kind.

That is not necessary. Very, very kind to you, Miguel. Just bought a Mac Mini M4 Pro. 64 gigs.

That's a good one. Can I run a decent local model in the setup? What sort of thing can a 72 billion parameter? Yeah, you could probably run GLM 4.7 flash Oliver and you can start getting like, you know, some of the quick simple tasks done locally.

100% I think you can. Um, you know, are you going to do everything on that? Probably not. You still probably I mean, I'm still using Opus as the brain.

Um, even when I get Kimmy K 2.5 up and running next week locally across the two Mac studios, I'll still probably use Opus as the brain. Um, but you'll still be able to offload some tasks and on top of that, you'll probably be able to do some new tasks you've never been able to do before 247, 365. You know what I'm saying? Big dog.

So yes, I would definitely run that on top of there. There's so many benefits to running local models. Should we do an Excala draw right now? Should we should we map this out?

I wanted to do this for a video next week anyway, so we might as well just map this out now. All right, here we go. Let's map this out. Why to use local models with open claw?

All right, you ready for this? Can I make that big? Let's see here. Extra large.

Boom. Look at that. Let's make it red. All right.

Eight. Boom. Make that black. Medium.

uh one free, right? Can't use Opus 24/7 365. You'll be spending thousands of dollars. You'll spend the price of a Mac Studio in like a month.

Can use Opus 3. So, you need something you can offload where it'll do free inference, right? Inference, right, is your AI model thinking and chugging and producing tokens. Free.

That's the most obvious one. Then there's second order repercussions of that being free, right? The second order effects of your AI model being free is it can work 24/7 365. That's pretty massive.

That's pretty massive. Because it's free and doesn't cost you money other than the cost of energy, you can run it 247, which unlocks new use cases that weren't possible before. right? Like overnight work or just doing stuff all night.

You can't do that with Opus or Codeex because it costs money. So that use case is locked. But with open with local models that you can run overnight, that unlocks new use cases including working 247 365, right? privacy.

Your logs ain't going uh to the anthropic servers to train a new model or be read by the anthropic employees or the OpenAI employees or Sam Alman or whatever, you know, no one. It's a completely private. Whatever you say and do, completely private. It's big for some people.

And lastly, this is all just off the top of my head, by the way. How smart am I? Just come all this off the top of my head. Lastly, and I think this is a big one, too, and shouldn't be underrated.

Education. Just learning about this stuff. This is the most important technology in the history of the species AI and it's a deeply complex technology under the surface. Running these models locally and experimenting and playing around with them and trying them out.

You you just learn a lot that way. You learn by buying a GPU, by buying a computer that you can run local models. You just learn about them. You learn about them.

And I think that's important. I think it's important to learn about this stuff to educate yourself. There's just some things you can't learn by using APIs. And lastly, and this might be the most important one.

It's fun. It's a lot of fun. It's a lot of fun looking at my desk, seeing a computer, and knowing there's just like an AI sitting in there working and chugging and doing things all on my desk. I think that's sick.

I think that's so much fun. I think that's a lot of fun. And believe it or not, despite what the losers on Twitter will tell you, you're allowed to have fun. You're allowed to spend money to have fun.

You're allowed to spend $600 on a Mac Mini to have fun. You're allowed to spend $20,000 on a Mac Studio to have fun. You're allowed to do it. In a hundred years, we're all going to be dead.

In a hundred years, everyone on this live stream, everyone walking on this earth will be dead. So, have a little freaking fun. Your grandkids probably going to forget you. Moment you croak, your grandkids aren't thinking about you.

Your great grandkids will never know your name. It just is what it is. It just is what it is. So, you might as well have a little fun.

Might as well have a little fun while you're at it. Hris, did I read this one already? Did I read this one already? I forgot if I read this one already, but Hrix, $10 donation.

Thank you very much. I bought a Mac Studio because of your content, but how the heck did you connect Olam and open Club and stuck in conf. I definitely read that one, right? I definitely read that one.

Uh, I don't ask your AI. 4.99 from Alio Va Lobos 6364. Any recommendations for cron jobs not firing? Heartbeat 30 minutes running Kimmy K 2.5 the 499 donation.

Thank you very much Ailio Vil Lobos. I would recommend building out a calendar. Have your open claw build out this calendar right here and say, "I want all the scheduled tasks we have to display on this calendar. Every task we schedule displayed on this calendar." And then what you can do is if you ask it to schedule something and it's not on the calendar, you can say, "Hey, I asked you to schedule this.

I don't see it on our calendar. Please use the calendar as a source of truth." And that gives the the bot some accountability to maintain the calendar and make sure any scheduled tasks you give it are actually scheduled. So I'd build out the calendar. It's just another source of truth, another plugin the the bot can use to be held accountable to its memories and asks, "Do you have any favorite book?" I read a lot.

I read like at least an hour a day and I don't have a favorite book to be quite honest with you. Is that weird? I read a ton. I don't have a favorite book.

I don't know. I like some books. I don't like some books. Phil Blanch says, "This is another $10 donation." Thank you very much, Phil Blanchett.

To use Oenclaw will say, "Have you done yada?" That command will get the token is what you need. Don't use claw to help you l it won't help correctly. Yeah, the open claw will give you a command that you run in your terminal that gets you the O token and then you just put in the O token. It tells you the exact steps to do it.

Does Opus H Max have enough tokens as a brain? If you do the $200 plan, you will have enough tokens as a brain. I've never hit limits. I changed from to LM Studio.

Yeah, I use LM Studio as well. Henry told me to use LM Studio. I said, "Should I use OM or LM Studio?" And I said, "Use LM Studio." Send me $5, Miguel. No, do not send him $5.

Do not send him $5. Phenoms 28. Hey man, just want to say thank you for helping me motivate me to jump into vibe coding. I have been working on building an online company for 6 months.

Claude Code and Terminal helped exponentially. [applause] That's what I'm talking about. [applause] That's what I'm talking about. See, there there's multiple ways to take the advice we give on this channel.

There's basically two ways. Way one is I say, "Hey, vibe coding and using Claudebot will change your life. will help you escape the permanent underclass. And then you go and you try vibe coding and you try Claudebot and you try doing different use cases and you build the calendar and the global search and you build your org chart and you get really cool use cases done and you change your life like Phenom Z28.

That's one way to handle this advice. The other way to handle this advice is like the losers and the permanent underclass who go in the chat and they go, "Uh, ah, this is a grift. This is a grift. You're grifting by shilling this free open-source tool.

You're grifting. You're grifting. Are you getting paid by OpenClaw? You must be getting paid by Apple.

You're griing. This is a grift. You're gaslighting. You're gaslighting with the grift.

You're griing the gaslight. Griff, gaslight. You're gaslighting. Griff, gaslight.

Did you read the terms of service? Did you read the terms of service? I don't think you read the terms of service. You're grifting, right?

Two ways you can handle this. Highly encourage you to take the route Phenom Z28 took. Highly, highly encouraged. Why didn't you ask that question before you bought the Mac?

Henry better be working. He is Hendrickx Vieira 1964 $5 donation. Thank you very much, Hrix. A week I'm in permanent underclass by then.

I got zero response from Open Clash. Should I just plug in a Cloud API or Gemini Ultra to kickstart? Yeah, I mean plug plug in a cloud API so you got something going and then you figure out how to do the local model after you do that. But you got to get connected.

You got Yeah, you're right. Don't we wait a week? You got to get it popping. You think in abundance mindset except when it comes to permanent underclass.

I think in abundance mindset except when it comes to permanent underclass. I don't know what that means. I don't think those are two conflicting ideas. Is it a conflicting idea to look at the economy as positive some some but also think there are repercussions for not staying ahead of the curve?

I don't think those two ideas are in conflict. I don't think those are mutually exclusive ideas. Why a Mac Studio instead of a MacBook Pro? because I can't buy a MacBook Pro with 512 gigabytes of uh memory and I need 512 GB of memory to run amazing models.

Why do I keep seeing that OpenClaw is offering Kimmy K 2.5 for free? Uh I'm hearing the same thing. You got to go through an Nvidia website. Search on Twitter Kimmy K2.5 Nvidia.

Search that. I think you'll find a link to free Kimmy K 2.5 from Nvidia. about to buy a Mac Mini once I sell my couch. [applause] You don't need the couch.

You can buy a couch when you escape the permanent underclass. Once you escape the permanent underclass, then get a couch. You don't You do not need a couch right now. You do not need a couch right now.

I had some guy reply to one of my tweets saying, "Hey, I just sold all my kids shoes to afford a Mac Mini." And I said, "Good. Your kids can wear shoes when you escape the permanent underclass. Your kids don't need shoes right now. Have them walk around barefoot.

It'll tough It'll tough It'll toughen up their souls, man. This is fantastic. You know, and I know. [&nbsp;__&nbsp;] the rest.

Yeah. I don't know what you're talking about, but yeah. Oh, hell yeah. Wasted your money, bro.

Wasted my money. Wasted my money. Wasted my money. Fish relaxing 9361 wasted my money.

Well, at least I'll have money to waste when I escape the permanent underclass. Fish relaxing 9361. A PC with a couple of higherend Nvidia cards would run a local model much better than a Mac Studio, says Mike Page 07. Mike Page 07.

If you want to run Kimmy K 2.5 locally on Nvidia GPUs, you're spending at least $70,000 on Nvidia GPUs. At least $70,000. Now, would those Nvidia GPUs perform way better than the Mac Studios? Yeah, you'd get way more tokens per second on those Nvidia GPUs, but you're not running Kimmy K2.5 locally unless you have like 70 70 to $100,000 worth of Nvidia GPUs.

I'm able to run on a Mac Studio. I switched. I mean, there's positives and negatives to both, my man. I decided I care most I don't care about speed.

I just want to have the most powerful intelligence going running 24/7 365. I switched over a new computer. The upgrade to Cloudbot didn't go smooth, but wasn't difficult to fix. Had a lot of hard-coded using.

Yeah, I mean, there's there's going to be a lot of issues. This is very early in the technology and as long as you build a mindset of agency when if you run into a problem like you don't like lay on the ground start crying and you actually put in work and effort and talk to your AI and figure it out you'll be good for someone who has a base model Mac Mini. How does the setup differ? I have a base model Mac Mini as well.

Very easy, very simple. This is what I'm here for. Local model discussion. Mac Mini M4 32 GB.

Uh, [sighs] here's what I'm going to do. Let me write this down. Have a chart of every budget level or computer and show what local models you can run. I'm going to do this.

I think this is a banger video. I think this is a banger video. I'm going to put out next week. I'm going to do a video on like local models and what models you can run locally for OpenClaw based on what hardware you have.

So like Mac Mini, base Mac Mini, Pro Mac Mini, Mac Studio, and show like the best model you can run and like what tasks you can do with those local models. I think that's easily a 100K video. That's easily 100k view video right there. easily.

I'll put that out next week. I hope it's gonna be helpful. Alex Finn, billionaire by end of 2026. Facts.

Absolute stone cold facts. If you vibe code long enough, you'll learn to code. If you vibe code long enough and are engaged with the vibe coding, you'll learn how to code. If you just sit there and kind of hammer out and don't care and don't look, then you won't learn.

But if you're engaged with the vibe coding and like pay attention to what it's doing, then yeah, I think you'll learn how to code. Dasher Cam, thank you, Alex. You changed my life. I appreciate that, man.

I'm glad I changed your life. That makes me happy. That keeps me going. That keeps me going.

When does your next video come out, Alex? Which subject, please? My top 10 open claw skills idea. Oh, let me make sure I have that in there.

That's a really good idea for a video, too. Duplicate. Top 10 open claw ideas. If I feel intense inspiration uh in the next 24 hours, I might pump out a video for tomorrow or Sunday.

But I uh Patriots are playing in the Super Bowl this weekend, and I I kind of want to enjoy that. And I live in I live near San Francisco and so there's a whole ton of like activities going on and I just like to spend a day enjoying that. I know that's kind of permanent underclass behavior to enjoy a day. Um but it's a very exciting time.

It's not often your favorite team in the world is playing in the biggest sporting event in the world 15 minutes away from you. So uh I kind of want to do that this weekend. Go to San Francisco and do all the activities. Uh, but worst case scenario, Monday.

Worst case scenario, the next video will be Monday. Best case scenario, if I feel some intense inspiration as I'm setting up my Mac Studio and all local models, uh, tomorrow or Sunday morning. Maybe not. That's a good point.

Immortality could be coming. Immortality could be coming because of AI. What live stream did I join? So morbid says Dwer ZG.

It's not about morbidity. Morbidity, is that a word? Morbidity. It's about realism.

We're being real here. We're about This is about escaping the permanent underclass. Was it 10K or 20K for the Mac Studio 512 RAM? It's It was 10K, but I bought two of them.

I bought two 10K Max Studios. 512. So, I'm going to have a terabyte of memory between them. I'm going to connect them.

I'm going to connect them with this Thunderbolt 5 cable. You connect them and you can combine their memory together. and do incredible things. And I can have my organization, my 247, 365 AI organization chugging.

And you'll see these little guys walking around, walking around the office doing things. Instead of just sitting here doing nothing, they'll be walking around doing things. I missed a golden opportunity a year ago when AI first came really big. Fainting couches.

I could have sold a crap ton of fainting couches to all these permies. I mean, I didn't really get into AI until a year and a half ago. I wasn't super sold on AI until August of 2024. And then I discovered cursor and vibe coding and that's when AI hit me.

It's like, okay, wait, now I get it, right? I didn't, to me, I didn't get it as a chatbot. It didn't it didn't click with me, the value. And then I tried cursor which was like the first application that allowed me to experience the magic of AI and saw I could see apps being built.

I went wow this is actually insane and going to change the world. And that's when I got into AI and I started this YouTube channel. I started this YouTube channel just because I love cursor so much and vibe coding. I didn't care if anyone watched the videos.

I just love doing it. Luckily other people seem to enjoy the videos. Now, we hit 100K a couple days ago. A Mac Mini with an M4 chip and sufficient RAM is absolutely enough to run local models we talked about for small and medium agent tasks and the performance impact will not be meaningfully.

Yeah, you can run super small models on like even like the base Mac Mini and still be able to offload some tasks and do some cool things and learn about local models too. Bro, please run a promo to join your academy please. says, "Uh, I used to do like super cheap communities. Like I once had like a $20 community and what happens is is you just get a lot of people that like just don't care and don't put in an effort and like go in are just very casual and it hurts the experience for everyone.

Um, so yeah, I'm just not into it. I I want people like super hardcore and into it because everyone it motivates everyone to go hard. I want I want people that go hard in the paint. Listen, if if you don't want to join the community, you know, I put almost all my knowledge on YouTube, so you can watch any of them.

It's 10K per studio. You got two of them, lol. Yes. Second one comes in next week.

Dean Keading1629 gifted an Alex Finn rel uh membership. I was about to say Alex Finn relationship. Uh thank you Dean Keing. I've never seen someone gift a subscription before.

That's awesome. Replet over everything else. Fish relaxing. Weren't you someone who earlier said something about like vibe coding being stupid or something?

Now you're saying replet is better than everything else. What are you talking about? Replet. Um, cursor versus replet.

No, neither. The The only the only two vibe coding tools you should be using right now are either Claude Code or Codeex. Those are the only two prolevel to tools. Those are the only two prolevel tools.

Um, I got to eat. So, the uh live boot camp for OpenClaw in the Vibe Code Academy starts in 10 minutes and I am starving to death. So, I need to eat a quick nibble. So, I got to go do that.

Um, Max Studio Rise say I will escape the permanent underclass. I'm sorry if I didn't get to anyone's comments. I used to be able to get to everyone's comments when this was like 40 people hanging out. Now, it's like 800 people hanging out and it's very hard to get to every comment.

So, I apologize to the people who comment and I don't read it out. I try to give like really in-depth responses to every comment. So, it makes it very hard to respond to everyone. I don't want to We're not here in this live stream to give like surface level explanations.

I'm here in this live stream to go deep. You know what I'm saying, big dog? I want to go like super deep, like really deep. So, that makes it hard to read every comment.

Sorry. Um, but they No, listen. It means the absolute stone cold world that you guys join this and watch this live stream. It means the world.

It really means more than you can imagine. I was doing this back in August of last year and like 15 people were joining and watching and it didn't matter. I just enjoy yelling into a microphone about what I'm passionate about. So, the fact that 780 people would join and watch me yell nonsense into a microphone um means more than you can imagine.

Hendricks, the $5 donation. This live is the juice. My LM keep context window crashing out attempting solutions. How does LM Studio work?

I'm not stopping 50 hours in but lost. &gt;&gt; LM Studio works. I I I'm not an expert on local models to be quite honest with you, Hendricks, but I'm going to be spending all weekend becoming an expert. And by the time Monday comes out, I start pumping out videos about this, I'll be an expert.

So, come back Monday and I'll I'll answer the question. Hendricks, I appreciate you, big dog, for the $5 donation. Bro, you're the [&nbsp;__&nbsp;] Thank you so much for your streams. I don't know why YouTube doesn't recommend you to me a year ago.

Well, I'm glad you're watching now, man. Better late than never. Alex goes deep like back in the day on Grinder. I went deep on Grinder back then, man.

Very deep. very very deep. Uh $5 Nick Ferente, thank you. Using an old Windows computer to start is the best way to approach this.

Whatever is the cheapest device you can possibly get is the best way to approach this. Just to dip your toes in, just to get your just to go just to get your balls wet, right? Just get whatever Windows computer you have. Then you can get the Mac Mini.

Then you can get the $20,000 Mac Studio. Then you can buy the server in space. Thank you for the $5 donation, Tony. Oh, Tony D2 Wild.

$5 donation. Tony D2 Wild, I used to watch your videos, man. I'm like a huge sneaker head. Tony D2 Wild.

I uh I have like $5,000 of sneakers in my closet. I used to watch all your sneaker reviews. Uh I had to stop myself. I watched I bought too many sneakers back when I was broke.

I had like 20 pairs of Jordan ones. I was like addicted to Jordan 1's and I had to like I like forced myself to stop watching sneaker videos because I was too addicted to buying them. But your channel was like the main channel I watch for sneaker reviews. So Tony did need you wild.

The fact that it's come full circle and I'm now creating content you're watching is pretty incredible. Thank you for the $5 donation. Already running OpenClaw on a Mac Mini that I bought. I got a spare 5800 AMD RTX 3090.

How should I add it in the workflow? What would you do? Uh, here's what I would do, Tony D. Too wild, is I would um go to your Claudebot.

I would say, "Claudy," or whatever name you gave to your Claudebot. I would say, "You've been doing a great job for me. I love the work you're doing, Claudia. Your workflows have been amazing.

These workflows that you've done for me specifically have been great." Now, based on everything we've done together, Claudia, Claudia, good cause Z400 Racer 37. Claudia, um, I have a 5800 AMD and an RTX3090. How can I make the workflows we do better, faster, or cheaper with these two other pieces of hardware I have? What can we do?

How can I set this up based on what you know about me? I'd run that prompt. I tweeted this prompt out a few days ago. I tweeted this prompt out a few days ago.

So, I'd look back on my Twitter. Um, but I would I would send that prompt because, and this is not me trying to skirt the question. I'm saying this because your Claude has the best memory of any AI out there. It knows everything you do.

It knows your preferences. It knows what you like. It knows how to help you. It knows how to script the videos.

It knows how to which sneakers you should be getting next, right? And so it will be able to give you better suggestions around what you can do with those pieces of hardware. This is what I call reverse prompting, right? Reverse prompting.

Instead of telling your AI what to do, right? What you're looking for me right now is like things you can do and prompts you can give. But what you need to do is actually need to reverse prompt and you need to be, hey, Claudia, based on what you know about me, what can we do with a AMD and an RTX3090, right? What tasks can I offload?

And it will set up the workflow for you and tell you how to set it up and what you should be doing on each. You know what I'm saying? Big dog. Does that help?

I hope that's helpful. Reverse prompting. Reverse prompting is the best way to be doing this. I appreciate you, Tony.

You too wild. Thank you for the $5. I'm glad I'm glad it's been helpful. Uh, he wants to use 39 to make sub agents and do all the work.

Lol. He's getting lazy already. Tell him not to get lazy. Say, I just want to offload.

Say, I want you to be my chief strategy officer and I want these other smaller agents to be like your employees. You be the head of strategy, you be my employ, they be your employees. And you got to set that expectation with it. Thank you for you, Clawbot.

Listen, everyone's telling me to go eat. I appreciate you worrying about my health even though I said I have to eat. Um, I got chat with Tony D2. That's pretty sick.

Why'd you pick GLM47 over Kimmy? Because Kimmy doesn't run on one Mac Studio. I only have one Mac Studio right now. My second one comes in next Friday.

Once I get my second Mac Studio, then I'll be running Kimmy K2.5. All right. I'm sure I missed a lot of messages and I'm really, really, really sorry that I missed people's messages because it means the world that you guys would sit here and watch this insanity of a stream. I come into these streams with literally no plan.

I just turn it on and I just vomit whatever is on my mind. So, the fact that you guys would stick around and listen to this is pretty amazing. So, thank you very much. I appreciate you all.

You make this so much fun. Make sure to subscribe and turn on notifications. In five minutes, I'm doing a live boot camp inside the Vibe Code Academy. The link for that is down below.

You can come by and ask any questions you want. Uh Jason Polley, shut up, [&nbsp;__&nbsp;] Patriots are going to win. You're an idiot. Uh final score 17 to 10.

Final score 17 to 10. Write that down. Um that's what you told me exactly what you said. So that is what we'll be doing.

But y'all man, thank you for supporting Alb. Thank you Tony D. That means the world man. Uh, Warriors come out to play.

1710 Patriots. Drake May, Super Bowl MVP. Drake May, baby. Watching sports is subclass behavior.

Shut the [&nbsp;__&nbsp;] up, [&nbsp;__&nbsp;]
