#!/usr/bin/env python3
"""Convert YouTube auto-generated VTT to clean markdown transcript."""
import re
import sys

def clean_vtt(vtt_path, output_path, title, url, date_str):
    with open(vtt_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Remove WEBVTT header and metadata
    content = re.sub(r'WEBVTT\n.*?\n\n', '', content, count=1, flags=re.DOTALL)

    # Split into cue blocks
    blocks = content.strip().split('\n\n')

    lines = []
    for block in blocks:
        block_lines = block.strip().split('\n')
        text_lines = []
        for line in block_lines:
            # Skip timestamp lines
            if re.match(r'\d{2}:\d{2}:\d{2}\.\d{3}\s*-->', line):
                continue
            # Skip empty lines
            if not line.strip():
                continue
            # Clean HTML/VTT tags
            line = re.sub(r'<\d{2}:\d{2}:\d{2}\.\d{3}>', '', line)
            line = re.sub(r'</?c>', '', line)
            line = re.sub(r'align:start\s*position:\d+%', '', line)
            line = line.strip()
            if line:
                text_lines.append(line)
        
        if text_lines:
            # For YouTube auto-subs, the second line in a pair is usually the new content
            # Take the last non-empty line from each block as the "complete" version
            lines.append(text_lines[-1] if len(text_lines) > 0 else '')

    # Deduplicate consecutive identical lines
    deduped = []
    prev = None
    for line in lines:
        if line != prev and line.strip():
            deduped.append(line)
            prev = line

    # Now merge into paragraphs. YouTube auto-subs produce short fragments.
    # We'll join them, then split into paragraphs at natural breaks (sentence endings followed by gaps).
    full_text = ' '.join(deduped)
    
    # Clean up extra spaces
    full_text = re.sub(r'\s+', ' ', full_text).strip()
    
    # Split into paragraphs roughly every 4-6 sentences for readability
    sentences = re.split(r'(?<=[.!?])\s+', full_text)
    
    paragraphs = []
    current = []
    for i, sent in enumerate(sentences):
        current.append(sent)
        # Create paragraph every ~5 sentences
        if len(current) >= 5:
            paragraphs.append(' '.join(current))
            current = []
    if current:
        paragraphs.append(' '.join(current))

    # Build markdown
    md = f"""# {title}

- **Video:** [{url}]({url})
- **Channel:** Alex Finn
- **Extracted:** {date_str}

---

"""
    md += '\n\n'.join(paragraphs)
    md += '\n'

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(md)
    
    print(f"Done! {len(paragraphs)} paragraphs, {len(full_text)} chars written to {output_path}")

if __name__ == '__main__':
    clean_vtt(
        '/home/inkredible/.openclaw/workspace/transcripts/0v2-mUUWNdc.en.vtt',
        '/home/inkredible/.openclaw/workspace/transcripts/0v2-mUUWNdc.md',
        'LIVE: The ULTIMATE OpenClaw setup',
        'https://www.youtube.com/live/0v2-mUUWNdc',
        '2026-02-13'
    )
