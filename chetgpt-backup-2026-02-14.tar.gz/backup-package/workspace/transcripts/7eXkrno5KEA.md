# How to Setup Claude Memory in 5 Mins!
# URL: https://www.youtube.com/watch?v=7eXkrno5KEA

## Transcript (via youtube-transcript.io)

00:00
Today we're going to be looking at how to use claude code with claude mem. So it's called claude hyphen mem and this is a way of getting persistent memory inside claw codes. You can see this tweet here from tech with Mac who talks about it. He says clo close code use
00:15
open claw code. Sorry close claw code. Open claw code. It remembers everything using this. Right. So we're going to test this out and see how it performs today. The way that I'm going to use this is one second. So the way that I'm going to use this is I'm just going to install it with
00:31
terminal directly using claude. So if we open up claw code here, we'll use claw code to set up memory inside claw code. All right. So I'm going to say install this so that you can remember everything. Bear in mind like this is an open-source skill. Always be careful when you
00:47
install stuff from GitHub or that sort of thing. I test out live on YouTube to show you cool stuff. Just make sure you read through the skill MD files and everything else. um and run it through claw before you use it just to be careful here. And Greg says, "Silly
00:59
question. It's probably been answered already, but are you not concerned with security and open claw?" So, there's a few things I'd recommend um and I've I've covered it a lot inside all of my openclaw videos, but if you go inside here, if you're concerned with security,
01:11
set up malt worker, right? Molt worker. There's a full guide inside the air. We'll show you how to set up uh OpenClaw on Cloudflare. Why is that important? It's important because they protect half the internet. there is, you know, they're focused on on security and also
01:26
you need you you get to sandbox your open clause from the internet. Also, you approve anyone before they can even use it. And finally, and finally, they can um they have to get an email verification code before they can login. So, that's three ways to
01:41
make sure that open claw is more secure using molt worker. Again, like if you're not comfortable, if you're like, I'm worried about security blah blah blah, don't install it. Like, don't don't use anything that you're not comfortable with, right? Like that's that's the main
01:53
principle. I think some people forget that. But yeah, it's like if if you're looking at something, you're like, not sure if I should use that. Don't use it. So from here, we're going to get terminal to set up the GitHub. Like you can see, you might be wondering what it
02:07
is, how it works, etc. So let me talk you through that as well in the meantime. So Claude me is basically a plug-in for claw code that gives it permanent memory across your coding sessions, right? So it's kind of like giving Claude a brain that never forgets. And the problem is like
02:20
every time you close cord uh claw code, you open it again and it forgets everything, right? So it forgets all the stuff that you've done, you have to reexplain everything from scratch. Quite annoying. So with claude mem, this automatically captures everything Claude
02:32
does, compresses in searchable summaries and loads relevant context when you start new sessions, right? So there's no manual work required. This is fully open source as well. And if we go into terminal now, we should start setting up. You have this on the left hand side
02:45
so it's easier to manage. There we go. It's also quite easy to install because you can just get claw code set up in the first place. And then how it works, simple explanation. It automatically captures stuff, right? So every time Claude uses a tool reads a file or make
02:57
a change, Claude memory captures it in the background. This also allows you to do AI compression, right? So this is basically like a background service using Claude's agent SDK to compress observations um into summaries. And so like it just reduces the amount of
03:10
tokens you use. Top of that, you got smart retrieval. So when you start a new session, Claw memory automatically injects relevant context. It doesn't like just put everything it ever remembers inside there. It uses like just little bits, little tidbits to to
03:22
give it memory back to what you need. And then also you can search when you need it. So you can ask Claude like when did we work on this yesterday or what did we do here or show me the database changes or show me the changes you made on this blah blah blah. Right? So the
03:33
key features here that you get persistent memory, you get progressive disclosure. So it loads a lightweight index first to save tokens. You've actually got a real-time dashboard apparently when you set this up. You got privacy controls as well. You can
03:46
actually wrap stuff in private so it doesn't remember it if you want to keep anything in private. Your automatic operations and natural language search, right? And it's also automatic. That's the beauty of this, right? It just works automatically. So every time we use claw
03:59
code, it's just going to remember stuff in the background. We don't have to do anything. Now, why would this be useful? Well, number one, for content creators, you can remember all your content. You can track topics you've already covered, reference path, successful formats,
04:10
maintain continuity in series content, and search like what did I say about X in previous videos, right? Just to stay consistent. For coders, it's great because you get like architectural decisions that persist forever. Bug fixes are remembered, refactoring
04:23
history stays accessible, code patterns you've used before, and why did we build it this way sort of stuff is is ready there as well. So now what we have to do is just edit this. I'm just going to click enter inside the chat. You can also use it for AI agents. I think
04:35
that's one of the most powerful ways of using this is like you know it can it can remember how you use AI agents the teams that you set up etc. So show you in a minute, but if I said like set up a team that creates YouTube thumbnails, right, inside claw code and then I
04:50
closed claw code and reopened it at the minute, it wouldn't remember those thumbnails. But if I reopen it with persistent memory setup called mem, then we can get better um we can we can get better memory options in the future. It also saves a lot of tokens as well because everything is
05:07
summarized. So it loads compressed summaries. So for example, previously every session would reload the entire project context, whereas now you just load these compressed summaries, right, which uses less tokens. You can also see here we've now cloned and set up. So
05:21
here's what we've done. We've set up old meme, registered it, installed it, ran the setup, and we now get persistent memory. Plus, we can actually see past session history via this local host. Right? Okay. So if we go here we can check out the web UI in a second.
05:53
There we go. So this is claude me. So you can see this is the history of whatever we've done inside code. And now it is running in the background. Right. So this is our memory stream. So if we close claw code now and then open up um we'll say like okay build a simple
06:14
SEO count u let's let's say build a simple pomodora timer something like that right so we created this simple pomodora timer here right and then what we're going to do inside the chat here is we're going to close claw code open it up again and just check This is
06:31
working. You can see the history inside the chat here. So, if you open this up inside the console, you can see what we've worked on. And then we'll say, okay, open up that Pomodoro timer you just created. And there you go. Right, it's reopened it. The exact same file. So, it's not like
06:47
created a new one or anything like that. It's like remembered, okay, this is the Pomodoro timer that we just built. Boom. We've got the memory right there. So, it's pretty awesome to have that feature. I think it's really good to set up. Once you set up, once it's
06:60
automatically running in the background, you've got the full console history right here. You can auto refresh this as well. You can download the memory. It's automatically running inside a web UI as you can see. And then inside core code now automatically remembers stuff and
07:13
we're good to go on that. So I think it's a really powerful feature. It it helps me a lot because you know for example, let's say there's certain workflows I use with claw code every day. Well, if I have to shut down and then reopen it, that's super annoying.
07:27
Whereas if I have a permanent memory, well, it's it's pretty much clawbar. It's pretty much as good as clawbar. I think there's there's not much really that you can't do inside claw code that you could do inside open claw. The only difference is like you're using it
07:39
inside your terminal. Whereas, for example, if you're using open claw, you're using that directly inside telegram. But with the memory feature, it solves a lot of problems. It saves a lot of tokens as well. So, thanks so much for watching. If you want to get
07:50
the full guide on this, you can get it inside the AR profit boardroom. Just go to the classroom here link in the comments in description or go to arrufferborn.com and inside the 9th of November. You can see the full guide plus a link on how to set up persistent
08:03
memory plus how it works with claude code. And this is my AI automation community where I show you how to save time, scale and grow with AI automation. You can post questions inside the community here and get help and support whenever you need it. Additionally, you
08:15
can see inside the classroom we've got all sorts of stuff. So, if you want to learn how to go from like complete beginner to expert with AI, you can see that right here. Plus, you'll learn how to build your first AI agent in under 5 minutes. Additionally, you will learn,
08:28
for example, inside the playbooks here, how to automate avatar videos, Instagram videos, newsletters, Twitter, shorts, etc. And inside the classroom, you can get my daily updates. So, if you check out this section, you can see, for example, we're updating this um every
08:43
day with new tutorials. that you can see also inside the classroom here. You can learn how to get more clients with the agency course. You can learn how to rank number one with AI SEO based on what's working for me. And you get a full course on how to grow your YouTube with
08:55
AI based on what's working for me as well. So feel free to get that link in the comments description or go to apiprofitbom.com.
