# Alex Finn ClawdBot/OpenClaw - Complete Analysis

A comprehensive analysis of all Alex Finn ClawdBot/OpenClaw YouTube transcripts, organized by topic with citations.

---

## 1. SETUP TIPS - Commands, Configurations, Settings

### Installation Methods

**Local Installation (Recommended)**
- Go to openclaw.ai and copy the install command
- Paste into terminal (Mac/Linux) or command line (Windows)
- Run the installer - it handles everything automatically
- Use `openclaw onboard` in terminal to start onboarding
- Choose "quick start" for guided setup

Source: [ev4iiGXlnh0.md - DO NOT use a VPS for OpenClaw](https://youtube.com/watch?v=ev4iiGXlnh0)

**Cloud/VPS Installation (Not Recommended)**
- Create EC2 instance on AWS
- Configure security group: allow SSH (port 22) and custom TCP port 18789
- Launch instance and connect via browser console
- Copy install command from openclaw docs
- Use `OOTH` command flow for token setup

Source: [04wh2Hlgbds.md - CHEAPEST and EASIEST way to set up ClawdBot](https://youtube.com/watch?v=04wh2Hlgbds)

**Initial Configuration Settings**
- Choose AI provider: Anthropic (Claude), OpenAI (ChatGPT), or cheaper alternatives
- For Anthropic: use Claude Max subscription ($200/month) or API tokens
- For ChatGPT: use GPT-4o or cheaper models
- Set up messaging service: Telegram (recommended), iMessage, WhatsApp, or Discord
- Configure initial name and personality settings

Source: [Qkqe-uRhQJE.md - ClawdBot is the most powerful AI tool - Setup guide](https://youtube.com/watch?v=Qkqe-uRhQJE)

### Port Configuration
- Default OpenClaw port: 18789
- Ensure this port is open if using remote access
- Configure firewall settings appropriately

---

## 2. COST OPTIMIZATION - How to Reduce Spending on Models

### Model Selection by Budget

**Expensive but Best Quality ($200+/month)**
- Claude Opus 4/4.5: Best intelligence and personality
- Use for: complex reasoning, creative work, voice conversations

Source: [UTCi_q6iuCM.md - How to make ClawdBot 10x better (5 easy steps)](https://youtube.com/watch?v=UTCi_q6iuCM)

**Mid-Range Balance ($50-100/month)**
- Claude Sonnet 4: Good balance of cost and capability
- Use for: coding tasks, medium-complexity workflows

**Budget Options ($5-20/month)**
- Kimi K2.5 (Moonshot): Excellent value, near-Opus intelligence
- MiniMax: Cheapest option but less reliable
- Use for: simple tasks, high-volume operations

Source: [lxfakTpdz1Y.md - How to run ClawdBot for DIRT CHEAP](https://youtube.com/watch?v=lxfakTpdz1Y)

### Cost-Cutting Strategies

**1. Task-Specific Model Routing**
- Use Opus only for reasoning/creative tasks
- Use cheaper models for routine operations
- Route coding to Claude Code, research to Gemini/Perplexity

Source: [UTCi_q6iuCM.md - How to make ClawdBot 10x better](https://youtube.com/watch?v=UTCi_q6iuCM)

**2. Heartbeat Optimization**
- Reduce heartbeat frequency from 10 minutes to hourly or longer
- Use cheaper models (Haiku) for heartbeat checks
- Saves approximately $50+/month

Source: [lxfakTpdz1Y.md - How to run ClawdBot for DIRT CHEAP](https://youtube.com/watch?v=lxfakTpdz1Y)

**3. Local Models (Free After Hardware Cost)**
- GLM 4.7/5 (Zhipu): Excellent free local models
- Llama models for specific tasks
- Flux for image generation
- Run on Mac Studio ($3,000-10,000) or Mac Mini ($600)

Source: [0v2-mUUWNdc.md - LIVE: The ULTIMATE OpenClaw setup](https://youtube.com/watch?v=0v2-mUUWNdc)

**4. Context Window Management**
- Use Opus 4.6 1M token context for long projects
- Reduces need for repeated context setting
- More efficient token usage overall

Source: [iGkhfUvRV6o.md - Claude Opus 4.6 MASSIVE upgrade](https://youtube.com/watch?v=iGkhfUvRV6o)

---

## 3. MODEL ROUTING - Which Models for Which Tasks

### The Brain vs. Muscles Concept

**Brain (Orchestration Layer)**
- Claude Opus 4/4.6: Best for complex decision-making
- Claude Sonnet 4: Good for routine orchestration
- Kimi K2.5: Budget option for simple orchestration

**Muscles (Task Execution)**
- Claude Code/Codex: Coding tasks
- Kimi/GLM: Writing and research
- Flux: Image generation
- X API: Social media monitoring

Source: [0v2-mUUWNdc.md - LIVE: The ULTIMATE OpenClaw setup](https://youtube.com/watch?v=0v2-mUUWNdc)

### Specific Task Routing

| Task Type | Best Model | Budget Alternative |
|-----------|------------|-------------------|
| Complex reasoning | Claude Opus 4.6 | Claude Sonnet 4 |
| Coding | Claude Code + Codex | Kimi K2.5 |
| Web research | Gemini + Perplexity | DeepSeek |
| Content writing | Opus 4.6 | Kimi K2.5 |
| Image generation | Flux (local) | DALL-E 3 |
| Social monitoring | X API + GLM | Budget models |
| Voice interaction | Real-time APIs | Text-only |

Source: [lxfakTpdz1Y.md - How to run ClawdBot for DIRT CHEAP](https://youtube.com/watch?v=lxfakTpdz1Y)

---

## 4. SKILLS & PLUGINS - What to Install and Why

### Core Skills to Install

**1. Frontend Design Skill**
- Transforms AI-generated UIs from "blue and purple slop" to professional designs
- Install via Claude Code skills folder
- Usage: "Use the frontend design skill for this component"

Source: [thxXGxYIwUI.md - Claude Code Skills are INSANE](https://youtube.com/watch?v=thxXGxYIwUI)

**2. Stripe Integration Skill**
- Consistent, correct Stripe setup every time
- Handles webhooks, subscriptions, customer management
- Critical for any SaaS build

Source: [thxXGxYIwUI.md - Claude Code Skills are INSANE](https://youtube.com/watch?v=thxXGxYIwUI)

**3. Content Research/Writer Skill**
- Analyzes your codebase to understand your product
- Writes marketing copy in YOUR voice
- Generates blog posts, tweets, newsletters

Source: [thxXGxYIwUI.md - Claude Code Skills are INSANE](https://youtube.com/watch?v=thxXGxYIwUI)

**4. Lead Research Assistant**
- Identifies target customers based on your product
- Finds decision makers and contact information
- Generates outreach templates

Source: [thxXGxYIwUI.md - Claude Code Skills are INSANE](https://youtube.com/watch?v=thxXGxYIwUI)

**5. Domain Name Brainstormer**
- Searches available domains across .ai, .com, .dev, .io
- Saves hours of manual checking
- Generates creative alternatives

Source: [thxXGxYIwUI.md - Claude Code Skills are INSANE](https://youtube.com/watch?v=thxXGxYIwUI)

### Skill Installation Process

1. Download skill folder (typically .skill file)
2. Rename to .zip and extract
3. Copy to Claude Code skills folder
4. Skill activates automatically based on context

Source: [lFGK0IvPaNc.md - Claude Skills explained](https://youtube.com/watch?v=lFGK0IvPaNc)

### Custom Skills Creation

**Idea Validator Skill**
- Evaluates market demand, competition, feasibility
- Prevents building products nobody wants
- Criteria: market crowdedness, demand, monetization

Source: [lFGK0IvPaNc.md - Claude Skills explained](https://youtube.com/watch?v=lFGK0IvPaNc)

**Launch Planner Skill**
- Creates MVPs with clear scope
- Generates PRDs and database schemas
- Prevents overengineering

Source: [lFGK0IvPaNc.md - Claude Skills explained](https://youtube.com/watch?v=lFGK0IvPaNc)

**Marketing Writer Skill**
- Landing page copy
- Tweet threads
- Product Hunt descriptions
- Launch emails

Source: [lFGK0IvPaNc.md - Claude Skills explained](https://youtube.com/watch?v=lFGK0IvPaNc)

**Roadmap Builder (Product Manager)**
- Feature prioritization
- MVP scoping
- User retention strategies

Source: [lFGK0IvPaNc.md - Claude Skills explained](https://youtube.com/watch?v=lFGK0IvPaNc)

---

## 5. AUTOMATION IDEAS - Workflows, Cron Jobs, Integrations

### Morning Brief Automation
- Schedule: 8 AM daily
- Contents: Weather, trending videos, tasks, agent overnight progress
- Connect to Things 3 or any to-do list
- Include Brave search API for trending stories

Source: [b-l9sGh1-UY.md - 5 insane ClawdBot use cases](https://youtube.com/watch?v=b-l9sGh1-UY)

### Multi-Agent Orchestration Setup

**Agent Team Structure**
- Henry: Main orchestrator/conductor
- Scout: Research agent (X monitoring, trending detection)
- Quill: Writing/content agent
- Pixel: Thumbnail/visual design agent
- Digest: Daily summary agent
- Trend Radar: Opportunity identification

Source: [0v2-mUUWNdc.md - LIVE: The ULTIMATE OpenClaw setup](https://youtube.com/watch?v=0v2-mUUWNdc)

### Workflow Automations

**1. Viral Content Detection**
- Scout monitors X every 5-20 seconds
- Alerts on trending posts about AI/Claude
- Immediate notification via Discord
- Never miss a trending topic

Source: [0v2-mUUWNdc.md - LIVE: The ULTIMATE OpenClaw setup](https://youtube.com/watch?v=0v2-mUUWNdc)

**2. YouTube Script Factory**
- Quill researches trending topics
- Generates complete scripts in your voice
- Creates thumbnail concepts
- Output to review queue

Source: [0v2-mUUWNdc.md - LIVE: The ULTIMATE OpenClaw setup](https://youtube.com/watch?v=0v2-mUUWNdc)

**3. Second Brain System**
- Next.js app for document storage
- Automatic journal entries
- Concept exploration documents
- Markdown viewer with organization

Source: [b-l9sGh1-UY.md - 5 insane ClawdBot use cases](https://youtube.com/watch?v=b-l9sGh1-UY)

**4. Daily Research Reports**
- Scheduled afternoon delivery
- Based on your interests and business
- Deep dives on relevant concepts
- Workflow improvement suggestions

Source: [b-l9sGh1-UY.md - 5 insane ClawdBot use cases](https://youtube.com/watch?v=b-l9sGh1-UY)

**5. Reddit/X Research Skill**
- Parallel research across platforms
- 30-day trend analysis
- Content opportunity identification
- Citation and source tracking

Source: [b-l9sGh1-UY.md - 5 insane ClawdBot use cases](https://youtube.com/watch?v=b-l9sGh1-UY)

### Claude Code Automations

**Weekly Check-in**
- Tracks all business metrics
- Personal goals progress
- Side hustle updates
- Creates visual dashboard

Source: [wfiv67NixCY.md - How I use Claude Code to automate my entire life](https://youtube.com/watch?v=wfiv67NixCY)

**Daily Check-in/Journaling**
- Runs via `/daily` command
- Captures wins, feelings, accomplishments
- Stores in journaling dashboard
- Builds habit tracking system

Source: [wfiv67NixCY.md - How I use Claude Code to automate my entire life](https://youtube.com/watch?v=wfiv67NixCY)

**Newsletter Research & Draft**
- `/newsletter_researcher` command
- Analyzes competitor newsletters
- Studies your past content
- Writes draft in your voice

Source: [wfiv67NixCY.md - How I use Claude Code to automate my entire life](https://youtube.com/watch?v=wfiv67NixCY)

**Brain Dump Analyzer**
- `/brain_dump_analysis` command
- Weekly analysis of notes
- Creates mind map visualizations
- Extracts philosophy, identity, strategies

Source: [wfiv67NixCY.md - How I use Claude Code to automate my entire life](https://youtube.com/watch?v=wfiv67NixCY)

**Daily Brief Agent**
- `/daily_brief` command
- Researches all your interests
- Compiles industry news
- Content opportunity identification

Source: [wfiv67NixCY.md - How I use Claude Code to automate my entire life](https://youtube.com/watch?v=wfiv67NixCY)

---

## 6. WARNINGS - Things to Avoid, Common Mistakes

### Security Warnings

**⚠️ DO NOT Use VPS for OpenClaw**
- VPS instances are often insecure by default
- Anyone can scan and access poorly configured EC2 instances
- Requires technical expertise to secure properly
- Local device is default-secure (especially Mac)

Source: [ev4iiGXlnh0.md - DO NOT use a VPS for OpenClaw](https://youtube.com/watch?v=ev4iiGXlnh0)

**⚠️ Avoid Unofficial Scrapers**
- X API violations can get your account suspended
- Use official API routes only
- Risk of lawsuits from platform owners
- Brand damage if account is lost

Source: [0v2-mUUWNdc.md - LIVE: The ULTIMATE OpenClaw setup](https://youtube.com/watch?v=0v2-mUUWNdc)

**⚠️ Be Careful with Community Skills**
- Skills marketplaces can contain compromised code
- Skills have full access to your system
- Better to have Claude create custom skills
- Or thoroughly audit any downloaded skills

Source: [0v2-mUUWNdc.md - LIVE: The ULTIMATE OpenClaw setup](https://youtube.com/watch?v=0v2-mUUWNdc)

### Common Mistakes

**❌ Treating Claudebot Like a Search Engine**
- It's an employee, not a chatbot
- Set expectations proactively
- Treat it like a human subordinate

Source: [UTCi_q6iuCM.md - How to make ClawdBot 10x better](https://youtube.com/watch?v=UTCi_q6iuCM)

**❌ Using Opus for Everything**
- Most tasks don't need Opus intelligence
- Burning expensive tokens on simple tasks
- Route to cheaper models for routine work

Source: [lxfakTpdz1Y.md - How to run ClawdBot for DIRT CHEAP](https://youtube.com/watch?v=lxfakTpdz1Y)

**❌ Not Doing Brain Dump**
- Skip the initial personality/context setup
- Without context, Claudebot can't be proactive
- Spend 10+ minutes telling it about yourself

Source: [Qkqe-uRhQJE.md - ClawdBot is the most powerful AI tool](https://youtube.com/watch?v=Qkqe-uRhQJE)

**❌ Ignoring Memory Settings**
- Default memory compaction causes forgetting
- Enable memory flush and session memory search
- Significantly improves memory retention

Source: [UTCi_q6iuCM.md - How to make ClawdBot 10x better](https://youtube.com/watch?v=UTCi_q6iuCM)

**❌ Not Using Reverse Prompting**
- Only doing "regular prompting" (telling what to do)
- Missing out on Claudebot's proactive suggestions
- Reverse prompting = asking what IT should do

Source: [UTCi_q6iuCM.md - How to make ClawdBot 10x better](https://youtube.com/watch?v=UTCi_q6iuCM)

**❌ Running Without Review**
- Don't let agents push directly to production
- Review all code and content before publishing
- Especially for customer-facing products

Source: [0v2-mUUWNdc.md - LIVE: The ULTIMATE OpenClaw setup](https://youtube.com/watch?v=0v2-mUUWNdc)

---

## 7. HARDWARE RECOMMENDATIONS

### Minimum Viable Setup

**Mac Mini (M4 Pro recommended)**
- 64GB RAM minimum
- 512GB+ storage
- Cost: ~$1,500-2,000
- Can run local models for cost savings

Source: [0v2-mUUWNdc.md - LIVE: The ULTIMATE OpenClaw setup](https://youtube.com/watch?v=0v2-mUUWNdc)

### Recommended Setup

**Mac Studio**
- 512GB RAM for heavy local model usage
- Runs GLM 4.7/5, Flux for images
- Cost: ~$3,000-10,000 fully loaded
- Best for running multiple local models simultaneously

Source: [0v2-mUUWNdc.md - LIVE: The ULTIMATE OpenClaw setup](https://youtube.com/watch?v=0v2-mUUWNdc)

### Budget Options

**Raspberry Pi ($50-150)**
- Minimal setup for learning
- Limited capability but functional
- Good for dipping toes before investing

Source: [ev4iiGXlnh0.md - DO NOT use a VPS for OpenClaw](https://youtube.com/watch?v=ev4iiGXlnh0)

**Old Laptop**
- Wipe and install fresh OS
- Use as dedicated Claudebot machine
- Free if you have spare hardware

Source: [ev4iiGXlnh0.md - DO NOT use a VPS for OpenClaw](https://youtube.com/watch?v=ev4iiGXlnh0)

### Local Model Hardware Requirements

| Model Type | RAM Required | Use Case |
|-----------|-------------|----------|
| GLM 4.7/5 | 30-60GB | Research, writing |
| Flux | 30GB+ | Image generation |
| Llama variants | 16-64GB | Various tasks |

Source: [0v2-mUUWNdc.md - LIVE: The ULTIMATE OpenClaw setup](https://youtube.com/watch?v=0v2-mUUWNdc)

---

## 8. BROWSER/WEB AUTOMATION - Scraping, Web Control

### X/Twitter Monitoring

**Official API Setup**
- Use X API (not scrapers)
- Sign up at developer.x.com
- Get bearer token for authentication
- Pay per use (~$42,000/year for heavy usage)

Source: [0v2-mUUWNdc.md - LIVE: The ULTIMATE OpenClaw setup](https://youtube.com/watch?v=0v2-mUUWNdc)

**Alert Configuration**
- Monitor every 5-20 seconds for trending topics
- Filter by keywords (AI, Claude, OpenClaw)
- Discord channel notifications
- Never miss viral moments

Source: [0v2-mUUWNdc.md - LIVE: The ULTIMATE OpenClaw setup](https://youtube.com/watch?v=0v2-mUUWNdc)

### YouTube Research

**Content Opportunity Detection**
- Monitor trending videos in your niche
- Analyze engagement patterns
- Generate content angles
- Create reaction video topics

Source: [0v2-mUUWNdc.md - LIVE: The ULTIMATE OpenClaw setup](https://youtube.com/watch?v=0v2-mUUWNdc)

### Web Research Pipeline

**Competitor Analysis**
- Subscribe to competitor newsletters
- Analyze their content strategy
- Identify gaps and opportunities
- Use Claude Code researcher agent

Source: [wfiv67NixCY.md - How I use Claude Code to automate my entire life](https://youtube.com/watch?v=wfiv67NixCY)

---

## 9. MEMORY MANAGEMENT - How to Persist Important Data

### Brain Dump Framework

**Initial Context Setup**
- Spend 10+ minutes telling Claudebot about yourself
- Include: dreams, ambitions, goals, daily routine
- Personal relationships, interests, hobbies
- Work details and career objectives

Source: [Qkqe-uRhQJE.md - ClawdBot is the most powerful AI tool](https://youtube.com/watch?v=Qkqe-uRhQJE)

**Memory Files Structure**
- soul.md: Core identity and values
- memory.md: Interaction history and preferences
- agent.md: Agent-specific configurations
- Separate files for different agent roles

Source: [0v2-mUUWNdc.md - LIVE: The ULTIMATE OpenClaw setup](https://youtube.com/watch?v=0v2-mUUWNdc)

### Memory Optimization Settings

**Enable Advanced Memory Features**
1. Memory Flush: Saves important context before compaction
2. Session Memory Search: Searches full conversation history
3. Custom Memory Skills: Claude creates memory structures

Source: [UTCi_q6iuCM.md - How to make ClawdBot 10x better](https://youtube.com/watch?v=UTCi_q6iuCM)

### Second Brain System

**Next.js App Structure**
- Document viewer with search
- Journal entries (daily)
- Concept explorations
- Project documentation
- Automatic tagging by category

Source: [b-l9sGh1-UY.md - 5 insane ClawdBot use cases](https://youtube.com/watch?v=b-l9sGh1-UY)

**Installation Prompt**
```
I want you to build a second brain. This should be a Next.js app
that shows a list of documents you create as you work together
in a nice document viewer that feels like a mix of Obsidian and Linear.
Create a folder where all the documents are viewable.
Update your memory skills so we create documents exploring important concepts.
Create daily journal entries summarizing our discussions.
```

Source: [b-l9sGh1-UY.md - 5 insane ClawdBot use cases](https://youtube.com/watch?v=b-l9sGh1-UY)

### Memory Persistence Patterns

**Preference Learning**
- React with ✅ or ❌ to generated content
- Claudebot saves preferences automatically
- Improves future outputs based on reactions
- Iterative refinement of voice and style

Source: [0v2-mUUWNdc.md - LIVE: The ULTIMATE OpenClaw setup](https://youtube.com/watch?v=0v2-mUUWNdc)

**Context Architecture**
- Shared memory across all agents
- Separate agent-specific contexts
- Daily sync and consolidation
- Version history for rollback

Source: [0v2-mUUWNdc.md - LIVE: The ULTIMATE OpenClaw setup](https://youtube.com/watch?v=0v2-mUUWNdc)

---

## 10. SUB-AGENT PATTERNS - Background Tasks Effectively

### Agent Teams (Claude Code 4.6+)

**Enable Agent Teams**
- New feature in Opus 4.6
- Disabled by default
- Use command: "Use an agent team to build this"
- Spins up multiple Claude Code sessions in parallel

Source: [iGkhfUvRV6o.md - Claude Opus 4.6 MASSIVE upgrade](https://youtube.com/watch?v=iGkhfUvRV6o)

**Team Communication**
- Shift+Up/Down to switch between agents
- Talk to team lead or individual agents
- Hierarchical communication structure
- Much more flexible than sub-agents

Source: [iGkhfUvRV6o.md - Claude Opus 4.6 MASSIVE upgrade](https://youtube.com/watch?v=iGkhfUvRV6o)

### Sub-Agent Best Practices

**Single Prompt Sub-Agents**
- Use `/daily`, `/weekly`, `/researcher` commands
- Each spawns dedicated agent for task
- Agent returns structured output
- No manual orchestration needed

Source: [wfiv67NixCY.md - How I use Claude Code to automate my entire life](https://youtube.com/watch?v=wfiv67NixCY)

**Autonomous Workflow**
```
Before sleep: "Build something cool tonight"
Morning: Review completed work
Feedback: Approve or request changes
Iteration: Agent improves based on feedback
```

Source: [Qkqe-uRhQJE.md - ClawdBot is the most powerful AI tool](https://youtube.com/watch?v=Qkqe-uRhQJE)

### Multi-Agent Coordination

**Orchestrator Pattern**
```
Henry (main) → Scouts → Research → Quill → Content
                         ↓
                    Pixel → Visuals
```

**Daily Digest Pattern**
- All agents report overnight progress
- Single morning review of all work
- Approve or redirect as needed
- Continuous improvement cycle

Source: [0v2-mUUWNdc.md - LIVE: The ULTIMATE OpenClaw setup](https://youtube.com/watch?v=0v2-mUUWNdc)

### Claude Code Sub-Agents

**Setup Commands**

Weekly Check-in:
```
Create a weekly check-in sub-agent that:
- Collects metrics on business, personal goals, side hustles
- Creates visual dashboard
- Identifies growth opportunities
```

Source: [wfiv67NixCY.md - How I use Claude Code to automate my entire life](https://youtube.com/watch?v=wfiv67NixCY)

Newsletter Researcher:
```
Build a newsletter researcher agent that:
- Analyzes competitor newsletters
- Studies your past content
- Writes draft in your voice
- Suggests trending angles
```

Source: [wfiv67NixCY.md - How I use Claude Code to automate my entire life](https://youtube.com/watch?v=wfiv67NixCY)

---

## Summary: Key Takeaways

1. **Start Local** - Don't use VPS, install on your own device
2. **Budget Wisely** - Use cheaper models for routine tasks, Opus only for complex reasoning
3. **Build Skills** - Custom skills transform Claude Code from generalist to specialist
4. **Automate Everything** - Morning briefs, daily digests, overnight builds
5. **Memory First** - Extensive brain dump enables proactivity
6. **Multi-Agent** - Specialized agents for research, writing, visuals
7. **Review Everything** - Don't let agents push to production without approval
8. **Reverse Prompt** - Ask what IT should do, don't just tell it what to do

---

*Analysis compiled from 11 Alex Finn ClawdBot/OpenClaw YouTube transcripts*
*Generated: February 2026*
