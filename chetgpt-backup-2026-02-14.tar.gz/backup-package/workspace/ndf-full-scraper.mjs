#!/usr/bin/env node
// NDF Full Price Scraper - Fetches pages, extracts attrs, calls API, builds Excel
import { writeFileSync } from 'fs';
import { JSDOM } from 'jsdom';

const API_URL = 'https://calculator.nextdayflyers.com/v1/computePrice';
const API_KEY = 'calculator.site';
const API_SECRET = 'KEfm75#XjwSMux92zUWD9T8AafG!vwV6';
const AUTH = 'Basic ' + Buffer.from(`${API_KEY}:${API_SECRET}`).toString('base64');

const PRODUCTS = [
  { name: 'Postcards', url: 'https://www.nextdayflyers.com/postcard-printing/standard-postcards.php' },
  { name: 'Business Cards', url: 'https://www.nextdayflyers.com/business-card-printing/standard-business-cards.php' },
  { name: 'Flyers', url: 'https://www.nextdayflyers.com/flyer-printing/business-flyers.php' },
  { name: 'Banners', url: 'https://www.nextdayflyers.com/banner-printing/vinyl-banners.php' },
  { name: 'Stickers', url: 'https://www.nextdayflyers.com/sticker-printing/bulk-stickers.php' },
  { name: 'Brochures (Tri-fold)', url: 'https://www.nextdayflyers.com/brochure-printing/tri-fold-brochure' },
  { name: 'Posters', url: 'https://www.nextdayflyers.com/poster-printing/bulk-posters.php' },
  { name: 'Door Hangers', url: 'https://www.nextdayflyers.com/door-hanger-printing/' },
  { name: 'Rack Cards', url: 'https://www.nextdayflyers.com/rack-card-printing/custom-rack-cards.php' },
  { name: 'Booklets', url: 'https://www.nextdayflyers.com/booklet-printing/' },
];

// Key quantities to focus on
const KEY_QTY_TEXTS = ['25','50','100','250','500','1,000','2,500','5,000','10,000','25,000','50,000'];

async function fetchPage(url) {
  const resp = await fetch(url, {
    headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
  });
  return resp.text();
}

function extractAttrsFromHTML(html) {
  const dom = new JSDOM(html);
  const doc = dom.window.document;
  
  const attrs = {};
  
  // Find all attr containers
  doc.querySelectorAll('[id^="attr_container_"]').forEach(container => {
    const attrId = container.id.replace('attr_container_', '');
    if (attrId.includes('label') || attrId === 'width' || attrId === 'height') return;
    
    const options = container.querySelectorAll('.attr-value[data-value]');
    if (options.length === 0) return;
    
    const optList = [];
    options.forEach(o => {
      const val = o.getAttribute('data-value');
      const display = o.getAttribute('data-display') || o.textContent.trim();
      if (val && val !== 'custom') {
        optList.push({ text: display, id: val });
      }
    });
    
    if (optList.length > 0) {
      attrs[attrId] = optList;
    }
  });
  
  // Extract product_id from page scripts
  let productId = null;
  const scripts = doc.querySelectorAll('script');
  for (const script of scripts) {
    const text = script.textContent;
    // Look for product_id in various patterns
    const match = text.match(/product_id['":\s]+(\d+)/);
    if (match) {
      productId = match[1];
      break;
    }
  }
  
  // Also look for calc-data or ng-init with product_id
  if (!productId) {
    const calcData = doc.querySelector('[data-product-id]');
    if (calcData) productId = calcData.getAttribute('data-product-id');
  }
  
  // Try to find product_id in inline JSON
  if (!productId) {
    const bodyText = html;
    const pidMatch = bodyText.match(/"product_id"\s*:\s*"?(\d+)"?/);
    if (pidMatch) productId = pidMatch[1];
  }
  
  return { attrs, productId };
}

function identifyAttrTypes(attrs) {
  // Identify which attr IDs are size, quantity, turnaround, etc.
  let sizeAttrId = null;
  let qtyAttrId = null;
  let tatAttrId = '333'; // Always 333 for NDF products
  const otherDefaults = {};
  
  for (const [attrId, options] of Object.entries(attrs)) {
    const firstText = options[0]?.text || '';
    
    // Size: attr 3 is always size for NDF, or contains "x" dimensions
    if (attrId === '3' || (firstText.match(/\d+(\.\d+)?\s*x\s*\d+/i) && !sizeAttrId)) {
      sizeAttrId = attrId;
      continue;
    }
    
    // Quantity: attr 5 is always quantity, or all numeric values
    if (attrId === '5' || (!qtyAttrId && options.every(o => o.text.replace(/,/g, '').match(/^\d+$/)))) {
      qtyAttrId = attrId;
      continue;
    }
    
    // Turnaround: contains "Business Day" or "Ready Today" (may not be in DOM)
    if (options.some(o => o.text.includes('Business Day') || o.text.includes('Ready Today'))) {
      tatAttrId = attrId;
      continue;
    }
    
    // Everything else: use first option as default
    otherDefaults[`attr${attrId}`] = options[0].id;
  }
  
  return { sizeAttrId, qtyAttrId, tatAttrId, otherDefaults };
}

async function computePrice(priceData) {
  try {
    const resp = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': AUTH },
      body: JSON.stringify(priceData),
    });
    if (!resp.ok) return null;
    return resp.json();
  } catch (e) {
    return null;
  }
}

async function processProduct(product) {
  console.log(`\n=== ${product.name} ===`);
  console.log(`Fetching: ${product.url}`);
  
  let html;
  try {
    html = await fetchPage(product.url);
  } catch (e) {
    console.log(`  FAILED to fetch: ${e.message}`);
    return [];
  }
  
  if (html.includes("can't seem to find the page") || html.length < 5000) {
    console.log(`  Page not found or too short (${html.length} bytes)`);
    return [];
  }
  
  const { attrs, productId } = extractAttrsFromHTML(html);
  console.log(`  Product ID: ${productId}`);
  console.log(`  Attributes found: ${Object.keys(attrs).join(', ')}`);
  
  if (!productId) {
    console.log(`  SKIPPING: no product_id found`);
    return [];
  }
  
  const { sizeAttrId, qtyAttrId, tatAttrId, otherDefaults } = identifyAttrTypes(attrs);
  console.log(`  Size attr: ${sizeAttrId}, Qty attr: ${qtyAttrId}, TAT attr: ${tatAttrId}`);
  
  if (!sizeAttrId && !qtyAttrId) {
    console.log(`  SKIPPING: can't identify size/qty attributes`);
    return [];
  }
  
  const sizes = sizeAttrId ? attrs[sizeAttrId] : [{ text: 'Default', id: null }];
  const qtys = qtyAttrId ? attrs[qtyAttrId].filter(q => KEY_QTY_TEXTS.includes(q.text)) : [];
  
  if (qtys.length === 0) {
    // If no matching qtys found, try the first few
    const allQtys = qtyAttrId ? attrs[qtyAttrId] : [];
    qtys.push(...allQtys.slice(0, 10));
  }
  
  // Find display names for paper stock and coating
  let paperStock = 'Default';
  let coating = 'Default';
  for (const [attrId, options] of Object.entries(attrs)) {
    const isPaper = options.some(o => o.text.includes('pt.') || o.text.includes('lb.'));
    const isCoating = options.some(o => o.text.includes('Gloss') || o.text.includes('Matte') || o.text.includes('UV') || o.text.includes('Uncoated'));
    
    if (isPaper && attrId !== sizeAttrId && attrId !== qtyAttrId) {
      // For paper stock, prefer 14pt if available
      const pref = options.find(o => o.text.includes('14 pt'));
      if (pref) {
        otherDefaults[`attr${attrId}`] = pref.id;
        paperStock = pref.text;
      } else {
        const selected = options.find(o => o.id === otherDefaults[`attr${attrId}`]);
        if (selected) paperStock = selected.text;
      }
    }
    if (isCoating && !isPaper && attrId !== sizeAttrId && attrId !== qtyAttrId) {
      const selected = options.find(o => o.id === otherDefaults[`attr${attrId}`]);
      if (selected) coating = selected.text;
    }
  }
  
  console.log(`  Sizes: ${sizes.length}, Qtys: ${qtys.length}`);
  console.log(`  Paper: ${paperStock}, Coating: ${coating}`);
  
  const results = [];
  let done = 0;
  const total = sizes.length * qtys.length;
  
  for (const size of sizes) {
    for (const qty of qtys) {
      const priceReq = { ...otherDefaults };
      if (sizeAttrId && size.id) priceReq[`attr${sizeAttrId}`] = size.id;
      if (qtyAttrId) priceReq[`attr${qtyAttrId}`] = qty.id;
      priceReq.product_id = productId;
      priceReq.addon_attributes = tatAttrId ? [tatAttrId] : [];
      priceReq.addon_attributes_limit = [];
      priceReq.get_shipping_base_price = true;
      
      // Set TAT to first option if available
      if (tatAttrId && attrs[tatAttrId]) {
        priceReq[`attr${tatAttrId}`] = attrs[tatAttrId][0].id;
      }
      
      const data = await computePrice(priceReq);
      done++;
      
      if (!data) {
        console.log(`  Error: ${size.text} x ${qty.text}`);
        continue;
      }
      
      if (data.addon_attrs && tatAttrId && data.addon_attrs[tatAttrId]) {
        for (const [tatId, tatData] of Object.entries(data.addon_attrs[tatAttrId])) {
          results.push({
            product: product.name,
            size: size.text,
            quantity: qty.text.replace(/,/g, ''),
            paperStock,
            coating,
            turnaround: tatData.attr_value,
            price: parseFloat(tatData.price),
            unitPrice: parseFloat(tatData.unit_price),
            inStock: tatData.item_data?.in_stock_flag === 'y',
          });
        }
      } else {
        // No addon attrs, use main price
        results.push({
          product: product.name,
          size: size.text,
          quantity: qty.text.replace(/,/g, ''),
          paperStock,
          coating,
          turnaround: 'Standard',
          price: parseFloat(data.price || data.total_price || 0),
          unitPrice: parseFloat(data.unit_price || 0),
          inStock: data.in_stock_flag === 'y',
        });
      }
      
      if (done % 5 === 0) {
        process.stdout.write(`\r  Progress: ${done}/${total}`);
      }
      
      // Small delay
      await new Promise(r => setTimeout(r, 30));
    }
  }
  
  console.log(`\n  Got ${results.length} price points`);
  return results;
}

async function buildExcel(allResults) {
  const XLSX = (await import('xlsx')).default;
  const wb = XLSX.utils.book_new();
  
  // Master sheet
  const masterRows = allResults.map(r => ({
    'Product': r.product,
    'Size': r.size,
    'Quantity': parseInt(r.quantity),
    'Paper Stock': r.paperStock,
    'Coating': r.coating,
    'Turnaround': r.turnaround,
    'NDF Price': r.price,
    'Per Unit': r.unitPrice,
    'In Stock': r.inStock ? 'Yes' : 'No',
    'Floor (=NDF)': r.price,
    'Target (+10%)': Math.round(r.price * 1.10 * 100) / 100,
    'Opening (+25%)': Math.round(r.price * 1.25 * 100) / 100,
    'Per Unit Floor': r.unitPrice,
    'Per Unit Target': Math.round(r.unitPrice * 1.10 * 10000) / 10000,
    'Per Unit Opening': Math.round(r.unitPrice * 1.25 * 10000) / 10000,
  }));
  
  const masterWs = XLSX.utils.json_to_sheet(masterRows);
  XLSX.utils.book_append_sheet(wb, masterWs, 'All Products');
  
  // Per-product pivot sheets
  const products = [...new Set(allResults.map(r => r.product))];
  for (const prod of products) {
    const prodResults = allResults.filter(r => r.product === prod);
    const combos = {};
    
    for (const r of prodResults) {
      const key = `${r.size}|${r.quantity}`;
      if (!combos[key]) {
        combos[key] = { 'Size': r.size, 'Quantity': parseInt(r.quantity), 'Paper Stock': r.paperStock };
      }
      
      let tatName;
      if (r.turnaround.includes('6 Business')) tatName = '6-Day';
      else if (r.turnaround.includes('4 Business')) tatName = '4-Day';
      else if (r.turnaround.includes('3 Business')) tatName = 'Standard (3-Day)';
      else if (r.turnaround.includes('2 Business')) tatName = '2-Day';
      else if (r.turnaround.includes('Next')) tatName = 'Next Day';
      else if (r.turnaround.includes('Today') || r.turnaround.includes('Same')) tatName = 'Same Day';
      else tatName = r.turnaround;
      
      combos[key][`${tatName} Price`] = r.price;
      combos[key][`${tatName} /ea`] = r.unitPrice;
    }
    
    const pivotArr = Object.values(combos).sort((a, b) => {
      if (a.Size !== b.Size) return a.Size.localeCompare(b.Size);
      return a.Quantity - b.Quantity;
    });
    
    // Add markup on standard price
    for (const row of pivotArr) {
      const stdPrice = row['Standard (3-Day) Price'] || row['6-Day Price'] || row['4-Day Price'] || 0;
      if (stdPrice) {
        row['Floor'] = stdPrice;
        row['Target (+10%)'] = Math.round(stdPrice * 1.10 * 100) / 100;
        row['Opening (+25%)'] = Math.round(stdPrice * 1.25 * 100) / 100;
      }
    }
    
    const sheetName = prod.substring(0, 31);
    const ws = XLSX.utils.json_to_sheet(pivotArr);
    XLSX.utils.book_append_sheet(wb, ws, sheetName);
  }
  
  XLSX.writeFile(wb, '/home/inkredible/.openclaw/workspace/ndf-pricing-complete.xlsx');
  console.log('\nSaved ndf-pricing-complete.xlsx');
  
  const csvContent = XLSX.utils.sheet_to_csv(masterWs);
  writeFileSync('/home/inkredible/.openclaw/workspace/ndf-pricing-complete.csv', csvContent);
  console.log('Saved ndf-pricing-complete.csv');
}

async function main() {
  const allResults = [];
  
  for (const product of PRODUCTS) {
    try {
      const results = await processProduct(product);
      allResults.push(...results);
      
      // Save partial results after each product
      writeFileSync('/home/inkredible/.openclaw/workspace/ndf-prices-raw.json', JSON.stringify(allResults, null, 2));
    } catch (err) {
      console.log(`\n  FATAL ERROR for ${product.name}: ${err.message}`);
    }
  }
  
  console.log(`\n\n=== TOTAL: ${allResults.length} price points across ${new Set(allResults.map(r => r.product)).size} products ===`);
  
  await buildExcel(allResults);
}

main().catch(err => {
  console.error('Fatal:', err);
  process.exit(1);
});
