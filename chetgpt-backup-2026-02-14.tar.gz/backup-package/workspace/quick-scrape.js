/**
 * NextDayFlyers Quick Scraper
 * 
 * Instructions:
 * 1. Open NextDayFlyers in Chrome
 * 2. For each size/quantity combination, screenshot the price
 * 3. Or copy the 3 prices directly: 3 Business Days | Next Day | Same Day
 * 4. Paste into this format
 * 
 * Run: node quick-scrape.js
 */

const readline = require('readline');
const fs = require('fs');
const XLSX = require('xlsx');

// Products and their sizes
const PRODUCTS = {
  'Postcards': ['4x6', '5x7', '6x9', '6x11'],
  'Flyers': ['8.5x11', '8.5x14', '11x17'],
  'Booklets': ['8.5x11', '8.5x5.5'],
  'Hang Tags': ['2x3', '3x4', '4x6']
};

const QUANTITIES = [100, 250, 500, 1000, 2500, 5000];

function generatePrompt() {
  let prompt = `
============================================
NEXT DAY FLYERS PRICING - COPY/PASTE GUIDE
============================================

OPEN: https://www.nextdayflyers.com/postcard-printing/standard-postcards.php

FOR EACH SIZE: 4x6, 5x7, 6x9, 6x11
FOR EACH QTY: 100, 250, 500, 1000, 2500, 5000

COPY THE 3 PRICES SHOWN:
┌─────────────────┬────────────┬───────────┬──────────┐
│ Size            │ 3 Bus Days │ Next Day  │ Same Day │
├─────────────────┼────────────┼───────────┼──────────┤
│ 4x6 @ 100       │ $XX.XX     │ $XX.XX    │ $XX.XX   │
│ 4x6 @ 250       │ ...        │ ...       │ ...      │
│ 5x7 @ 100       │ ...        │ ...       │ ...      │
└─────────────────┴────────────┴───────────┴──────────┘

PASTE BELOW IN THIS FORMAT:
4x6,100,45.99,62.99,89.99
4x6,250,62.99,85.99,125.99
5x7,100,52.99,71.99,99.99
6x9,100,65.99,89.99,129.99
6x11,100,78.99,105.99,149.99

(continue for all sizes × quantities)

============================================
`;
  return prompt;
}

async function collectData() {
  console.clear();
  console.log('📸 NextDayFlyers Quick Scraper\n');
  
  console.log(generatePrompt());
  
  console.log('⬆️  PASTE YOUR PRICING DATA NOW (Ctrl+D to finish):\n');
  
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  
  let data = '';
  
  rl.on('close', () => {
    processData(data);
  });
  
  rl.input.on('keypress', (ch, key) => {
    if (key && key.ctrl && key.name === 'd') {
      rl.close();
    }
  });
  
  rl.setPrompt('');
  rl.prompt();
  
  for await (const line of rl) {
    data += line + '\n';
    rl.setPrompt('');
    rl.prompt();
  }
}

function processData(rawData) {
  console.log('\n📊 Processing data...\n');
  
  const lines = rawData.trim().split('\n');
  const results = {};
  
  for (const line of lines) {
    const parts = line.split(',').map(p => p.trim());
    if (parts.length >= 5) {
      const size = parts[0];
      const qty = parts[1];
      const prices = {
        '3 Business Days': parseFloat(parts[2]),
        'Next Day': parseFloat(parts[3]),
        'Same Day': parseFloat(parts[4])
      };
      
      if (!results[size]) results[size] = {};
      results[size][qty] = prices;
    }
  }
  
  saveToExcel(results);
}

function saveToExcel(results) {
  const wb = XLSX.utils.book_new();
  
  // Create summary sheet
  const summary = [['Size', 'Quantity', '3 Business Days', 'Next Day', 'Same Day']];
  
  for (const [size, quantities] of Object.entries(results)) {
    for (const [qty, prices] of Object.entries(quantities)) {
      summary.push([size, qty, prices['3 Business Days'], prices['Next Day'], prices['Same Day']]);
    }
  }
  
  const ws = XLSX.utils.aoa_to_sheet(summary);
  XLSX.utils.book_append_sheet(wb, ws, 'Pricing');
  
  const filename = 'nextdayflyers-pricing.xlsx';
  XLSX.writeFile(wb, filename);
  
  console.log(`💾 Saved: ${filename}`);
  console.log(`📦 ${Object.keys(results).length} sizes captured\n`);
  console.log('✅ Done! Import this Excel into your pricing system.');
}

collectData();
