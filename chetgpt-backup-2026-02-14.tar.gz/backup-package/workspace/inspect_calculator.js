const puppeteer = require('puppeteer-core');

async function inspectCalculator() {
  const browser = await puppeteer.connect({
    browserURL: 'http://localhost:18800',
    defaultViewport: { width: 1400, height: 900 }
  });
  
  const page = await browser.newPage();
  
  try {
    console.log('Loading page...');
    await page.goto('https://www.nextdayflyers.com/postcard-printing/standard-postcards.php', { waitUntil: 'networkidle2', timeout: 60000 });
    await new Promise(r => setTimeout(r, 8000));
    
    // Take screenshot
    await page.screenshot({ path: 'calculator_screenshot.png', fullPage: true });
    console.log('Screenshot saved to calculator_screenshot.png');
    
    // Look for calculator-related elements
    const calcInfo = await page.evaluate(() => {
      // Find all buttons, dropdowns, and inputs
      const buttons = Array.from(document.querySelectorAll('button, .btn, [role="button"]')).slice(0, 20).map(b => ({
        text: b.textContent?.trim().substring(0, 50),
        className: b.className,
        id: b.id
      }));
      
      const dropdowns = Array.from(document.querySelectorAll('select, .dropdown, [role="listbox"]')).map(d => ({
        text: d.textContent?.trim().substring(0, 100),
        className: d.className,
        id: d.id,
        name: d.name
      }));
      
      const priceElements = Array.from(document.querySelectorAll('*')).filter(el => 
        el.textContent?.includes('$') && el.children.length === 0
      ).slice(0, 10).map(el => ({
        text: el.textContent?.trim(),
        className: el.className,
        id: el.id,
        parentClass: el.parentElement?.className
      }));
      
      return { buttons, dropdowns, priceElements };
    });
    
    console.log('\nButtons:', JSON.stringify(calcInfo.buttons, null, 2));
    console.log('\nDropdowns:', JSON.stringify(calcInfo.dropdowns, null, 2));
    console.log('\nPrice elements:', JSON.stringify(calcInfo.priceElements, null, 2));
    
  } catch (e) {
    console.error('Error:', e);
  } finally {
    await page.close();
    await browser.disconnect();
  }
}

inspectCalculator();
