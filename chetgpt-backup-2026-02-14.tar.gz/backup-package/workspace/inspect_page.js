const puppeteer = require('puppeteer-core');
const fs = require('fs');

async function inspectPage() {
  const browser = await puppeteer.connect({
    browserURL: 'http://localhost:18800',
    defaultViewport: { width: 1280, height: 800 }
  });
  
  const page = await browser.newPage();
  
  try {
    console.log('Loading page...');
    await page.goto('https://www.nextdayflyers.com/postcard-printing/standard-postcards.php', { waitUntil: 'networkidle2', timeout: 60000 });
    await new Promise(r => setTimeout(r, 5000));
    
    // Get page HTML to inspect
    const html = await page.content();
    fs.writeFileSync('page_debug.html', html);
    
    // Look for select elements
    const selects = await page.evaluate(() => {
      const allSelects = document.querySelectorAll('select');
      return Array.from(allSelects).map(s => ({
        name: s.name,
        id: s.id,
        className: s.className,
        options: Array.from(s.options).slice(0, 5).map(o => o.value)
      }));
    });
    
    console.log('Found select elements:');
    console.log(JSON.stringify(selects, null, 2));
    
    // Look for price elements
    const priceElements = await page.evaluate(() => {
      const elements = document.querySelectorAll('*');
      const priceEls = [];
      for (const el of elements) {
        if (el.textContent && el.textContent.includes('$') && el.children.length === 0) {
          priceEls.push({
            tag: el.tagName,
            className: el.className,
            id: el.id,
            text: el.textContent.trim().substring(0, 100)
          });
        }
      }
      return priceEls.slice(0, 20);
    });
    
    console.log('\nFound price elements:');
    console.log(JSON.stringify(priceElements, null, 2));
    
  } catch (e) {
    console.error('Error:', e);
  } finally {
    await page.close();
    await browser.disconnect();
  }
}

inspectPage();
