const axios = require('axios');
const cheerio = require('cheerio');
const fs = require('fs');

// Test fetch to see page structure
async function explorePage() {
  try {
    const response = await axios.get('https://www.nextdayflyers.com/marketing-materials/postcards.html', {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
      }
    });

    const $ = cheerio.load(response.data);
    
    // Look for pricing-related elements
    console.log('=== PAGE TITLE ===');
    console.log($('title').text());
    
    console.log('\n=== SCRIPTS ===');
    const scripts = $('script');
    scripts.each((i, el) => {
      const src = $(el).attr('src') || 'inline';
      if (src.includes('app') || src.includes('api') || src.includes('pricing')) {
        console.log(`Script ${i}: ${src}`);
      }
    });

    console.log('\n=== PRICING ELEMENTS ===');
    // Look for common pricing patterns
    const priceSelectors = $('[class*="price"], [class*="Price"], [id*="price"], [id*="Price"], [class*="pricing"]');
    console.log(`Found ${priceSelectors.length} price-related elements`);
    
    console.log('\n=== PRODUCT ELEMENTS ===');
    const productSelectors = $('[class*="product"], [class*="Product"], [data-product]');
    console.log(`Found ${productSelectors.length} product-related elements`);
    
    console.log('\n=== SAMPLE HTML ===');
    // Get first 2000 chars of body
    console.log($('body').html().substring(0, 3000));
    
    // Save full HTML for analysis
    fs.writeFileSync('nextdayflyers-postcards.html', response.data);
    console.log('\n=== Full HTML saved to nextdayflyers-postcards.html ===');
    
  } catch (error) {
    console.error('Error:', error.message);
  }
}

explorePage();
