# Overnight Extraction Summary — 2026-02-13

## Run Overview
- **Started:** ~6:01 AM ET
- **Stopped:** ~7:00 AM ET (Gemini API quota exhausted)
- **Vendors attempted:** 2 of 9 (Ddpmsc running, Lindenmeyr already complete)
- **Vendors skipped (quota):** Piedmontplastics, Plockmatic Document Finishing Inc, Sfsupplies, Shardarsp, Steadfast Papers Inc, Tri State Knife Grinding Corp, Uline

## Results

### Ddpmsc (this run)
- **PDFs processed successfully:** 22/73
- **PDFs failed (429 quota):** ~9 (files #22, #24–#31)
- **PDFs not attempted:** ~42
- **Items extracted:** 95 (from 20 unique source files with data + 2 PDFs with 0 items)
- **vs. baseline (20 PDFs/89 items):** +2 PDFs, +6 items net
- **New file extracted:** `20230420_141026_000112.pdf` (9 items)
- **Baseline file lost (failed to re-extract):** `CA_INV2_drosen(1).pdf` (3 items in baseline JSON, failed 429 this run)
- **Note:** 19 shared files re-extracted with identical totals (86 items each)

### Lindenmeyr (already complete before this run)
- **PDFs:** 15/15 ✅
- **Items:** 28
- **Status:** Complete, not re-run

### Remaining Vendors (not run)
| Vendor | PDFs | Status |
|---|---:|---|
| Piedmontplastics | 43 | ⏳ Not started |
| Plockmatic Document Finishing Inc | 4 | ⏳ Not started |
| Sfsupplies | 7 | ⏳ Not started |
| Shardarsp | 4 | ⏳ Not started |
| Steadfast Papers Inc | 13 | ⏳ Not started |
| Tri State Knife Grinding Corp | 3 | ⏳ Not started |
| Uline | 1 | ⏳ Not started |

## Library Totals

| Metric | Count |
|---|---:|
| Total PDFs in library | 163 |
| PDFs with extracted data | 35 |
| PDFs processed (incl. 0-item) | 37 |
| Total line items extracted | 123 |
| Coverage | 21.5% → 22.7% |
| PDFs remaining | 126 |

## Changes vs. Baseline (35 PDFs / 117 items)
- **New PDFs with data:** +0 net (gained 1, lost 1 due to 429 failure)
- **New line items:** +6 net (95+28=123 vs 89+28=117)
- **New PDFs processed (incl. 0-item):** +2

## Quota Issue
- Gemini API returned `429: You exceeded your current quota` starting at file #22 (~6:08 AM ET)
- All files from #22 onward failed after 5 retries each (mix of 0s and 59s retry delays)
- Each failed file took ~3–5 minutes to exhaust retries
- Process killed at file #31 to prevent hours of futile retrying
- **Recommendation:** Check Gemini API billing/quota. The free tier or daily limit appears exhausted. Consider upgrading the plan or waiting for quota reset before re-running.

## Files
- `ddpmsc-extracted.csv` — 95 items, 20 source files (authoritative for this run)
- `ddpmsc-extracted.json` — 89 items, 20 source files (from baseline, includes CA_INV2_drosen(1).pdf)
- `lindenmeyr-extracted.csv` — 28 items
- `lindenmeyr-extracted.json` — 28 items
- `progress.json` — last updated at file #23 (succeeded: 22, failed: 1)
