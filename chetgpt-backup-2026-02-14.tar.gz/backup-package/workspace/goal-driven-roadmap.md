# Goal-Driven Roadmap (Autonomous Work System)

**Owner:** Aviel  
**Operator:** ChetGPT + sub-agents  
**Created:** 2026-02-13 (EST)  
**Purpose:** Convert Aviel’s brain-dump goals into a self-running execution engine (not a passive to-do list).

---

## Priority Scoring Method
To keep prioritization objective, each goal is scored on:

- **Revenue Impact (R)**: 1-10
- **Emotional Importance (E)**: 1-10
- **Feasibility (F)**: 1-10

**Priority Score (1-10) = round((R × E × F) / 100, 1)**

---

## 1) Scale INKredible to a $1M+ Revenue Engine (Large Format First)

- **Why it matters (emotional + financial):**
  - Emotional: Aviel wants to stop feeling stuck in reactive same-day chaos and become an owner-operator, not a bottleneck.
  - Financial: Large-format work (especially floor graphics) is the strongest margin/revenue lever and core path to $1-2M/year.
- **Measurable milestone (done state):**
  - 12-month rolling revenue at **$1M run rate**
  - At least **40% of monthly revenue from recurring event/rental clients**
  - Aviel doing **<20% manual production hours**
- **Next 3 concrete tasks:**
  1. Build a **floor-graphics pipeline tracker** (lead → quote → booked → produced → paid) with weekly conversion metrics.
  2. Create a **Top-50 target account list** (event planners, rental companies, luxury event firms) with contact and outreach scripts.
  3. Deploy a **repeat-client reactivation sequence** for dormant high-value customers.
- **ChetGPT can do autonomously:**
  - Build tracker templates, conversion dashboards, reactivation scripts, and lead list research pack.
- **Needs Aviel input:**
  - Approve pricing guardrails, share top existing client list, and approve outreach voice.
- **Priority score:**
  - R=10, E=9, F=8 → **7.2/10**

---

## 2) Build INKredible MIS into a Real Product (Internal First, Then SaaS)

- **Why it matters (emotional + financial):**
  - Emotional: This is identity-level proof that Aviel can build something great.
  - Financial: A working MIS could become a second revenue stream sold to other print shops.
- **Measurable milestone (done state):**
  - MIS v1 used daily at INKredible for **90 days**
  - Tracks quotes, jobs, profitability, and weekly KPIs from one dashboard
  - **3 pilot print shops** agree to test external beta
- **Next 3 concrete tasks:**
  1. Lock MIS v1 scope: CRM + quote tracking + job calendar + KPI chat queries.
  2. Build **floor-job calendar + quote analytics module** (already requested in brain dump).
  3. Produce a **pilot package** (demo script, onboarding checklist, pricing hypothesis).
- **ChetGPT can do autonomously:**
  - Write PRD, schema, wireframes, KPI definitions, pilot docs, and build tickets.
- **Needs Aviel input:**
  - Approve v1 feature scope, validate workflow reality, provide pilot-intro contacts.
- **Priority score:**
  - R=9, E=10, F=7 → **6.3/10**

---

## 3) Financial Clarity + Debt Stabilization System

- **Why it matters (emotional + financial):**
  - Emotional: Financial avoidance is a major anxiety source and confidence drain.
  - Financial: Current overdrawn checking + high debt exposure blocks every growth goal.
- **Measurable milestone (done state):**
  - Monthly financial close completed by day 5
  - Checking account remains non-negative for **90 straight days**
  - Debt paydown plan running with monthly tracking and reduction trend
- **Next 3 concrete tasks:**
  1. Build a **cash + QuickBooks reconciliation workflow** (including off-books cash capture template).
  2. Build a **debt waterfall model** (APR-ranked payoff plan + minimum safe cash reserve).
  3. Launch a **weekly finance scoreboard** (cash, A/R, A/P, debt, gross margin, large-format revenue share).
- **ChetGPT can do autonomously:**
  - Dashboard logic, reconciliation templates, debt model scenarios, automated weekly report format.
- **Needs Aviel input:**
  - 2025 cash logs, account balances/rates, spending-cut decisions, final debt strategy selection.
- **Priority score:**
  - R=10, E=10, F=8 → **8.0/10**

---

## 4) Ship the Wispr Flow Desktop Stack (Then Android IME)

- **Why it matters (emotional + financial):**
  - Emotional: Strongest confidence unlock; proof Aviel can ship software he uses daily.
  - Financial: Improves productivity immediately and can become a product capability later.
- **Measurable milestone (done state):**
  - All 3 repos pushed and stable
  - Desktop app used daily for **30 consecutive days**
  - Android IME prototype reaches first end-to-end dictation demo
- **Next 3 concrete tasks:**
  1. Run a **release-readiness audit** across all 3 repos (blockers, bugs, missing docs).
  2. Execute **nightly dev sprints** focused on highest-impact blockers.
  3. Package installer + test plan + usage checklist for daily use.
- **ChetGPT can do autonomously:**
  - Code audit notes, bug-fix queue, docs, packaging checklist, QA test matrix.
- **Needs Aviel input:**
  - Final UX decisions, platform priorities, and any credential/prod setup approvals.
- **Priority score:**
  - R=7, E=10, F=7 → **4.9/10**

---

## 5) Marketing Engine with Brandon (Instagram + Referral Flywheel)

- **Why it matters (emotional + financial):**
  - Emotional: Aviel values loyalty and wants Brandon in a true partner role.
  - Financial: Better marketing fills pipeline with high-ticket floor and event graphics jobs.
- **Measurable milestone (done state):**
  - 12-week content cadence sustained
  - **20 qualified inbound leads/month**
  - **2 new recurring event/rental clients/month**
- **Next 3 concrete tasks:**
  1. Build **Marie’s Touch style teardown**: content formats, hooks, offer structure, CTA patterns.
  2. Create a **90-day content operating system** (post calendar, templates, production SOP).
  3. Build lead capture + response SOP (DM script → quote handoff).
- **ChetGPT can do autonomously:**
  - Research pack, content calendar draft, caption libraries, hook bank, SOP docs.
- **Needs Aviel input:**
  - Brandon’s weekly time allocation, on-brand approvals, offer positioning decisions.
- **Priority score:**
  - R=8, E=8, F=8 → **5.1/10**

---

## 6) ADHD-Compatible Performance + Health System

- **Why it matters (emotional + financial):**
  - Emotional: Gym and structure reduce anxiety, improve confidence, and restore sense of control.
  - Financial: Better focus/time execution directly improves output and business follow-through.
- **Measurable milestone (done state):**
  - 5 workouts/week sustained for 8 weeks
  - Daily top-3 priorities completed at **≥80% adherence** for 30 days
  - Weekly planning/review habit sustained for 6 weeks
- **Next 3 concrete tasks:**
  1. Build a **push-based daily execution board** (ADHD-first: small wins, clear done criteria).
  2. Create **morning + shutdown checklists** tied to business priorities and family boundaries.
  3. Implement a **confidence scorecard** (wins logged daily, visible progress trend).
- **ChetGPT can do autonomously:**
  - Templates, reminder scripts, dashboard views, progress logic, weekly summary reports.
- **Needs Aviel input:**
  - Preferred schedule windows, therapy insight integration, non-negotiable routines.
- **Priority score:**
  - R=7, E=10, F=8 → **5.6/10**

---

## 7) Family Presence + Home Stability Architecture

- **Why it matters (emotional + financial):**
  - Emotional: Aviel wants to be present with wife/kids, support parents more, and enjoy life.
  - Financial: House readiness and domestic support planning require consistent cash discipline.
- **Measurable milestone (done state):**
  - Weekly protected family blocks adhered to for 8/10 weeks
  - Parent call cadence met monthly
  - House-readiness plan with savings target + timeline locked
- **Next 3 concrete tasks:**
  1. Build a **family-first calendar framework** with protected no-work blocks.
  2. Create a **house readiness model** (down payment target, debt constraints, timeline scenarios).
  3. Set **parent connection reminders** + accountability check-in flow.
- **ChetGPT can do autonomously:**
  - Calendar template, house model calculator, reminder framework, weekly follow-up prompts.
- **Needs Aviel input:**
  - Wife/family schedule preferences, house budget range, parent contact constraints.
- **Priority score:**
  - R=6, E=9, F=8 → **4.3/10**

---

## 8) Structured Trading as a Guardrailed Hobby (Not Escape Loop)

- **Why it matters (emotional + financial):**
  - Emotional: Trading is intellectually exciting for Aviel, but must stay controlled to avoid addiction patterns.
  - Financial: Potential upside is secondary; primary goal is discipline without downside damage.
- **Measurable milestone (done state):**
  - 60-day paper-trading streak with rule adherence >90%
  - No real-money trading until rules and emotional triggers are stable
- **Next 3 concrete tasks:**
  1. Create a **trading rulebook** (entry/exit, max risk, no-chase rules).
  2. Build a **daily pre-market checklist** and post-trade journal template.
  3. Set escalation guardrails (cooldown after rule breaks, automatic pause triggers).
- **ChetGPT can do autonomously:**
  - Rulebook drafts, checklist templates, journal analytics, educational market recap structure.
- **Needs Aviel input:**
  - Risk limits, acceptable instruments, final go/no-go decisions for live trades.
- **Priority score:**
  - R=4, E=7, F=7 → **2.0/10**

---

# Nightly Autonomous Build Queue (Goal Engine)

**Operating window:** every night after family hours  
**Selection rule:** always pick highest-priority **unblocked** task, then chain downstream tasks automatically.

## Queue Order

### Q1) Financial Command Center v1
- **Build:** cash + debt + margin dashboard from existing QuickBooks exports
- **Sub-agent model:** **openai-codex/gpt-5.3-codex** (data + implementation)
- **Expected output:** `workspace/financial-command-center-v1.md` + dashboard data schema + action list
- **Goal link:** Goal 3 (Financial Clarity)
- **Trigger next:** if dashboard complete → auto-trigger Q2 (weekly finance scoreboard automation)

### Q2) Weekly Finance Scoreboard Automation
- **Build:** auto-generated weekly summary template (cash, debt, gross margin, floor-graphics share)
- **Sub-agent model:** **anthropic/claude-opus-4-6** (strategy + narrative) + codex for implementation
- **Expected output:** `workspace/weekly-finance-scoreboard-template.md`
- **Goal link:** Goal 3
- **Trigger next:** if KPI definitions validated → trigger Q3 (revenue engine pipeline tracker)

### Q3) Floor Graphics Revenue Pipeline Tracker
- **Build:** lead/quote/booked/produced/paid tracker with conversion math
- **Sub-agent model:** **openai-codex/gpt-5.3-codex**
- **Expected output:** `workspace/floor-graphics-pipeline-system.md` + CSV template
- **Goal link:** Goal 1
- **Trigger next:** once tracker exists → trigger Q4 (Top-50 account builder)

### Q4) Top-50 High-Value Account Builder
- **Build:** curated prospect list (event planners/rental/luxury event firms) + outreach scripts
- **Sub-agent model:** **anthropic/claude-opus-4-6**
- **Expected output:** `workspace/top-50-target-accounts.md`
- **Goal link:** Goal 1 + Goal 5
- **Trigger next:** if top-50 complete → trigger Q5 (marketing content OS)

### Q5) Brandon Content OS (90 Days)
- **Build:** post calendar, hooks, CTA library, post-production SOP
- **Sub-agent model:** **anthropic/claude-opus-4-6**
- **Expected output:** `workspace/brandon-content-os-90-day.md`
- **Goal link:** Goal 5
- **Trigger next:** if content OS done → trigger Q6 (DM-to-quote workflow)

### Q6) DM-to-Quote Conversion Workflow
- **Build:** inbound lead triage + response scripts + quote handoff checklist
- **Sub-agent model:** **openai-codex/gpt-5.3-codex**
- **Expected output:** `workspace/dm-to-quote-sop.md`
- **Goal link:** Goal 1 + Goal 5
- **Trigger next:** if SOP done → trigger Q7 (MIS v1 scope lock)

### Q7) MIS v1 Scope Lock + Build Plan
- **Build:** non-negotiable v1 module set and phased implementation backlog
- **Sub-agent model:** **anthropic/claude-opus-4-6**
- **Expected output:** `workspace/mis-v1-scope-lock.md` + prioritized build backlog
- **Goal link:** Goal 2
- **Trigger next:** if scope approved-ready → trigger Q8 (floor job calendar module spec)

### Q8) MIS Floor Job Calendar + Quote Analytics Spec
- **Build:** technical spec + data model + KPI definitions
- **Sub-agent model:** **openai-codex/gpt-5.3-codex**
- **Expected output:** `workspace/mis-floor-calendar-quote-analytics-spec.md`
- **Goal link:** Goal 2 + Goal 1
- **Trigger next:** if spec complete → trigger Q9 (Wispr release-readiness)

### Q9) Wispr Desktop Release-Readiness Audit
- **Build:** blocker list and release sequence for all 3 repos
- **Sub-agent model:** **openai-codex/gpt-5.3-codex**
- **Expected output:** `workspace/wispr-release-readiness-audit.md`
- **Goal link:** Goal 4
- **Trigger next:** if blockers prioritized → trigger Q10 (nightly fix sprint planner)

### Q10) ADHD Execution System (Push Planner + Confidence Scorecard)
- **Build:** daily top-3 push planner + win log + weekly review template
- **Sub-agent model:** **anthropic/claude-opus-4-6**
- **Expected output:** `workspace/adhd-execution-system.md`
- **Goal link:** Goal 6
- **Trigger next:** if planner complete → trigger recurring nightly optimization cycle

---

## Self-Generating Logic (Autonomous Chaining Rules)

1. **Nightly Intake**
   - Load: this roadmap + idea queue + latest financial/work artifacts.
   - Select highest-priority unblocked item.

2. **Blocker Handling**
   - If task is blocked by Aviel dependency, auto-generate:
     - `workspace/input-request-<task>.md` (exact decisions/data needed)
   - Immediately move to next highest-priority unblocked task.

3. **Definition of Done Gate**
   - A task is complete only if:
     - Output file exists
     - Includes clear “what changed / why it matters / next trigger” section
     - Contains explicit handoff for next task

4. **Automatic Next Trigger**
   - On completion, spawn next dependent task from queue chain.
   - If no direct dependency, pull highest-priority backlog item from this roadmap.

5. **Weekly Re-prioritization**
   - Recalculate scores weekly using current revenue impact, emotional urgency, and feasibility.
   - Promote goals that remove bottlenecks for higher-scoring goals.

6. **Confidence Flywheel Rule**
   - Every night must include at least one “proof-of-progress” deliverable that Aviel can see immediately.
   - This preserves momentum and directly supports confidence rebuilding.

---

## Engine Principle (Alex Finn-Style)

This system is **not** a static to-do list. It is a **closed-loop operating engine**:

**Prioritize → Build → Verify output → Trigger next → Surface blockers → Continue autonomously.**

When one task ends, the next one is already defined.