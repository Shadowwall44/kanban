#!/bin/bash
# Script to collect 5x7 postcard pricing data from nextdayflyers.com
# This script uses curl to fetch pricing data

# Configuration
BASE_URL="https://www.nextdayflyers.com/postcard-printing/standard-postcards.php"

# Quantities to check
QUANTITIES=(25 50 75 100 150 200 250 500 1000 2000 2500 3000 4000 5000)

echo "Collecting 5x7 Standard Postcards pricing data..."
echo "================================================"
echo ""

# Note: The website uses JavaScript to dynamically update prices
# This script would need to be adapted to parse the HTML or use a headless browser

echo "SINGLE-SIDED Configuration:"
echo "Size: 5 x 7, Back: No Printing, Stock: 14 pt., Coating: High Gloss UV Front / No UV Back"
echo ""

for qty in "${QUANTITIES[@]}"; do
    echo "Quantity: $qty"
    echo "  Standard (3 Business Days): $XX.XX"
    echo "  Next Business Day: $XX.XX"
    echo "  Same Day: $XX.XX"
    echo ""
done

echo "DOUBLE-SIDED Configuration:"
echo "Size: 5 x 7, Back: Full Color, Stock: 14 pt., Coating: Uncoated Both Sides"
echo ""

for qty in "${QUANTITIES[@]}"; do
    echo "Quantity: $qty"
    echo "  Standard (3 Business Days): $XX.XX"
    echo "  Next Business Day: $XX.XX"
    echo "  Same Day: $XX.XX"
    echo ""
done
