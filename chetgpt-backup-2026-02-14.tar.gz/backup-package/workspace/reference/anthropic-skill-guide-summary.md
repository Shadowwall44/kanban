# Anthropic Skill Guide — Comprehensive Summary (Audit Benchmark)

Source reviewed: `reference/anthropic-skill-guide.pdf` (33 pages)

This summary consolidates the guide into practical requirements, best practices, patterns, anti-patterns, and troubleshooting criteria for auditing skills.

---

## 1) Required File Structure for Skills

## Mandatory minimum
A skill is a **folder** with:

```text
your-skill-name/
└── SKILL.md   # required
```

Optional subfolders:

```text
your-skill-name/
├── SKILL.md
├── scripts/      # optional executable code (Python/Bash/etc.)
├── references/   # optional docs loaded only when needed
└── assets/       # optional templates/fonts/icons/resources
```

## Strict naming and packaging rules
- File must be exactly: **`SKILL.md`** (case-sensitive).
  - Invalid: `skill.md`, `SKILL.MD`, etc.
- Skill folder name should be **kebab-case**.
  - Valid: `notion-project-setup`
  - Invalid: spaces, underscores, capitals.
- Do **not** put `README.md` inside the skill folder.
  - Put user-facing README at repository root when distributing via GitHub.

## YAML frontmatter (the trigger engine)
The frontmatter is always loaded and controls whether Claude decides to load the full skill.

Minimum:

```yaml
---
name: your-skill-name
description: What it does. Use when user asks to [specific phrases].
---
```

### Required fields
- `name`
  - kebab-case
  - no spaces/caps
  - should match folder name
- `description`
  - must include both:
    - what the skill does
    - when to use it (trigger conditions)
  - must be under 1024 chars
  - include realistic user trigger phrases
  - mention relevant file types where applicable

### Optional fields (from guide)
- `license` (e.g., MIT, Apache-2.0)
- `compatibility` (1–500 chars; runtime/surface/dependency constraints)
- `metadata` (author, version, mcp-server, etc.)
- `allowed-tools` (optional restriction expression shown in reference section)

### Security / validity restrictions
Forbidden:
- XML angle brackets `< >` in frontmatter content
- skill names containing reserved prefixes/terms (`claude`, `anthropic`)

Rationale: frontmatter is inserted into system prompt context; malformed or adversarial content can cause instruction injection risk.

## Architectural principles (required for robust design)
- **Progressive disclosure (3-level model)**
  1. Frontmatter: tiny routing signal, always loaded
  2. SKILL.md body: full instructions loaded when relevant
  3. Linked files: deep docs/scripts/assets loaded on demand
- **Composability**: skill must coexist with other skills enabled simultaneously.
- **Portability**: skill should work across Claude.ai / Claude Code / API, assuming environment dependencies are available.

---

## 2) SKILL.md Best Practices

## Core objective
Write SKILL.md so Claude can reliably:
1. trigger correctly,
2. execute predictable steps,
3. recover from common failure modes,
4. produce consistent outputs.

## Description-field best practices (most important text)
Recommended formula:

**`[What it does] + [When to use it] + [Key capabilities]`**

Good characteristics:
- concrete, specific, and user-language aligned
- includes phrases users actually type/say
- includes domain and artifact/file-type cues
- narrow enough to avoid accidental triggering

Bad descriptions:
- vague: “Helps with projects.”
- no trigger guidance
- too implementation-heavy/technical without user intent cues

## Recommended SKILL.md body structure
After frontmatter, use clear markdown sections with explicit steps:
- `# Skill name`
- `## Instructions`
  - `### Step 1`, `### Step 2`, ...
  - command/tool calls
  - expected output/validation criteria
- `## Examples`
  - common scenarios with user utterance, actions, expected result
- `## Troubleshooting`
  - known errors + cause + fix

## Instruction writing quality rules
- Be **specific and actionable** (explicit commands, conditions, expected outcomes).
- Include **error handling** and recovery paths.
- Put critical constraints at top under clear headers (e.g., `## Critical`).
- Use concise bullets/numbered steps instead of long prose.
- Use references folder for deep details; keep core SKILL.md focused.
- Link explicitly to bundled docs/scripts (`references/...`, `scripts/...`).

## Practical size and clarity guidance
- Keep SKILL.md lean; move heavy docs into `references/`.
- Guide suggests keeping SKILL.md under ~5,000 words to reduce context drag.
- Ambiguous instructions degrade adherence; deterministic scripts are preferred for strict validation.

## Anti-patterns in SKILL.md
- Vague verbs without criteria (“validate properly”).
- Buried critical rules.
- No examples.
- No troubleshooting.
- Overlong monolithic instructions.
- No trigger specificity in description.

---

## 3) MCP Integration Patterns

## Mental model: MCP + Skill
- MCP = connectivity and tool access (“what Claude can do”).
- Skill = workflow knowledge and best practices (“how Claude should do it”).

Without skills on top of MCP, users often face uncertainty, inconsistent prompting, repeated support load, and unreliable results.

## Common use-case class where MCP is central
**Category 3: MCP Enhancement**
- skill embeds domain workflow around an MCP server’s raw tools
- coordinates calls, handles errors, provides context users would otherwise specify

## High-value MCP patterns (from guide)

### Pattern 1: Sequential workflow orchestration
Use when steps must run in fixed order.
- explicit step dependencies
- per-step validation gates
- rollback/fallback for partial failure

### Pattern 2: Multi-MCP coordination
Use when one job spans several services.
- phase boundaries per service
- handoff data contracts between phases
- validate each phase before proceeding
- centralized error strategy

### Pattern 3: Iterative refinement loops
Use when output quality improves through repeated validation.
- generate draft
- run checks (script preferred)
- fix issues
- re-validate until threshold met
- stop conditions explicitly defined

### Pattern 4: Context-aware tool selection
Use decision tree logic to choose the right MCP/tool for context.
- clear selection criteria
- transparent user explanation of chosen path
- fallback options when preferred tool unavailable

### Pattern 5: Domain-specific intelligence
Embed policy/compliance/expert judgment before invoking tools.
- precondition checks first
- decision logging
- audit trail outputs

## MCP integration hardening checklist
- server connected (Claude settings/extensions)
- auth valid (keys/scopes/tokens)
- tool names exact and case-sensitive
- independent MCP call works without skill
- then test skill orchestration layer

---

## 4) Testing and Iteration Guidance

## Testing levels by rigor
1. **Manual in Claude.ai**: fastest feedback loop.
2. **Scripted in Claude Code**: repeatable regression checks.
3. **Programmatic via API**: scalable evaluation suites.

## Recommended test coverage (3 pillars)

### A. Triggering tests
Goal: skill loads when appropriate and not otherwise.
- obvious trigger phrases
- paraphrases/synonyms
- unrelated requests should not trigger

### B. Functional tests
Goal: workflow correctness.
- expected outputs created
- tool/API calls succeed
- error handling paths verified
- edge cases exercised

### C. Performance comparison vs baseline
Goal: prove improvement from enabling skill.
- fewer clarifying turns
- fewer failed tool calls
- lower token usage
- faster/cleaner completion

## Suggested success metrics from guide
Quantitative:
- ~90% trigger rate on relevant prompts (10–20 query sample)
- target tool-call efficiency vs no-skill baseline
- zero failed API calls per workflow (or measured reduction)

Qualitative:
- users need less steering
- workflows complete without correction
- consistent quality across repeated runs/sessions

## Iteration strategy (important)
- Start with one hard representative task.
- Iterate until robust, then generalize to broader scenarios.
- Treat skills as living documents; refine using observed failures.

## Under-trigger vs over-trigger diagnosis
- Under-trigger signals: manual enabling, missed activations, support “when do I use this?”
  - fix: richer trigger phrasing and clearer domain terms
- Over-trigger signals: fires on irrelevant prompts, users disable skill
  - fix: narrow scope, add negative triggers, tighten description specificity

## skill-creator role
Useful for:
- generating first draft structure/frontmatter
- spotting common structural issues
- proposing test cases and improvements

Not a replacement for quantitative evaluation harnesses.

---

## 5) Distribution Requirements

## Current distribution flow (as documented)
Individual users:
1. obtain skill folder
2. zip if needed
3. upload in Claude.ai (Settings > Capabilities > Skills) **or** place in Claude Code skills directory

Organization level:
- admins can deploy workspace-wide skills
- centralized management and updates

## Open standard positioning
- Agent Skills are positioned as a portable/open standard across platforms.
- Platform-specific requirements should be documented via compatibility metadata.

## API distribution/production usage
Guide highlights:
- `/v1/skills` endpoint for management/listing
- attach skills in Messages API via `container.skills`
- versioning/management through Claude Console
- integrates with Agent SDK
- API skill use requires Code Execution Tool beta

## Recommended go-to-market packaging
- Host in public GitHub repo (for open-source distribution)
- Add clear repo-level README with install + examples/screenshots
- Link skill from MCP docs and explain combined MCP+Skill value
- Include quick-start installation + first test prompt

## Messaging/positioning requirements
- sell outcomes, not implementation details
- explain “MCP gives access; skill provides workflow intelligence”
- show concrete time-to-value improvements

---

## 6) Common Patterns and Troubleshooting

## Patterns catalog (quick audit view)
- Sequential orchestration
- Multi-MCP phased workflow
- Iterative quality loop with validators
- Context-aware tool routing
- Domain-policy/compliance intelligence

## Troubleshooting matrix

### Upload errors
1. **“Could not find SKILL.md”**
   - cause: wrong filename/case
   - fix: exact `SKILL.md`
2. **“Invalid frontmatter”**
   - cause: malformed YAML (missing delimiters, unclosed quotes)
   - fix: valid YAML wrapped in `---`
3. **“Invalid skill name”**
   - cause: caps/spaces/etc.
   - fix: kebab-case

### Triggering problems
1. **Doesn’t trigger**
   - cause: vague or missing trigger cues
   - fix: rewrite description with concrete user phrases and scope
   - debug prompt: ask Claude when it would use the skill and inspect returned reasoning anchor (description)
2. **Triggers too often**
   - cause: broad scope language
   - fix: tighten scope + add negative triggers (e.g., “Do NOT use for ...”)

### MCP call failures
- skill loads but tool invocation fails:
  - verify connection status
  - re-check auth/scopes/token freshness
  - test MCP directly (no skill)
  - verify exact tool naming

### Instructions ignored / partial adherence
Common causes and fixes:
- too verbose → simplify structure
- important rules buried → move to top, mark critical
- ambiguity → replace with explicit checks
- for strict checks, prefer scripts over prose

### Large context / degraded performance
Causes:
- oversized SKILL.md
- too many enabled skills simultaneously
- poor progressive disclosure

Fixes:
- move detail to `references/`
- keep SKILL.md concise (<~5k words guidance)
- reduce concurrent enabled skills (guide notes evaluating when many skills are enabled)

---

## Consolidated Anti-Patterns (for audits)

- Missing `SKILL.md` or wrong case
- Non-kebab folder/skill names
- Frontmatter missing required fields or delimiters
- Description lacks clear trigger language
- Description too broad/vague/implementation-only
- No negative scope for closely related adjacent tasks
- Instructions not stepwise, not testable, no expected outcomes
- No embedded error handling/recovery
- Critical requirements buried in long prose
- Overstuffed SKILL.md instead of progressive disclosure
- No examples + no troubleshooting section
- MCP references without validating connection/auth/tool names
- No baseline/performance comparison during iteration

---

## Audit-Ready Validation Checklist

Use this as a practical benchmark:

1. **Structure**: `SKILL.md` present and exact; optional dirs used correctly.
2. **Frontmatter**: valid YAML; `name` + `description` compliant; no forbidden content.
3. **Trigger quality**: precise inclusion/exclusion behavior demonstrated by tests.
4. **Instruction quality**: explicit steps, validations, expected outputs, error handling.
5. **Progressive disclosure**: heavy content moved to references/assets/scripts.
6. **MCP robustness**: tool names/auth/connectivity checks and fallback behavior defined.
7. **Testing evidence**: trigger + functional + baseline comparison documented.
8. **Iteration evidence**: known failure cases incorporated in revisions.
9. **Distribution readiness**: repo packaging/docs/install steps/positioning complete.
10. **Troubleshooting readiness**: symptom→cause→fix guidance included.

---

This benchmark reflects the guide’s central principle: **excellent skills are not just instructions; they are reliable trigger logic + executable workflow design + iterative quality controls + clear distribution packaging.**
