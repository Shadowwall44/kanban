const fs = require('fs');

// API endpoint and auth
const API_URL = 'https://calculator.digitalroom.com/v1/computePrice';
const AUTH = 'Basic Y2FsY3VsYXRvci5zaXRlOktFZm03NSNYandTTXV4OTJ6VVdEOVQ4QWFmRyF2d1Y2';

// Attribute mappings from API data
const sizes = [
  { name: '4 x 6', id: '22396' },
  { name: '5 x 7', id: '22397' },
  { name: '6 x 9', id: '22399' }
];

const stocks = [
  { name: '14 pt.', id: '22406' }
];

const quantities = [
  { name: '100', id: '22413' },
  { name: '250', id: '22414' },
  { name: '500', id: '22415' },
  { name: '1000', id: '22416' },
  { name: '2500', id: '22418' },
  { name: '5000', id: '22421' }
];

// Fixed attributes
const FRONT_SIDE = '22402'; // Full color
const BACK_SIDE = '22403'; // Full color
const COATING = '22408'; // High Gloss UV
const UV_SIDES = '27443'; // Both Sides
const SHRINK_WRAP = '22412'; // No
const TURNAROUND_STANDARD = '22518';

async function getAllPrices(sizeId, stockId, qtyId) {
  const payload = {
    productType: 'offset',
    publishedVersion: true,
    product_id: '459',
    attr3: sizeId,
    attr5: qtyId,
    attr336: FRONT_SIDE,
    attr337: BACK_SIDE,
    attr338: stockId,
    attr339: COATING,
    attr340: SHRINK_WRAP,
    attr356: UV_SIDES,
    attr333: TURNAROUND_STANDARD,
    mailing_service: 'on',
    addon_attributes: ['333'],
    addon_attributes_limit: {}
  };

  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Authorization': AUTH,
        'Content-Type': 'application/json',
        'Origin': 'https://www.nextdayflyers.com'
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    
    // Extract all turnaround prices from addon_attrs (response is at top level)
    const turnaroundPrices = {};
    if (data && data.addon_attrs && data.addon_attrs['333']) {
      const turnarounds = data.addon_attrs['333'];
      
      // Standard (3 Business Days) - 22518
      if (turnarounds['22518']) {
        turnaroundPrices.standard = {
          price: turnarounds['22518'].price,
          unitPrice: turnarounds['22518'].unit_price
        };
      }
      
      // Next Business Day - 22519
      if (turnarounds['22519']) {
        turnaroundPrices.nextDay = {
          price: turnarounds['22519'].price,
          unitPrice: turnarounds['22519'].unit_price
        };
      }
      
      // Ready Today - 22520
      if (turnarounds['22520']) {
        turnaroundPrices.sameDay = {
          price: turnarounds['22520'].price,
          unitPrice: turnarounds['22520'].unit_price
        };
      }
    }
    
    return turnaroundPrices;
  } catch (error) {
    console.error('Error fetching price:', error.message);
    return null;
  }
}

async function scrapeAllPrices() {
  const results = [];
  
  console.log('Starting API price scraping...\n');
  
  for (const size of sizes) {
    for (const stock of stocks) {
      for (const quantity of quantities) {
        console.log(`Fetching: ${size.name}, ${stock.name}, Qty ${quantity.name}`);
        
        // Add delay to avoid rate limiting
        await new Promise(r => setTimeout(r, 600));
        
        const prices = await getAllPrices(size.id, stock.id, quantity.id);
        
        if (prices) {
          const row = {
            size: size.name,
            stock: stock.name,
            quantity: quantity.name,
            standardPrice: prices.standard?.price || 'N/A',
            standardPerPiece: prices.standard?.unitPrice || 'N/A',
            nextDayPrice: prices.nextDay?.price || 'N/A',
            nextDayPerPiece: prices.nextDay?.unitPrice || 'N/A',
            sameDayPrice: prices.sameDay?.price || 'N/A',
            sameDayPerPiece: prices.sameDay?.unitPrice || 'N/A'
          };
          
          results.push(row);
          
          console.log(`  Standard: $${row.standardPrice} ($${row.standardPerPiece} each)`);
          console.log(`  Next Day: $${row.nextDayPrice} ($${row.nextDayPerPiece} each)`);
          console.log(`  Same Day: $${row.sameDayPrice} ($${row.sameDayPerPiece} each)`);
        } else {
          results.push({
            size: size.name,
            stock: stock.name,
            quantity: quantity.name,
            standardPrice: 'Error',
            standardPerPiece: 'Error',
            nextDayPrice: 'Error',
            nextDayPerPiece: 'Error',
            sameDayPrice: 'Error',
            sameDayPerPiece: 'Error'
          });
          console.log('  Error fetching prices');
        }
        
        console.log('');
      }
    }
  }
  
  // Save to CSV
  const headers = [
    'Size', 'Stock', 'Quantity',
    'Standard Price', 'Standard Price Per Piece',
    'Next Day Price', 'Next Day Price Per Piece',
    'Same Day Price', 'Same Day Price Per Piece'
  ];
  
  const csv = [headers.join(',')];
  
  for (const row of results) {
    csv.push([
      `"${row.size}"`,
      `"${row.stock}"`,
      row.quantity,
      `"${row.standardPrice}"`,
      `"${row.standardPerPiece}"`,
      `"${row.nextDayPrice}"`,
      `"${row.nextDayPerPiece}"`,
      `"${row.sameDayPrice}"`,
      `"${row.sameDayPerPiece}"`
    ].join(','));
  }
  
  fs.writeFileSync('nextdayflyers_pricing_final.csv', csv.join('\n'));
  fs.writeFileSync('pricing_api_results.json', JSON.stringify(results, null, 2));
  
  console.log('\n✓ CSV saved to nextdayflyers_pricing_final.csv');
  console.log(`Total rows: ${results.length}`);
}

scrapeAllPrices();
