# ChetGPT Full Restore Guide
# Run these steps after Ubuntu + OpenClaw are installed

## Step 1: Install OpenClaw
```bash
npm install -g openclaw
openclaw init
```

## Step 2: Copy this backup
Unzip this backup-package into ~/.openclaw/
```bash
# Copy skills
cp -r backup-package/skills/* ~/.openclaw/skills/

# Copy workspace files
cp -r backup-package/workspace/* ~/.openclaw/workspace/

# Copy agent config (auth profiles, models)
cp -r backup-package/agent-config/* ~/.openclaw/agents/main/agent/

# Copy main config
cp backup-package/openclaw.json ~/.openclaw/openclaw.json
```

## Step 3: Clone GitHub repos
```bash
cd ~/.openclaw/workspace
git clone https://github.com/Shadowwall44/kanban.git
git clone https://github.com/Shadowwall44/inkredible-tools.git
git clone https://github.com/Shadowwall44/inkredible-voice.git
git config --global user.email "avielsamucha92@gmail.com"
git config --global user.name "Shadowwall44"
```

## Step 4: Recreate cron jobs
Load crons/all-crons.json and recreate each job via OpenClaw.
ChetGPT will do this automatically on first boot.

## Step 5: Verify
```bash
openclaw status
openclaw gateway start
```

## What's included:
- /skills/ — 9 custom skills (coaching, research, deploy, etc.)
- /workspace/ — All memory, reports, templates, pricing data, transcripts
- /agent-config/ — Auth profiles (Anthropic, OpenAI, Google), model config
- /crons/ — All cron job definitions for recreation
- openclaw.json — Main configuration
- GITHUB-REPOS.md — Which repos to clone

## What's NOT included (already on GitHub):
- inkredible-tools repo (shadowwall44.github.io)
- inkredible-voice repo
- kanban repo

## Auth tokens:
The auth-profiles.json contains OAuth tokens that may expire.
You'll need to re-authenticate:
- Anthropic: Use your existing subscription token
- OpenAI: Re-do OAuth flow via OpenClaw
- Google: API key should still work
