# GitHub Repos (pull these after install)

All on github.com/Shadowwall44:

1. `git clone https://github.com/Shadowwall44/kanban.git`
2. `git clone https://github.com/Shadowwall44/inkredible-tools.git`
3. `git clone https://github.com/Shadowwall44/inkredible-voice.git`

Git config:
```
git config --global user.email "avielsamucha92@gmail.com"
git config --global user.name "Shadowwall44"
```
