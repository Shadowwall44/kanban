# INKredible Printing — Pricing Model

## Three-Tier Markup Strategy

All pricing anchored to NextDayFlyers (NDF) as the baseline competitor.

| Tier | Formula | When to Use |
|------|---------|-------------|
| **Opening price** | NDF + 25% | First quote to new customer. Room to negotiate. |
| **Target price** | NDF + 10% | Where we want to land. Healthy margin. |
| **Floor price** | NDF base | Absolute minimum. Match NDF only to win strategic accounts. |

## How It Works
1. Customer asks for a quote (e.g., 500 postcards, 4x6, 16pt, gloss UV)
2. Look up NDF price for that exact product/quantity/options
3. Quote at Opening price (NDF + 25%)
4. Customer negotiates → Target price (NDF + 10%)
5. If they push hard or it's a big account → Floor (NDF match)

## NDF Pricing Data
- CSV file: `workspace/nextdayflyers_pricing_final.csv`
- 18 postcard combos scraped (quantities × options)
- 8 more products pending: Business Cards, Flyers, Brochures, Booklets, Folded Cards, Tags, Die Cut, Menus
- Data scraped from NDF API — real wholesale-to-retail prices

## Cost Inputs
- **Konica click charge**: $0.045 per color click (both sides = 2 clicks)
- **Paper cost**: From vendor invoices (Lindenmeyr, Sharda, etc.) — tracked in extraction system
- **Wide format**: Ink + media cost per sq ft (varies by machine and media type)
- **Labor**: Brandon at $33/hr for production time
- **Overhead**: Rent ($6,361/mo), utilities, insurance — allocated per job

## Margin Targets
- Gross margin target: 55-60% (currently at 54.5%)
- Net margin target: 10-15% (currently at -1.6% — needs improvement)
- Shipping: pass-through for Messilot account, built into price for others

## 9 MVP Products
1. Postcards ✅ (pricing scraped)
2. Business Cards
3. Flyers
4. Brochures
5. Booklets
6. Folded Cards
7. Tags
8. Die Cut
9. Menus

## Market Context
- Brooklyn print market is negotiation-heavy
- Russian-speaking and Jewish community customer base
- Customers anchor to online competitors (NDF, VistaPrint, GotPrint)
- Our advantage: speed, quality, local service, white ink capability, custom finishing
