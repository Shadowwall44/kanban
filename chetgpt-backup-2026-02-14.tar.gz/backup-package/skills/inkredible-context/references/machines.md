# INKredible Printing — Machine Inventory

## Small Format

### Konica Minolta AccurioPress C3080
- **Type**: Digital press (small format)
- **Click charge**: $0.045 per color click (core cost input)
- **Products**: Business cards, postcards, flyers, brochures, booklets, menus
- **Max sheet size**: 13" x 19.2"
- **Speed**: 80 ppm color
- **Notes**: Main production machine for small format. Click charge is the baseline for all small format costing.

## Wide Format

### Roland VG2-540
- **Type**: Print & cut (wide format)
- **Capabilities**: Print AND contour cut in one pass
- **Max width**: 54"
- **Products**: Vinyl decals, stickers, vehicle wraps, window graphics, die-cut shapes
- **Notes**: Versatile — can do print-only or print+cut. Eco-solvent ink.

### HP Latex 700W
- **Type**: Wide format latex printer
- **Capabilities**: White ink capable (prints on dark/clear media)
- **Max width**: 64"
- **Products**: Banners, fabric prints, wall murals, dance floor wraps, backdrops, vehicle wraps
- **Notes**: Latex ink = odorless, indoor-safe, scratch-resistant. White ink is a competitive advantage.

## Finishing

### Intec ColorCut FB550
- **Type**: Digital die cutter (flatbed)
- **Capabilities**: Contour cutting on sheets up to 550mm
- **Products**: Custom-shaped business cards, packaging, labels, stickers
- **Notes**: Uses registration marks for precise cutting

### Triumph 5260
- **Type**: Guillotine paper cutter
- **Capabilities**: Stack cutting up to 20.5" wide
- **Products**: Trimming all small format jobs to final size
- **Notes**: Essential finishing tool, used on every small format job

## Dream Machine (future)
- Aviel wants a $300K flatbed UV printer + cutter for custom build shop
- Would enable: direct-to-substrate printing, rigid media, specialty products
- Timeline: after revenue hits $1M+ consistently
