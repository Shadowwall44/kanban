# INKredible — Repository & File Map

## Workspace Root
`/home/inkredible/.openclaw/workspace/`

## Repositories

| Repo | Local Path | Purpose |
|------|-----------|---------|
| kanban | `workspace/kanban/` | Work + Personal Kanban boards (GitHub Pages) |
| inkredible-tools | `workspace/inkredible-tools/` | Hub, Dashboard, Mission Control, Second Brain, Quote Tool |
| inkredible-voice | `workspace/inkredible-voice/` | Desktop voice-to-text app (Electron, Windows) |
| INKredible-vault | (not pulled locally) | Business docs, research, notes |
| inkredible-extractor | (not pulled locally) | Invoice extraction React app |
| inkredible-invoices | `workspace/inkredible-invoices/` | 163 vendor invoice PDFs |

## GitHub
- Username: `Shadowwall44`
- PAT: `~/.git-credentials` (HTTPS auth)
- Base URL: `https://github.com/Shadowwall44/`

## Key Directories

```
workspace/
├── memory/                  # Daily logs, brain dumps, learning files
│   ├── 2026-02-13.md       # Today's comprehensive log
│   ├── brain-dump-01.md    # Aviel's complete brain dump
│   ├── self-improvement.md # ChetGPT self-reflection
│   ├── engineer-lessons.md # Sub-agent engineering knowledge
│   ├── research-lessons.md # Sub-agent research knowledge
│   └── operations-lessons.md # Sub-agent ops knowledge
├── .secrets/                # API keys and tokens (chmod 600)
│   ├── intuit-credentials.json
│   └── quickbooks-tokens.json
├── financials/              # Financial analysis
│   └── pnl-analysis.md
├── research/                # Research outputs
│   ├── skill-proposals.md
│   ├── himalaya-email-setup.md
│   └── zoho-mis-blueprint.md
├── transcripts/             # YouTube transcripts + analyses
├── audits/                  # Code audit reports
├── kanban/                  # Kanban board repo
├── inkredible-tools/        # Tools suite repo
│   └── public/
│       └── status.json     # Mission Control data (polled every 15s)
├── inkredible-voice/        # Voice app repo
├── inkredible-invoices/     # Vendor PDFs
├── extraction-results/      # Invoice extraction output
├── quickbooks/              # QB integration files
│   └── oauth-server.mjs
├── nextdayflyers_pricing_final.csv  # NDF pricing data
├── usage-tracker.json       # Session usage tracking
├── idea-queue.md           # Captured ideas for future
└── AGENTS.md, SOUL.md, etc. # OpenClaw config files
```

## File Conventions
- Daily logs: `memory/YYYY-MM-DD.md`
- Research output: `research/[topic].md`
- Transcripts: `transcripts/[video-id].md`
- Audit reports: `audits/[target]-audit.md`
- Drafts: `drafts/[name].md` (NOT `workspace/workspace/drafts/` — avoid double nesting)
- Secrets: `.secrets/[name].json` with chmod 600

## Design System
All web UIs use the Origin Design System. See `origin-design-system` skill for full spec.
