---
name: inkredible-context
description: "INKredible Printing business context and operational knowledge. Use when working on any INKredible task: quoting, invoicing, financial analysis, customer communication, machine operations, team coordination, or building tools for the business. Provides machines, pricing model, team, vendors, file locations, repo structure, and conventions."
---

# INKredible Printing — Business Context

## The Business
Custom printing shop in Brooklyn, NY. Dance floor wraps, signage, fabric printing, business cards, banners, postcards, flyers, brochures.

## Team
- **Aviel** (CEO/Owner) — strategy, sales, customer relationships. Has ADHD — needs bite-sized tasks.
- **Brandon** (COO, $33/hr) — operations, production, has QuickBooks access. PARTNER, not employee.
- **Diandra** (Secretary, $15/hr) — admin, front desk
- **ChetGPT / Chet** (AI COO/Advisor) — Opus 4.6, strategy + coaching + orchestration

## Machines
For machine specs, capabilities, and job routing: see `references/machines.md`

## Pricing Model
For pricing rules, NDF anchoring, and three-tier markup: see `references/pricing.md`

## File Locations & Repos
For all repo paths, workspace structure, and file conventions: see `references/repos.md`

## Financial Overview
- Revenue: ~$686K/yr ($27K/mo average)
- Gross Margin: 54.5%
- Net Income: -$10.7K (barely break-even)
- Total Debt: ~$174K (LOC $43K at ~14% APR + CC balances)
- Goal: Scale to $1-2M through systematization + MIS

## Key Rules
- Store hours: Mon-Thu 10am-6pm, Fri 10am-2pm, Sat-Sun closed
- Sabbath: Friday sundown → Saturday sundown — NO external-facing actions
- Brandon = partner, always involved in business decisions
- Dashboard and tools = team-wide access (Aviel + Brandon + Diandra)
