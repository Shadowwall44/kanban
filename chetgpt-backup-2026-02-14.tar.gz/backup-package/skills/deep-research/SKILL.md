---
name: deep-research
description: >
  Deep web research methodology for thorough, source-backed analysis.
  Use when: researching competitors, markets, frameworks, tools, pricing,
  best practices, or any topic requiring multiple sources and synthesis.
  Trigger phrases: research this, look into, find out about, compare options,
  what's the best, deep dive, investigate, analyze the market.
---

# Deep Research Skill

## Purpose
Conduct thorough, multi-source web research with structured output. Every claim backed by a source. Every recommendation grounded in evidence.

## Critical Rules
- **Minimum 5 sources** per research topic before drawing conclusions
- **Always cite sources** — URL + date for every factual claim
- **Distinguish facts from opinions** — label clearly
- **Check source recency** — prefer content from last 12 months
- **Cross-validate** — if only one source says it, flag it as unconfirmed
- **Declare confidence level** — High/Medium/Low for each finding

## Instructions

### Step 1: Define the Research Question
Before searching, write a clear research question in one sentence.
- What specifically are we trying to learn?
- What decision will this research inform?
- What would "good enough" look like?

### Step 2: Search Strategy
Run 3-5 targeted searches with different angles:
1. **Direct query** — the obvious search
2. **Expert perspective** — add "expert" or specific author names
3. **Contrarian view** — add "problems with" or "criticism of" or "alternatives to"
4. **Practical examples** — add "case study" or "real example" or "implementation"
5. **Recent developments** — use freshness filters for last 12 months

### Step 3: Source Evaluation
For each source, assess:
- **Authority**: Who wrote it? What's their expertise?
- **Recency**: When was it published?
- **Depth**: Surface-level summary or detailed analysis?
- **Bias**: Is the source selling something related?

Rate sources: ⭐⭐⭐ (authoritative), ⭐⭐ (useful), ⭐ (filler)

### Step 4: Synthesis
Combine findings into structured output:
```markdown
## Research: [Topic]
**Question**: [What we're answering]
**Sources consulted**: [N sources, N ⭐⭐⭐]
**Confidence**: [High/Medium/Low]

### Key Findings
1. [Finding] — Source: [URL]
2. [Finding] — Source: [URL]

### Consensus View
[What most sources agree on]

### Contrarian/Minority Views
[What some sources disagree on]

### Gaps
[What we couldn't find reliable data on]

### Recommendation
[Actionable next step based on findings]
```

### Step 5: Store Results
Save research output to `workspace/research/[topic]-[date].md`
Update relevant memory files if findings affect ongoing projects.

## Examples

**User says**: "Research the best CRM for small print shops"
1. Define: "Which CRM platforms best serve small-format printing businesses with 2-5 employees?"
2. Search: CRM for print shops, print industry CRM comparison, small business CRM 2026, CRM problems print industry
3. Evaluate: prioritize industry-specific reviews over generic CRM listicles
4. Synthesize: structured comparison with pricing, features, integration capabilities
5. Store: `workspace/research/crm-print-shops-2026-02-14.md`

**User says**: "Look into floor graphics pricing in NYC"
1. Define: "What do NYC competitors charge for floor graphics, and how does INKredible compare?"
2. Search: floor graphics pricing NYC, custom floor wrap cost, event floor graphics quotes
3. Evaluate: prioritize actual pricing pages over blog posts
4. Synthesize: competitive pricing landscape with INKredible positioning
5. Store: `workspace/research/price-watch/floor-graphics-nyc-[date].md`

## Troubleshooting
- **Rate limited on search API**: Space searches 2+ seconds apart, fetch URLs directly when possible
- **Paywalled content**: Note the paywall, use available snippets, find alternative sources
- **Contradictory sources**: Present both views with source quality ratings
- **Topic too broad**: Break into sub-questions, research each separately
- **No recent sources**: Note the data gap, use older sources with recency caveat
