# Aviel — Coaching Profile (Living Document)

> Updated by ChetGPT after significant coaching interactions.
> This document tracks patterns, progress, and growth areas.

## ADHD Profile
- **Diagnosed**: Yes
- **Therapist**: Active (mentioned hyper-focus as both strength and risk)
- **Medication**: Not discussed — not our domain
- **Primary EF challenges**: Task initiation, working memory, self-motivation for personal tasks
- **Strengths**: Hyperfocus (when interested), creative ideation, risk tolerance, resilience

## Behavioral Patterns Observed

### Momentum Cycles
- **Pattern**: All-or-nothing. Intense productive periods → gap → guilt → longer gap → re-engagement
- **Typical productive streak**: 1-3 days of intense work
- **Recovery trigger**: Usually external (business need, customer demand, or ChetGPT nudge)
- **Re-entry approach that works**: No guilt, smallest next step, quick win first

### Idea Generation
- **Pattern**: Rapid-fire ideation during engagement (5+ ideas in 15 minutes is normal)
- **Risk**: Starting 10 things, finishing none
- **What works**: Capture all ideas, sequence them, serve one at a time
- **Therapist insight**: Hyper-focus can be a problem if not channeled — it's his superpower AND his risk

### Task Avoidance
- **Business tasks**: Generally gets done (external accountability from customers/Brandon)
- **Personal tasks**: High avoidance (executive dysfunction — no external dopamine)
- **Financial tasks**: Historically avoided ("too scared to look")
- **Approach that works**: Make it visible, make it tiny, make it social

## Growth Wins (Evidence of Progress)
Track concrete evidence of growth for reference during low moments:
- [2026-02-14] Proactively asked for accountability system instead of waiting
- [2026-02-14] Self-identified ADHD hyper-focus pattern in real-time
- [2026-02-14] Raised AI safety concerns unprompted — mature, strategic thinking
- [2026-02-13] Engaged deeply with financial data (previously "too scared to look")
- [2026-02-13] Set up ChetGPT as operational system (not just a chatbot)

## Current Goals (from Brain Dump + Conversations)
1. Financial peace of mind
2. MIS system (identity-level project)
3. Wispr Flow clone (identity-level project)
4. Enjoy life more
5. Be the best version of himself
6. $1M revenue
7. Be more present with family
8. Build confidence and organization

## Relationship Check-Ins
- **Wife**: Help him be present. Don't enable late-night work.
- **Mom**: Not doing well. Aviel feels guilty. Gentle periodic reminder to call.
- **Kids**: Daughter (6, bus), Son (4, Aviel drives), Baby (8mo, alarm clock)

## Energy Patterns
- **Morning**: Baby wakes 6-6:30 AM. Drives son to school. Peak energy unknown — track.
- **Afternoon**: At the shop. External structure helps.
- **Evening**: Family time. Risk of late-night work sessions.
- **Shabbat**: Rest day. Physical books. Ideas still flow (as evidenced by today's voice notes).

## Coaching Notes
- Responds well to direct, honest feedback
- Does NOT respond well to: "Great question!" or overly positive validation
- Needs: clear action items, numbered steps, mobile-friendly format
- Learns by doing — give exact commands, not explanations
- Format for TickTick when creating task lists
