# ADHD & Personal Development Frameworks — Deep Reference

## Dr. Russell Barkley — Executive Function & Self-Regulation

### ADHD as Executive Function Deficit
Barkley's unified theory of ADHD (1997, updated through 2015) reframes ADHD as fundamentally a disorder of **self-regulation**, not attention. The "attention deficit" is actually a symptom of impaired executive functions.

### The Five Executive Functions Affected by ADHD

#### 1. Self-Awareness (Self-Directed Attention)
- Ability to monitor your own behavior in real-time
- ADHD impact: Poor self-monitoring, not noticing when you've gone off-track
- Compensation: External monitoring (coach, app, timer, accountability partner)

#### 2. Self-Restraint (Behavioral Inhibition)
- The "brake pedal" — ability to stop an impulse before acting
- ADHD impact: Impulsive decisions, interrupting, starting new projects without finishing current ones
- Compensation: Structured decision processes, "sleep on it" rules, delayed response protocols

#### 3. Working Memory (Nonverbal & Verbal)
- Holding information in mind to guide behavior
- ADHD impact: Losing track of multi-step plans, forgetting commitments, "out of sight, out of mind"
- Compensation: External memory systems (lists, reminders, visual task boards, written commitments)

#### 4. Emotional Self-Regulation
- Managing emotional reactions to stay productive
- ADHD impact: Frustration intolerance, rejection sensitivity, mood swings affecting work
- Compensation: Emotion labeling, cooling-off protocols, coaching support during emotional states

#### 5. Self-Motivation (Reconstitution)
- Generating internal drive without external rewards
- ADHD impact: Difficulty persisting on boring/unrewarding tasks, needing external deadlines
- Compensation: External accountability, gamification, artificial urgency, reward systems

### Barkley's Key Principles for ADHD Management

1. **"The point of performance"**: Interventions must happen AT the point where behavior occurs, not before or after. Don't lecture — change the environment.

2. **"Make the invisible visible"**: Externalize information that neurotypical people hold in working memory. Write it down, put it on a wall, set a reminder.

3. **"Make time physical"**: ADHD brains struggle with time perception. Use visible timers, countdowns, and calendar blocking.

4. **"Make motivation external"**: Don't rely on internal motivation. Create external rewards, consequences, and accountability structures.

5. **"Self-regulation is a limited resource"**: Decision fatigue hits ADHD brains faster. Reduce the number of decisions required — automate, delegate, systematize.

### Treatment Hierarchy (Barkley's Recommendation)
1. Medication (if applicable — not our domain)
2. Environmental modification (external scaffolding)
3. Behavioral strategies (habits, systems)
4. Coaching (ongoing accountability and pattern recognition)

**Source**: Barkley, R.A. (1997). "Behavioral inhibition, sustained attention, and executive functions." *Psychological Bulletin*, 121(1), 65-94. Updated in: Barkley, R.A. (2015). *Attention Deficit Hyperactivity Disorder: A Handbook for Diagnosis and Management*. Guilford Press.

---

## James Clear — Atomic Habits (2018)

### The Core Philosophy
"You do not rise to the level of your goals. You fall to the level of your systems."

### Three Layers of Behavior Change
1. **Outcomes** (what you get) — Losing weight, making money
2. **Processes** (what you do) — Exercise routine, work habits
3. **Identity** (what you believe) — "I am a runner" vs "I want to run"

**Most people try to change outcomes. The most effective change starts with identity.**

### Identity-Based Habits
- Decide the TYPE of person you want to be
- Prove it to yourself with small wins
- "Every action is a vote for the type of person you wish to become"

**ADHD application**: 
- Don't say "I need to be more organized" → Say "I am someone who writes things down"
- Don't say "I need to stop procrastinating" → Say "I am someone who does the hard thing first"
- Each tiny action that matches the identity reinforces it

### The Four Laws of Behavior Change (Detailed)

#### Law 1: Make It Obvious (Cue)
- **Habit scorecard**: List current habits, mark +/-/= for each
- **Implementation intention**: "I will [BEHAVIOR] at [TIME] in [LOCATION]"
- **Habit stacking**: "After I [CURRENT HABIT], I will [NEW HABIT]"
- **Environment design**: Make cues of good habits visible, remove cues of bad habits

**ADHD-specific**: Environment design is 10x more important for ADHD brains because self-cueing is impaired (Barkley's working memory deficit). The environment must do the prompting.

#### Law 2: Make It Attractive (Craving)
- **Temptation bundling**: Pair something you NEED to do with something you WANT to do
  - "I'll only listen to my favorite podcast while doing bookkeeping"
- **Join a culture where your desired behavior is the norm**
- **Create a motivation ritual**: Do something enjoyable right before a difficult habit

**ADHD-specific**: Dopamine-seeking brains respond powerfully to temptation bundling. Pair boring tasks with high-dopamine rewards.

#### Law 3: Make It Easy (Response)
- **Two-minute rule**: Scale down any habit to something you can do in 2 minutes or less
  - "Read 30 pages" → "Read one page"
  - "Do a full workout" → "Put on your workout shoes"
- **Reduce friction**: Decrease the number of steps between you and good habits
- **Prime the environment**: Prepare the space for the next habit

**ADHD-specific**: The 2-minute rule is perhaps the single most important strategy for ADHD. Task initiation is the primary barrier — not task completion. Once started, ADHD brains often hyperfocus and exceed the goal.

#### Law 4: Make It Satisfying (Reward)
- **Immediate reward**: Give yourself something pleasant right after the habit
- **Habit tracking**: Visual progress (streak counter, checkmarks) provides satisfaction
- **Never miss twice**: Missing once is an accident. Missing twice is the start of a new habit.
- **Accountability partner**: Social cost of not following through

**ADHD-specific**: Immediate rewards are crucial because ADHD brains discount future rewards more steeply than neurotypical brains (Barkley). The reward MUST be immediate, not promised for later.

### The 1% Rule
- 1% better every day = 37x better in one year
- 1% worse every day = near zero in one year
- Tiny changes compound. This is why systems beat goals.

**Source**: Clear, J. (2018). *Atomic Habits: An Easy & Proven Way to Build Good Habits & Break Bad Ones*. Avery.

---

## BJ Fogg — Tiny Habits / Fogg Behavior Model (Stanford)

### B = MAP (Behavior = Motivation × Ability × Prompt)
Three elements must converge at the same moment for a behavior to occur:

1. **Motivation**: The desire to do the behavior (can be high or low)
2. **Ability**: How easy it is to do the behavior (friction level)
3. **Prompt**: The trigger that initiates the behavior (reminder, cue, signal)

**If behavior doesn't happen, at least one element is missing.**

### The Action Line
Plot Motivation (vertical) vs Ability (horizontal). The "action line" curves between them.
- Above the line + prompt = behavior happens
- Below the line = behavior doesn't happen, even with a prompt

**Key insight**: You can compensate for low motivation by making the behavior extremely easy. You don't need willpower if the action is tiny enough.

### Tiny Habits Recipe
1. **Anchor Moment**: An existing routine that reliably happens (e.g., "After I pour my morning coffee...")
2. **Tiny Behavior**: The smallest version of the new habit (e.g., "...I will write one sentence in my journal")
3. **Celebration**: Immediate positive emotion (e.g., "YES!" + fist pump)

**Rules**:
- The tiny behavior must take less than 30 seconds
- The celebration must happen IMMEDIATELY (within 0.5 seconds)
- Emotions create habits, not repetition alone
- Scale up naturally — don't force growth

### Three Types of Prompts
1. **Spark**: Person has ability but lacks motivation → prompt must inspire
2. **Facilitator**: Person has motivation but lacks ability → prompt must make it easier
3. **Signal**: Person has both motivation and ability → just needs a reminder

### ADHD Application of Fogg Model

**The ADHD prompt problem**: ADHD brains have impaired self-prompting (Barkley's self-awareness deficit). External prompts are not optional — they're essential.

**Best prompts for ADHD**:
- Timer/alarm (bypasses working memory)
- Environment cue (visual reminder in physical space)
- Accountability check-in (social prompt)
- Habit stack (piggyback on existing automatic behavior)

**Worst prompts for ADHD**:
- "I'll remember to do it later" (working memory deficit)
- "I'll feel motivated to do it tomorrow" (self-motivation deficit)
- Calendar reminders alone (easily dismissed/forgotten)

**Source**: Fogg, B.J. (2020). *Tiny Habits: The Small Changes That Change Everything*. Houghton Mifflin Harcourt. Also: behaviormodel.org (Stanford Behavior Design Lab).

---

## ADHD-Entrepreneur Research

### The 6x Statistic
Entrepreneurs are approximately 6 times more likely to have ADHD than the general population. 

**Why**: The same neurological traits that create ADHD challenges also create entrepreneurial advantages:
- Risk tolerance (impulsivity → willingness to leap)
- Pattern recognition (distractibility → noticing connections others miss)
- Hyperfocus (attention dysregulation → intense deep work on interesting problems)
- Resilience (emotional dysregulation → ability to bounce back from failure)
- Energy (hyperactivity → drive and hustle)

**Source**: Verheul, I. et al. (2015). "ADHD-like behavior and entrepreneurial intentions." *Small Business Economics*, 45(1), 85-101. Published by Springer.

### External Scaffolding Model (Commit Action)
Professional ADHD business coaching provides five types of external scaffolding:

1. **Dopamine Regulation**: External deadlines and social commitment trigger dopamine release even for low-interest tasks
2. **Working Memory Support**: Coach maintains the strategic thread when focus naturally shifts
3. **Task Initiation Boost**: Commitment to report progress overcomes activation energy barrier
4. **Emotion Regulation Partner**: Navigate the emotional rollercoaster of entrepreneurship
5. **Implementation Structure**: Weekly rituals create external scaffolding regardless of internal motivation

### What Research Shows Works for ADHD Entrepreneurs
- **Specific accountability** ("Logo revision due Thursday 2 PM") beats vague accountability ("Let me know how it goes")
- **Breaking tasks into concrete steps** with deadlines tied to energy patterns
- **Identifying friction points** and designing workarounds, not demanding discipline
- **Weekly review rituals** that don't depend on the person remembering to initiate them

**Source**: Commit Action coaching research; ADDA (Attention Deficit Disorder Association) best practices.

---

## Practical Integration: The ADHD Coaching Stack

For coaching an ADHD entrepreneur, layer these frameworks:

1. **Barkley** → Understand WHY they struggle (EF deficits, not character flaws)
2. **Clear** → Build identity-based habits with environmental design
3. **Fogg** → Make every behavior tiny and attach to existing anchors
4. **External Scaffolding** → Provide accountability, memory support, task initiation, emotional regulation

**The coaching role combines all four**: You ARE the external scaffolding (Barkley), helping build identity-based systems (Clear), using tiny behavior design (Fogg), and providing the specific accountability that ADHD entrepreneurs need (Commit Action model).
