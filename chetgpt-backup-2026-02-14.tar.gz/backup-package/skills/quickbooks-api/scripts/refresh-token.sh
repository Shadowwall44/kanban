#!/usr/bin/env bash
# QuickBooks Token Refresh — refreshes access token using stored refresh token
# Usage: bash refresh-token.sh
# Requires: jq, curl

set -euo pipefail

CREDS_FILE="/home/inkredible/.openclaw/workspace/.secrets/intuit-credentials.json"
TOKENS_FILE="/home/inkredible/.openclaw/workspace/.secrets/quickbooks-tokens.json"
TOKEN_URL="https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer"

# Check files exist
if [[ ! -f "$CREDS_FILE" ]]; then
  echo "❌ Credentials not found at $CREDS_FILE"
  echo "   Run OAuth server first: node workspace/quickbooks/oauth-server.mjs"
  exit 1
fi

if [[ ! -f "$TOKENS_FILE" ]]; then
  echo "❌ Tokens not found at $TOKENS_FILE"
  echo "   Run OAuth server first to get initial tokens"
  exit 1
fi

# Read credentials
CLIENT_ID=$(jq -r '.clientId' "$CREDS_FILE")
CLIENT_SECRET=$(jq -r '.clientSecret' "$CREDS_FILE")
REFRESH_TOKEN=$(jq -r '.refresh_token' "$TOKENS_FILE")

if [[ -z "$CLIENT_ID" || -z "$CLIENT_SECRET" || -z "$REFRESH_TOKEN" ]]; then
  echo "❌ Missing credentials or refresh token"
  exit 1
fi

# Base64 encode client credentials
AUTH_HEADER=$(echo -n "${CLIENT_ID}:${CLIENT_SECRET}" | base64 -w 0)

echo "🔄 Refreshing QuickBooks access token..."

# Make refresh request
RESPONSE=$(curl -s -X POST "$TOKEN_URL" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -H "Authorization: Basic ${AUTH_HEADER}" \
  -d "grant_type=refresh_token&refresh_token=${REFRESH_TOKEN}")

# Check for errors
if echo "$RESPONSE" | jq -e '.error' > /dev/null 2>&1; then
  ERROR=$(echo "$RESPONSE" | jq -r '.error')
  DESC=$(echo "$RESPONSE" | jq -r '.error_description // "No description"')
  echo "❌ Token refresh failed: $ERROR"
  echo "   $DESC"
  if [[ "$ERROR" == "invalid_grant" ]]; then
    echo "   Refresh token expired. Re-authorize via OAuth server."
  fi
  exit 1
fi

# Extract new tokens
NEW_ACCESS=$(echo "$RESPONSE" | jq -r '.access_token')
NEW_REFRESH=$(echo "$RESPONSE" | jq -r '.refresh_token')
EXPIRES_IN=$(echo "$RESPONSE" | jq -r '.expires_in')
TIMESTAMP=$(date -Iseconds)

if [[ -z "$NEW_ACCESS" || "$NEW_ACCESS" == "null" ]]; then
  echo "❌ No access token in response"
  echo "$RESPONSE" | jq '.'
  exit 1
fi

# Save updated tokens
jq -n \
  --arg at "$NEW_ACCESS" \
  --arg rt "$NEW_REFRESH" \
  --arg ei "$EXPIRES_IN" \
  --arg ts "$TIMESTAMP" \
  '{
    access_token: $at,
    refresh_token: $rt,
    token_type: "bearer",
    expires_in: ($ei | tonumber),
    obtained_at: $ts
  }' > "$TOKENS_FILE"

chmod 600 "$TOKENS_FILE"

echo "✅ Token refreshed successfully"
echo "   Expires in: ${EXPIRES_IN}s"
echo "   Saved to: $TOKENS_FILE"
