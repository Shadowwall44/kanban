# QuickBooks API — Endpoints & Queries

## Base URLs
- **Sandbox**: `https://sandbox-quickbooks.api.intuit.com/v3/company/9341456363972482`
- **Production**: `https://quickbooks.api.intuit.com/v3/company/{COMPANY_ID}`

## Common Queries (SQL-like syntax)

### Company Info
```
GET /companyinfo/{companyId}
```

### Profit & Loss Report
```
GET /reports/ProfitAndLoss?start_date=2025-01-01&end_date=2025-12-31
```
Optional params: `summarize_column_by=Month`, `accounting_method=Accrual`

### Balance Sheet
```
GET /reports/BalanceSheet?date=2025-12-31
```

### Customers
```
GET /query?query=SELECT * FROM Customer MAXRESULTS 1000
```
Key fields: DisplayName, PrimaryEmailAddr, PrimaryPhone, Balance

### Invoices
```
GET /query?query=SELECT * FROM Invoice WHERE TxnDate > '2025-01-01' MAXRESULTS 1000
```
Key fields: TxnDate, TotalAmt, Balance, CustomerRef, Line items

### Expenses / Purchases
```
GET /query?query=SELECT * FROM Purchase WHERE TxnDate > '2025-01-01' MAXRESULTS 1000
```

### Vendors
```
GET /query?query=SELECT * FROM Vendor MAXRESULTS 500
```

### Items (Products/Services)
```
GET /query?query=SELECT * FROM Item MAXRESULTS 500
```

### Accounts (Chart of Accounts)
```
GET /query?query=SELECT * FROM Account MAXRESULTS 500
```

## Response Format
All responses are JSON. Key patterns:
```json
{
  "QueryResponse": {
    "Customer": [...],    // Array of entities
    "startPosition": 1,
    "maxResults": 100,
    "totalCount": 42
  }
}
```

For reports:
```json
{
  "Header": { "ReportName": "ProfitAndLoss", ... },
  "Rows": { "Row": [...] },
  "Columns": { "Column": [...] }
}
```

## Pagination
- Default max: 1000 results per query
- Use `STARTPOSITION` and `MAXRESULTS` for pagination:
  ```
  SELECT * FROM Invoice STARTPOSITION 1001 MAXRESULTS 1000
  ```

## Error Codes
| Code | Meaning | Action |
|------|---------|--------|
| 401 | Token expired | Refresh token and retry |
| 403 | Insufficient scope | Check app permissions |
| 404 | Entity not found | Check ID/company |
| 429 | Rate limited | Wait and retry |
| 500 | QB server error | Retry after 30s |

## INKredible-Specific Queries

### Monthly Revenue
```
GET /reports/ProfitAndLoss?start_date=2025-01-01&end_date=2025-12-31&summarize_column_by=Month
```

### Outstanding Customer Balances
```
SELECT DisplayName, Balance FROM Customer WHERE Balance > '0'
```

### Top Expenses
```
GET /reports/ProfitAndLoss → parse Expenses section → sort by amount
```

### Owner's Draw (Distributions)
```
SELECT * FROM Account WHERE AccountType = 'Equity'
```
Then: Reports → Balance Sheet Detail → filter Equity accounts
