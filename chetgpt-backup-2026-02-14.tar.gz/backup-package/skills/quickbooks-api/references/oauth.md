# QuickBooks API — OAuth Flow

## Overview
QuickBooks uses OAuth 2.0 with authorization code flow.
- Access token: expires in 1 hour
- Refresh token: expires in ~101 days
- Must refresh before expiry to maintain connection

## OAuth Server
Local server at: `workspace/quickbooks/oauth-server.mjs`
- Port: 8080
- Redirect URI: `http://localhost:8080/callback`

## Initial Authorization Flow
1. Start OAuth server: `node workspace/quickbooks/oauth-server.mjs`
2. Open the auth URL it prints (in browser)
3. Sign in to Intuit and authorize the app
4. Server captures the callback code
5. Exchanges code for access + refresh tokens
6. Saves tokens to `.secrets/quickbooks-tokens.json`

## Token Refresh (automated)
Use the refresh script:
```bash
bash /home/inkredible/.openclaw/skills/quickbooks-api/scripts/refresh-token.sh
```

Or manually:
```bash
curl -s -X POST 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -H "Authorization: Basic $(echo -n "$CLIENT_ID:$CLIENT_SECRET" | base64)" \
  -d "grant_type=refresh_token&refresh_token=$REFRESH_TOKEN"
```

## Key URLs
- Auth: `https://appcenter.intuit.com/connect/oauth2`
- Token: `https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer`
- Revoke: `https://developer.api.intuit.com/v2/oauth2/tokens/revoke`

## Scopes
- `com.intuit.quickbooks.accounting` — full accounting access (read + write)

## Token File Schema
```json
{
  "access_token": "...",
  "refresh_token": "...",
  "token_type": "bearer",
  "expires_in": 3600,
  "x_refresh_token_expires_in": 8726400,
  "obtained_at": "ISO-8601 timestamp"
}
```

## Troubleshooting
| Issue | Cause | Fix |
|-------|-------|-----|
| 401 on API call | Access token expired | Run refresh-token.sh |
| "invalid_grant" on refresh | Refresh token expired (~101 days) | Re-authorize via OAuth server |
| "unauthorized_client" | Wrong client ID/secret | Check .secrets/intuit-credentials.json |
| Redirect URI mismatch | URL doesn't match app config | Must be exactly `http://localhost:8080/callback` |
