---
name: quickbooks-api
description: "QuickBooks Online API integration for INKredible Printing. Use when querying financial data, building dashboards, connecting to QuickBooks, refreshing OAuth tokens, or working with accounting data. Trigger on: QuickBooks, QBO, financial data, P&L, balance sheet, invoices, customers, expenses, accounting API, OAuth token."
---

# QuickBooks API Integration

## Current Status
- **Sandbox**: ✅ Connected (Company ID: 9341456363972482)
- **Production**: ⏳ Questionnaire submitted, awaiting Intuit review (1-5 business days)
- **App**: "INKredible Claude MCP" (AppID: 2b631777-7e7a-49e7-b441-a32cb3a001fc)

## Quick Reference

### Token Refresh
Access tokens expire every hour. Refresh before any API call:
```bash
bash /home/inkredible/.openclaw/skills/quickbooks-api/scripts/refresh-token.sh
```

### API Call Pattern
```bash
# 1. Refresh token
bash scripts/refresh-token.sh

# 2. Read fresh token
TOKEN=$(cat ~/.openclaw/workspace/.secrets/quickbooks-tokens.json | jq -r '.access_token')

# 3. Make API call
curl -s -H "Authorization: Bearer $TOKEN" \
  -H "Accept: application/json" \
  "$BASE_URL/$COMPANY_ID/query?query=SELECT * FROM Customer"
```

## Endpoints
For all API endpoints, query examples, and response schemas: see `references/endpoints.md`

## OAuth Flow
For the full OAuth setup and token management: see `references/oauth.md`

## Credentials
- **Location**: `~/.openclaw/workspace/.secrets/intuit-credentials.json` (chmod 600)
- **Tokens**: `~/.openclaw/workspace/.secrets/quickbooks-tokens.json` (chmod 600)
- **NEVER** log, print, or include credentials in memory files or chat messages

## Important Rules
1. ALWAYS refresh token before API calls (they expire hourly)
2. Use sandbox URL for testing, production URL for real data
3. Error 401 = expired token → refresh and retry
4. Error 403 = wrong scope or suspended app
5. Rate limit: 500 requests per minute (generous, rarely hit)
