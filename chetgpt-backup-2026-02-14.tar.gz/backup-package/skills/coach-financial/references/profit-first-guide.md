# Profit First — Detailed Implementation Guide

## The Core Problem Profit First Solves
Traditional accounting: **Sales - Expenses = Profit**
- Problem: Profit is a leftover. There's never anything left.
- Parkinson's Law: Expenses expand to consume available resources.
- Result: Business owner works 70 hours/week and is still broke.

Profit First accounting: **Sales - Profit = Expenses**
- Profit is taken FIRST from every deposit.
- Expenses must fit within what remains.
- Forces lean operations and intentional spending.

## The Five Accounts (Detailed)

### 1. Income Account (The Holding Tank)
- ALL revenue deposits go here first
- Money sits here temporarily before allocation
- Should return to $0 after each allocation cycle
- Never pay bills from this account

### 2. Profit Account (Your Reward)
- Represents the owner's reward for taking business risk
- Quarterly distributions as owner bonuses
- NEVER used for operating expenses — ever
- Even 1% of revenue is better than 0%
- Ideally at a DIFFERENT bank (adds friction to prevent raiding)

### 3. Owner's Compensation Account
- Your actual salary for work performed
- Paid consistently, like any employee
- Not the same as profit distributions
- Separate from business expenses

### 4. Tax Account (No Surprises)
- Portion of every deposit set aside for taxes
- Federal, state, self-employment, sales tax
- Eliminates the annual tax scramble
- Sits untouched until tax time

### 5. Operating Expenses Account
- Everything left after other allocations
- Rent, payroll, supplies, materials, utilities, software
- The ONLY account you pay bills from
- When it runs low: cut expenses or increase revenue. Do NOT raid other accounts.

## Target Allocation Percentages (TAPs)

### By Revenue Range
| Revenue Range | Profit | Owner's Pay | Tax | OpEx |
|--------------|--------|-------------|-----|------|
| $0-$250K | 5% | 50% | 15% | 30% |
| $250K-$500K | 10% | 35% | 15% | 40% |
| $500K-$1M | 15% | 20% | 15% | 50% |
| $1M-$5M | 10-20% | 10-15% | 15% | 50-65% |

### INKredible (~$686K revenue) Target
| Account | Current Estimate | Target | Gap |
|---------|-----------------|--------|-----|
| Profit | ~0% | 12% (~$82K) | -$82K |
| Owner's Pay | Unknown | 25% (~$172K) | Unknown |
| Tax | Unknown | 15% (~$103K) | Unknown |
| OpEx | ~100% | 48% (~$329K) | Massive |

**Note**: The "cash gap" (unreported cash income) means actual numbers are likely better than QuickBooks shows. Step 1 is getting accurate revenue numbers.

## Implementation Timeline

### Week 1: The Instant Assessment
1. Pull last 12 months of revenue from QuickBooks
2. Calculate actual percentages going to: materials, labor, overhead, owner pay, taxes, profit
3. Compare to TAPs
4. The difference = your improvement roadmap

### Week 2: Open the Accounts
1. Open 4 additional checking accounts at your bank (many offer free business checking)
2. Label them: PROFIT, OWNER PAY, TAX, OPEX
3. Consider opening Profit account at a DIFFERENT bank (friction = protection)

### Weeks 3-4: Start Allocating
1. Use CURRENT ACTUAL percentages (even if profit = 0%)
2. Every 10th and 25th of the month: transfer from Income to other accounts
3. Log each allocation

### Ongoing: Adjust by 1-2% Per Quarter
- Each quarter, move 1-2% from OpEx toward Profit
- This forces gradual expense reduction
- Don't try to jump to targets immediately — it's a marathon
- Celebrate each percentage point improvement

## The Allocation Ritual (10th and 25th)
1. Check Income account balance
2. Calculate allocation amounts using current percentages
3. Transfer to each account
4. Pay yourself from Owner's Pay account
5. Pay bills from OpEx account
6. Never touch Profit or Tax accounts

## Quarterly Profit Distribution
- Every quarter, take 50% of the Profit account as an owner bonus
- Leave 50% as a cash reserve
- This is your REWARD — enjoy it guilt-free
- If the business can't survive without raiding profit, expenses are too high

## Common Objections and Responses

**"I can't afford to take profit — I need every dollar for operations"**
→ Start with 1%. On $686K revenue, that's $6,860/year = $572/month. You won't miss it, and it changes your mindset.

**"My business is different"**
→ 200,000+ businesses use Profit First across every industry. The percentages may vary, but the principle is universal.

**"I'll start when business picks up"**
→ If you can't be profitable at $686K, more revenue won't fix it. Revenue just hides the problem longer.

**"What about my debt payments?"**
→ Debt payments come from OpEx. Profit First forces you to find the money by cutting waste, not by sacrificing profit.

## Sources
- Michalowicz, M. (2017). *Profit First: Transform Your Business from a Cash-Eating Monster to a Money-Making Machine*. Portfolio/Penguin.
- Brex.com (2025). "Profit First Method: How it works, benefits, and step-by-step implementation."
- Mercury.com (2023). "How to use Profit First accounting."
