---
name: origin-design-system
description: "INKredible Origin Design System for web UIs. Use when building any dashboard, tool, page, component, or web interface for INKredible. Provides color palette, glassmorphic panel styles, typography, dark/light mode toggle, mobile breakpoints, and component patterns. Trigger on: build UI, create page, design dashboard, style component, Origin design, glassmorphic, dark mode."
---

# Origin Design System

All INKredible web tools use the Origin design language. Follow these rules for visual consistency.

## Core Principles
1. **Dark mode default** — light mode via toggle, preference saved to localStorage
2. **Glassmorphic panels** — frosted glass effect with subtle borders
3. **Mesh gradient backgrounds** — animated, layered color gradients
4. **Mobile-first** — responsive grid, touch-friendly targets
5. **Minimal, not empty** — every element earns its space

## Quick Start
Copy `assets/design-tokens.css` into your HTML `<style>` block. It contains all CSS variables.

For component patterns (panels, cards, pills, toggles): see `references/components.md`
For responsive breakpoints and mobile layout: see `references/responsive.md`

## Color Palette

### Dark Mode (default)
```css
--bg-primary: #0a0a0f;
--bg-panel: rgba(255, 255, 255, 0.05);
--bg-panel-hover: rgba(255, 255, 255, 0.08);
--border-subtle: rgba(255, 255, 255, 0.1);
--border-hover: rgba(255, 255, 255, 0.2);
--text-primary: #ffffff;
--text-secondary: rgba(255, 255, 255, 0.6);
--text-muted: rgba(255, 255, 255, 0.4);
--accent-blue: #3b82f6;
--accent-green: #10b981;
--accent-red: #ef4444;
--accent-amber: #f59e0b;
--accent-purple: #8b5cf6;
--glow-blue: rgba(59, 130, 246, 0.3);
--glow-green: rgba(16, 185, 129, 0.3);
```

### Light Mode
```css
--bg-primary: #f8f9fa;
--bg-panel: rgba(255, 255, 255, 0.8);
--bg-panel-hover: rgba(255, 255, 255, 0.95);
--border-subtle: rgba(0, 0, 0, 0.1);
--border-hover: rgba(0, 0, 0, 0.2);
--text-primary: #1a1a2e;
--text-secondary: rgba(0, 0, 0, 0.6);
--text-muted: rgba(0, 0, 0, 0.4);
```

## Glassmorphic Panel (core component)
```css
.panel {
  background: var(--bg-panel);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border: 1px solid var(--border-subtle);
  border-radius: 16px;
  padding: 24px;
  transition: all 0.3s ease;
}
.panel:hover {
  border-color: var(--border-hover);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
}
```

## Background Gradient
```css
body {
  background: var(--bg-primary);
  background-image:
    radial-gradient(at 20% 80%, rgba(59, 130, 246, 0.15) 0%, transparent 50%),
    radial-gradient(at 80% 20%, rgba(139, 92, 246, 0.1) 0%, transparent 50%),
    radial-gradient(at 50% 50%, rgba(16, 185, 129, 0.05) 0%, transparent 50%);
  min-height: 100vh;
}
```

## Theme Toggle
```javascript
function toggleTheme() {
  const html = document.documentElement;
  const isDark = html.getAttribute('data-theme') !== 'light';
  html.setAttribute('data-theme', isDark ? 'light' : 'dark');
  localStorage.setItem('theme', isDark ? 'light' : 'dark');
}
// On load:
const saved = localStorage.getItem('theme') || 'dark';
document.documentElement.setAttribute('data-theme', saved);
```

## Typography
```css
font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
/* Headings */
h1 { font-size: 2rem; font-weight: 700; letter-spacing: -0.02em; }
h2 { font-size: 1.5rem; font-weight: 600; }
h3 { font-size: 1.125rem; font-weight: 600; }
/* Body */
body { font-size: 0.9375rem; line-height: 1.6; }
```

## Cache Busting (REQUIRED)
Samsung Internet caches aggressively. Always include:
```html
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
```
