# Origin Design — Responsive & Mobile Layout

## Target Device
Samsung Galaxy Z Fold 7 (Aviel's primary device)
- Folded: ~375px wide (phone mode)
- Unfolded: ~717px wide (tablet mode)
- Samsung Internet browser (aggressive caching — cache-busting required)

## Breakpoints
```css
/* Mobile first — base styles are mobile */
/* Tablet / Fold unfolded */
@media (min-width: 768px) { ... }
/* Desktop */
@media (min-width: 1024px) { ... }
/* Large desktop */
@media (min-width: 1280px) { ... }
```

## Grid Pattern
```css
.grid {
  display: grid;
  gap: 16px;
  grid-template-columns: 1fr;
}
@media (min-width: 768px) {
  .grid { grid-template-columns: repeat(2, 1fr); }
}
@media (min-width: 1024px) {
  .grid { grid-template-columns: repeat(3, 1fr); }
}
@media (min-width: 1280px) {
  .grid { grid-template-columns: repeat(4, 1fr); }
}
```

## Stat Cards Grid
```css
.stats-grid {
  display: grid;
  gap: 12px;
  grid-template-columns: repeat(2, 1fr);
}
@media (min-width: 768px) {
  .stats-grid { grid-template-columns: repeat(4, 1fr); }
}
```

## Touch Targets
- Minimum touch target: 44px × 44px (Apple HIG / Material guideline)
- Pill buttons: min-height 40px, padding 8px 16px
- Navigation items: min-height 48px
- FAB: 56px × 56px

## Mobile Considerations
- **No hover effects on mobile** — use `:active` for tap feedback
- **Horizontal scroll for pill bars** — overflow-x: auto with momentum scrolling
- **Bottom navigation on mobile** — sidebar converts to bottom bar at 768px
- **Font sizes**: Don't go below 13px on mobile
- **Padding**: 16px page padding on mobile, 24px on desktop

## Page Layout Template
```css
.page {
  padding: 16px;
  max-width: 1200px;
  margin: 0 auto;
}
@media (min-width: 1024px) {
  .page {
    padding: 24px 32px;
    margin-left: 256px; /* sidebar width + padding */
  }
}
```

## Samsung Internet Specific
- Add cache-busting meta tags to ALL HTML
- Test with both folded and unfolded views
- Samsung Internet may not support some backdrop-filter values — always include -webkit- prefix
