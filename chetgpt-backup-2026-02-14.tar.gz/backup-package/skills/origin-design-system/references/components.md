# Origin Design — Component Patterns

## Pill Bar (Navigation/Filters)
```css
.pill-bar {
  display: flex;
  gap: 8px;
  padding: 4px;
  background: var(--bg-panel);
  border-radius: 12px;
  border: 1px solid var(--border-subtle);
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
}
.pill {
  padding: 8px 16px;
  border-radius: 8px;
  font-size: 0.8125rem;
  font-weight: 500;
  cursor: pointer;
  white-space: nowrap;
  transition: all 0.2s;
  background: transparent;
  color: var(--text-secondary);
  border: none;
}
.pill.active {
  background: var(--accent-blue);
  color: white;
}
```

## Stat Card
```css
.stat-card {
  background: var(--bg-panel);
  backdrop-filter: blur(20px);
  border: 1px solid var(--border-subtle);
  border-radius: 12px;
  padding: 20px;
  text-align: center;
}
.stat-value {
  font-size: 1.75rem;
  font-weight: 700;
  color: var(--text-primary);
}
.stat-label {
  font-size: 0.75rem;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--text-muted);
  margin-top: 4px;
}
```

## Priority Pills (Kanban/Tasks)
```css
.priority-critical { background: rgba(239, 68, 68, 0.2); color: #ef4444; }
.priority-high { background: rgba(245, 158, 11, 0.2); color: #f59e0b; }
.priority-medium { background: rgba(59, 130, 246, 0.2); color: #3b82f6; }
.priority-low { background: rgba(107, 114, 128, 0.2); color: #9ca3af; }
```

## Status Dots
```css
.status-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  display: inline-block;
}
.status-active { background: #10b981; box-shadow: 0 0 8px rgba(16, 185, 129, 0.5); }
.status-working { background: #3b82f6; animation: pulse 2s infinite; }
.status-idle { background: #6b7280; }
.status-offline { background: #374151; }

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}
```

## Floating Action Button
```css
.fab {
  position: fixed;
  bottom: 24px;
  right: 24px;
  width: 56px;
  height: 56px;
  border-radius: 50%;
  background: var(--accent-blue);
  color: white;
  border: none;
  cursor: pointer;
  font-size: 1.5rem;
  box-shadow: 0 4px 16px rgba(59, 130, 246, 0.4);
  z-index: 1000;
  transition: transform 0.2s;
}
.fab:hover { transform: scale(1.1); }
```

## Sidebar (Desktop) / Bottom Bar (Mobile)
```css
.sidebar {
  width: 240px;
  height: 100vh;
  position: fixed;
  left: 0;
  top: 0;
  background: var(--bg-panel);
  backdrop-filter: blur(20px);
  border-right: 1px solid var(--border-subtle);
  padding: 24px 16px;
  z-index: 100;
}
@media (max-width: 768px) {
  .sidebar {
    width: 100%;
    height: auto;
    position: fixed;
    bottom: 0;
    left: 0;
    top: auto;
    border-right: none;
    border-top: 1px solid var(--border-subtle);
    padding: 8px;
    display: flex;
    justify-content: space-around;
  }
}
```

## Glow on Hover (for cards)
```css
.card-glow:hover {
  border-color: var(--accent-blue);
  box-shadow: 0 0 20px var(--glow-blue), 0 8px 32px rgba(0, 0, 0, 0.3);
}
```

## Dark/Light Theme Toggle Button
```html
<button onclick="toggleTheme()" class="theme-toggle" aria-label="Toggle theme">
  <span class="dark-icon">🌙</span>
  <span class="light-icon">☀️</span>
</button>
```
```css
.theme-toggle {
  background: var(--bg-panel);
  border: 1px solid var(--border-subtle);
  border-radius: 8px;
  padding: 8px 12px;
  cursor: pointer;
  font-size: 1rem;
}
[data-theme="light"] .dark-icon { display: none; }
[data-theme="dark"] .light-icon { display: none; }
```
