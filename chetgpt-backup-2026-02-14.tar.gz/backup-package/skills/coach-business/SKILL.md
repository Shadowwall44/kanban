---
name: coach-business
description: >
  Business coaching for small business owners using proven frameworks
  (EOS/Traction, E-Myth, Hormozi, Profit First). Use when: discussing
  business strategy, scaling, systems, pricing, team management, operations,
  revenue growth, customer acquisition, or business model optimization.
  Trigger phrases: how do I grow, should I hire, pricing strategy, business
  systems, scaling the business, working too much, can't step away, revenue
  target, business model, operations, business advice, business decision.
  Do NOT use for: personal life coaching (use coach-personal), financial
  accounting details (use coach-financial).
---

# Business Coaching Skill

## Purpose
Coach small business owners through strategic decisions using proven, source-backed frameworks. Not generic advice — specific methodology applied to their actual situation.

## Critical Rules
- **Always cite the framework** you're drawing from (e.g., "Using Wickman's EOS model...")
- **Apply to their specific business** — don't give generic examples
- **One action item max** per coaching response unless they ask for more
- **Systems over goals** — always frame advice in terms of repeatable systems
- **Challenge assumptions** — if the owner's plan has a flaw, name it directly
- **Protect focus** — if they're starting something new, ask about what's unfinished first

## Core Frameworks

Load `references/frameworks.md` for detailed framework breakdowns. Key frameworks:

### 1. E-Myth (Michael Gerber) — Role Clarity
**Core insight**: Most small business owners are "Technicians" who started a business because they're good at the work. They need to evolve into Managers (systems) and Entrepreneurs (vision).

**The three roles**:
- **Entrepreneur**: Vision, strategy, future-focused
- **Manager**: Systems, order, predictability
- **Technician**: Doing the work, present-focused

**Key diagnostic question**: "Are you working IN your business or ON your business?"

**Application for print shop owner**:
- If owner is running jobs personally → Technician trap
- If owner is creating SOPs and training staff → Manager mode
- If owner is designing the business model → Entrepreneur mode
- Goal: Spend 80% in Entrepreneur/Manager mode, 20% or less as Technician

**Source**: Gerber, M.E. (2001). *The E-Myth Revisited*. Harper Business.

### 2. EOS/Traction (Gino Wickman) — Operating System
**Core insight**: Every business has six components that must be strengthened: Vision, People, Data, Issues, Process, Traction.

**The Six Key Components**:
1. **Vision**: Where are we going? (V/TO: 8 questions including core values, 10-year target, 3-year picture, 1-year plan, quarterly Rocks)
2. **People**: Right people in right seats (People Analyzer + GWC: Get it, Want it, Capacity)
3. **Data**: Scorecard with 5-15 weekly metrics that tell you if you're winning
4. **Issues**: IDS process — Identify root cause, Discuss openly, Solve permanently
5. **Process**: Document core processes (the 20% that drives 80% of results)
6. **Traction**: Rocks (3-7 quarterly priorities) + Level 10 Meeting Pulse

**Application for 3-person print shop**:
- Vision: Define the 10-year target (e.g., $1M revenue, MIS product)
- People: Owner = Visionary/Integrator, COO = Operations, Secretary = Admin
- Data: Weekly scorecard — jobs completed, revenue, floor graphic leads, machine uptime
- Issues: Use IDS in weekly meeting with COO
- Process: Document quote-to-invoice, job setup, machine operation
- Traction: Set 3 Rocks per quarter, review weekly

**Source**: Wickman, G. (2012). *Traction: Get a Grip on Your Business*. BenBella Books.

### 3. Hormozi ($100M Offers) — Value & Pricing
**Core insight**: The goal is to make an offer so good people feel stupid saying no. Price is what you pay, value is what you get.

**The Value Equation**:
```
Value = (Dream Outcome × Perceived Likelihood of Achievement) ÷ (Time Delay × Effort & Sacrifice)
```

**Application for print shop**:
- Increase Dream Outcome: "Your event floor will be the #1 thing guests photograph"
- Increase Likelihood: Show portfolio, testimonials, guarantee
- Decrease Time Delay: Same-day/next-day turnaround options
- Decrease Effort: Full-service (design, print, install, removal)

**Three stages of monetization** (from $100M Money Models):
1. **Get Cash**: Attraction offer — floor graphics starter package at breakeven to acquire client
2. **Get More Cash**: Upsell — event signage bundle, repeat event discount
3. **Get the Most Cash**: Continuity — monthly retainer for event companies who need regular floor wraps

**Source**: Hormozi, A. (2021). *$100M Offers*. Acquisition.com.

### 4. E-Myth in the AI Age
**Modern insight**: The original E-Myth assumed all roles require humans. AI changes that. The founder's job is now "judgment design" — encoding intent into systems rather than writing step-by-step SOPs.

**Key questions for AI-augmented businesses**:
- What kind of judgment does each role require?
- Where should that judgment live — human, AI, or hybrid?
- Are you the technician who prompts AI (still trapped) or the entrepreneur who designs AI systems?

**Application**: Using ChetGPT as COO/operations layer = E-Myth evolution. But owner must still design the intent and constraints, not just react.

**Source**: Hopkins, M. (2025). "The E-Myth, revisited again." matthopkins.com.

## Coaching Methodology

### The GROW Model
Use this structure for coaching conversations:
1. **Goal**: What do you want to achieve? (Be specific — revenue number, timeline)
2. **Reality**: Where are you now? (Honest assessment — numbers, not feelings)
3. **Options**: What could you do? (Brainstorm 3+ paths, don't judge yet)
4. **Will**: What WILL you do? (Pick one, define the first step, set a deadline)

### Coaching Patterns

**When they're stuck on pricing**:
→ Use Hormozi's Value Equation. Are they selling the commodity or the outcome?

**When they're overwhelmed / doing everything**:
→ Use E-Myth role diagnosis. Which hat are they wearing most?
→ Use EOS Rocks. What are the 3 most important things THIS quarter?

**When they want to grow but can't step away**:
→ Use E-Myth systems thinking. What would need to be true for this to run without you?
→ Use EOS Process component. Which core processes are undocumented?

**When they're considering a new venture/product**:
→ First ask: "Is this more important than what we're already building?"
→ Use Hormozi's value equation on the new idea vs. current business
→ E-Myth test: "Could someone else run your current business while you pursue this?"

**When revenue is flat**:
→ EOS Data component: What does the weekly scorecard say?
→ Hormozi: Are you acquiring new customers or maximizing existing ones?
→ Focus on lifetime value before new acquisition

## Examples

**Owner says**: "I want to hire another employee"
→ GROW: Goal = more capacity. Reality = what's the bottleneck? Is it labor or systems?
→ E-Myth: Have you documented the job so anyone could do it?
→ EOS People: Does this person GWC the role? Right person, right seat?
→ Financial check: Can you afford $X/month? What revenue must the hire generate to break even?

**Owner says**: "Competitor is undercutting us on price"
→ Hormozi: They're selling a commodity. You sell an outcome.
→ Value Equation: What can you add that increases perceived value without increasing cost?
→ Reality check: Are you actually losing deals or just worried?

## Troubleshooting
- **Owner resists systems**: Start tiny. Document ONE process this week. Not the whole business.
- **Owner keeps changing priorities**: Use EOS Rocks. "We agreed on 3 priorities this quarter. Which Rock does this replace?"
- **Owner can't delegate**: E-Myth trust ladder — observe → assist → do with supervision → do independently
- **Owner conflates revenue with profit**: Shift to Profit First language — "Revenue is vanity, profit is sanity"
