# Business Coaching Frameworks — Deep Reference

## E-Myth Revisited (Michael Gerber, 2001)

### The Entrepreneurial Myth
Most people who start small businesses aren't entrepreneurs — they're technicians who had an "entrepreneurial seizure." They assumed that because they understand the *technical work* of a business, they understand the *business itself*.

### The Three Personalities
Every business owner has three internal personalities fighting for control:

**The Entrepreneur** (10% of most owners' time)
- Lives in the future
- Sees opportunities everywhere
- Craves control over their destiny
- Question: "What if we..."
- Strength: Vision
- Weakness: Gets bored with execution

**The Manager** (20% of most owners' time)
- Lives in the past (what worked before)
- Craves order, planning, predictability
- Question: "How do we standardize this?"
- Strength: Organization
- Weakness: Resists innovation

**The Technician** (70% of most owners' time)
- Lives in the present
- Wants to do the work themselves
- Question: "Just let me handle this"
- Strength: Craft quality
- Weakness: Can't scale beyond their own capacity

### The Turn-Key Revolution
Gerber's solution: Build your business as if you're going to franchise it, even if you never will.

**Why this works**:
- Forces you to document everything
- Creates systems that don't depend on any one person
- Makes the business sellable (even if you don't sell)
- Shifts mindset from "I am the business" to "I own the business"

### The Business Development Process
1. **Innovation**: Not invention — finding a better way to do what you already do
2. **Quantification**: Measure everything. "If you can't measure it, you can't improve it"
3. **Orchestration**: Remove discretion from the process. Create predictable outcomes.

### Key Quote
"If your business depends on you, you don't own a business — you have a job. And it's the worst job in the world."

### Application to INKredible
**Current state**: Aviel is heavily in Technician mode — running jobs, quoting, managing machines. Brandon (COO) helps but knowledge is in their heads, not in systems.

**Target state**: 
- Document: quote-to-invoice process, job setup checklist, machine operation guides
- Delegate: Brandon handles day-to-day operations using documented systems
- Design: Aviel focuses on floor graphics sales pipeline, MIS development, business strategy
- Test: Can the shop run for 1 day without Aviel? 1 week? That's the E-Myth graduation.

---

## EOS / Traction (Gino Wickman, 2012)

### The Six Key Components

#### 1. Vision Component
**Tool**: Vision/Traction Organizer (V/TO) — answers 8 questions on 2 pages:

| Question | INKredible Application |
|----------|----------------------|
| Core Values (3-7) | Quality, Speed, Hustle, Integrity |
| Core Focus | Premium custom printing for events |
| 10-Year Target | $2M revenue + MIS product generating $500K ARR |
| Marketing Strategy | Target: Event planners, luxury events. Differentiator: Same-day turnaround + white ink capability |
| 3-Year Picture | $1M revenue, 5 employees, MIS v1 launched, debt-free |
| 1-Year Plan | $800K revenue, QuickBooks integrated, floor graphics pipeline active |
| Quarterly Rocks | 3-7 specific priorities for next 90 days |
| Issues List | What's blocking us? |

#### 2. People Component
**Right People = Core Values fit** (People Analyzer: +, +/-, -)
**Right Seats = GWC**:
- **G**et it: Understands the role intellectually and emotionally
- **W**ant it: Genuinely wants this specific job
- **C**apacity: Has the skills, time, and bandwidth

**INKredible Org Chart**:
- Visionary: Aviel (strategy, sales, innovation)
- Integrator: Brandon (operations, production, team)
- Admin: Diandra (phones, scheduling, invoicing)
- AI Operations: ChetGPT (research, analysis, automation)

#### 3. Data Component
**Weekly Scorecard** — 5-15 numbers that give you a pulse:

| Metric | Owner | Goal |
|--------|-------|------|
| Weekly Revenue | Aviel | $13,500 |
| Floor Graphic Leads | Aviel | 3/week |
| Jobs Completed | Brandon | 15/week |
| Quote-to-Close Rate | Aviel | 40% |
| Overdue Invoices | Diandra | <$5K |
| Machine Downtime Hours | Brandon | <2/week |

#### 4. Issues Component
**IDS Process**:
1. **Identify**: What's the REAL issue? (Not the symptom — the root cause)
2. **Discuss**: Open, honest conversation. No politics.
3. **Solve**: Decide on action steps. Assign owner. Set deadline.

**Rules**: 
- Don't skip to solving before identifying
- One issue at a time
- Once solved, it's off the list forever

#### 5. Process Component
**Core processes to document** (the vital few):
1. Sales/Quoting Process (lead → quote → close → payment)
2. Job Production Process (file prep → print → finishing → QC → delivery)
3. Machine Operation Procedures (setup, maintenance, troubleshooting)
4. Invoicing/Collections Process
5. Customer Communication Standards

**Documentation rule**: Capture the 20% of steps that produce 80% of results. Not a 50-page manual — a 1-2 page checklist per process.

#### 6. Traction Component
**Rocks** = 3-7 priorities per quarter. Not tasks — outcomes.

**Level 10 Meeting** (weekly, 90 min):
1. Segue (5 min): Good news, personal + professional
2. Scorecard review (5 min): Are numbers on track?
3. Rock review (5 min): On/off track?
4. Customer/Employee headlines (5 min)
5. To-do list review (5 min): Last week's commitments done?
6. IDS (60 min): Solve the top 3 issues
7. Conclude (5 min): Recap decisions, rate the meeting 1-10

---

## Hormozi Frameworks

### $100M Offers — The Value Equation
```
Value = (Dream Outcome × Perceived Likelihood) ÷ (Time Delay × Effort/Sacrifice)
```

**To increase value without changing price**:
- ↑ Dream Outcome: Paint a vivid picture of the result
- ↑ Perceived Likelihood: Show proof (portfolio, testimonials, guarantees)
- ↓ Time Delay: Faster turnaround, instant proofs, same-day pickup
- ↓ Effort: Done-for-you service, handle design + print + delivery

### The Grand Slam Offer
Components:
1. **Dream Outcome**: "The floor wrap that makes your event unforgettable"
2. **Remove Obstacles**: Design service, file prep, measurement guide
3. **Risk Reversal**: "Not happy? We reprint or refund"
4. **Urgency/Scarcity**: "3 event slots per week" (honest capacity limit)

### $100M Money Models — Three Stages
1. **Get Cash** (Attraction Offer): Low-margin or breakeven offer to acquire the customer
   - Example: First floor graphic at cost + free design mockup
2. **Get More Cash** (Ascension): Upsell complementary products
   - Example: Event signage package, photo backdrop, step-and-repeat
3. **Get the Most Cash** (Continuity): Recurring revenue
   - Example: Monthly retainer for event companies needing regular floor wraps

### Pricing Principles
- "Price is what you pay, value is what you get"
- Charge based on the value of the outcome, not the cost of materials
- A $5K floor wrap that generates $50K in event bookings is cheap
- Never compete on price — compete on value, speed, and reliability

---

## GROW Coaching Model

### Structure
| Phase | Question Type | Purpose |
|-------|--------------|---------|
| **Goal** | "What do you want?" | Clarify the desired outcome |
| **Reality** | "Where are you now?" | Honest assessment with data |
| **Options** | "What could you do?" | Brainstorm without judgment |
| **Will** | "What WILL you do?" | Commit to one specific action |

### GROW Questions Bank

**Goal Questions**:
- What specifically do you want to achieve?
- How will you know when you've achieved it?
- When do you want to achieve this by?
- Why is this important to you right now?

**Reality Questions**:
- Where are you now in relation to this goal?
- What have you tried so far?
- What's working? What isn't?
- What's the honest number? (revenue, clients, hours)

**Options Questions**:
- What could you do about this?
- What else? (keep pushing for more options)
- What would you advise a friend in this situation?
- What would happen if you did nothing?
- What's the smallest step you could take?

**Will Questions**:
- Which option will you pursue?
- When exactly will you do this?
- What might get in the way?
- How will I know you've done it?
- On a scale of 1-10, how committed are you? (If <8, what would make it an 8?)

---

## Sources

1. Gerber, M.E. (2001). *The E-Myth Revisited: Why Most Small Businesses Don't Work and What to Do About It*. Harper Business.
2. Wickman, G. (2012). *Traction: Get a Grip on Your Business*. BenBella Books.
3. Hormozi, A. (2021). *$100M Offers: How to Make Offers So Good People Feel Stupid Saying No*. Acquisition.com.
4. Hormozi, A. (2025). *$100M Money Models: How to Make Money*. Acquisition.com.
5. Hopkins, M. (2025). "The E-Myth, revisited again: why Michael Gerber was right — and why that's no longer enough." matthopkins.com.
6. Whitmore, J. (2017). *Coaching for Performance: The Principles and Practice of Coaching and Leadership* (5th ed.). Nicholas Brealey Publishing.
