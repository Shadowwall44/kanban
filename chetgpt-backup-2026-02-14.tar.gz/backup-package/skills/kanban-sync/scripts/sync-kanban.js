#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

const DEFAULT_FILE = '/home/inkredible/.openclaw/workspace/kanban/work.html';
const VALID_COLUMNS = new Set(['backlog', 'inProgress', 'chetActive', 'done']);

function usage() {
  console.log(`Kanban Sync — update CHET_TASKS in work.html

Usage:
  node sync-kanban.js --changes-file <path> [--file <work.html>] [--dry-run]
  node sync-kanban.js --changes-json '<json>' [--file <work.html>] [--dry-run]

Options:
  --file <path>         Path to work.html (default: ${DEFAULT_FILE})
  --changes-file <path> JSON file of task operations
  --changes-json <json> JSON string of task operations
  --dry-run             Validate + preview only (no write)
  --help                Show this message
`);
}

function parseArgs(argv) {
  const args = {
    file: DEFAULT_FILE,
    dryRun: false,
    changesFile: null,
    changesJson: null,
    help: false
  };

  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--file') args.file = argv[++i];
    else if (a === '--changes-file') args.changesFile = argv[++i];
    else if (a === '--changes-json') args.changesJson = argv[++i];
    else if (a === '--dry-run') args.dryRun = true;
    else if (a === '--help' || a === '-h') args.help = true;
    else throw new Error(`Unknown argument: ${a}`);
  }

  if (!args.help && !args.changesFile && !args.changesJson) {
    throw new Error('Provide one of: --changes-file or --changes-json');
  }

  if (args.changesFile && args.changesJson) {
    throw new Error('Use either --changes-file or --changes-json, not both');
  }

  return args;
}

function readJsonInput(args) {
  if (args.changesFile) {
    const file = path.resolve(args.changesFile);
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  }
  return JSON.parse(args.changesJson);
}

function normalizeOps(input) {
  if (Array.isArray(input)) {
    return input.map((item) => normalizeOp(item));
  }

  if (!input || typeof input !== 'object') {
    throw new Error('Changes must be a JSON array or object');
  }

  // Single operation object: { op, id, ... }
  if (typeof input.op === 'string' || typeof input.action === 'string') {
    return [normalizeOp(input)];
  }

  const ops = [];

  for (const task of asArray(input.upsert)) ops.push(normalizeOp({ op: 'upsert', ...task }));
  for (const task of asArray(input.add)) ops.push(normalizeOp({ op: 'add', ...task }));
  for (const task of asArray(input.update)) ops.push(normalizeOp({ op: 'update', ...task }));

  for (const move of asArray(input.move)) {
    if (typeof move === 'string') throw new Error('move entries must be objects with id + column');
    ops.push(normalizeOp({ op: 'move', ...move }));
  }

  for (const c of asArray(input.complete)) {
    if (typeof c === 'string') ops.push(normalizeOp({ op: 'complete', id: c }));
    else ops.push(normalizeOp({ op: 'complete', ...c }));
  }

  for (const r of asArray(input.remove)) {
    if (typeof r === 'string') ops.push(normalizeOp({ op: 'remove', id: r }));
    else ops.push(normalizeOp({ op: 'remove', ...r }));
  }

  if (ops.length === 0) {
    throw new Error('No operations found in changes input');
  }

  return ops;
}

function asArray(value) {
  if (!value) return [];
  return Array.isArray(value) ? value : [value];
}

function normalizeOp(op) {
  if (!op || typeof op !== 'object') throw new Error('Each operation must be an object');
  const action = (op.op || op.action || '').toLowerCase();
  if (!action) throw new Error('Operation missing op/action');

  const normalized = { ...op, op: action };

  if (action !== 'add' && action !== 'upsert' && action !== 'update' && action !== 'move' && action !== 'complete' && action !== 'remove') {
    throw new Error(`Unsupported operation: ${action}`);
  }

  if (!normalized.id || typeof normalized.id !== 'string') {
    throw new Error(`Operation '${action}' requires string 'id'`);
  }

  if (action === 'move' && !normalized.column) {
    throw new Error(`Operation 'move' requires 'column'`);
  }

  if ((action === 'add' || action === 'upsert') && !normalized.text) {
    throw new Error(`Operation '${action}' requires 'text'`);
  }

  if (normalized.column && !VALID_COLUMNS.has(normalized.column)) {
    throw new Error(`Invalid column '${normalized.column}'. Valid: backlog, inProgress, chetActive, done`);
  }

  return normalized;
}

function parseTasksFromHtml(html) {
  const startToken = 'const CHET_TASKS = [';
  const startIdx = html.indexOf(startToken);
  if (startIdx === -1) throw new Error('Could not locate CHET_TASKS start token');

  const arrayStart = startIdx + startToken.length;
  const arrayEnd = html.indexOf('\n        ];', arrayStart);
  if (arrayEnd === -1) throw new Error('Could not locate CHET_TASKS array end');

  const arrayBody = html.slice(arrayStart, arrayEnd);
  let tasks;
  try {
    tasks = Function(`"use strict"; return [${arrayBody}\n];`)();
  } catch (err) {
    throw new Error(`Failed to parse CHET_TASKS array: ${err.message}`);
  }

  if (!Array.isArray(tasks)) throw new Error('Parsed CHET_TASKS is not an array');

  return { tasks, startIdx, arrayEnd };
}

function sanitizeTask(task, nowIso) {
  const t = { ...task };
  if (!t.id || typeof t.id !== 'string') throw new Error('Task missing string id');
  if (!t.text || typeof t.text !== 'string') throw new Error(`Task '${t.id}' missing text`);

  t.column = t.column || 'backlog';
  if (!VALID_COLUMNS.has(t.column)) {
    throw new Error(`Task '${t.id}' has invalid column '${t.column}'`);
  }

  t.tag = t.tag || 'setup';
  t.source = 'chet';

  if (t.column === 'done' && !t.completedAt) {
    t.completedAt = nowIso;
  }

  if (t.column !== 'done' && t.completedAt === null) {
    delete t.completedAt;
  }

  return t;
}

function applyOps(originalTasks, ops) {
  const nowIso = new Date().toISOString();
  const tasks = originalTasks.map((t) => sanitizeTask(t, nowIso));

  for (const op of ops) {
    const idx = tasks.findIndex((t) => t.id === op.id);
    const exists = idx !== -1;

    if (op.op === 'remove') {
      if (exists) tasks.splice(idx, 1);
      continue;
    }

    if (op.op === 'move') {
      if (!exists) throw new Error(`move: task '${op.id}' not found`);
      tasks[idx].column = op.column;
      if (op.column === 'done' && !tasks[idx].completedAt) tasks[idx].completedAt = nowIso;
      continue;
    }

    if (op.op === 'complete') {
      if (!exists) throw new Error(`complete: task '${op.id}' not found`);
      tasks[idx].column = 'done';
      tasks[idx].completedAt = op.completedAt || nowIso;
      if (op.text) tasks[idx].text = op.text;
      if (op.tag) tasks[idx].tag = op.tag;
      if (op.priority) tasks[idx].priority = op.priority;
      continue;
    }

    if (op.op === 'update') {
      if (!exists) throw new Error(`update: task '${op.id}' not found`);
      const merged = { ...tasks[idx], ...stripOpFields(op) };
      tasks[idx] = sanitizeTask(merged, nowIso);
      continue;
    }

    if (op.op === 'add') {
      if (exists) throw new Error(`add: task '${op.id}' already exists`);
      const task = sanitizeTask({ ...stripOpFields(op) }, nowIso);
      tasks.push(task);
      continue;
    }

    if (op.op === 'upsert') {
      if (exists) {
        const merged = { ...tasks[idx], ...stripOpFields(op) };
        tasks[idx] = sanitizeTask(merged, nowIso);
      } else {
        const task = sanitizeTask({ ...stripOpFields(op) }, nowIso);
        tasks.push(task);
      }
      continue;
    }
  }

  // De-duplicate by id, keeping first occurrence in list order.
  const seen = new Set();
  const deduped = [];
  for (const task of tasks) {
    if (seen.has(task.id)) continue;
    seen.add(task.id);
    deduped.push(task);
  }

  return deduped;
}

function stripOpFields(op) {
  const copy = { ...op };
  delete copy.op;
  delete copy.action;
  return copy;
}

function escapeSingleQuoted(value) {
  return String(value)
    .replace(/\\/g, '\\\\')
    .replace(/'/g, "\\'")
    .replace(/\n/g, '\\n');
}

function renderTasks(tasks) {
  const preferredOrder = ['id', 'text', 'column', 'tag', 'source', 'priority', 'createdAt', 'completedAt'];

  return tasks
    .map((task) => {
      const t = { ...task };
      const orderedKeys = [...preferredOrder.filter((k) => k in t)];
      for (const k of Object.keys(t)) {
        if (!orderedKeys.includes(k)) orderedKeys.push(k);
      }

      const parts = [];
      for (const key of orderedKeys) {
        const value = t[key];
        if (value === undefined || value === null) continue;

        if (typeof value === 'string') {
          parts.push(`${key}: '${escapeSingleQuoted(value)}'`);
        } else if (typeof value === 'number' || typeof value === 'boolean') {
          parts.push(`${key}: ${value}`);
        } else {
          parts.push(`${key}: ${JSON.stringify(value)}`);
        }
      }

      return `            { ${parts.join(', ')} },`;
    })
    .join('\n');
}

function replaceTaskBlock(html, renderedTasks, timestamp) {
  const blockRegex = /const CHET_TASKS = \[[\s\S]*?\n        \];\n        \/\/ SYNC_TIMESTAMP:[^\n]*/m;
  const replacement = `const CHET_TASKS = [\n${renderedTasks}\n        ];\n        // SYNC_TIMESTAMP: ${timestamp}`;

  if (!blockRegex.test(html)) {
    throw new Error('Could not find CHET_TASKS block for replacement');
  }

  return html.replace(blockRegex, replacement);
}

function main() {
  try {
    const args = parseArgs(process.argv.slice(2));
    if (args.help) {
      usage();
      process.exit(0);
    }

    const htmlPath = path.resolve(args.file);
    const html = fs.readFileSync(htmlPath, 'utf8');
    const parsed = parseTasksFromHtml(html);
    const changesInput = readJsonInput(args);
    const ops = normalizeOps(changesInput);

    const updatedTasks = applyOps(parsed.tasks, ops);
    const timestamp = new Date().toISOString();
    const renderedTasks = renderTasks(updatedTasks);
    const nextHtml = replaceTaskBlock(html, renderedTasks, timestamp);

    if (args.dryRun) {
      console.log(`✅ Dry run successful`);
      console.log(`   File: ${htmlPath}`);
      console.log(`   Operations: ${ops.length}`);
      console.log(`   Task count: ${parsed.tasks.length} -> ${updatedTasks.length}`);
      console.log(`   New timestamp: ${timestamp}`);
      return;
    }

    fs.writeFileSync(htmlPath, nextHtml, 'utf8');
    console.log(`✅ Updated ${htmlPath}`);
    console.log(`   Operations: ${ops.length}`);
    console.log(`   Task count: ${parsed.tasks.length} -> ${updatedTasks.length}`);
    console.log(`   SYNC_TIMESTAMP: ${timestamp}`);
  } catch (err) {
    console.error(`❌ ${err.message}`);
    process.exit(1);
  }
}

main();
