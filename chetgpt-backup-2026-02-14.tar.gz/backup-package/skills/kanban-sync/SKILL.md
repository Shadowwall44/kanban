---
name: kanban-sync
description: "Update workspace/kanban/work.html by editing the CHET_TASKS array and SYNC_TIMESTAMP from structured task changes. Trigger on: kanban stale, task moved, task completed, backlog refresh, work board sync."
---

# Kanban Sync

## Purpose
Keep `workspace/kanban/work.html` aligned with real work state by applying structured task operations (upsert, move, complete, remove) to the `CHET_TASKS` source array.

## Primary Script
```bash
node /home/inkredible/.openclaw/skills/kanban-sync/scripts/sync-kanban.js --changes-file <path-to-json>
```

## Supported Operations
- `upsert` — create or update a task by `id`
- `add` — add a new task (fails if `id` exists)
- `update` — patch existing task fields
- `move` — change `column`
- `complete` — move to `done` and stamp `completedAt`
- `remove` — delete task by `id`

## Input Format
Provide either:
1. A JSON array of operations, or
2. A JSON object with grouped keys (`upsert`, `move`, `complete`, `remove`, `update`).

Example file:
```json
{
  "upsert": [
    {
      "id": "kanban_sync_skill",
      "text": "kanban-sync skill built",
      "column": "done",
      "tag": "infra",
      "priority": "high"
    }
  ],
  "move": [
    { "id": "tier2_skills", "column": "done" }
  ],
  "complete": [
    "kanban_realtime"
  ]
}
```

## Useful Commands
```bash
# Dry run (validate + preview changes only)
node /home/inkredible/.openclaw/skills/kanban-sync/scripts/sync-kanban.js \
  --changes-file /tmp/kanban-changes.json --dry-run

# Apply to default board path
node /home/inkredible/.openclaw/skills/kanban-sync/scripts/sync-kanban.js \
  --changes-file /tmp/kanban-changes.json

# Apply to custom file
node /home/inkredible/.openclaw/skills/kanban-sync/scripts/sync-kanban.js \
  --file /home/inkredible/.openclaw/workspace/kanban/work.html \
  --changes-json '[{"op":"move","id":"qb_api","column":"done"}]'
```

## Notes
- Automatically updates `// SYNC_TIMESTAMP: ...` in `work.html`
- Preserves task IDs so localStorage merge logic continues to work
- Default board path: `/home/inkredible/.openclaw/workspace/kanban/work.html`
