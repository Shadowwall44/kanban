# Last 30 Days — Research Methodology Reference

## Source Hierarchy & Weighting

### Tier 1: Community Sources (highest weight)
- **Reddit threads** — Upvotes and comments = real engagement. Multiple commenters agreeing = strong signal.
- **X/Twitter posts** — Likes, reposts, quote tweets. @handles with high engagement = influential voices.
- **Why highest**: These are real people sharing real opinions. No SEO incentive, no sponsorship bias (usually).

### Tier 2: Expert Content (medium weight)
- **Blog posts from practitioners** — People who actually use the tools/products
- **YouTube videos with community discussion** — Comments section adds context
- **GitHub repos/issues** — For technical topics, real usage data

### Tier 3: Press/SEO Content (lowest weight)
- **News articles** — Useful for facts/dates, less useful for sentiment
- **Listicles/roundups** — Often SEO-driven, may not reflect real usage
- **Press releases** — Company messaging, not user experience

## Search Query Construction

### Effective patterns:
- `site:reddit.com {topic}` — Forces Reddit-only results
- `site:x.com {topic} OR site:twitter.com {topic}` — Forces X results
- `{topic} 2026` — Year anchoring for recency
- `"{exact phrase}"` — When looking for specific product/tool mentions
- `{topic} vs {competitor}` — Comparison discussions are gold
- `{topic} review honest` — Filters for genuine reviews

### Avoid:
- `{topic} best` on its own — Gets SEO listicles
- Single-word topics — Too broad, get noise
- Adding "Reddit" without site: — Gets articles ABOUT Reddit, not from Reddit

## Freshness Parameters (Brave Search)
- `pd` — Past 24 hours (breaking news)
- `pw` — Past week (trending now)
- `pm` — Past month (default for this skill)
- `py` — Past year (broader context)
- `YYYY-MM-DDtoYYYY-MM-DD` — Custom date range

## Engagement Signals to Extract

### From Reddit (via web_fetch):
- Upvote count
- Comment count
- Subreddit name (niche subs = more relevant audience)
- Top comments (often more valuable than the post itself)
- Award count (if visible)

### From X (via web_fetch):
- Like count
- Repost count
- @handle (for attribution)
- Quote tweets (show conversation)
- Follower count of poster (authority signal)

### From Web:
- Publication name (authority)
- Date published (recency verification)
- Author credentials (if visible)

## Synthesis Best Practices

### Cross-Source Validation
- Pattern appears in Reddit + X + Web = **strong signal** (lead with this)
- Pattern appears in Reddit + X only = **community consensus** (reliable)
- Pattern appears in Web only = **may be press narrative** (verify against community)
- Pattern appears in one X post only = **single voice** (note, don't over-weight)

### Contradiction Handling
When sources disagree:
1. Note the disagreement explicitly
2. Weight community sources over press
3. Check if disagreement is temporal (old view vs new view)
4. Present both sides, let user decide

### Anti-Hallucination Checks
Before finalizing synthesis:
- [ ] Every cited @handle actually appeared in search results
- [ ] Every r/subreddit actually appeared in search results
- [ ] Engagement numbers come from actual fetched content, not estimated
- [ ] Quotes are from sources, not paraphrased training knowledge
- [ ] Date claims are verified from search results

## INKredible-Relevant Research Angles

When the user is researching topics related to the printing business:
- **Competitor tracking**: VistaPrint, Shutterfly, local Brooklyn shops
- **Equipment news**: HP, Roland, Konica Minolta releases
- **Industry trends**: Wide format growth, UV/latex developments
- **Event market**: Wedding/event industry trends affecting floor graphics demand
- **Pricing shifts**: Material costs, wholesale pricing changes
- **Technology**: AI in print, web-to-print platforms, MIS systems

These don't override the user's query — they provide useful context when the topic overlaps.
