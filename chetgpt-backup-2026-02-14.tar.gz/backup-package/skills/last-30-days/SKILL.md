---
name: last-30-days
description: >
  Research any topic from the last 30 days across Reddit, X, and the web.
  Synthesize what people are actually saying, recommending, and debating right now.
  Use when: user asks "what's happening with X", "what are people saying about X",
  "research X trends", "last 30 days of X", "what's new in X", "recent news about X",
  "what should I know about X right now", "current state of X".
  Do NOT use for: historical research (>30 days), general knowledge questions,
  how-to guides not tied to recent community discussion.
---

# Last 30 Days — Recent Topic Research

Research ANY topic across Reddit, X (Twitter), and the web. Surface what real people
are actually discussing, recommending, and debating **right now** — not 6 months ago.

## Critical Rules

1. **Ground ALL synthesis in actual search results.** Never substitute your training knowledge for what the research says.
2. **Cite real sources.** Use @handles from X, r/subreddit names, publication names. Never paste raw URLs.
3. **One research pass, then expert mode.** After initial research, answer follow-ups from what you learned — don't re-search unless the user asks about a different topic.
4. **Wait for the user after delivering results.** Don't auto-generate prompts or next steps unless asked.

---

## Step 1: Parse User Intent

Before searching, extract and display:

- **TOPIC**: What they want to learn about
- **QUERY_TYPE**: Detect from phrasing:
  - **RECOMMENDATIONS** — "best X", "top X", "what X should I use"
  - **NEWS** — "what's happening with X", "X news", "latest on X"
  - **HOW-TO** — "how to X", "X techniques", "X best practices"
  - **GENERAL** — anything else
- **FOCUS** (optional): Any specific angle ("for print shops", "in Brooklyn", "for ADHD")

Display to user before searching:

```
Researching {TOPIC} across Reddit, X, and the web (last 30 days).

Parsed intent:
- Topic: {TOPIC}
- Type: {QUERY_TYPE}
- Focus: {FOCUS or "broad"}

Starting research now — this takes 1-3 minutes.
```

---

## Step 2: Execute Research (3 Search Waves)

Use the `web_search` tool with `freshness: "pm"` (past month) for all searches.
Run **3 waves** of searches to get breadth and depth.

### Wave 1 — Reddit + X Discovery (2 searches)

```
Search 1: "site:reddit.com {TOPIC}" (freshness: pm)
Search 2: "site:x.com OR site:twitter.com {TOPIC}" (freshness: pm)
```

### Wave 2 — Web + Deep Drill (2-3 searches)

Based on QUERY_TYPE:

**RECOMMENDATIONS:**
```
Search 3: "best {TOPIC} 2026 recommendations"
Search 4: "top {TOPIC} list compared"
```

**NEWS:**
```
Search 3: "{TOPIC} news announcement 2026"
Search 4: "{TOPIC} update release"
```

**HOW-TO:**
```
Search 3: "{TOPIC} techniques tips 2026"
Search 4: "{TOPIC} best practices guide"
```

**GENERAL:**
```
Search 3: "{TOPIC} discussion 2026"
Search 4: "{TOPIC} community opinion"
```

### Wave 3 — Enrichment (1-2 fetches)

Use `web_fetch` on the **2-3 most promising URLs** from Wave 1-2 results to get
full content, engagement metrics, and specific quotes. Prioritize:
1. Reddit threads (have upvotes, comments, real discussion)
2. X posts with high engagement
3. Blog posts or articles with concrete data

**Max 5 total web_search calls. Max 3 web_fetch calls.** Stay lean.

---

## Step 3: Synthesize (Judge Phase)

After all searches complete, internally:

1. **Weight sources**: Reddit/X mentions > web articles (people > press)
2. **Find cross-source patterns**: What appears in 2+ sources = strongest signal
3. **Note contradictions**: Where sources disagree, call it out
4. **Extract top 3-5 actionable insights**: Specific, cited, useful
5. **Count engagement**: Upvotes, likes, comment counts when available

**Anti-pattern check**: Re-read your synthesis. Does it reflect the ACTUAL search results
or your pre-existing knowledge? If you catch yourself projecting, rewrite from the sources.

---

## Step 4: Deliver Results

### Format by QUERY_TYPE:

**RECOMMENDATIONS:**
```
🏆 Most Mentioned:

**{Item}** — {n}x mentions
What it does: {one line}
Sources: @handle, r/subreddit, Publication

**{Item}** — {n}x mentions
What it does: {one line}
Sources: @handle, r/subreddit

Notable mentions: {items with 1-2 mentions}
```

**NEWS / HOW-TO / GENERAL:**
```
What I learned:

**{Topic 1}** — {1-2 sentences about what people are saying, per @handle or r/sub}

**{Topic 2}** — {1-2 sentences, per @handle or r/sub}

**{Topic 3}** — {1-2 sentences, per @handle or r/sub}

KEY PATTERNS from the research:
1. {Pattern} — per @handle
2. {Pattern} — per r/sub
3. {Pattern} — per Publication
```

### Stats Box (always include):

```
---
✅ Research complete
├─ 🟠 Reddit: {N} threads found
├─ 🔵 X: {N} posts found
├─ 🌐 Web: {N} pages analyzed
└─ 🗣️ Top voices: @{handle}, r/{sub}
---
```

If a source returned 0 results, say so: "├─ 🟠 Reddit: 0 threads (no results this cycle)"

### Invitation (always include, tailored to QUERY_TYPE):

Include **2-3 specific follow-up suggestions** based on what you actually found.

**RECOMMENDATIONS:**
> Want me to go deeper? For example:
> - Compare {specific item A} vs {specific item B} from the results
> - Explain why {item C} is trending right now

**NEWS:**
> Some things you could ask:
> - {Specific follow-up about the biggest story}
> - {Question about implications}

**HOW-TO:**
> Want me to apply any of this? For example:
> - Walk through {technique from research} step by step
> - Adapt {approach} for {user's context if known}

**GENERAL:**
> Some things I can help with:
> - {Deeper dive into most discussed aspect}
> - {Practical application of what was learned}

---

## Step 5: Expert Mode (Follow-ups)

After delivering results, you are now an **expert on this topic**.

- **Questions about the topic** → Answer from your research. No new searches.
- **"Go deeper on X"** → Elaborate using research findings + do 1-2 targeted searches if needed.
- **"Apply this to my situation"** → Use research insights + user context (check memory/SKILL context).
- **New topic** → Start over from Step 1.

---

## Options

Users can modify behavior with flags in their request:

- **"last 7 days"** or **"past week"** → Use `freshness: "pw"` instead of `"pm"`
- **"past year"** → Use `freshness: "py"`
- **"quick"** → 2 searches only (1 Reddit, 1 web), skip enrichment
- **"deep"** → 5 searches + 5 web_fetch calls for maximum coverage

Default is balanced: 4-5 searches + 2-3 fetches.

---

## Examples

### Example 1: Industry Research
**User:** "What's been happening in the print industry last 30 days"
**Parse:** TOPIC=print industry, TYPE=NEWS, FOCUS=broad
**Searches:** site:reddit.com print industry, site:x.com print industry, print industry news 2026, wide format printing trends
**Output:** Synthesized news about equipment launches, market shifts, pricing trends with Reddit/X community reactions

### Example 2: Tool Research
**User:** "Best AI tools for small business right now"
**Parse:** TOPIC=AI tools for small business, TYPE=RECOMMENDATIONS, FOCUS=small business
**Searches:** site:reddit.com AI tools small business, site:x.com AI tools small business, best AI tools small business 2026 list
**Output:** Ranked list of most-mentioned tools with source citations and engagement data

### Example 3: Competitor Intelligence
**User:** "What are people saying about VistaPrint lately"
**Parse:** TOPIC=VistaPrint, TYPE=GENERAL, FOCUS=customer sentiment
**Searches:** site:reddit.com VistaPrint, site:x.com VistaPrint, VistaPrint reviews 2026
**Output:** Customer sentiment synthesis with specific complaints, praise, and trends

---

## Troubleshooting

### No Reddit/X results
- **Cause**: Topic too niche or brand name too specific
- **Fix**: Broaden search terms, try industry category instead of specific brand
- **Fallback**: Lean on web results, note limited social data in stats box

### Results seem outdated
- **Cause**: Freshness filter might not catch everything
- **Fix**: Add current year to search queries, verify dates in fetched content
- **Note**: Always verify dates when quoting sources

### Too many generic results
- **Cause**: Topic too broad
- **Fix**: Ask user to narrow focus, add context (industry, use case, platform)

### Rate limiting on searches
- **Cause**: Brave Search free tier limit (1 req/sec)
- **Fix**: Space searches slightly, prioritize highest-value queries first
