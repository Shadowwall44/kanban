# Mission Control — status.json Schema

## File Location
`/home/inkredible/.openclaw/workspace/inkredible-tools/public/status.json`

## Top-Level Fields

```json
{
  "lastUpdated": "ISO-8601 timestamp",
  "mission": "string — team mission statement",
  "agents": [...],
  "tasks": {...},
  "activity": [...],
  "usage": {...},
  "schedule": [...]
}
```

## Agents Array
Each agent object:
```json
{
  "id": "unique-id",
  "name": "Display Name",
  "role": "Job Title",
  "status": "active|working|idle|offline",
  "currentTask": "What they're doing right now",
  "model": "Model name or Human",
  "cost": "Pricing info",
  "skills": ["Skill 1", "Skill 2"]
}
```

Current agents: aviel, chet, codex, codex-mini, gemma

## Tasks Object
Three arrays:
```json
{
  "queued": [{"title": "...", "agent": "agent-id", "priority": "critical|high|medium|low"}],
  "inProgress": [{"title": "...", "agent": "agent-id", "priority": "..."}],
  "done": [{"title": "...", "agent": "agent-id", "completedAt": "ISO-8601"}]
}
```

## Activity Array
Most recent first, max ~15 entries:
```json
{"time": "HH:MM", "text": "What happened"}
```

## Usage Object
```json
{
  "sessionPct": number,
  "weeklyPct": number,
  "sessionResetsAt": "human-readable time",
  "weeklyResetsAt": "human-readable time",
  "model": "current model name",
  "exchangeCount": number
}
```

## Schedule Array
```json
{
  "name": "Cron job name",
  "schedule": "human-readable schedule",
  "model": "assigned model",
  "lastRun": "human-readable last run time",
  "status": "ok|timeout|error"
}
```
