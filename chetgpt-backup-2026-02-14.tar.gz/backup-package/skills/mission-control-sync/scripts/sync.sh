#!/usr/bin/env bash
# Mission Control Status Sync — Update status.json and deploy
# Usage: bash sync.sh '<json-patch>'
#
# Accepts a JSON string to merge into status.json, then deploys to gh-pages.
# Requires: jq

set -euo pipefail

STATUS_FILE="/home/inkredible/.openclaw/workspace/inkredible-tools/public/status.json"
DEPLOY_SCRIPT="/home/inkredible/.openclaw/skills/gh-pages-deploy/scripts/deploy.sh"
REPO_DIR="/home/inkredible/.openclaw/workspace/inkredible-tools"

PATCH="${1:-}"

if [[ -z "$PATCH" ]]; then
  echo "Usage: bash sync.sh '<json-patch>'"
  echo ""
  echo "Quick patches:"
  echo '  Activity only:  {"activity":"✅ Task completed"}'
  echo '  Agent status:   {"agent":"codex","status":"working","task":"Building X"}'
  echo ""
  exit 1
fi

# Ensure status.json exists
if [[ ! -f "$STATUS_FILE" ]]; then
  echo "❌ status.json not found at $STATUS_FILE"
  exit 1
fi

# Update timestamp
TIMESTAMP=$(date -Iseconds)
CURRENT=$(cat "$STATUS_FILE")

# Parse the patch type and apply
if echo "$PATCH" | jq -e '.activity' > /dev/null 2>&1; then
  # Add activity entry
  ACTIVITY_TEXT=$(echo "$PATCH" | jq -r '.activity')
  TIME=$(date +"%H:%M")
  CURRENT=$(echo "$CURRENT" | jq \
    --arg time "$TIME" \
    --arg text "$ACTIVITY_TEXT" \
    --arg ts "$TIMESTAMP" \
    '.activity = [{"time": $time, "text": $text}] + .activity[:14] | .lastUpdated = $ts')
fi

if echo "$PATCH" | jq -e '.agent' > /dev/null 2>&1; then
  # Update agent status
  AGENT_ID=$(echo "$PATCH" | jq -r '.agent')
  NEW_STATUS=$(echo "$PATCH" | jq -r '.status // empty')
  NEW_TASK=$(echo "$PATCH" | jq -r '.task // empty')

  if [[ -n "$NEW_STATUS" ]]; then
    CURRENT=$(echo "$CURRENT" | jq \
      --arg id "$AGENT_ID" \
      --arg status "$NEW_STATUS" \
      '(.agents[] | select(.id == $id or .name == $id)).status = $status')
  fi
  if [[ -n "$NEW_TASK" ]]; then
    CURRENT=$(echo "$CURRENT" | jq \
      --arg id "$AGENT_ID" \
      --arg task "$NEW_TASK" \
      '(.agents[] | select(.id == $id or .name == $id)).currentTask = $task')
  fi
  CURRENT=$(echo "$CURRENT" | jq --arg ts "$TIMESTAMP" '.lastUpdated = $ts')
fi

if echo "$PATCH" | jq -e '.usage' > /dev/null 2>&1; then
  # Update usage stats
  USAGE=$(echo "$PATCH" | jq '.usage')
  CURRENT=$(echo "$CURRENT" | jq \
    --argjson usage "$USAGE" \
    --arg ts "$TIMESTAMP" \
    '.usage = (.usage * $usage) | .lastUpdated = $ts')
fi

# Write back
echo "$CURRENT" | jq '.' > "$STATUS_FILE"
echo "✅ status.json updated at $TIMESTAMP"

# Deploy to gh-pages
if [[ -x "$DEPLOY_SCRIPT" ]]; then
  echo "📤 Deploying to gh-pages..."
  bash "$DEPLOY_SCRIPT" "$REPO_DIR" public gh-pages
else
  echo "⚠️  Deploy script not found. Run manually:"
  echo "   bash $DEPLOY_SCRIPT $REPO_DIR public gh-pages"
fi
