---
name: mission-control-sync
description: "Update Mission Control status.json and deploy to GitHub Pages. Use when spawning a sub-agent, completing a sub-agent task, updating agent status, changing task status, or syncing the activity feed. Trigger on: status update, mission control, agent status change, task complete, sub-agent spawn."
---

# Mission Control Status Sync

## When to Update
- **Every sub-agent spawn** — add to agents list, add activity entry
- **Every sub-agent completion** — update status, add activity entry
- **Task status changes** — move between queued/active/review/done
- **Cron job completions** — update schedule last-run status
- **Any significant operational event** — activity feed entry

## Quick Update

Run the update script with a JSON patch:

```bash
bash /home/inkredible/.openclaw/skills/mission-control-sync/scripts/sync.sh '<json-patch>'
```

**Examples:**
```bash
# Mark a sub-agent as active
bash scripts/sync.sh '{"agent":"codex-5.3","status":"working","task":"Building dashboard"}'

# Log an activity
bash scripts/sync.sh '{"activity":"✅ Dashboard deployed to gh-pages"}'

# Full status update (agents + activity + tasks)
bash scripts/sync.sh '{"agents":[...],"activity":"...","tasks":{...}}'
```

## Manual Update (without script)
1. Edit `workspace/inkredible-tools/public/status.json`
2. Deploy using gh-pages-deploy skill:
   ```bash
   bash /home/inkredible/.openclaw/skills/gh-pages-deploy/scripts/deploy.sh \
     /home/inkredible/.openclaw/workspace/inkredible-tools public gh-pages
   ```

## Status.json Schema
See `references/schema.md` for the full JSON structure with field descriptions.

## Important Notes
- Mission Control polls status.json every 15 seconds
- GitHub Pages CDN cache adds 1-5 min delay
- Status.json lives at: `workspace/inkredible-tools/public/status.json`
- Live URL: https://shadowwall44.github.io/inkredible-tools/mission-control.html
