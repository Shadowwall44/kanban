# Repository Map — INKredible GitHub Pages Deployments

## Active Repos

### kanban
- **URL**: https://github.com/Shadowwall44/kanban
- **Local**: `/home/inkredible/.openclaw/workspace/kanban`
- **Source dir**: `.` (root — static HTML files)
- **Branch**: `gh-pages`
- **Live URLs**:
  - https://shadowwall44.github.io/kanban/work.html
  - https://shadowwall44.github.io/kanban/personal.html
- **Files**: work.html, personal.html, usage.json, index.html
- **Notes**: Direct HTML files, no build step needed

### inkredible-tools
- **URL**: https://github.com/Shadowwall44/inkredible-tools
- **Local**: `/home/inkredible/.openclaw/workspace/inkredible-tools`
- **Source dir**: `out` (Next.js static export) or `public` (for status.json-only updates)
- **Branch**: `gh-pages`
- **Build command**: `npm run build` (outputs to `out/`)
- **Live URLs**:
  - Hub: https://shadowwall44.github.io/inkredible-tools/
  - Dashboard: https://shadowwall44.github.io/inkredible-tools/dashboard.html
  - Mission Control: https://shadowwall44.github.io/inkredible-tools/mission-control.html
  - Second Brain: https://shadowwall44.github.io/inkredible-tools/second-brain/
- **Notes**: 
  - Next.js 16 requires `global-error.tsx` for static export
  - `public/status.json` polled by Mission Control every 15s
  - For status.json-only updates, deploy from `public/` to avoid full rebuild

## GitHub Credentials
- Username: Shadowwall44
- PAT: stored in `~/.git-credentials`
- PAT scopes: does NOT have `workflow` scope (can't modify GitHub Actions)
- Auth method: HTTPS with credential helper

## Common Deploy Commands

```bash
SKILL_DIR="/home/inkredible/.openclaw/skills/gh-pages-deploy/scripts"

# Full kanban deploy
bash $SKILL_DIR/deploy.sh ~/.openclaw/workspace/kanban . gh-pages

# Full inkredible-tools deploy (after npm run build)
bash $SKILL_DIR/deploy.sh ~/.openclaw/workspace/inkredible-tools out gh-pages

# Quick status.json update only
bash $SKILL_DIR/deploy.sh ~/.openclaw/workspace/inkredible-tools public gh-pages
```
