---
name: gh-pages-deploy
description: "Deploy static files to GitHub Pages via gh-pages branch. Use when deploying any web app, dashboard, tool, or static site to GitHub Pages. Handles git identity, cache-busting, clean branch creation, and node_modules exclusion. Trigger on: deploy, publish, push to gh-pages, update live site, ship to GitHub Pages."
---

# GitHub Pages Deployment

## Critical Rules
1. NEVER include `node_modules/` — GitHub blocks files >100MB
2. ALWAYS use temp-directory approach — never push from working dir
3. ALWAYS set git identity before committing
4. ALWAYS add cache-busting meta tags (target device caches aggressively)

## Quick Deploy

Run the deploy script:

```bash
bash /home/inkredible/.openclaw/skills/gh-pages-deploy/scripts/deploy.sh <repo-dir> <source-dir> [branch]
```

**Arguments:**
- `repo-dir`: Path to the repo's `.git` parent (e.g., `/home/inkredible/.openclaw/workspace/kanban`)
- `source-dir`: Directory containing built files to deploy (e.g., `out`, `public`, `.` for root)
- `branch`: Target branch (default: `gh-pages`)

**Examples:**
```bash
# Deploy kanban boards
bash /home/inkredible/.openclaw/skills/gh-pages-deploy/scripts/deploy.sh \
  /home/inkredible/.openclaw/workspace/kanban . gh-pages

# Deploy inkredible-tools (Next.js static export)
bash /home/inkredible/.openclaw/skills/gh-pages-deploy/scripts/deploy.sh \
  /home/inkredible/.openclaw/workspace/inkredible-tools out gh-pages

# Deploy just status.json update
bash /home/inkredible/.openclaw/skills/gh-pages-deploy/scripts/deploy.sh \
  /home/inkredible/.openclaw/workspace/inkredible-tools public gh-pages
```

## What the Script Does
1. Creates a clean temp directory
2. Copies ONLY the source files (excludes node_modules, .git, .next)
3. Injects cache-busting meta tags into all HTML files
4. Inits fresh git repo in temp dir
5. Sets git identity (ChetGPT / chetgpt@inkredible.com)
6. Commits and force-pushes to gh-pages branch
7. Cleans up temp directory

## Our Repositories

See `references/repo-map.md` for all repo URLs, source directories, and deployment notes.

## Troubleshooting

| Problem | Cause | Fix |
|---------|-------|-----|
| Push rejected (file too large) | node_modules included | Script excludes it — if still happening, check source-dir |
| "Please tell me who you are" | Missing git identity | Script sets it automatically |
| Changes not visible on site | GitHub CDN cache (1-5 min) | Wait, or append `?v=timestamp` to URL |
| Auth failure on push | PAT missing or expired | Check `~/.git-credentials` has valid token |
| gh-pages branch doesn't exist | First deploy | Script creates orphan branch automatically |
