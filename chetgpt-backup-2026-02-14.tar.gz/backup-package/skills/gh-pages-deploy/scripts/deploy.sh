#!/usr/bin/env bash
# GitHub Pages Deploy Script — INKredible Operations
# Usage: bash deploy.sh <repo-dir> <source-dir> [branch]
#
# Deploys static files to gh-pages using clean temp-directory approach.
# Handles: git identity, cache-busting, node_modules exclusion, orphan branch.

set -euo pipefail

REPO_DIR="${1:?Usage: deploy.sh <repo-dir> <source-dir> [branch]}"
SOURCE_DIR="${2:?Usage: deploy.sh <repo-dir> <source-dir> [branch]}"
BRANCH="${3:-gh-pages}"

# Resolve paths
REPO_DIR="$(cd "$REPO_DIR" && pwd)"
if [[ "$SOURCE_DIR" == "." ]]; then
  SOURCE_FULL="$REPO_DIR"
else
  SOURCE_FULL="$REPO_DIR/$SOURCE_DIR"
fi

# Validate
if [[ ! -d "$REPO_DIR/.git" ]]; then
  echo "❌ Error: $REPO_DIR is not a git repository"
  exit 1
fi

if [[ ! -d "$SOURCE_FULL" ]]; then
  echo "❌ Error: Source directory $SOURCE_FULL does not exist"
  exit 1
fi

# Get remote URL
REMOTE_URL=$(cd "$REPO_DIR" && git remote get-url origin 2>/dev/null)
if [[ -z "$REMOTE_URL" ]]; then
  echo "❌ Error: No git remote 'origin' found"
  exit 1
fi

echo "🚀 Deploying to $BRANCH"
echo "   Repo: $REPO_DIR"
echo "   Source: $SOURCE_FULL"
echo "   Remote: $REMOTE_URL"

# Create clean temp directory
TEMP_DIR=$(mktemp -d)
trap 'rm -rf "$TEMP_DIR"' EXIT

echo "📁 Copying files to temp directory..."

# Copy files, excluding build artifacts and dev files
rsync -a \
  --exclude='node_modules' \
  --exclude='.git' \
  --exclude='.next' \
  --exclude='.env' \
  --exclude='.env.local' \
  --exclude='*.log' \
  --exclude='.DS_Store' \
  --exclude='__pycache__' \
  --exclude='.secrets' \
  "$SOURCE_FULL/" "$TEMP_DIR/"

# Count files
FILE_COUNT=$(find "$TEMP_DIR" -type f | wc -l)
echo "   Copied $FILE_COUNT files"

# Check for accidentally large files
LARGE_FILES=$(find "$TEMP_DIR" -type f -size +50M 2>/dev/null || true)
if [[ -n "$LARGE_FILES" ]]; then
  echo "⚠️  Warning: Large files detected (>50MB):"
  echo "$LARGE_FILES"
  echo "   GitHub may reject these. Consider excluding them."
fi

# Inject cache-busting meta tags into HTML files
echo "🔄 Adding cache-busting meta tags..."
CACHE_META='<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"><meta http-equiv="Pragma" content="no-cache"><meta http-equiv="Expires" content="0">'

find "$TEMP_DIR" -name "*.html" -type f | while read -r html_file; do
  if ! grep -q 'no-cache, no-store' "$html_file" 2>/dev/null; then
    # Insert after <head> tag
    sed -i "s|<head>|<head>\n${CACHE_META}|" "$html_file" 2>/dev/null || true
  fi
done

# Init git and deploy
cd "$TEMP_DIR"
git init -q
git config user.email "chetgpt@inkredible.com"
git config user.name "ChetGPT"
git checkout -q --orphan "$BRANCH"
git add -A

TIMESTAMP=$(date -u +"%Y-%m-%d %H:%M:%S UTC")
git commit -q -m "Deploy: $TIMESTAMP ($FILE_COUNT files)"

echo "📤 Pushing to $BRANCH..."
git push -f "$REMOTE_URL" "$BRANCH:$BRANCH" 2>&1 | tail -3

echo ""
echo "✅ Deployed $FILE_COUNT files to $BRANCH"
echo "🌐 Live in 1-5 minutes (GitHub CDN cache)"
